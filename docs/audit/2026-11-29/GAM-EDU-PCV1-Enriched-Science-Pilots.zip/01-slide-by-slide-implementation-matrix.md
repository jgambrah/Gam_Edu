# PCV-1 Slide-by-Slide Implementation Matrix

## Pilot A — Cambridge AS & A-Level Chemistry: Hydrocarbons (`cambridge-as-a-level-chemistry-hydrocarbons`)
| Candidate Slide | Status | Implemented Engine(s) & Activity ID(s) | Justification / Notes |
|---|---|---|---|
| `a02` | **Implemented** | `graph-slider 1.0.0` (`hc-a02-homologous-series`) | Integer $n \in [1,10]$, live $2n+2$ & $14n+2$ readouts, prediction, octane challenge |
| `a06` | **Implemented** | `atom-bond-builder 1.2.0` (`hc-a06-methane-vsepr`) | Methane CH₄ tetrahedral VSEPR (109.5°, nonpolar) with 2D-vs-3D model note |
| `a07` | **Deferred (Engine Limitation)** | — | `diagram-hotspots` requires approved WebP/PNG rather than inline SVG; unrestricted pentane skeletal builder not supported |
| `b01` | **Implemented** | `graph-slider 1.0.0` (`hc-b01-boiling-points`) | Discrete verified experimental normal boiling points C₁–C₈ (integer step 1), room-temp reference line, prediction |
| `b02` | **Deferred (Engine Limitation)** | — | Discrete categorical branching comparison best served by `sort-classify` or categorical bar chart (not yet production-activated) |
| `b04` | **Implemented** | `process-stepper 1.0.0` (`hc-b04-fractional-distillation`) | Linear 4-stage column temperature gradient; explicitly states fractions are mixtures |
| `c01` | **Implemented** | `equation-balancer 1.1.0` (`hc-c01-methane-combustion`, `hc-c01-propane-combustion`) | Guided methane + independent propane complete combustion, simplest whole-number ratio |
| `c02` | **Implemented** | `equation-balancer 1.1.0` (`hc-c02-incomplete-combustion`) | Propane → C(s) + H₂O with explicit model note on mixed CO/C/CO₂ products |
| `c04` | **Implemented** | `equation-balancer 1.1.0` (`hc-c04-catalytic-converter`) | `2CO + 2NO -> 2CO2 + N2`; explicitly clarifies CO₂ is produced, not removed |
| `d02` | **Implemented** | `process-stepper 1.0.0` (`hc-d02-frs-mechanism`) | UV initiation + Propagation 1 & 2 with radical dots `•` and sequence challenge |
| `d03` | **Implemented** | `process-stepper 1.0.0` (`hc-d03-termination`) | All 3 valid radical-radical termination pathways + trace ethane evidence prediction |
| `e03` | **Implemented** | `equation-balancer 1.1.0` (`hc-e03-cracking-balance`) | `C12H26 -> C6H14 + 3C2H4` with constrained products note |
| `f01` | **Implemented** | `atom-bond-builder 1.2.0` (`hc-f01-ethene-geometry`) | Trigonal planar 120° around sp² carbon in ethene; distinguishes σ vs π bonds |
| `f03` | **Implemented** | `process-stepper 1.0.0` (`hc-f03-bromine-water-test`) | Virtual bromine-water unsaturation test (explicitly labelled virtual, non-home-lab) |
| `f04` | **Deferred (Engine Limitation)** | — | Needs inline-SVG hotspots or dedicated stereoisomer renderer |
| `g01` | **Not Educationally Necessary** | — | Individual pathways already well covered across `g02`–`g04` and `h02` without branching stepper |
| `g05` | **Implemented** | `math-evaluator 1.1.0` (`hc-g05-atom-economy`) | 100% atom economy calculation + prediction distinguishing atom economy vs % yield |
| `h01` | **Not Educationally Necessary** | — | Existing SVG + narration clearly contrasts homolytic vs heterolytic; reinforced in `d02` & `h02` |
| `h02` | **Implemented** | `process-stepper 1.0.0` (`hc-h02-electrophilic-addition-hbr`) | Complete 6-stage HBr addition preserving atom counts, charge, valency + sequence challenge |
| `h04` / `h07` | **Not Educationally Necessary** | — | Existing coursebook simplified vs bromonium-ion enrichment slides are clear; unrestricted curly-arrow drawing deferred |
| `i03` | **Implemented** | `process-stepper 1.0.0` (`hc-i03-propene-carbocations`) | Secondary vs primary carbocation comparison under ordinary electrophilic conditions |
| `j02` / `k01` / `k03` | **Deferred (Engine Limitation)** | — | Unrestricted structural/polymer drawing and inline-SVG hotspot identification not yet supported |
| `p01` | **Implemented** | `equation-balancer 1.1.0` + 2× `math-evaluator 1.1.0` (`hc-p01-*`) | Balance propane combustion, then compute 100 cm³ O₂ and 60 cm³ CO₂ |
| `p03` | **Implemented** | 3× `math-evaluator 1.1.0` (`hc-p03-*`) | Sequential 3 s.f. checks: 0.500 mol ethene, 23.0 g theoretical ethanol, 70.0% yield |
| `p05` / `p07` | **Deferred (Engine Limitation)** | — | Unrestricted skeletal structure input & freehand multi-valid radical equation input retained as paper self-marking |
| `p09` | **Implemented** | 4× `math-evaluator 1.1.0` (`hc-p09-*`) | Sequential 3 s.f. checks: 0.200 mol, 37.6 g, 90.0%, 28.2 g at 75.0% yield |

## Pilot B — NaCCA Basic 8 Science: Atoms and the Periodic Table (`b8-sci-t1-atoms-and-the-periodic-table`)
| Candidate Slide | Status | Implemented Engine(s) & Activity ID(s) | Justification / Notes |
|---|---|---|---|
| `s03` / `s05` | **Not Educationally Necessary** | — | Native checkpoints + `s04`/`s06` interactive atom builders directly cover particles & charges |
| `s04` | **Implemented** | `atom-bond-builder 1.2.0` (`b8-s04-carbon-atom`) | Build neutral Carbon-12 (6p, 6n, 6e⁻) with energy-level shell model note |
| `s06` | **Implemented** | `atom-bond-builder 1.2.0` (`b8-s06-neutral-lithium`) | Adjust electrons on Lithium-7 to reach charge 0 + neutrality prediction |
| `s07` | **Implemented** | `atom-bond-builder 1.2.0` (`b8-s07-proton-identity`) | Transform Carbon-12 to Nitrogen-14 to demonstrate proton number defines element |
| `s09` | **Implemented** | `atom-bond-builder 1.2.0` (`b8-s09-isotope-c14`) | Build Carbon-14 isotope; distinguishes mass number from relative atomic mass |
| `s10` | **Implemented** | `math-evaluator 1.1.0` (`b8-s10-fluorine-neutrons`) | Independent numeric particle count: Fluorine-19 neutrons = 10 |
| `s12` | **Implemented** | 2× `math-evaluator 1.1.0` (`b8-s12-*`) | Brand-new non-narrated examples: Magnesium-24 neutrons (12) & neutral Phosphorus-31 electrons (15) |
| `s14` / `s16` / `s17` | **Deferred (Engine Limitation)** | — | `diagram-hotspots` requires WebP/PNG image asset (not inline SVG); periodic table slides use inline SVGs |
| `s18` | **Implemented** | `atom-bond-builder 1.2.0` (`b8-s18-neon-shells`) | Guided shell filling for Neon (2, 8) with `lockNucleus: true` |
| `s20` | **Implemented** | `atom-bond-builder 1.2.0` (`b8-s20-sodium-shells`) | Build Sodium (2, 8, 1) highlighting 1 valence electron |
| `s21` | **Implemented** | 2× `atom-bond-builder 1.2.0` (`b8-s21-*`) | Independent first-20-elements practice: Chlorine (2, 8, 7) and Calcium (2, 8, 8, 2) |
| `s22` | **Implemented** | `atom-bond-builder 1.2.0` (`b8-s22-fluoride-ion`) | Form Fluoride ion F⁻ (9p, 10e⁻, charge −1) with prediction |
| `s23` | **Implemented** | 2× `atom-bond-builder 1.2.0` (`b8-s23-*`) | Guided NaCl (with 3D lattice note) + independent Magnesium Oxide (MgO) |
| `s24` | **Not Educationally Necessary** | — | Concept introduced immediately before hands-on covalent construction on `s25` |
| `s25` | **Implemented** | 2× `atom-bond-builder 1.2.0` (`b8-s25-*`) | Covalent construction of H₂O (single bonds) and CO₂ (double bonds) |
| `s26` | **Implemented** | `math-evaluator 1.1.0` (`b8-s26-argon-neutrons`) | Practical mastery particle count (Argon-40 = 22n); explicitly notes practice is not recorded in teacher gradebook |
