# PCV-1 Original vs Enriched Structural Diff & Media Preservation Report

Automated verification in `scripts/lessons/enrich-pcv1-pilots.ts` stripped `slide.interactive` from each enriched lesson and compared `JSON.stringify(stripped) === JSON.stringify(original)`:
- **Pilot A (`cambridge-as-a-level-chemistry-hydrocarbons`)**: **BYTE-FOR-BYTE IDENTICAL** on all 71 slides' `id`, `order`, `sectionId`, `title`, `purpose`, `onScreenText`, `visual`, `narration`, `audioUrl`, `audioHash`, `cues`, `checkpoints`, `masteryCheck`, `teacherNote`, `summary`, `extensionActivity`, `coverageMatrix`. Only addition: `26` `slide.interactive` objects across `18` slides.
- **Pilot B (`b8-sci-t1-atoms-and-the-periodic-table`)**: **BYTE-FOR-BYTE IDENTICAL** on all 26 slides' non-interactive fields. Only addition: `17` `slide.interactive` objects across `13` slides.
- **Zero paid AI/TTS credits consumed**: Published with `--skip-media`, reusing 100% of existing hashed MP3s and WebPs.
