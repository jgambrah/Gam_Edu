# PCV-1 Capability-Gap Register (Observed During Real Curriculum Authoring)

1. **`diagram-hotspots` inline-SVG reuse**: Currently requires an approved WebP/PNG image URL (`visual-region.ts`), preventing direct hotspot layering over existing sanitised inline slide SVGs (deferred `a07`, `f04`, `s14`, `s16`, `s17`).
2. **`sort-classify 1.0.0` production activation**: High-value classification & matching activities (e.g. alkane branching comparison `b02`, periodic table groups/periods) are implemented in dev but `productionVersion: null`.
3. **Unrestricted organic skeletal / stereoisomer / curly-arrow drawing**: Deferred for future chemistry tooling (`a07`, `f04`, `h04`, `k03`, `p05`, `p07`).
4. **Live browser screenshots**: Local Playwright Chromium headless shell binary is not installed on this workstation; browser visual verification on 360px/tablet/desktop/dark-theme remains open for owner live testing & CI/audit Chromium run.
5. **Interactive completion persistence**: `slide.interactive` remains ephemeral practice exploration (0 Firestore writes); teacher gradebook persistence is a future architectural stage.
