# PCV-1 Controlled Publication, Owner Testing URLs & Exact Rollback Procedure

## 1. Owner Testing URLs (Authenticated Staff Accounts: Director / Administrator / Teacher)
- **Pilot A — Cambridge AS & A-Level Chemistry (Hydrocarbons)**:
  - Staff Dashboard URL: `/dashboard/narrated-lessons/cambridge-as-a-level-chemistry-hydrocarbons`
  - Direct Player URL: `/narrated-lessons/cambridge-as-a-level-chemistry-hydrocarbons`
- **Pilot B — NaCCA Basic 8 Science (Atoms and the Periodic Table)**:
  - Staff Dashboard URL: `/dashboard/narrated-lessons/b8-sci-t1-atoms-and-the-periodic-table`
  - Direct Player URL: `/narrated-lessons/b8-sci-t1-atoms-and-the-periodic-table`

*Production Compatibility*: **100% of added activities (43/43)** passed `assertValidLessonInteractives(lesson, { allowDevOnlyEngines: false })` using ONLY currently LIVE production engines (`graph-slider 1.0.0`, `process-stepper 1.0.0`, `math-evaluator 1.1.0`, `equation-balancer 1.1.0`, `atom-bond-builder 1.2.0`). No new engine activation was needed.

## 2. Publication Ledger (Catalogue `v96` → `v100`, 2026-11-28)
| Lesson ID | Original Immutable Package (Preserved) | Current Live Enriched Package (`1.2.0` LIVE) | Next Playground Package (Ready for `1.8.0` Activation) |
|---|---|---|---|
| `cambridge-as-a-level-chemistry-hydrocarbons` | `packages/cambridge-as-a-level-chemistry-hydrocarbons.739c1252e89e.json` (`739c1252e89e`) | `packages/cambridge-as-a-level-chemistry-hydrocarbons.3e38184d5581.json` (`3e38184d5581`, `v99`, fixed dimensionless `Mr` + `Molar mass g mol⁻¹`) | N/A |
| `b8-sci-t1-atoms-and-the-periodic-table` | `packages/b8-sci-t1-atoms-and-the-periodic-table.15080192a16a.json` (`15080192a16a`) | `packages/b8-sci-t1-atoms-and-the-periodic-table.379856075c2c.json` (`379856075c2c`, `v100`, removed `s21` premature answer disclosure) | `lessons/b8-sci-t1-atoms-and-the-periodic-table.playground-v1.8.0-ready.json` (held until manual Vercel promotion + `1.8.0` activation) |

- All 47 other catalogue entries remain untouched (`49` total entries in `catalogue.json` `v98`).
- **Cache Behaviour**: `catalogue.json` uses `Cache-Control: public, max-age=60, stale-while-revalidate=300`. Rollback propagation completes within 60–360 seconds after updating `catalogue.json` (not described as instantaneous).

## 3. Exact Rollback Procedure
To roll back either lesson individually (preserving all other 48 entries):
1. Download current `story-spark-preview/narrated-lessons/catalogue.json`.
2. Replace the target lesson entry's `packagePath` and `packageHash` with the original immutable path/hash from the table above (e.g. `739c1252e89e` or `15080192a16a`) and increment `catalogueVersion`.
3. Upload updated `catalogue.json` with `ifGenerationMatch` lock and `Cache-Control: public, max-age=60, stale-while-revalidate=300`.
4. To roll back BOTH lessons simultaneously, restore `backups/catalogue.2026-11-28T09-57-12-709Z.json` with an incremented `catalogueVersion`.
