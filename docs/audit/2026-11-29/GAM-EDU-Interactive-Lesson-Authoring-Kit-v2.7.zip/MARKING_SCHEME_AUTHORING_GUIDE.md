# GAM EDU — Mathematical Marking-Scheme Authoring Guide (`math-evaluator` v1.1.0)

- Declarative M/A/B/ECF mark categories with `requiresMarkIds`, strategy groups, anti-double-counting, 10,000-case oracle (9,248 structurally unique, 0 discrepancies), and focused hand-verified fixtures in `tests/math-workspace.test.tsx`.
