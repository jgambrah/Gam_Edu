# GAM EDU — Interactive Lesson Authoring Kit v2.7 (Single-File Reference)

**Date:** 2026-11-28  
**Milestone:** Step 5G — Bounded Dynamic Physics Workbench (`construction-lab: physics-workbench 1.10.0`, production-inactive pending review)

## 1. Active Engine Registry (`schemas/interactive-schema.ts`)

| Engine | `engineVersion` | `productionVersion` | Scoped `productionCapabilities` |
|---|---|---|---|
| `code-playground`, `rule-explorer`, `graph-slider`, `process-stepper`, `diagram-hotspots` | `1.0.0` | `1.0.0` | — |
| `math-evaluator` | `1.1.0` | `1.1.0` | — |
| `construction-lab` | `1.10.0` | **`1.3.0`** | `atom-bond-builder: "1.9.0"`, `equation-balancer: "1.9.0"` (**LIVE**). Measurement `1.4.0`, Data Stats `1.5.0`, Geometry 5E `1.6.0`, Number Manipulative `1.7.0`, and **Physics Workbench `1.10.0`** remain **production-inactive**. |
| `sort-classify` | `1.0.0` | `null` | Not activated |

## 2. Step 5G Physics Workbench (`labKind: "physics-workbench"`, `minEngineVersion: "1.10.0"`)
- **Six bounded modes:** `reflection`, `refraction` (Snell + critical angle + TIR + normal/equal-n boundaries), `thin-lens` (converging/diverging, real-is-positive, explicit $u=f$ infinity handling), `spherical-mirror` (concave/convex), `moments` (adjustable pivot, 1–6 forces, rotational vs complete static equilibrium with pivot reaction), and `simple-machines` (levers, 1–6 strand pulleys, inclined planes; ideal vs non-ideal efficiency $\le 100\%$).
- Supports shared selectable `examples` banks (1–8 items), `interactionMode` (`free-exploration` | `guided` | `independent-challenge`), `Explore Further` isolated sandbox, and `isAssessment: true` protection.
- Pilot fixture: `pilots/step5g-physics-workbench-pilot.json` (10 slides covering all 6 domains).
