import React from 'react';
import fs from 'node:fs';
import path from 'node:path';
import { describe, expect, it } from 'vitest';
import { fireEvent, render, screen } from '@testing-library/react';
import {
  computeCircleTheoremGeometry,
  computeCuboidMetrics,
  evaluateCombinedLocus,
  evaluateCubeNet,
  evaluateLocusConstraint,
  evaluateProtractorAngle,
  evaluateTriangleRHS,
  isValidTriangleRHS,
  pointToSegmentDistance,
  type GridCell,
} from './geometry-engine';
import {
  SUPPORTED_INTERACTIVE_ENGINES,
  assertValidLessonInteractives,
  type GeometryCircleTheoremConfig,
  type GeometryCompassConfig,
  type GeometryCubeNetConfig,
  type GeometryLociRegionConfig,
  type GeometryTransformationConfig,
} from '@/lib/narrated-lessons/interactive-schema';
import { GeometryConstructorLab } from '@/components/narrated-lessons/construction/GeometryConstructorLab';

// All 11 distinct canonical cube nets (independent geometric catalogue)
const ALL_11_VALID_CUBE_NETS: Array<{ name: string; cells: GridCell[] }> = [
  { name: '1-4-1 Cross (a)', cells: [{ r: 0, c: 1 }, { r: 1, c: 0 }, { r: 1, c: 1 }, { r: 1, c: 2 }, { r: 1, c: 3 }, { r: 2, c: 1 }] },
  { name: '1-4-1 (b)', cells: [{ r: 0, c: 0 }, { r: 1, c: 0 }, { r: 1, c: 1 }, { r: 1, c: 2 }, { r: 1, c: 3 }, { r: 2, c: 0 }] },
  { name: '1-4-1 (c)', cells: [{ r: 0, c: 0 }, { r: 1, c: 0 }, { r: 1, c: 1 }, { r: 1, c: 2 }, { r: 1, c: 3 }, { r: 2, c: 1 }] },
  { name: '1-4-1 (d)', cells: [{ r: 0, c: 0 }, { r: 1, c: 0 }, { r: 1, c: 1 }, { r: 1, c: 2 }, { r: 1, c: 3 }, { r: 2, c: 2 }] },
  { name: '1-4-1 (e)', cells: [{ r: 0, c: 0 }, { r: 1, c: 0 }, { r: 1, c: 1 }, { r: 1, c: 2 }, { r: 1, c: 3 }, { r: 2, c: 3 }] },
  { name: '1-4-1 (f)', cells: [{ r: 0, c: 1 }, { r: 1, c: 0 }, { r: 1, c: 1 }, { r: 1, c: 2 }, { r: 1, c: 3 }, { r: 2, c: 2 }] },
  { name: '2-3-1 (a)', cells: [{ r: 0, c: 0 }, { r: 0, c: 1 }, { r: 1, c: 1 }, { r: 1, c: 2 }, { r: 1, c: 3 }, { r: 2, c: 1 }] },
  { name: '2-3-1 (b)', cells: [{ r: 0, c: 0 }, { r: 0, c: 1 }, { r: 1, c: 1 }, { r: 1, c: 2 }, { r: 1, c: 3 }, { r: 2, c: 2 }] },
  { name: '2-3-1 (c)', cells: [{ r: 0, c: 0 }, { r: 0, c: 1 }, { r: 1, c: 1 }, { r: 1, c: 2 }, { r: 1, c: 3 }, { r: 2, c: 3 }] },
  { name: '2-2-2 Stairs', cells: [{ r: 0, c: 0 }, { r: 0, c: 1 }, { r: 1, c: 1 }, { r: 1, c: 2 }, { r: 2, c: 2 }, { r: 2, c: 3 }] },
  { name: '3-3 Offset', cells: [{ r: 0, c: 0 }, { r: 0, c: 1 }, { r: 0, c: 2 }, { r: 1, c: 2 }, { r: 1, c: 3 }, { r: 1, c: 4 }] },
];

describe('Step 5E — Remaining Geometry Capabilities (construction-lab: geometry-constructor 1.6.0)', () => {
  it('keeps construction-lab engineVersion >= 1.6.0 while holding productionVersion at 1.3.0', () => {
    expect(SUPPORTED_INTERACTIVE_ENGINES['construction-lab'].engineVersion >= '1.6.0').toBe(true);
    expect(SUPPORTED_INTERACTIVE_ENGINES['construction-lab'].productionVersion).toBe('1.3.0');
  });

  describe('1. RHS Triangle Construction (Including Reflected Solutions) & Virtual Protractor Angle', () => {
    it('validates RHS feasibility and accepts both reflected orientations of a 3-4-5 right triangle', () => {
      expect(isValidTriangleRHS(3, 5)).toBe(true);
      expect(isValidTriangleRHS(5, 5)).toBe(false); // degenerate: hyp == leg
      expect(isValidTriangleRHS(6, 5)).toBe(false); // impossible: hyp < leg

      const A = { id: 'A', label: 'A', x: 0, y: 0 };
      const B = { id: 'B', label: 'B', x: 3, y: 0 };
      const Cpos = { id: 'C', label: 'C', x: 0, y: 4 };
      const Cneg = { id: 'C', label: 'C', x: 0, y: -4 };
      expect(evaluateTriangleRHS(A, B, Cpos, 3, 5).passed).toBe(true);
      expect(evaluateTriangleRHS(A, B, Cneg, 3, 5).passed).toBe(true); // reflected solution!
      expect(evaluateTriangleRHS(A, B, { id: 'C', label: 'C', x: 1, y: 4 }, 3, 5).passed).toBe(false);
    });

    it('evaluates virtual-protractor general angles and distinguishes method from pure compass', () => {
      const res = evaluateProtractorAngle(
        { id: 'O', label: 'O', x: 0, y: 0 },
        { id: 'A', label: 'A', x: 5, y: 0 },
        { id: 'B', label: 'B', x: 5 * Math.cos((37 * Math.PI) / 180), y: 5 * Math.sin((37 * Math.PI) / 180) },
        37,
      );
      expect(res.passed).toBe(true);
      expect(res.method).toBe('virtual-protractor');
      expect(res.measuredDeg).toBeCloseTo(37, 1);
    });
  });

  describe('2. Remaining Circle Theorems (Alternate Segment, Equal Tangents, Chord Perpendicular Bisector)', () => {
    it('computes exact alternate segment theorem (minor & major arc), equal tangents, and chord bisector', () => {
      // Alternate segment: chord from 270° to 30° spans 120° -> inscribed angle in major arc = 60° = tangent-chord angle
      const altMajor = computeCircleTheoremGeometry('alternate-segment', [270, 30], 150);
      expect(altMajor.validDomain).toBe(true);
      expect(altMajor.measuredAngleDeg).toBe(60);
      expect(altMajor.relatedAngleDeg).toBe(60);
      // Point in minor arc (330°) gives 120° = obtuse tangent-chord angle
      const altMinor = computeCircleTheoremGeometry('alternate-segment', [270, 30], 330);
      expect(altMinor.validDomain).toBe(true);
      expect(altMinor.measuredAngleDeg).toBe(120);
      expect(altMinor.relatedAngleDeg).toBe(120);

      // Equal tangents at d = 2R -> ∠T1OT2 = 120°, ∠T1ET2 = 60°
      const eqT = computeCircleTheoremGeometry('equal-tangents', [0, 2], 0);
      expect(eqT.validDomain).toBe(true);
      expect(eqT.measuredAngleDeg).toBe(60);
      expect(eqT.relatedAngleDeg).toBe(120);

      // Chord perpendicular bisector -> 90°
      const chord = computeCircleTheoremGeometry('chord-perp-bisector', [210, 330], 270);
      expect(chord.validDomain).toBe(true);
      expect(chord.measuredAngleDeg).toBe(90);
    });
  });

  describe('3. Extended Loci & Combined Feasible Regions', () => {
    it('verifies finite segment endpoint arcs, parallel midline, intersecting bisectors, and combined constraints', () => {
      // Finite segment (0,0)-(4,0) distance 2 -> endpoint arc (6,0) is at distance 2, (6,2) is at sqrt(8)≈2.83
      expect(pointToSegmentDistance({ x: 6, y: 0 }, { x: 0, y: 0 }, { x: 4, y: 0 })).toBe(2);
      expect(
        evaluateLocusConstraint(
          { kind: 'fixed-distance-segment', p1: { x: 0, y: 0 }, p2: { x: 4, y: 0 }, distance: 2, relation: 'eq' },
          { x: 6, y: 0 },
        ).satisfied,
      ).toBe(true);

      // Intersecting lines (axes): both internal (3,3) and external (-3,3) bisectors pass
      const inter = {
        kind: 'equidistant-intersecting-lines' as const,
        l1p1: { x: -5, y: 0 },
        l1p2: { x: 5, y: 0 },
        l2p1: { x: 0, y: -5 },
        l2p2: { x: 0, y: 5 },
      };
      expect(evaluateLocusConstraint(inter, { x: 3, y: 3 }).satisfied).toBe(true);
      expect(evaluateLocusConstraint(inter, { x: -3, y: 3 }).satisfied).toBe(true);

      // Parallel lines y=0 and y=6 -> midline (1, 3) passes, (1, 9) fails
      const para = {
        kind: 'equidistant-parallel-lines' as const,
        l1p1: { x: -4, y: 0 },
        l1p2: { x: 4, y: 0 },
        l2p1: { x: -4, y: 6 },
        l2p2: { x: 4, y: 6 },
      };
      expect(evaluateLocusConstraint(para, { x: 1, y: 3 }).satisfied).toBe(true);
      expect(evaluateLocusConstraint(para, { x: 1, y: 9 }).satisfied).toBe(false);

      // Combined feasible region
      const comb = evaluateCombinedLocus(
        [
          { kind: 'fixed-distance-point', center: { x: 0, y: 0 }, distance: 4, relation: 'lte' },
          { kind: 'equidistant-two-points', p1: { x: 0, y: 0 }, p2: { x: 6, y: 0 }, relation: 'closer-to-p1' },
        ],
        { x: 1, y: 1 },
      );
      expect(comb.passed).toBe(true);
    });
  });

  describe('4. All 11 Valid Cube Nets, Rotation/Reflection Equivalence, Invalid Hexominoes & Cuboid Metrics', () => {
    it.each(ALL_11_VALID_CUBE_NETS)('certifies valid cube net: $name (plus 90° rotation and reflection)', ({ cells }) => {
      expect(evaluateCubeNet(cells).valid).toBe(true);
      // 90° rotation: (r, c) -> (c, 5 - r)
      const rotated = cells.map(({ r, c }) => ({ r: c, c: 5 - r }));
      expect(evaluateCubeNet(rotated).valid).toBe(true);
      // Horizontal reflection: (r, c) -> (r, 5 - c)
      const reflected = cells.map(({ r, c }) => ({ r, c: 5 - c }));
      expect(evaluateCubeNet(reflected).valid).toBe(true);
    });

    it('rejects invalid hexominoes (2x3 block, 1x6 strip, U-loop, disconnected, wrong count, duplicate cells) and computes cuboid metrics', () => {
      // 2x3 rectangle (contains 2x2 block -> faces overlap in 3D!)
      expect(
        evaluateCubeNet([
          { r: 0, c: 0 }, { r: 0, c: 1 }, { r: 0, c: 2 },
          { r: 1, c: 0 }, { r: 1, c: 1 }, { r: 1, c: 2 },
        ]).valid,
      ).toBe(false);
      // 1x6 straight strip (folds around 4 faces and overlaps!)
      expect(
        evaluateCubeNet([
          { r: 0, c: 0 }, { r: 0, c: 1 }, { r: 0, c: 2 }, { r: 0, c: 3 }, { r: 0, c: 4 }, { r: 0, c: 5 },
        ]).valid,
      ).toBe(false);
      // Disconnected
      expect(
        evaluateCubeNet([
          { r: 0, c: 0 }, { r: 0, c: 1 }, { r: 0, c: 2 }, { r: 3, c: 3 }, { r: 3, c: 4 }, { r: 3, c: 5 },
        ]).valid,
      ).toBe(false);
      // Wrong face count
      expect(evaluateCubeNet([{ r: 0, c: 0 }, { r: 0, c: 1 }]).valid).toBe(false);

      // Cuboid 4 x 3 x 2
      expect(computeCuboidMetrics(4, 3, 2)).toEqual({
        faces: 6,
        edges: 12,
        vertices: 8,
        surfaceArea: 52,
        volume: 24,
      });
    });
  });

  describe('5. Pilot Fixture, Production Gate & UI Interaction', () => {
    it('validates all 12 slides in step5e-geometry-extensions-pilot.json and keeps 1.6.0 production gate CLOSED', () => {
      const fixturePath = path.resolve(process.cwd(), 'public/preview-fixtures/step5e-geometry-extensions-pilot.json');
      const lesson = JSON.parse(fs.readFileSync(fixturePath, 'utf8')) as {
        lessonId: string;
        slides: Array<{ id: string; interactive?: unknown[] }>;
      };
      expect(lesson.slides).toHaveLength(12);
      expect(() => assertValidLessonInteractives(lesson, { allowDevOnlyEngines: true })).not.toThrow();
      expect(() => assertValidLessonInteractives(lesson, { allowDevOnlyEngines: false })).toThrow(/1\.6\.0|production/i);
    });

    it('renders CubeNetWorkbench UI and tests 3D foldability interactively', () => {
      const cfg: GeometryCubeNetConfig = {
        id: 'ui-net-1',
        engine: 'construction-lab',
        labKind: 'geometry-constructor',
        mode: 'cube-nets',
        schemaVersion: 1,
        minEngineVersion: '1.6.0',
        curriculumLevel: 'introductory',
        title: 'Cube Net UI Test',
        instructions: 'Test the cross net.',
        accessibilityLabel: 'Cube net UI test',
        fallbackText: 'Cross net folds into a cube.',
        initialCells: ALL_11_VALID_CUBE_NETS[0].cells,
      };
      render(<GeometryConstructorLab config={cfg} />);
      fireEvent.click(screen.getByRole('button', { name: 'Test 3D Foldability' }));
      expect(screen.getByText(/Valid cube net!/i)).toBeTruthy();
      expect(screen.getByText(/Folded face labels:/i)).toBeTruthy();
    });

    it('supports learner-facing RHS triangle construction (reflected solution + arc provenance) in CompassWorkbench (D-031)', () => {
      const rhsCfg: GeometryCompassConfig = {
        id: 'ui-rhs-1',
        engine: 'construction-lab',
        labKind: 'geometry-constructor',
        mode: 'compass-straightedge',
        schemaVersion: 1,
        minEngineVersion: '1.6.0',
        curriculumLevel: 'igcse',
        title: 'RHS 3-4-5 Triangle',
        instructions: 'Construct a 3-4-5 right triangle on AB.',
        accessibilityLabel: 'RHS triangle construction',
        fallbackText: '3-4-5 right triangle with hypotenuse 5.',
        gridBounds: { xMin: -2, xMax: 6, yMin: -6, yMax: 6, step: 1 },
        initialPoints: [
          { id: 'A', label: 'A', x: 0, y: 0, locked: true },
          { id: 'B', label: 'B', x: 3, y: 0, locked: true },
        ],
        initialSegments: [{ id: 'AB', from: 'A', to: 'B', locked: true }],
        constructionGoal: {
          kind: 'triangle-rhs',
          referencePointIds: ['A', 'B'],
          targetMeasures: [3, 5],
          requireConstructionArcs: true,
        },
      };
      render(<GeometryConstructorLab config={rhsCfg} />);
      // Draw hypotenuse compass arc radius 5 centred at B
      fireEvent.change(screen.getByLabelText('Compass centre point'), { target: { value: 'B' } });
      fireEvent.change(screen.getByLabelText('Compass radius'), { target: { value: '5' } });
      fireEvent.click(screen.getByRole('button', { name: 'Draw Arc' }));
      // Place reflected vertex C at (0, -4)
      fireEvent.change(screen.getByLabelText('New point x coordinate'), { target: { value: '0' } });
      fireEvent.change(screen.getByLabelText('New point y coordinate'), { target: { value: '-4' } });
      fireEvent.click(screen.getByRole('button', { name: 'Add Point' }));
      // Connect A -> P3 and B -> P3
      fireEvent.change(screen.getByLabelText('Segment start point'), { target: { value: 'A' } });
      fireEvent.change(screen.getByLabelText('Segment end point'), { target: { value: 'P3' } });
      fireEvent.click(screen.getByRole('button', { name: 'Connect Segment' }));
      fireEvent.change(screen.getByLabelText('Segment start point'), { target: { value: 'B' } });
      fireEvent.change(screen.getByLabelText('Segment end point'), { target: { value: 'P3' } });
      fireEvent.click(screen.getByRole('button', { name: 'Connect Segment' }));
      fireEvent.click(screen.getByRole('button', { name: /Check/i }));
      expect(screen.getByText(/Verified RHS triangle/i)).toBeTruthy();
      expect(screen.getByText(/Hypotenuse compass arc provenance verified/i)).toBeTruthy();
    });

    it('supports learner-facing Virtual Protractor angle construction in CompassWorkbench (D-031)', () => {
      const protCfg: GeometryCompassConfig = {
        id: 'ui-prot-1',
        engine: 'construction-lab',
        labKind: 'geometry-constructor',
        mode: 'compass-straightedge',
        schemaVersion: 1,
        minEngineVersion: '1.6.0',
        curriculumLevel: 'introductory',
        title: 'Protractor 52° Angle',
        instructions: 'Plot a 52° ray from O.',
        accessibilityLabel: 'Virtual protractor angle construction',
        fallbackText: '52 degree angle using virtual protractor.',
        gridBounds: { xMin: -1, xMax: 6, yMin: -1, yMax: 6, step: 1 },
        initialPoints: [
          { id: 'O', label: 'O', x: 0, y: 0, locked: true },
          { id: 'A', label: 'A', x: 5, y: 0, locked: true },
        ],
        initialSegments: [{ id: 'OA', from: 'O', to: 'A', locked: true }],
        constructionGoal: {
          kind: 'protractor-angle',
          referencePointIds: ['O', 'A'],
          targetMeasures: [52],
        },
      };
      render(<GeometryConstructorLab config={protCfg} />);
      fireEvent.change(screen.getByLabelText('Protractor angle in degrees'), { target: { value: '52' } });
      fireEvent.click(screen.getByRole('button', { name: 'Plot Protractor Ray' }));
      fireEvent.click(screen.getByRole('button', { name: /Check/i }));
      expect(screen.getByText(/Verified virtual-protractor angle/i)).toBeTruthy();
    });

    it('renders SVG geometry for alternate-segment, equal-tangents, and chord-perp-bisector circle theorems (D-031)', () => {
      const theorems: Array<{ theorem: 'alternate-segment' | 'equal-tangents' | 'chord-perp-bisector'; fixed: number[]; mov: number; ans: string }> = [
        { theorem: 'alternate-segment', fixed: [270, 30], mov: 150, ans: '60' },
        { theorem: 'equal-tangents', fixed: [0, 2], mov: 0, ans: '60' },
        { theorem: 'chord-perp-bisector', fixed: [210, 330], mov: 270, ans: '90' },
      ];
      for (const tc of theorems) {
        const cfg: GeometryCircleTheoremConfig = {
          id: `ui-ct-${tc.theorem}`,
          engine: 'construction-lab',
          labKind: 'geometry-constructor',
          mode: 'circle-theorems',
          schemaVersion: 1,
          minEngineVersion: '1.6.0',
          curriculumLevel: 'igcse',
          title: `Theorem ${tc.theorem}`,
          instructions: 'Deduce the angle.',
          accessibilityLabel: `Circle theorem ${tc.theorem}`,
          fallbackText: `Expected ${tc.ans} degrees.`,
          circleTheorem: {
            theorem: tc.theorem,
            fixedAnglesDeg: tc.fixed,
            movablePointAngleDeg: tc.mov,
            targetPrompt: 'Enter angle in degrees.',
          },
        };
        const { container, unmount } = render(<GeometryConstructorLab config={cfg} />);
        expect(container.querySelectorAll('svg line').length).toBeGreaterThanOrEqual(4);
        fireEvent.change(screen.getByLabelText('Deduced angle in degrees'), { target: { value: tc.ans } });
        fireEvent.click(screen.getByRole('button', { name: /Check/i }));
        expect(screen.getByText(/Verified: derived angle/i)).toBeTruthy();
        unmount();
      }
    });

    it('renders SVG locus boundaries, finite-segment endpoint arcs, shaded feasible region, and Congruence/Similarity readout (D-031)', () => {
      const lociCfg: GeometryLociRegionConfig = {
        id: 'ui-loci-1',
        engine: 'construction-lab',
        labKind: 'geometry-constructor',
        mode: 'loci-regions',
        schemaVersion: 1,
        minEngineVersion: '1.6.0',
        curriculumLevel: 'igcse',
        title: 'Stadium & Feasible Region',
        instructions: 'Test a point inside the feasible region.',
        accessibilityLabel: 'Loci feasible region canvas',
        fallbackText: '(1, 1) is inside.',
        gridBounds: { xMin: -4, xMax: 6, yMin: -4, yMax: 4, step: 1 },
        locusConstraints: [
          { kind: 'fixed-distance-segment', p1: { x: 0, y: 0 }, p2: { x: 4, y: 0 }, distance: 2, relation: 'lte' },
          { kind: 'equidistant-two-points', p1: { x: 0, y: 0 }, p2: { x: 4, y: 0 }, relation: 'closer-to-p1' },
        ],
        targetPrompt: 'Find a point within 2 units of segment (0,0)-(4,0) and closer to (0,0).',
      };
      const { container, unmount } = render(<GeometryConstructorLab config={lociCfg} />);
      expect(container.querySelector('[aria-label="Finite segment stadium locus with semicircular endpoint arcs"]')).toBeTruthy();
      expect(container.querySelector('[aria-label="Shaded feasible region"]')).toBeTruthy();
      fireEvent.change(screen.getByLabelText('Locus test point x'), { target: { value: '1' } });
      fireEvent.change(screen.getByLabelText('Locus test point y'), { target: { value: '1' } });
      fireEvent.click(screen.getByRole('button', { name: 'Test Locus Point' }));
      expect(screen.getByText(/Verified!/i)).toBeTruthy();
      unmount();

      const simCfg: GeometryTransformationConfig = {
        id: 'ui-sim-1',
        engine: 'construction-lab',
        labKind: 'geometry-constructor',
        mode: 'transformations',
        schemaVersion: 1,
        minEngineVersion: '1.3.0',
        curriculumLevel: 'igcse',
        title: 'Similarity Enlargement',
        instructions: 'Enlarge by scale factor 2.',
        accessibilityLabel: 'Similarity enlargement grid',
        fallbackText: 'Scale factor 2 doubles side lengths.',
        gridBounds: { xMin: -2, xMax: 8, yMin: -2, yMax: 8, step: 1 },
        preImageVertices: [
          { x: 1, y: 1, label: 'A' },
          { x: 3, y: 1, label: 'B' },
          { x: 1, y: 2, label: 'C' },
        ],
        transformation: { kind: 'enlargement', cx: 0, cy: 0, scaleFactor: 2 },
      };
      render(<GeometryConstructorLab config={simCfg} />);
      expect(screen.getByText(/Congruence & Similarity Readout/i)).toBeTruthy();
      expect(screen.getByText(/scale factor k = 2/i)).toBeTruthy();
    });
  });
});
