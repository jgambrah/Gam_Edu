# 02 — Configuration-First Dynamic Capability Audit (All 43 Pilot Activities)

Classification key: **A** = Dynamic capability already available · **B** = Configuration-only improvement (implemented now) · **C** = Small shared engine refinement proposed · **D** = Significant new capability (separate approval) · **E** = Fixed-target assessment intentionally retained.

## Pilot A — Hydrocarbons (26 Activities across 18 Slides)
| Slide | Activity ID | Engine | Class | Current Mode & Recommendation |
|---|---|---|---|---|
| `a02` | `hc-a02-homologous-series` | `graph-slider 1.0.0` | **B (Implemented)** | Dynamic slider; upgraded via config with `showDataTable: true`, full integer presets `[1,2,3,4,5,8,10]`, dimensionless `Mr` + `Molar mass g mol⁻¹` |
| `a06` | `hc-a06-methane-vsepr` | `atom-bond-builder 1.2.0` | **C (Proposed)** | Guided VSEPR (CH₄); small reusable `moleculeBank` selector would allow comparing CH₄, NH₃, H₂O, CO₂ in one lab |
| `b01` | `hc-b01-boiling-points` | `graph-slider 1.0.0` | **B (Implemented)** | Dynamic slider; upgraded via config with `showDataTable: true` & full integer presets `[1..8]` |
| `b04` | `hc-b04-fractional-distillation` | `process-stepper 1.0.0` | **A** | Interactive 4-stage column explorer with state table & prediction |
| `c01` | `hc-c01-methane-combustion` | `equation-balancer 1.1.0` | **C (Proposed)** | Guided example; small reusable `equationBank` would let learners pick CH₄/C₂H₆/C₃H₈/C₄H₁₀ |
| `c01` | `hc-c01-propane-combustion` | `equation-balancer 1.1.0` | **E** | Independent stoichiometry practice intentionally retained |
| `c02` | `hc-c02-incomplete-combustion` | `equation-balancer 1.1.0` | **C (Proposed)** | Could offer selectable CO vs C(soot) incomplete pathways via `equationBank` |
| `c04` | `hc-c04-catalytic-converter` | `equation-balancer 1.1.0` | **E** | Focused catalytic converter redox check intentionally retained |
| `d02` | `hc-d02-frs-mechanism` | `process-stepper 1.0.0` | **B (Implemented)** | Enriched via config with `whatChanges`, `whyItMatters`, `reactionMeta` (bonds broken, electron movement) |
| `d03` | `hc-d03-termination` | `process-stepper 1.0.0` | **A** | Multi-pathway termination explorer + prediction |
| `e03` | `hc-e03-cracking-balance` | `equation-balancer 1.1.0` | **C (Proposed)** | Selectable cracking equation bank would illustrate multiple valid cracking splits |
| `f01` | `hc-f01-ethene-geometry` | `atom-bond-builder 1.2.0` | **E** | Focused sp² trigonal planar check intentionally retained |
| `f03` | `hc-f03-bromine-water-test` | `process-stepper 1.0.0` | **A** | Virtual comparison explorer + prediction |
| `g05` | `hc-g05-atom-economy` | `math-evaluator 1.1.0` | **E** | Quantitative atom economy check + prediction intentionally retained |
| `h02` | `hc-h02-electrophilic-addition-hbr` | `process-stepper 1.0.0` | **B (Implemented)** | Enriched via config with `whatChanges` and `reactionMeta` |
| `i03` | `hc-i03-propene-carbocations` | `process-stepper 1.0.0` | **A** | Secondary vs primary carbocation pathway comparison + prediction |
| `p01` (×3) | `hc-p01-*` | `equation-balancer` + `math-evaluator` | **E** | Digital exam practice intentionally retained as fixed assessment |
| `p03` (×3) | `hc-p03-*` | `math-evaluator 1.1.0` | **E** | Sequential 3 s.f. exam practice intentionally retained |
| `p09` (×4) | `hc-p09-*` | `math-evaluator 1.1.0` | **E** | Sequential 3 s.f. exam practice intentionally retained |

## Pilot B — Basic 8 Atoms & Periodic Table (17 Activities across 13 Slides)
| Slide | Activity ID | Engine | Class | Current Mode & Recommendation |
|---|---|---|---|---|
| `s04` | `b8-s04-carbon-atom` | `atom-bond-builder` | **A (Ready in 1.8.0)** | Upgraded to Open-Ended Atomic Playground (`free-exploration` + Periodic Table selector) in `playground-v1.8.0-ready.json` |
| `s06`, `s07`, `s09` | `b8-s06/07/09-*` | `atom-bond-builder 1.2.0` | **E** | Focused guided discoveries (neutrality, proton identity, C-14 isotope) intentionally retained; optional `Explore Further` proposed |
| `s10`, `s12` (×2), `s26` | `b8-s10/12/26-*` | `math-evaluator 1.1.0` | **E** | Independent numeric particle-count practice intentionally retained |
| `s18`, `s20` | `b8-s18/20-*` | `atom-bond-builder 1.2.0` | **E** | Guided Neon (2,8) & Sodium (2,8,1) shell construction intentionally retained |
| `s21` (×2) | `b8-s21-*` | `atom-bond-builder` | **A (Ready in 1.8.0)** | Upgraded to 4-target `independent-challenge` (H, O, Cl, Ca) with zero premature disclosure |
| `s22` | `b8-s22-fluoride-ion` | `atom-bond-builder 1.2.0` | **E** | Focused Fluoride ion formation intentionally retained |
| `s23` (×2) | `b8-s23-nacl/mgo-ionic` | `atom-bond-builder 1.2.0` | **C (Proposed)** | Small reusable `ionicBank` selector would let learners explore NaCl, MgO, MgCl₂, CaCl₂, Al₂O₃ in one playground |
| `s25` (×2) | `b8-s25-water/co2-covalent` | `atom-bond-builder 1.2.0` | **C (Proposed)** | Small reusable `covalentBank` selector would let learners build H₂, O₂, N₂, H₂O, CO₂, NH₃, CH₄ in one playground |
