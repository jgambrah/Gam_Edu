# 01 — Actual Current Deployment, CDN & Activation Status (Reconciled)

- **Git `origin/fixed-version`**: Updated through PCV-1 Refinement 2 (previous checkpoints: `512fca19` foundation, `1bd9eaab` discovery, `a35a207b` PCV-1 implementation, `5103e762` Refinement 1).
- **Live CDN `catalogue.json`**: `catalogueVersion: 101` (updated `2026-11-28T11:24:36.098Z`, `49` entries).
  - **Hydrocarbons (`cambridge-as-a-level-chemistry-hydrocarbons`)**: `d81bff77545d` (`packages/cambridge-as-a-level-chemistry-hydrocarbons.d81bff77545d.json`) — 100% LIVE `1.0.0–1.2.0` engines, including dimensionless `Mr` + `Molar mass g mol⁻¹`, `showDataTable: true`, full integer presets, and `reactionMeta`. Original `739c1252e89e` preserved.
  - **Basic 8 Atoms (`b8-sci-t1-atoms-and-the-periodic-table`)**: `379856075c2c` (`packages/b8-sci-t1-atoms-and-the-periodic-table.379856075c2c.json`) — 100% LIVE `1.2.0` engines (removed premature `s21` disclosure). Original `15080192a16a` preserved.
- **Reconciliation of Owner Observation vs `1.8.0` Gate**:
  - `construction-lab` `engineVersion` is `1.8.0`, while `productionVersion` remains strictly held at `1.3.0`.
  - The live CDN Basic 8 package (`379856075c2c`) uses `minEngineVersion: "1.2.0"` (fixed-target activities); the upgraded **v1.8.0 Open-Ended Atomic Playground JSON** (`lessons/b8-sci-t1-atoms-and-the-periodic-table.playground-v1.8.0-ready.json`) is validated (`allowDevOnlyEngines: true`) and held back from live CDN publish until the owner manually promotes `fixed-version` on Vercel and approves `construction-lab` activation.
  - Student Enrichment remains **Under Construction** (`src/lib/student-enrichment-release.ts`).
