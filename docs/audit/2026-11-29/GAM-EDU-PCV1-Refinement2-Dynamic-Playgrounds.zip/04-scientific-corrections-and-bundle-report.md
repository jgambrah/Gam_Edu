# 04 — Scientific Corrections, Functional Tests & Bundle-Size Report

## 1. All 6 Atomic Structure Playground Scientific Corrections Completed (`atom-bond-atomic.ts`)
1. **Unsupported subshell configurations**: `getExpectedSubshells(el.symbol, actualCharge) === null` now returns `passed: false, status: 'unverified-subshells'` (never silently passed as verified!).
2. **Neutral atoms vs common ions**: `isCommonIon` is now `actualCharge !== 0 && el.supportedCharges.includes(actualCharge)` (neutral atoms always have `isCommonIon: false`).
3. **Malformed/negative/fractional/non-finite counts**: Explicitly rejected with `status: 'invalid-input'`, `passed: false`.
4. **Independent shell/subshell capacity validation**: Enforced directly inside `evaluateFreeAtomicExploration` (`0 <= shells[i] <= [2,8,8,2][i]`, `0 <= subshells[k] <= SUBSHELL_MAX_CAPACITY[k]`) independent of UI button clamping.
5. **Known isotopes vs unverified combinations**: Strict check against verified `el.isotopes`; unlisted neutron counts classified as `unverified-isotope` without claiming stability.
6. **Group/Period invariance on ion formation**: `groupPeriodNote` and ion feedback explicitly state that forming an ion changes charge/electrons only, never the element's Group or Period.

## 2. Verification & Bundle-Size Impact
- **Unit & Functional UI Tests**: `atom-playground.test.tsx` (6/6), `atom-bond-lab.test.tsx` (8/8), `pcv1-enriched-pilots.test.tsx` (3/3) — **17/17 PASSED**.
- **TypeScript Ratchet**: `Ratchet OK: 351 <= 351`.
- **Production Build (`npm run build`, Next.js 15.5.29)**: **Exit 0**.
  - Shared First Load JS: **`103 kB`** (0 kB increase on core school-management routes!).
  - `/narrated-lessons/[lessonId]` First Load JS: `257 kB` (`+2 kB` vs `255 kB`; `AtomBondLab` remains independently lazy-loaded).
  - Operational cost: **0 Firestore reads/writes**, **0 paid AI calls**, **0 paid media regeneration**.
