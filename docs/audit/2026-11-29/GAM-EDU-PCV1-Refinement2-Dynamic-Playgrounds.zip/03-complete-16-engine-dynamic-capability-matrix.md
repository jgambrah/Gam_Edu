# 03 — Complete 16-Engine Dynamic Exploration Capability Matrix

| # | Engine / Subtype | Current Dynamic Support | Proposed Small Extension (For Review) |
|---|---|---|---|
| 1 | `atom-bond-builder: atomic-structure` | **Implemented (1.8.0)**: `free-exploration` + Periodic Table selector (Z=1..20/30) + `guided` + `independent-challenge` + 6 scientific fixes | Activate after manual Vercel promotion |
| 2 | `atom-bond-builder: ionic-bonding` | Fixed cation/anion pair per activity | Add optional `ionicBank: IonicExample[]` selector (reusing existing `evaluateIonicBonding`) |
| 3 | `atom-bond-builder: covalent-bonding` | Fixed molecule per activity | Add optional `covalentBank: CovalentExample[]` selector (H₂, O₂, N₂, H₂O, CO₂, CH₄, NH₃) |
| 4 | `atom-bond-builder: molecular-geometry` | Fixed VSEPR molecule per activity | Add optional `vseprBank: VseprExample[]` selector |
| 5 | `equation-balancer` | Fixed equation per activity | Add optional `equationBank: EquationExample[]` selector (validated at authoring time) |
| 6 | `electrical-circuit` | Fixed topology with swappable component palette | Already supports open-ended slot experimentation + check |
| 7 | `bio-sequence-builder` | Fixed target sequence per activity | Optional `sequenceBank` selector |
| 8 | `graph-slider` | **LIVE dynamic**: sliders, presets, `showDataTable`, challenges, predictions | Already strongly dynamic via config |
| 9 | `process-stepper` | **LIVE dynamic**: linear/cyclic stages, state diff, `reactionMeta`, predictions, sequence challenge | Already dynamic for non-branching processes |
| 10 | `diagram-hotspots` | **LIVE dynamic**: Explore + Identify modes | Future: allow safe inline-SVG reuse alongside WebP/PNG |
| 11 | `math-evaluator` | Guided / Independent / Exam-Practice working workspace | Intentional assessment engine (not a free playground) |
| 12 | `sort-classify` | Category bins, matching, cloze, ordering (dev-only) | Activate when promoted |
| 13 | `measurement-lab` | Interactive scale/parallax/tare/zero-error manipulation (dev 1.4.0) | Already interactive; activate when promoted |
| 14 | `data-stats-lab` | Interactive trial runner, data editing, outlier toggle, 8 charts (dev 1.5.0) | Already strongly dynamic; activate when promoted |
| 15 | `geometry-constructor` | Interactive compass/protractor, movable circle theorems, loci plane, cube nets (1.3.0 LIVE / 1.6.0 dev) | Already strongly dynamic |
| 16 | `number-manipulative` | 9 interactive CPA primary manipulatives (dev 1.7.0) | Optional `free-exploration` toggle in future refinement |

## Proposed `Explore Further` Control (Section 10 Feasibility)
- **Feasibility**: Cleanly implementable inside `ConstructionLabShell` (or `AtomBondLab`) via an optional `exploreFurther?: boolean` flag that opens a sandboxed local React state drawer/modal backed by the **same already-loaded lazy chunk** (0 extra downloads, 0 Firestore writes).
- **Isolation Guarantee**: Separate `exploreSnapshot` state object so closing `Explore Further` restores the learner's untouched assessment `state` without corrupting answers or leaking target solutions.
- **Status**: Proposed for ChatGPT approval before implementation.
