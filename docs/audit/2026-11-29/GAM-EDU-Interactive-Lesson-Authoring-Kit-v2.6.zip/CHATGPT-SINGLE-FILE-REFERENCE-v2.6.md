# GAM EDU — Interactive Lesson Authoring Kit v2.6 (Single-File Reference)

**Date:** 2026-11-28  
**Milestone:** PCV-1 Refinement 3 — Reusable Dynamic Chemistry Playgrounds & Scoped Production Activation (`construction-lab 1.9.0`)

## 1. Active Engine Registry & Scoped Capability Activation (`schemas/interactive-schema.ts`)

| Engine | `engineVersion` | `productionVersion` | Scoped `productionCapabilities` |
|---|---|---|---|
| `code-playground` | `1.0.0` | `1.0.0` | — |
| `rule-explorer` | `1.0.0` | `1.0.0` | — |
| `graph-slider` | `1.0.0` | `1.0.0` | — |
| `process-stepper` | `1.0.0` | `1.0.0` | — |
| `diagram-hotspots` | `1.0.0` | `1.0.0` | — |
| `math-evaluator` | `1.1.0` | `1.1.0` | — |
| `construction-lab` | `1.9.0` | **`1.3.0`** | `construction-lab:atom-bond-builder: "1.9.0"`, `construction-lab:equation-balancer: "1.9.0"` (Measurement `1.4.0`, Data Stats `1.5.0`, Geometry 5E `1.6.0`, Number Manipulative `1.7.0` remain gated) |
| `sort-classify` | `1.0.0` | `null` | Not activated |

## 2. Reusable Dynamic Chemistry Capabilities (`1.8.0`–`1.9.0`)
- **Open-Ended Atomic Structure Playground (`1.8.0`):** `interactionMode: "free-exploration" | "independent-challenge" | "guided"`, `allowElementSelector`, `maxElementZ`, `startEmpty`, 3-tier `evaluationTier` (`verified` / `unverified-consistent` / `incorrect`), Helium Group 18 duet explanation, simplified first-20 filling model note.
- **Shared Selectable `examples` Banks (`1.9.0`):** Supported on `atom-bond-builder` (`ionic-bonding`, `covalent-bonding`, `molecular-geometry`) and `equation-balancer` (1–8 validated items, unique `id`, non-empty `label`, validated by reusing existing subtype validators).
- **Ionic Electron-Transfer Conservation (`schemas/atom-bond-ionic.ts`):** Distinguishes available metal donor e⁻, required non-metal acceptor e⁻, `maxTransferableElectrons`, remaining imbalance, charge balance, simplest empirical ratio, and rejects impossible excess transfers.
- **Stoichiometry Cap (`schemas/stoichiometry-engine.ts`):** `maxCoefficientHardCap: 15` (default `12` preserved) supporting genuine butane complete combustion (`2C₄H₁₀ + 13O₂ → 8CO₂ + 10H₂O`).
- **Isolated `Explore Further` & Assessment Protection (`ui/ConstructionLabShell.tsx`):** `exploreFurther: true` opens an isolated sandbox (`Escape`-to-close, focus restored, 0 Firestore writes); `isAssessment: true` disables `Explore Further`, hints, prediction scaffolding, and example switching.

## 3. Permanent Five-Tier Educational Standard
1. **Demonstration** → 2. **Free Exploration (Open-Ended Playground)** → 3. **Guided Practice** → 4. **Independent Practice** (no premature answer disclosure) → 5. **Mastery Assessment** (`isAssessment: true`).

## 4. Validated PCV-1 Enriched Pilot Lessons
- `pcv1-lessons/b8-sci-t1-atoms-and-the-periodic-table.refinement3-v1.9.0.json` (26 slides: `s04`, `s14`, `s21`, `s23`, `s25`)
- `pcv1-lessons/cambridge-as-a-level-chemistry-hydrocarbons.refinement3-v1.9.0.json` (71 slides: `a06`, `c01`, `c02`, `e03`; retains `f01` & exam slides `p01`, `p03`, `p09`)
