# 07 — Complete Slide-by-Slide Inventory for Recommended JHS Science Pilots (155 Slides)

# Diversity of Matter: Atoms and the Periodic Table (`b8-sci-t1-atoms-and-the-periodic-table`)

- **CDN packagePath**: `packages/b8-sci-t1-atoms-and-the-periodic-table.15080192a16a.json` (hash `15080192a16a`, updated `2026-11-23T12:55:58.736Z`)
- **Curriculum**: ges · **Class**: Basic 8 · **Subject**: Science · **Term**: 1
- **Content Standard**: B8.1.1.2
- **Indicators**: B8.1.1.2.1, B8.1.1.2.2
- **Total Slides**: 26 · **Checkpoints**: 15 · **Mastery Check Items**: 5

## Slide 1: `s01` — Everything Is Made of Atoms
- **Learning Objective / Purpose**: Hook: elements and atoms in daily life.
- **Indicators**: B8.1.1.2.1
- **On-Screen Educational Text**:
  - Everything is made of atoms
  - Atoms are far too small to see
  - Today: inside the atom
- **Key Ideas**: Gold, aluminium and water are made of atoms. | Atoms are far too small to see. | We will study the atom and the periodic table.
- **Complete Narration Text**: Good morning, class. A goldsmith shapes a gold ring, a woman cooks in an aluminium pot, and a girl pours water. Gold and aluminium are elements, and elements are made of tiny particles called atoms. Water is made of atoms joined together. Today we will look inside the atom and see how the elements are arranged in the periodic table.
- **Audio Asset Reference**: `audio/s01.1d64ccf3bde4.mp3` (24s, source: tts)
- **Visual Type**: `illustration` · **Description**: A busy Kumasi workshop where a goldsmith shapes a gold ring, a woman lifts an aluminium cooking pot from a coal pot, and a girl pours clean water into a glass.
- **Image Asset Reference**: `images/s01.d85adf0f0f39.webp` · **Alt Text**: A busy Kumasi workshop where a goldsmith shapes a gold ring, a woman lifts an aluminium cooking pot from a coal pot, and a girl pours clean water into a glass.
- **Visual Labels**: None
- **SVG Content**: None
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B8.1.1.2.1 is previewed here. Gold and aluminium (from bauxite) are Ghanaian examples. AI image placement is approximate.
- **Existing Checkpoints After This Slide**: None

## Slide 2: `s02` — What Is an Atom?
- **Learning Objective / Purpose**: Explain an atom and an element (indicator 1, exemplar 1).
- **Indicators**: B8.1.1.2.1
- **On-Screen Educational Text**:
  - An element has one kind of atom
  - An atom is the smallest particle
  - Atoms have even smaller parts
- **Key Ideas**: An element has only one kind of atom. | An atom is the smallest particle of an element. | Sub-atomic particles are smaller than the atom.
- **Complete Narration Text**: An element is a pure substance made of only one kind of atom, such as gold, aluminium or oxygen. An atom is the smallest particle of an element that still has the properties of that element. Atoms are far too small to see with our eyes. Different elements have different kinds of atoms. Atoms are made of even smaller particles called sub-atomic particles, which means particles smaller than the atom.
- **Audio Asset Reference**: `audio/s02.4b23c520c880.mp3` (28s, source: tts)
- **Visual Type**: `svg` · **Description**: Atom: Smallest part of an element. Remember: Too small to see, Made of particles, Elements differ, Atoms build matter.
- **Image Asset Reference**: `None` · **Alt Text**: Atom: Smallest part of an element. Remember: Too small to see, Made of particles, Elements differ, Atoms build matter.
- **Visual Labels**: Atom, Smallest part of an element, Too small to see, Made of particles, Elements differ, Atoms build matter
- **SVG Content**: Present (1897 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B8.1.1.2.1 (explain an atom and its structure, linked to the periodic table). The link to the periodic table is made in section C. An atom is the smallest particle of an element that keeps its chemical identity.
- **Existing Checkpoints After This Slide**: None

## Slide 3: `s03` — Sub-atomic Particles
- **Learning Objective / Purpose**: Name the sub-atomic particles and their locations (indicator 1, exemplar 2).
- **Indicators**: B8.1.1.2.1
- **On-Screen Educational Text**:
  - Protons and neutrons: in the nucleus
  - Electrons: around the nucleus
  - Most atoms have neutrons
- **Key Ideas**: The sub-atomic particles are protons, neutrons and electrons. | Most atoms have neutrons, but the most common hydrogen atom has none. | Protons and neutrons are in the nucleus, and electrons are in shells.
- **Complete Narration Text**: Atoms are made of sub-atomic particles: protons, electrons and, in most atoms, neutrons. Protons and neutrons are found together in the centre of the atom, called the nucleus. Electrons move around the nucleus in regions called shells. The most common hydrogen atom has one proton and one electron and no neutron. The nucleus is tiny, but it holds almost all of the mass of the atom.
- **Audio Asset Reference**: `audio/s03.9d4d3840ce67.mp3` (26s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 3 rows: Proton, In the nucleus; Neutron, In the nucleus; Electron, Around the nucleus.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 3 rows: Proton, In the nucleus; Neutron, In the nucleus; Electron, Around the nucleus.
- **Visual Labels**: Particle, Where it is, Proton, Neutron, Electron, In the nucleus, In the nucleus, Around the nucleus
- **SVG Content**: Present (2219 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 of B8.1.1.2.1 (list the sub-atomic particles and indicate their location). Most atoms contain protons, neutrons and electrons, but the most common form of hydrogen has no neutron. Sub-atomic means smaller than the atom.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcA1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qA.1`: Which two particles are found in the nucleus? — Correct: c (a: Protons and electrons | b: Neutrons and electrons | c: Protons and neutrons | d: Electrons only)

## Slide 4: `s04` — The Structure of an Atom
- **Learning Objective / Purpose**: Model of the atom (indicator 1, exemplars 1 and 2).
- **Indicators**: B8.1.1.2.1
- **On-Screen Educational Text**:
  - The nucleus is at the centre
  - Electrons are in shells
  - This is a simple model
- **Key Ideas**: Lithium-7 has 3 protons, 4 neutrons and 3 electrons. | The electron configuration is 2, 1. | The shell circles are a simple model, not real paths.
- **Complete Narration Text**: Look at this model of an atom, lithium-7. The nucleus is at the centre and contains 3 protons and 4 neutrons. The 3 electrons are in shells around the nucleus, 2 in the first shell and 1 in the second, so the electron configuration is 2, 1. This is a simple model: real electrons do not travel in neat circles, but the model helps us count and arrange them.
- **Audio Asset Reference**: `audio/s04.07f62b799299.mp3` (28s, source: tts)
- **Visual Type**: `svg` · **Description**: A model of a lithium-7 atom: a nucleus at the centre with 3 orange protons and 4 grey neutrons, and 3 blue electrons, 2 in the first shell and 1 in the second. Labels point to the nucleus, an electron, a shell, a proton and a neutron.
- **Image Asset Reference**: `None` · **Alt Text**: A model of a lithium-7 atom: a nucleus at the centre with 3 orange protons and 4 grey neutrons, and 3 blue electrons, 2 in the first shell and 1 in the second. Labels point to the nucleus, an electron, a shell, a proton and a neutron.
- **Visual Labels**: Nucleus, Electron (-), Shell, Proton (+), Neutron (0), Lithium-7
- **SVG Content**: Present (3058 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplars 1 and 2 of B8.1.1.2.1. The drawing shows lithium-7: 3 protons, 4 neutrons (mass number 7) and 3 electrons, with the electron configuration 2, 1. The shell circles are a simplified model and not literal electron paths. Pupils may build this with bottle tops.
- **Existing Checkpoints After This Slide**: None

## Slide 5: `s05` — Charges of the Particles
- **Learning Objective / Purpose**: Electrical charges (indicator 1, exemplar 3).
- **Indicators**: B8.1.1.2.1
- **On-Screen Educational Text**:
  - Proton: positive
  - Electron: negative
  - Neutron: no charge
- **Key Ideas**: A proton has a positive charge. | An electron has a negative charge. | A neutron has no charge.
- **Complete Narration Text**: Each sub-atomic particle has an electrical charge. A proton has a positive charge, written plus one. An electron has a negative charge, written minus one. A neutron has no charge. Opposite charges attract, which helps to keep the electrons near the nucleus.
- **Audio Asset Reference**: `audio/s05.62662d3018ba.mp3` (17s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 3 rows: Proton, Positive (+1); Electron, Negative (-1); Neutron, No charge (0).
- **Image Asset Reference**: `None` · **Alt Text**: A table with 3 rows: Proton, Positive (+1); Electron, Negative (-1); Neutron, No charge (0).
- **Visual Labels**: Particle, Charge, Proton, Electron, Neutron, Positive (+1), Negative (-1), No charge (0)
- **SVG Content**: Present (2211 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 3 of B8.1.1.2.1 (state the electrical charges on the sub-atomic particles).
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcA2` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qA.2`: Which particle has a negative charge? — Correct: b (a: The proton | b: The electron | c: The neutron | d: The nucleus)

## Slide 6: `s06` — Why an Atom Is Neutral
- **Learning Objective / Purpose**: Neutral atoms (indicator 1, exemplar 3).
- **Indicators**: B8.1.1.2.1
- **On-Screen Educational Text**:
  - An atom has no overall charge
  - Protons equal electrons
  - Positive and negative cancel
- **Key Ideas**: A neutral atom has no overall charge. | It has equal numbers of protons and electrons. | Neutrons do not change the charge.
- **Complete Narration Text**: An atom as a whole has no overall charge, so we say it is neutral. This is because it has the same number of protons and electrons. The positive and negative charges cancel out. Neutrons do not change the charge, because they have none.
- **Audio Asset Reference**: `audio/s06.856c0388f71a.mp3` (18s, source: tts)
- **Visual Type**: `svg` · **Description**: Neutral atom: Protons and electrons are equal. Because: Charges balance, Protons: positive, Electrons: negative, Net charge is zero.
- **Image Asset Reference**: `None` · **Alt Text**: Neutral atom: Protons and electrons are equal. Because: Charges balance, Protons: positive, Electrons: negative, Net charge is zero.
- **Visual Labels**: Neutral atom, Protons and electrons are equal, Charges balance, Protons: positive, Electrons: negative, Net charge is zero
- **SVG Content**: Present (1919 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 3 of B8.1.1.2.1. This also prepares counting electrons in section B and ions in section E.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpA` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `cpA.1`: What is an element? — Correct: d (a: A mixture of several different kinds of atoms | b: A particle that is smaller than any atom | c: Any material that is found in the ground | d: A pure substance made of only one kind of atom)
    - [mcq] `cpA.2`: An atom has equal numbers of protons and electrons. Why is it neutral? — Correct: a (a: The positive and negative charges cancel out | b: Neutrons cancel the charge of the protons | c: Electrons have no charge at all | d: The nucleus has no charge at all)
    - [mcq] `cpA.3`: Which statement about an atom is correct? — Correct: c (a: Electrons are found in the nucleus with the protons | b: Protons move around the nucleus in shells | c: Electrons move around the nucleus in shells | d: Neutrons carry a negative charge)
    - [mcq] `cpA.4`: An atom has 7 protons and 7 electrons. What is its overall charge? — Correct: b (a: Positive, plus 7 | b: Zero (neutral) | c: Negative, minus 7 | d: Positive, plus 14)

## Slide 7: `s07` — Atomic Number
- **Learning Objective / Purpose**: Atomic number (indicator 1, exemplar 4).
- **Indicators**: B8.1.1.2.1
- **On-Screen Educational Text**:
  - Atomic number is the number of protons
  - We write it as Z
  - Each element has its own number
- **Key Ideas**: The atomic number is the number of protons. | We write it as Z. | It identifies the element.
- **Complete Narration Text**: The atomic number is the number of protons in the nucleus of an atom. We write it with the letter Z. Every element has its own atomic number, so the atomic number tells us which element the atom belongs to. For example, every carbon atom has six protons, so the atomic number of carbon is six.
- **Audio Asset Reference**: `audio/s07.0dd49fb1cbc3.mp3` (22s, source: tts)
- **Visual Type**: `svg` · **Description**: Atomic number: The number of protons in an atom. Key facts: Symbol: Z, Identifies element, Z = protons, Unique to element.
- **Image Asset Reference**: `None` · **Alt Text**: Atomic number: The number of protons in an atom. Key facts: Symbol: Z, Identifies element, Z = protons, Unique to element.
- **Visual Labels**: Atomic number, The number of protons in an atom, Symbol: Z, Identifies element, Z = protons, Unique to element
- **SVG Content**: Present (1910 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 4 of B8.1.1.2.1 (describe the differences between the atomic number and the mass number).
- **Existing Checkpoints After This Slide**: None

## Slide 8: `s08` — Mass Number
- **Learning Objective / Purpose**: Mass number (indicator 1, exemplar 4).
- **Indicators**: B8.1.1.2.1
- **On-Screen Educational Text**:
  - Mass number is protons plus neutrons
  - We write it as A
  - It is a whole number
- **Key Ideas**: The mass number is protons plus neutrons. | Relative masses: proton 1, neutron 1, electron about 0. | The decimal in some periodic tables is not the mass number.
- **Complete Narration Text**: The mass number is the total number of protons and neutrons in the nucleus. We write it with the letter A. A proton has a relative mass of 1, a neutron also has a relative mass of 1, and an electron has a negligible mass, about zero. So electrons do not change the mass number, and most of the mass of an atom is in its nucleus. The mass number is a whole number for a particular atom, and it is not the same as the decimal relative atomic mass shown in some periodic tables.
- **Audio Asset Reference**: `audio/s08.f4f9891dd5f5.mp3` (38s, source: tts)
- **Visual Type**: `svg` · **Description**: Mass number: Protons plus neutrons. Key facts: Symbol: A, A = p + n, A whole number, Mass is in nucleus.
- **Image Asset Reference**: `None` · **Alt Text**: Mass number: Protons plus neutrons. Key facts: Symbol: A, A = p + n, A whole number, Mass is in nucleus.
- **Visual Labels**: Mass number, Protons plus neutrons, Symbol: A, A = p + n, A whole number, Mass is in nucleus
- **SVG Content**: Present (1890 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 4 of B8.1.1.2.1. The relative atomic mass printed in some periodic tables (for example 35.5 for chlorine) is an average and is not the mass number; the lesson uses whole mass numbers only.
- **Existing Checkpoints After This Slide**: None

## Slide 9: `s09` — Atomic Number and Mass Number
- **Learning Objective / Purpose**: Compare the two numbers (indicator 1, exemplar 4).
- **Indicators**: B8.1.1.2.1
- **On-Screen Educational Text**:
  - Z counts the protons
  - A counts protons and neutrons
  - Only Z identifies the element
- **Key Ideas**: Z counts protons only. | A counts protons and neutrons together. | Only the atomic number identifies the element.
- **Complete Narration Text**: Let us compare the two numbers. The atomic number is Z, and it counts only the protons. The mass number is A, and it counts the protons and the neutrons together. So the mass number is never smaller than the atomic number. Only the atomic number tells us which element we have. For enrichment, atoms of the same element with different numbers of neutrons are called isotopes.
- **Audio Asset Reference**: `audio/s09.d894088d04a5.mp3` (27s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 3 rows: Symbol Z, Symbol A; Protons only, Protons + neutrons; Z is never above A, A is never below Z.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 3 rows: Symbol Z, Symbol A; Protons only, Protons + neutrons; Z is never above A, A is never below Z.
- **Visual Labels**: Atomic number, Mass number, Symbol Z, Protons only, Z is never above A, Symbol A, Protons + neutrons, A is never below Z
- **SVG Content**: Present (2248 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 4 of B8.1.1.2.1. Isotopes are named as enrichment only: atoms of the same element with different numbers of neutrons. No isotope calculations are taught at Basic 8.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcB1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qB.1`: What does the atomic number tell us? — Correct: a (a: The number of protons | b: The number of neutrons | c: The protons plus the neutrons | d: The number of shells)

## Slide 10: `s10` — Counting the Particles
- **Learning Objective / Purpose**: Steps to find protons, electrons and neutrons (indicator 1, exemplar 5).
- **Indicators**: B8.1.1.2.1
- **On-Screen Educational Text**:
  - Protons equal the atomic number
  - Electrons equal protons if neutral
  - Neutrons equal A minus Z
- **Key Ideas**: Protons equal the atomic number. | Electrons equal protons in a neutral atom. | Neutrons equal the mass number minus the atomic number.
- **Complete Narration Text**: Here is how to find the particles in an atom. First, the atomic number gives the number of protons. Second, in a neutral atom the number of electrons is the same as the number of protons. Third, find the mass number. Last, subtract the atomic number from the mass number to get the number of neutrons.
- **Audio Asset Reference**: `audio/s10.041c2bd6c2d0.mp3` (22s, source: tts)
- **Visual Type**: `svg` · **Description**: Four numbered steps: find Z: protons = Z, electrons = protons (if neutral), find A from the question, neutrons = A - Z.
- **Image Asset Reference**: `None` · **Alt Text**: Four numbered steps: find Z: protons = Z, electrons = protons (if neutral), find A from the question, neutrons = A - Z.
- **Visual Labels**: Find Z: protons = Z, Electrons = protons (if neutral), Find A from the question, Neutrons = A - Z
- **SVG Content**: Present (2147 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 5 of B8.1.1.2.1 (determine the number of protons, neutrons and electrons in an atom).
- **Existing Checkpoints After This Slide**: None

## Slide 11: `s11` — Worked Example: Sodium
- **Learning Objective / Purpose**: Count particles in sodium (indicator 1, exemplar 5).
- **Indicators**: B8.1.1.2.1
- **On-Screen Educational Text**:
  - Sodium: Z is 11, A is 23
  - Protons and electrons: 11
  - Neutrons: 23 minus 11
- **Key Ideas**: Sodium has 11 protons. | A neutral sodium atom has 11 electrons. | Sodium has 23 - 11 = 12 neutrons.
- **Complete Narration Text**: Let us try sodium, with atomic number eleven and mass number twenty-three. The number of protons is the atomic number, so sodium has eleven protons. The atom is neutral, so it has eleven electrons. The number of neutrons is twenty-three minus eleven, which is twelve. In exams you may see sodium written with the mass number on top and the atomic number at the bottom, like this: twenty-three over eleven, Na.
- **Audio Asset Reference**: `audio/s11.b132c2769c81.mp3` (28s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 3 rows: Protons, 11; Electrons, 11; Neutrons, 23 - 11 = 12.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 3 rows: Protons, 11; Electrons, 11; Neutrons, 23 - 11 = 12.
- **Visual Labels**: Sodium: Z 11, A 23, Number, Protons, Electrons, Neutrons, 11, 11, 23 - 11 = 12
- **SVG Content**: Present (2199 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 5 of B8.1.1.2.1. Sodium is Na, from the Latin natrium. Standard notation: the mass number is written at the top left of the symbol and the atomic number at the bottom left (23 over 11 Na).
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcB2` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qB.2`: Sodium has Z = 11 and A = 23. How many neutrons has it? — Correct: d (a: 11 | b: 23 | c: 34 | d: 12)

## Slide 12: `s12` — More Practice
- **Learning Objective / Purpose**: Count particles in oxygen, aluminium and carbon (indicator 1, exemplar 5).
- **Indicators**: B8.1.1.2.1
- **On-Screen Educational Text**:
  - Oxygen: 8, 8, 8
  - Aluminium: 13, 13, 14
  - Carbon: 6, 6, 6
- **Key Ideas**: Oxygen has 8 protons, 8 electrons and 8 neutrons. | Aluminium has 13 protons, 13 electrons and 14 neutrons. | Always subtract Z from A to find the neutrons.
- **Complete Narration Text**: Now try these three. Oxygen has eight protons, eight electrons and eight neutrons. Aluminium, which we get from bauxite in Ghana, has thirteen protons, thirteen electrons and fourteen neutrons. Carbon has six protons, six electrons and six neutrons. Check each one by subtracting the atomic number from the mass number.
- **Audio Asset Reference**: `audio/s12.beba33fd42ee.mp3` (20s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 3 rows: Oxygen: Z 8, A 16, 8, 8, 8; Aluminium: Z 13, A 27, 13, 13, 14; Carbon: Z 6, A 12, 6, 6, 6.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 3 rows: Oxygen: Z 8, A 16, 8, 8, 8; Aluminium: Z 13, A 27, 13, 13, 14; Carbon: Z 6, A 12, 6, 6, 6.
- **Visual Labels**: Atom, p, e, n, Oxygen: Z 8, A 16, Aluminium: Z 13, A 27, Carbon: Z 6, A 12, 8, 8, 8, 13, 13, 14, 6, 6, 6
- **SVG Content**: Present (2216 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 5 of B8.1.1.2.1. The columns are protons, electrons and neutrons (p, e, n). Pupils should repeat the working in their books.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpB` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `cpB.1`: The mass number of an atom is the number of... — Correct: c (a: protons only in the atom | b: neutrons only in the atom | c: protons plus neutrons | d: protons plus electrons)
    - [mcq] `cpB.2`: An atom has Z = 8 and A = 16. How many protons, electrons and neutrons has it, in that order? — Correct: b (a: 8, 8 and 16 | b: 8, 8 and 8 | c: 16, 16 and 8 | d: 8, 16 and 8)
    - [mcq] `cpB.3`: Two atoms both have 6 protons. What must be true? — Correct: a (a: They are atoms of the same element | b: They have the same mass number | c: They have the same number of neutrons | d: They are atoms of different elements)
    - [mcq] `cpB.4`: Why can we find the electrons of a neutral atom from its atomic number? — Correct: d (a: Z counts the neutrons and the electrons | b: The electrons always equal the neutrons | c: The electrons are found by A minus Z | d: Electrons equal protons, and Z counts protons)

## Slide 13: `s13` — Elements and Their Symbols
- **Learning Objective / Purpose**: Element symbols (indicator 2, exemplar 1).
- **Indicators**: B8.1.1.2.2
- **On-Screen Educational Text**:
  - Each element has a symbol
  - The first letter is a capital
  - Gold is Au; iron is Fe
- **Key Ideas**: Each element has a symbol of one or two letters. | The first letter is a capital. | Gold is Au and iron is Fe.
- **Complete Narration Text**: Chemists give each element a short symbol of one or two letters, and the first letter is always a capital. Oxygen is O and sodium is Na. Gold is Au, from its Latin name aurum, and iron is Fe, from ferrum. Ghana is well known for gold, and it also has bauxite, which gives aluminium. These symbols are used all over the world.
- **Audio Asset Reference**: `audio/s13.da68bc024d14.mp3` (25s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 4 rows: Oxygen, O; Sodium, Na; Gold, Au; Iron, Fe.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 4 rows: Oxygen, O; Sodium, Na; Gold, Au; Iron, Fe.
- **Visual Labels**: Element, Symbol, Oxygen, Sodium, Gold, Iron, O, Na, Au, Fe
- **SVG Content**: Present (2672 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B8.1.1.2.2 (explain how elements are arranged using the periodic table). Symbols prepare pupils to read the table. Gold and bauxite are Ghanaian examples from general knowledge.
- **Existing Checkpoints After This Slide**: None

## Slide 14: `s14` — Part of the Periodic Table
- **Learning Objective / Purpose**: The first 20 elements (indicator 2, exemplar 1).
- **Indicators**: B8.1.1.2.2
- **On-Screen Educational Text**:
  - Simplified teaching layout
  - Each box: symbol and atomic number
  - Rows are called periods
- **Key Ideas**: This is a simplified layout of the first 20 elements. | Each element has one more proton than the one before it. | The complete modern periodic table has 18 groups.
- **Complete Narration Text**: This is a simplified teaching layout of the periodic table, showing the first twenty elements. Each box shows the symbol and the atomic number. The rows are called periods, and period 1 has hydrogen and helium. Period 2 starts with lithium, with three protons. Each element has one more proton than the one before it, and the complete modern table has eighteen groups.
- **Audio Asset Reference**: `audio/s14.6688402501c7.mp3` (25s, source: tts)
- **Visual Type**: `svg` · **Description**: A simplified teaching layout with four rows. Row 1: H 1 and He 2. Row 2: Li 3, Be 4, B 5, C 6, N 7, O 8, F 9, Ne 10. Row 3: Na 11, Mg 12, Al 13, Si 14, P 15, S 16, Cl 17, Ar 18. Row 4: K 19 and Ca 20. Each box shows the symbol and the atomic number. The label reads Simplified teaching layout.
- **Image Asset Reference**: `None` · **Alt Text**: A simplified teaching layout with four rows. Row 1: H 1 and He 2. Row 2: Li 3, Be 4, B 5, C 6, N 7, O 8, F 9, Ne 10. Row 3: Na 11, Mg 12, Al 13, Si 14, P 15, S 16, Cl 17, Ar 18. Row 4: K 19 and Ca 20. Each box shows the symbol and the atomic number. The label reads Simplified teaching layout.
- **Visual Labels**: H, 1, He, 2, Li, 3, Be, 4, B, 5, C, 6, N, 7, O, 8, F, 9, Ne, 10, Na, 11, Mg, 12, Al, 13, Si, 14, P, 15, S, 16, Cl, 17, Ar, 18, K, 19, Ca, 20, Simplified teaching layout
- **SVG Content**: Present (8230 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B8.1.1.2.2. Exemplar 1 of B8.1.1.2.1 is also linked here. This is a simplified 8-column teaching layout, with hydrogen and helium at the two ends of period 1. The complete modern table has 18 groups, so B, C, N, O, F and Ne are groups 13 to 18 there. Only the first 20 elements are needed.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcC1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qC.1`: Apart from the symbol, what does each box of the periodic table show? — Correct: a (a: The atomic number | b: The mass of the atom in grams | c: The colour of the element | d: The year of discovery)

## Slide 15: `s15` — Arranged by Protons
- **Learning Objective / Purpose**: How elements are ordered (indicator 2, exemplar 1).
- **Indicators**: B8.1.1.2.2
- **On-Screen Educational Text**:
  - Order of increasing protons
  - The atomic number decides the place
  - No two elements share a number
- **Key Ideas**: Elements are in order of atomic number. | Hydrogen has 1 proton, helium 2, lithium 3 and beryllium 4. | No two elements have the same atomic number.
- **Complete Narration Text**: The periodic table arranges the elements in order of their atomic number, that is, the number of protons in the nucleus. Hydrogen has one proton, helium has two, lithium has three and beryllium has four. No two elements have the same number of protons. So the number of protons decides where an element sits in the table.
- **Audio Asset Reference**: `audio/s15.3434db941d3c.mp3` (23s, source: tts)
- **Visual Type**: `svg` · **Description**: Periodic table: Elements in order of protons. Order: H: 1 proton, He: 2 protons, Li: 3 protons, Be: 4 protons.
- **Image Asset Reference**: `None` · **Alt Text**: Periodic table: Elements in order of protons. Order: H: 1 proton, He: 2 protons, Li: 3 protons, Be: 4 protons.
- **Visual Labels**: Periodic table, Elements in order of protons, H: 1 proton, He: 2 protons, Li: 3 protons, Be: 4 protons
- **SVG Content**: Present (1899 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B8.1.1.2.2 (explain how elements are arranged in order of the number of protons).
- **Existing Checkpoints After This Slide**: None

## Slide 16: `s16` — Periods and Groups
- **Learning Objective / Purpose**: Periods and groups (indicator 2, exemplar 1).
- **Indicators**: B8.1.1.2.2
- **On-Screen Educational Text**:
  - Periods are rows
  - Groups are columns
  - A group has similar properties
- **Key Ideas**: Periods are rows and groups are columns. | Elements in a group have similar properties. | The period number is the number of shells.
- **Complete Narration Text**: The rows of the periodic table are called periods, and the columns are called groups. Elements in the same group have similar properties. For example, lithium, sodium and potassium are alkali metals in Group 1, and they are soft metals that react strongly with water. Hydrogen sits at the top of the first column in this simplified table, but it is a non-metal gas, not a Group 1 metal. The period number also tells us how many shells the atoms have.
- **Audio Asset Reference**: `audio/s16.6bb1cd6f6e68.mp3` (32s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 3 rows: Period, A row across; Group, A column down; Same group, Similar properties.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 3 rows: Period, A row across; Group, A column down; Same group, Similar properties.
- **Visual Labels**: Word, Meaning, Period, Group, Same group, A row across, A column down, Similar properties
- **SVG Content**: Present (2206 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B8.1.1.2.2. The reaction of Group 1 metals with water is only described; it is explained by the teacher or shown in a suitable educational video, and pupils never test these metals themselves. Hydrogen is placed above Group 1 in the simplified layout for convenience, but it is a non-metal gas. The period number equals the number of occupied shells for these elements. Do not confuse the 8-column teaching layout with the 18-group numbering of the modern table.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcC2` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qC.2`: What is a column of the periodic table called? — Correct: c (a: A period | b: A shell | c: A group | d: An ion)

## Slide 17: `s17` — Using the Periodic Table
- **Learning Objective / Purpose**: Read an element from the table (indicator 2, exemplar 1).
- **Indicators**: B8.1.1.2.2
- **On-Screen Educational Text**:
  - Find the element
  - Read the atomic number
  - Protons equal the atomic number
- **Key Ideas**: Find the symbol, then read the atomic number. | The atomic number is the number of protons. | A neutral atom has the same number of electrons.
- **Complete Narration Text**: We can use the periodic table to learn about an atom. First, find the element by its symbol. Second, read its atomic number. The atomic number is the number of protons. In a neutral atom, the number of electrons is the same, so magnesium, with atomic number twelve, has twelve protons and twelve electrons.
- **Audio Asset Reference**: `audio/s17.4d93291dc1c6.mp3` (22s, source: tts)
- **Visual Type**: `svg` · **Description**: Four numbered steps: find the element in the table, read its atomic number, atomic number = protons, neutral atom: electrons = protons.
- **Image Asset Reference**: `None` · **Alt Text**: Four numbered steps: find the element in the table, read its atomic number, atomic number = protons, neutral atom: electrons = protons.
- **Visual Labels**: Find the element in the table, Read its atomic number, Atomic number = protons, Neutral atom: electrons = protons
- **SVG Content**: Present (2165 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B8.1.1.2.2. Exemplar 5 of B8.1.1.2.1 is reinforced here.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpC` (retryRule: 2 attempts, then show the answer with the explanation):
    - [tapDiagram] `cpC.1`: Tap the element that has 8 protons. — Hotspot: h3
    - [mcq] `cpC.2`: Using the periodic table, which atom has 11 protons? — Correct: b (a: Neon (Ne) | b: Sodium (Na) | c: Magnesium (Mg) | d: Fluorine (F))
    - [mcq] `cpC.3`: In what order are the elements arranged in the periodic table? — Correct: d (a: Increasing number of neutrons | b: Alphabetical order of their names | c: Increasing number of shells | d: Increasing number of protons)
    - [mcq] `cpC.4`: Lithium, sodium and potassium are in the same group. What does that suggest? — Correct: c (a: They have the same number of protons | b: They have the same mass number | c: They have similar properties | d: They are in the same period)

## Slide 18: `s18` — Electron Shells
- **Learning Objective / Purpose**: Shells and their capacities (indicator 2, exemplar 2).
- **Indicators**: B8.1.1.2.2
- **On-Screen Educational Text**:
  - Electrons are in shells
  - The arrangement is the electron configuration
  - Fill the inner shell first
- **Key Ideas**: The arrangement of electrons in shells is the electron configuration. | For the first 20 elements we use 2, 8, 8 and then the fourth shell. | The inner shell fills first.
- **Complete Narration Text**: The way electrons are arranged in shells is called the electron configuration. Each shell can hold only a certain number of electrons. For the first twenty elements we use a simplified school pattern: up to two electrons in the first shell, up to eight in the second, and eight in the third before the fourth shell starts. Electrons fill the shell nearest the nucleus first. This is a simplified pattern for these elements, and it is not a rule for all atoms.
- **Audio Asset Reference**: `audio/s18.0451580d19b0.mp3` (33s, source: tts)
- **Visual Type**: `svg` · **Description**: Electron configuration: How electrons are arranged. First 20 elements: Shell 1: up to 2, Shell 2: up to 8, Shell 3: 8 (school), Inner shells first.
- **Image Asset Reference**: `None` · **Alt Text**: Electron configuration: How electrons are arranged. First 20 elements: Shell 1: up to 2, Shell 2: up to 8, Shell 3: 8 (school), Inner shells first.
- **Visual Labels**: Electron configuration, How electrons are arranged, Shell 1: up to 2, Shell 2: up to 8, Shell 3: 8 (school), Inner shells first
- **SVG Content**: Present (1944 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 of B8.1.1.2.2 (draw the distribution of electrons, the electron configuration). The 2, 8, 8, 2 pattern is a simplified school-level arrangement for the first 20 elements, not a universal rule: in the full model the third shell can hold more than eight electrons. Larger atoms follow more complex rules that are not taught here.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcD1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qD.1`: How many electrons can the first shell hold? — Correct: d (a: Eight | b: One | c: Eighteen | d: Two)

## Slide 19: `s19` — Writing the Arrangement
- **Learning Objective / Purpose**: Steps for writing an electron arrangement (indicator 2, exemplar 2).
- **Indicators**: B8.1.1.2.2
- **On-Screen Educational Text**:
  - Count the electrons
  - Fill the shells from the inside out
  - Write the electron configuration
- **Key Ideas**: Count the electrons first. | Fill the shells in order, from the inside out. | Carbon, with 6 electrons, has the electron configuration 2, 4.
- **Complete Narration Text**: Here is how to write the electron configuration of an atom. First, find the number of electrons, which is the same as the atomic number for a neutral atom. Second, put up to two electrons in the first shell. Third, put up to eight in the second shell. Last, put the remaining electrons in the third shell, using the simplified school pattern, and then the fourth shell. For example, carbon has six electrons, so its electron configuration is two, four.
- **Audio Asset Reference**: `audio/s19.66e1ff27cfad.mp3` (32s, source: tts)
- **Visual Type**: `svg` · **Description**: Four numbered steps: find the number of electrons, fill shell 1 first: up to 2, then shell 2: up to 8, then shell 3, then shell 4.
- **Image Asset Reference**: `None` · **Alt Text**: Four numbered steps: find the number of electrons, fill shell 1 first: up to 2, then shell 2: up to 8, then shell 3, then shell 4.
- **Visual Labels**: Find the number of electrons, Fill shell 1 first: up to 2, Then shell 2: up to 8, Then shell 3, then shell 4
- **SVG Content**: Present (2159 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 of B8.1.1.2.2. Pupils write each electron configuration as numbers separated by commas, for example 2, 4. The simplified pattern for the first 20 elements is used; it is not a rule for all atoms.
- **Existing Checkpoints After This Slide**: None

## Slide 20: `s20` — Sodium: 2, 8, 1
- **Learning Objective / Purpose**: Electron diagram of sodium (indicator 2, exemplar 2).
- **Indicators**: B8.1.1.2.2
- **On-Screen Educational Text**:
  - Sodium has 11 electrons
  - Electron configuration: 2, 8, 1
  - The outer electron is a valence electron
- **Key Ideas**: Sodium has 11 protons and 11 electrons. | The electron configuration of sodium is 2, 8, 1. | Sodium has 1 valence electron in its outer shell.
- **Complete Narration Text**: Look at sodium. It has eleven protons in the nucleus and eleven electrons. Two electrons fill the first shell. Eight fill the second shell. The last electron is alone in the third shell. So the electron configuration of sodium is two, eight, one. An electron in the outermost shell is called a valence electron, and sodium has one, like the other Group 1 elements.
- **Audio Asset Reference**: `audio/s20.4e287071d165.mp3` (26s, source: tts)
- **Visual Type**: `svg` · **Description**: A sodium atom with a nucleus marked 11 p. Shell 1 holds 2 electrons, shell 2 holds 8 electrons and shell 3 holds 1 electron, so the arrangement is 2, 8, 1.
- **Image Asset Reference**: `None` · **Alt Text**: A sodium atom with a nucleus marked 11 p. Shell 1 holds 2 electrons, shell 2 holds 8 electrons and shell 3 holds 1 electron, so the arrangement is 2, 8, 1.
- **Visual Labels**: 11p, Shell 3: 1, Shell 2: 8, Shell 1: 2, Nucleus: 11 p, Sodium: 2, 8, 1
- **SVG Content**: Present (2741 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 of B8.1.1.2.2. Learners should draw this diagram themselves with a labelled nucleus and shells. Valence electrons are the electrons in the outermost shell; elements in the same group have the same number of them.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcD2` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qD.2`: What is the electron configuration of sodium? — Correct: b (a: 2, 9 | b: 2, 8, 1 | c: 8, 2, 1 | d: 2, 8, 2)

## Slide 21: `s21` — More Electron Arrangements
- **Learning Objective / Purpose**: Arrangements of some elements (indicator 2, exemplar 2).
- **Indicators**: B8.1.1.2.2
- **On-Screen Educational Text**:
  - Electron configuration of four elements
  - Valence electrons: the outer shell
  - Same group, same valence electrons
- **Key Ideas**: Hydrogen is 1, oxygen is 2, 6 and chlorine is 2, 8, 7. | Valence electrons are the electrons in the outer shell. | Elements in the same group have the same number of valence electrons.
- **Complete Narration Text**: Here are some electron configurations to check. Hydrogen has one electron, so its configuration is one. Oxygen has eight electrons: two, six. Chlorine has seventeen: two, eight, seven. Calcium has twenty: two, eight, eight, two. The electrons in the outer shell are the valence electrons, and elements in the same group have the same number of them. The number of shells matches the period.
- **Audio Asset Reference**: `audio/s21.51e1021249d6.mp3` (26s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 4 rows: Hydrogen, 1; Oxygen, 2, 6; Chlorine, 2, 8, 7; Calcium, 2, 8, 8, 2.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 4 rows: Hydrogen, 1; Oxygen, 2, 6; Chlorine, 2, 8, 7; Calcium, 2, 8, 8, 2.
- **Visual Labels**: Element, Configuration, Hydrogen, Oxygen, Chlorine, Calcium, 1, 2, 6, 2, 8, 7, 2, 8, 8, 2
- **SVG Content**: Present (2703 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 of B8.1.1.2.2. The links to group and period are for the first 20 elements. Teacher-assessed drawing activity (not scored by the app): each pupil is given an atom from the first 20 elements, works out its electrons, draws the shells, places the electrons in each shell and writes the electron configuration. Rubric (4 marks): 1 electrons counted correctly; 1 correct number of shells; 1 correct electrons in each shell; 1 final electron configuration written. Give feedback on the shell number and the electron count separately. Exemplar 1 of B8.1.1.2.2 is also supported here.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpD` (retryRule: 2 attempts, then show the answer with the explanation):
    - [sequence] `cpD.1`: Put the steps for writing an electron configuration in order. — Order: st1 -> st4 -> st2 -> st3
    - [mcq] `cpD.2`: Carbon has 6 electrons. What is its electron configuration? — Correct: a (a: 2, 4 | b: 2, 2, 2 | c: 2, 8 | d: 4, 2)
    - [mcq] `cpD.3`: An atom has the electron configuration 2, 8, 7. How many electrons and shells has it? — Correct: b (a: 7 electrons in 3 shells | b: 17 electrons in 3 shells | c: 17 electrons in 7 shells | d: 10 electrons in 3 shells)
    - [mcq] `cpD.4`: Why is magnesium (12 electrons) written 2, 8, 2 and not 2, 10? — Correct: c (a: Magnesium has only two shells | b: The first shell holds 10 electrons | c: The second shell holds only 8 electrons | d: Electrons fill the outer shell first)

## Slide 22: `s22` — What Is an Ion?
- **Learning Objective / Purpose**: Ions (indicator 2, exemplar 3).
- **Indicators**: B8.1.1.2.2
- **On-Screen Educational Text**:
  - An ion is a charged particle
  - Cation: positive. Anion: negative
  - A full outer shell is stable
- **Key Ideas**: An ion is a charged particle. | A cation is a positive ion and an anion is a negative ion. | Atoms gain or lose electrons to get a full outer shell.
- **Complete Narration Text**: An atom can gain or lose electrons, and then it becomes an ion. An ion is a particle with an overall electrical charge. Atoms do this to get a full, stable outer shell, like the noble gases helium, neon and argon. If an atom loses electrons, it has more protons than electrons, so it becomes a positive ion, called a cation. If it gains electrons, it becomes a negative ion, called an anion. The number of protons does not change.
- **Audio Asset Reference**: `audio/s22.98c6410819ff.mp3` (32s, source: tts)
- **Visual Type**: `svg` · **Description**: Ion: A particle with an overall charge. Formed when atoms: Loses: cation (+), Gains: anion (-), Full outer shell, Protons unchanged.
- **Image Asset Reference**: `None` · **Alt Text**: Ion: A particle with an overall charge. Formed when atoms: Loses: cation (+), Gains: anion (-), Full outer shell, Protons unchanged.
- **Visual Labels**: Ion, A particle with an overall charge, Loses: cation (+), Gains: anion (-), Full outer shell, Protons unchanged
- **SVG Content**: Present (1910 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 3 of B8.1.1.2.2 (explain the formation of ions). Only simple ions are used. Charge = number of protons minus number of electrons. Atoms lose or gain electrons to reach a full, stable outer shell like a noble gas (helium, neon, argon).
- **Existing Checkpoints After This Slide**: None

## Slide 23: `s23` — Sodium and Chloride Ions
- **Learning Objective / Purpose**: Forming Na+ and Cl- (indicator 2, exemplar 3).
- **Indicators**: B8.1.1.2.2
- **On-Screen Educational Text**:
  - Sodium loses one electron: cation
  - Chlorine gains one electron: anion
  - Both reach a full outer shell
- **Key Ideas**: Na loses 1 electron to become the cation Na+. | Cl gains 1 electron to become the anion Cl-. | Each ion has a full outer shell, and the protons stay the same.
- **Complete Narration Text**: Let us see how ions form. A sodium atom has eleven protons and eleven electrons, with the electron configuration two, eight, one. It loses one electron to get a full outer shell and becomes Na+, with two, eight, which is a cation with a charge of plus one. A chlorine atom has seventeen protons and seventeen electrons, with the configuration two, eight, seven. It gains one electron, giving eighteen electrons and two, eight, eight, so Cl- is an anion with a charge of minus one.
- **Audio Asset Reference**: `audio/s23.c3bd25bde505.mp3` (34s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 2 rows: Na (2, 8, 1) -> Na+ (2, 8), Cation; Cl (2, 8, 7) -> Cl- (2, 8, 8), Anion.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 2 rows: Na (2, 8, 1) -> Na+ (2, 8), Cation; Cl (2, 8, 7) -> Cl- (2, 8, 8), Anion.
- **Visual Labels**: Atom -> ion, Ion type, Na (2, 8, 1) -> Na+ (2, 8), Cl (2, 8, 7) -> Cl- (2, 8, 8), Cation, Anion
- **SVG Content**: Present (1741 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 3 of B8.1.1.2.2. Na+ has 11 protons and 10 electrons; Cl- has 17 protons and 18 electrons. Both ions have a full outer shell. Common salt, from the salt pans in the earlier lesson, contains sodium ions and chloride ions. This links to the mixtures lesson.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcE1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qE.1`: An atom loses one electron. What kind of ion does it form? — Correct: a (a: A cation (positive ion) | b: An anion (negative ion) | c: A neutron in the nucleus | d: A new element altogether)

## Slide 24: `s24` — Molecules
- **Learning Objective / Purpose**: Molecules (indicator 2, exemplar 4).
- **Indicators**: B8.1.1.2.2
- **On-Screen Educational Text**:
  - Bonded atoms make a molecule
  - Water is H₂O
  - Salt is made of ions, not molecules
- **Key Ideas**: A molecule is two or more chemically bonded atoms. | A water molecule is H₂O. | Sodium chloride is ions in a lattice, not NaCl molecules.
- **Complete Narration Text**: A molecule is two or more atoms that are joined together by chemical bonds. In a water molecule, one oxygen atom is joined to two hydrogen atoms, so water is written H2O. The atoms in a molecule are held together by bonds, which involve their electrons. Some molecules, such as oxygen gas, contain only one kind of atom. Sodium chloride is different: it is made of sodium ions and chloride ions in a regular pattern called a lattice, so it has no separate NaCl molecules.
- **Audio Asset Reference**: `audio/s24.28a2832da64d.mp3` (34s, source: tts)
- **Visual Type**: `svg` · **Description**: A water molecule: one oxygen atom joined to two hydrogen atoms. Labels name the oxygen atom, the hydrogen atom and the water molecule H₂O.
- **Image Asset Reference**: `None` · **Alt Text**: A water molecule: one oxygen atom joined to two hydrogen atoms. Labels name the oxygen atom, the hydrogen atom and the water molecule H₂O.
- **Visual Labels**: O, H, H, Oxygen atom, Hydrogen atom, Water molecule: H₂O
- **SVG Content**: Present (1934 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 4 of B8.1.1.2.2 (describe a molecule as a combination of atoms). A molecule is two or more chemically bonded atoms. The bent shape of water is drawn as a simple model. Bonding is only named, not explained. Ionic compounds such as sodium chloride are not made of molecules: the sodium and chloride ions form a lattice, a regular repeating pattern.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcE2` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qE.2`: What is a molecule? — Correct: d (a: A single atom of one element | b: An atom that has a charge on it | c: The centre of an atom, the nucleus | d: Two or more atoms bonded together)

## Slide 25: `s25` — Molecules We Know
- **Learning Objective / Purpose**: Examples of molecules (indicator 2, exemplar 4).
- **Indicators**: B8.1.1.2.2
- **On-Screen Educational Text**:
  - O₂ and H₂: molecules of elements
  - H₂O and CO₂: molecules of compounds
  - CO₂ is carbon (IV) oxide
- **Key Ideas**: O₂ and H₂ are molecules of elements. | H₂O and CO₂ are molecules of compounds. | Carbon dioxide is also called carbon (IV) oxide.
- **Complete Narration Text**: Here are some molecules we know. Oxygen gas, which is part of the air we breathe, and hydrogen gas are molecules of elements, because each has only one kind of atom. Water, with two hydrogen atoms and one oxygen atom, is a molecule of a compound, because it has different kinds of atoms. Carbon dioxide, which plants use, is also a molecule of a compound, with one carbon atom and two oxygen atoms. Its chemical name is carbon (IV) oxide.
- **Audio Asset Reference**: `audio/s25.f30afd699746.mp3` (32s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 4 rows: Oxygen, O₂, Element: 2 O atoms; Hydrogen, H₂, Element: 2 H atoms; Water, H₂O, Compound: 2 H, 1 O; Carbon dioxide, CO₂, Compound: 1 C, 2 O.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 4 rows: Oxygen, O₂, Element: 2 O atoms; Hydrogen, H₂, Element: 2 H atoms; Water, H₂O, Compound: 2 H, 1 O; Carbon dioxide, CO₂, Compound: 1 C, 2 O.
- **Visual Labels**: Molecule, Type and atoms, Oxygen, O₂, Hydrogen, H₂, Water, H₂O, Carbon dioxide, CO₂, Element: 2 O atoms, Element: 2 H atoms, Compound: 2 H, 1 O, Compound: 1 C, 2 O
- **SVG Content**: Present (3016 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 4 of B8.1.1.2.2. Formulae are written with plain digits here (O₂, H₂O, CO₂). In printed books the digits are subscripts. O₂ and H₂ are molecules of elements; H₂O and CO₂ are molecules of compounds. Carbon (IV) oxide is the IUPAC-style name used in NaCCA materials.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpE` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `cpE.1`: A chlorine atom (17 protons) gains 1 electron to make an anion. What is true of this anion? — Correct: a (a: 18 electrons and a charge of minus one | b: 16 electrons and a charge of plus one | c: 18 protons and a charge of minus one | d: 17 electrons and no charge)
    - [mcq] `cpE.2`: Why does an atom that loses electrons become a positive ion, a cation? — Correct: d (a: It has more neutrons than protons | b: It loses protons as well | c: Electrons are positive | d: It has more protons than electrons)
    - [mcq] `cpE.3`: Which formula shows a molecule made of atoms of two different elements? — Correct: b (a: O₂ (oxygen gas) | b: H₂O (water) | c: H₂ (hydrogen gas) | d: N₂ (nitrogen gas))
    - [mcq] `cpE.4`: How many atoms are in one molecule of carbon dioxide, CO₂? — Correct: c (a: 2 atoms: 1 carbon and 1 oxygen | b: 3 atoms: 2 carbon and 1 oxygen | c: 3 atoms: 1 carbon and 2 oxygen | d: 4 atoms: 2 carbon and 2 oxygen)

## Slide 26: `s26` — Recap: Atoms and the Periodic Table
- **Learning Objective / Purpose**: Recap.
- **Indicators**: B8.1.1.2.1, B8.1.1.2.2
- **On-Screen Educational Text**:
  - Atoms have protons, neutrons and electrons
  - The periodic table follows atomic number
  - Atoms can form ions and molecules
- **Key Ideas**: An atom has protons, neutrons and electrons. | The periodic table is in order of atomic number. | Atoms form ions by gaining or losing electrons, and molecules by joining.
- **Complete Narration Text**: Let us recap. An atom is made of protons and neutrons in the nucleus, with electrons in shells around it. Protons are positive, electrons are negative and neutrons have no charge. The atomic number is the number of protons, and the mass number is protons plus neutrons. The periodic table arranges the elements by atomic number, and the electron configuration shows how the electrons fill the shells. Atoms can gain or lose electrons to form cations and anions, and atoms can join to form molecules.
- **Audio Asset Reference**: `audio/s26.b84d69790ca1.mp3` (34s, source: tts)
- **Visual Type**: `svg` · **Description**: A top box, atoms, with arrows to two columns: inside the atom, with protons plus one, electrons minus one and neutrons zero; and arranging atoms, with the periodic table, electron shells, and ions and molecules.
- **Image Asset Reference**: `None` · **Alt Text**: A top box, atoms, with arrows to two columns: inside the atom, with protons plus one, electrons minus one and neutrons zero; and arranging atoms, with the periodic table, electron shells, and ions and molecules.
- **Visual Labels**: Atoms, Inside the atom, Arranging atoms, Protons: +1, Electrons: -1, Neutrons: 0, Periodic table, Electron shells, Ions, molecules
- **SVG Content**: Present (2871 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Final slide before the mastery check.
- **Existing Checkpoints After This Slide**: None

## End-of-Lesson Mastery Check (Pass Mark: 4)
- [mcq] `mastery.1`: An atom has 15 protons and a mass number of 31. How many neutrons has it? — Correct: a (a: 16 | b: 15 | c: 31 | d: 46)
- [mcq] `mastery.2`: Which pair correctly matches a particle with its charge? — Correct: b (a: Proton: negative; electron: positive | b: Proton: positive; neutron: no charge | c: Neutron: positive; electron: none | d: Proton: no charge; neutron: negative)
- [mcq] `mastery.3`: Which statement about the periodic table is correct? — Correct: d (a: Elements are arranged by increasing number of neutrons | b: Elements are arranged in alphabetical order | c: Elements are arranged by their colour | d: Elements are arranged by increasing number of protons)
- [mcq] `mastery.4`: A magnesium atom (Z = 12) loses 2 electrons. How many electrons and what charge has the ion? — Correct: c (a: 14 electrons and a charge of plus two | b: 10 electrons and a charge of minus two | c: 10 electrons and a charge of plus two | d: 12 electrons and a charge of plus two)
- [mcq] `mastery.5`: Which description of a water molecule is correct? — Correct: a (a: One oxygen atom joined to two hydrogen atoms | b: One hydrogen atom joined to two oxygen atoms | c: Two oxygen atoms joined to two hydrogen atoms | d: A single charged oxygen atom)

# Forces and Energy: Electricity and Electronics (Electronic Components and Circuits) (`b7-sci-t4-electronic-components-and-circuits`)

- **CDN packagePath**: `packages/b7-sci-t4-electronic-components-and-circuits.42ac37a6f2f1.json` (hash `42ac37a6f2f1`, updated `2026-11-23T06:14:32.201Z`)
- **Curriculum**: ges · **Class**: Basic 7 · **Subject**: Science · **Term**: 3
- **Content Standard**: B7.4.2.2
- **Indicators**: B7.4.2.2.1, B7.4.2.2.2, B7.4.2.2.3
- **Total Slides**: 25 · **Checkpoints**: 16 · **Mastery Check Items**: 5

## Slide 1: `s01` — Parts Inside a Gadget
- **Learning Objective / Purpose**: Hook: parts inside everyday gadgets.
- **Indicators**: B7.4.2.2.1, B7.4.2.2.2
- **On-Screen Educational Text**:
  - Gadgets are built from small parts
  - These are electronic components
  - We will build a circuit that lights an LED
- **Key Ideas**: Gadgets contain small parts. | These parts are electronic components. | We will build a simple LED circuit.
- **Complete Narration Text**: Good morning, class. Inside every radio, phone and torch there are small parts that control electricity. These are called electronic components. Today we will meet some of them, learn what each one does, and use them to build a simple circuit that lights an LED. Our teacher will help us handle everything safely. Are you ready to begin?
- **Audio Asset Reference**: `audio/s01.82edbc231d0d.mp3` (24s, source: tts)
- **Visual Type**: `illustration` · **Description**: A teacher and pupils looking at the inside of an opened battery radio on a table, with a small LED torch beside it.
- **Image Asset Reference**: `images/s01.ca29681e4763.webp` · **Alt Text**: A teacher and pupils looking at the inside of an opened battery radio on a table, with a small LED torch beside it.
- **Visual Labels**: None
- **SVG Content**: None
- **Existing Interactive Configuration**: None
- **Teacher Note**: AI image placement is approximate.
- **Existing Checkpoints After This Slide**: None

## Slide 2: `s02` — What Is a Component?
- **Learning Objective / Purpose**: Define electronic component (exemplar 1).
- **Indicators**: B7.4.2.2.1
- **On-Screen Educational Text**:
  - A component is a small part
  - Each part has its own job
  - Parts join to make a circuit
- **Key Ideas**: A component is a small part of a circuit. | Each component has its own job. | A circuit is a path for current.
- **Complete Narration Text**: An electronic component is a small part used to build an electronic circuit. Each component has its own job. For example, an LED gives light, and a resistor limits the current. A circuit is a path that electric current can follow. Components are joined by wires or tracks on a flat board called a circuit board.
- **Audio Asset Reference**: `audio/s02.0aa6350fe977.mp3` (23s, source: tts)
- **Visual Type**: `svg` · **Description**: Component: A part of an electronic circuit. Examples: LED, Resistor, Diode, Capacitor.
- **Image Asset Reference**: `None` · **Alt Text**: Component: a part of an electronic circuit. Examples: LED, Resistor, Diode, Capacitor.
- **Visual Labels**: Component, A part of an electronic circuit, LED, Resistor, Diode, Capacitor
- **SVG Content**: Present (1870 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B7.4.2.2.1.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcA1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qA.1`: What is an electronic component? — Correct: d (a: A large machine that makes electricity | b: A kind of battery used in radios only | c: A wire that joins a house to the mains | d: A small part of an electronic circuit)

## Slide 3: `s03` — Six Common Components
- **Learning Objective / Purpose**: Name common components (exemplar 1).
- **Indicators**: B7.4.2.2.1
- **On-Screen Educational Text**:
  - Six common components
  - Each one has a different job
  - We meet them one by one
- **Key Ideas**: The LED gives light. | The resistor limits the current. | The diode lets current flow one way.
- **Complete Narration Text**: Here are six common components. The LED gives light. The resistor limits the current. The diode lets current flow easily in one direction. The capacitor stores electric charge. The inductor is a coil of wire. The switch opens and closes the circuit. We will look at each one in turn. Learn their names and their jobs well, because we will use them all lesson.
- **Audio Asset Reference**: `audio/s03.58aae3e5c868.mp3` (27s, source: tts)
- **Visual Type**: `svg` · **Description**: Six boxes: LED, resistor, diode, capacitor, inductor and switch.
- **Image Asset Reference**: `None` · **Alt Text**: Six boxes in two columns naming LED, resistor, diode, capacitor, inductor and switch.
- **Visual Labels**: LED, Resistor, Diode, Capacitor, Inductor, Switch
- **SVG Content**: Present (1673 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B7.4.2.2.1. Pronounce LED as the letters L E D.
- **Existing Checkpoints After This Slide**: None

## Slide 4: `s04` — The LED
- **Learning Objective / Purpose**: Describe the LED and its types (exemplar 1).
- **Indicators**: B7.4.2.2.1, B7.4.2.2.3
- **On-Screen Educational Text**:
  - LED means light emitting diode
  - LEDs come in colours and sizes
  - On a typical new LED, the longer leg is positive
- **Key Ideas**: An LED is a light emitting diode. | LEDs come in many colours and sizes. | On a typical new LED, the longer leg is positive; a flat edge marks the negative side.
- **Complete Narration Text**: An LED is a small part that gives out light when a little current passes through it. LED stands for light emitting diode. LEDs come in different colours, such as red, yellow, green and white, and in different sizes. A typical new LED has two legs. The longer leg is positive and the shorter leg is negative, and a flat edge on the rim also marks the negative side. Legs may be trimmed, so check the flat edge too. An LED must be connected the right way round, or it will not light.
- **Audio Asset Reference**: `audio/s04.40a5dce2a9da.mp3` (38s, source: tts)
- **Visual Type**: `svg` · **Description**: LED: Light emitting diode. Colours: Red, Green, Yellow, White.
- **Image Asset Reference**: `None` · **Alt Text**: LED: light emitting diode. Colours: Red, Green, Yellow, White.
- **Visual Labels**: LED, Light emitting diode, Red, Green, Yellow, White
- **SVG Content**: Present (1840 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B7.4.2.2.1 (types of LEDs). Show real LEDs of different colours and sizes if you can. Use red, yellow or green LEDs for the three volt circuit: blue and white LEDs need about three volts or more and may not light on two dry cells. On a typical new two-legged LED the longer leg is the anode (positive); the flat edge on the rim marks the cathode (negative). If the legs have been trimmed or the LED is unusual, rely on the flat edge or check with a cell and resistor. [VERIFY] 'Types of LEDs' is covered as colours, sizes and leg markings.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcA2` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qA.2`: Which leg of an LED is positive? — Correct: b (a: The shorter leg | b: The longer leg | c: Both legs equally | d: Neither leg is positive)

## Slide 5: `s05` — The Resistor
- **Learning Objective / Purpose**: Describe the resistor (exemplar 1).
- **Indicators**: B7.4.2.2.1, B7.4.2.2.3
- **On-Screen Educational Text**:
  - A resistor limits the current
  - It is measured in ohms
  - Coloured bands show its value
- **Key Ideas**: A resistor limits current. | Its unit is the ohm. | Bigger resistance means less current.
- **Complete Narration Text**: A resistor is an electronic component. It limits the flow of current in a circuit. Its value is measured in a unit called the ohm. A bigger resistance lets less current through. Resistors protect parts such as LEDs, which could burn out if too much current flowed. Most resistors have coloured bands that tell us their value. Remember that a resistor only limits current and never creates it.
- **Audio Asset Reference**: `audio/s05.935bcf80049f.mp3` (28s, source: tts)
- **Visual Type**: `svg` · **Description**: Resistor: Limits the flow of current. Remember: Ohms, Colour bands, Protects LED.
- **Image Asset Reference**: `None` · **Alt Text**: Resistor: limits the flow of current. Remember: Ohms, Colour bands, Protects LED.
- **Visual Labels**: Resistor, Limits the flow of current, Ohms, Colour bands, Protects LED
- **SVG Content**: Present (1619 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B7.4.2.2.1.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpA` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `cpA.1`: What does LED stand for? — Correct: c (a: Light energy distributor | b: Large electric device | c: Light emitting diode | d: Lamp that emits direct current)
    - [mcq] `cpA.2`: Why does an LED need a resistor? — Correct: a (a: To limit the current so it is not damaged | b: To make the LED change colour when it is on | c: To store charge so the LED can glow longer | d: To let current flow in one direction only)
    - [mcq] `cpA.3`: Which component gives out light? — Correct: b (a: Resistor | b: LED | c: Capacitor | d: Inductor)

## Slide 6: `s06` — Colour Code, Part One
- **Learning Objective / Purpose**: Resistor colour code (exemplar 1).
- **Indicators**: B7.4.2.2.1
- **On-Screen Educational Text**:
  - Each colour stands for a number
  - Black is zero, brown is one
  - Red is two, orange is three
- **Key Ideas**: Each colour stands for a number. | Black is zero and brown is one. | Red is two and orange is three.
- **Complete Narration Text**: Resistor bands use a colour code. Each colour stands for a number. Black is zero. Brown is one. Red is two. Orange is three. Many common resistors use this code, so learning it helps us read their values. Keep this table in your mind, because we will use it on the next slides. It helps to say the colours in order, over and over, until you remember them.
- **Audio Asset Reference**: `audio/s06.88b92a691af3.mp3` (28s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 4 rows: Black, 0; Brown, 1; Red, 2; Orange, 3.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 4 rows: Black, 0; Brown, 1; Red, 2; Orange, 3.
- **Visual Labels**: Colour, Number, Black, Brown, Red, Orange, 0, 1, 2, 3
- **SVG Content**: Present (2990 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B7.4.2.2.1.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcB1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qB.1`: What number does the colour red stand for? — Correct: c (a: Zero | b: One | c: Two | d: Three)

## Slide 7: `s07` — Colour Code, Part Two
- **Learning Objective / Purpose**: Resistor colour code, continued.
- **Indicators**: B7.4.2.2.1
- **On-Screen Educational Text**:
  - Yellow is four, green is five
  - Blue is six, violet is seven
  - Grey is eight, white is nine
- **Key Ideas**: Yellow is four and green is five. | Blue is six and violet is seven. | Grey is eight and white is nine.
- **Complete Narration Text**: Here are the next six colours. Yellow is four. Green is five. Blue is six. Violet is seven. Grey is eight. White is nine. Now you know all ten colours. Say them in order: black, brown, red, orange, yellow, green, blue, violet, grey, white. Practise with a friend until you can say them without looking.
- **Audio Asset Reference**: `audio/s07.955c58c308cc.mp3` (23s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 6 rows: Yellow, 4; Green, 5; Blue, 6; Violet, 7; Grey, 8; White, 9.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 6 rows: Yellow, 4; Green, 5; Blue, 6; Violet, 7; Grey, 8; White, 9.
- **Visual Labels**: Colour, Number, Yellow, Green, Blue, Violet, Grey, White, 4, 5, 6, 7, 8, 9
- **SVG Content**: Present (4137 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B7.4.2.2.1. Show a real four band resistor if you have one. The slide shows all ten digits across two slides: black to orange on the first, yellow to white on this one.
- **Existing Checkpoints After This Slide**: None

## Slide 8: `s08` — Reading a Resistor
- **Learning Objective / Purpose**: Worked example of the colour code.
- **Indicators**: B7.4.2.2.1
- **On-Screen Educational Text**:
  - Hold the gold or silver band on the right
  - Bands one and two give digits; band three gives zeros
  - Band four is the tolerance
- **Key Ideas**: The first two bands give two digits. | The third band gives the number of zeros. | The fourth band, gold or silver, is the tolerance.
- **Complete Narration Text**: Let us read a resistor with four bands: brown, black, red and gold. Hold it so that the gold or silver band is on the right, and read from the left. The first band is brown, which is one. The second band is black, which is zero, so we have ten. The third band is red, so we add two zeros. Ten with two zeros is one thousand ohms. The fourth band, gold, is the tolerance, which shows how far the real value may differ from this. This simple method works for common four band resistors.
- **Audio Asset Reference**: `audio/s08.c86cfdd2aac7.mp3` (41s, source: tts)
- **Visual Type**: `svg` · **Description**: Four numbered steps: read the first band, read the second band, read the third band, write the value in ohms.
- **Image Asset Reference**: `None` · **Alt Text**: Four numbered steps for reading a resistor: read the first band, read the second band, read the third band, write the value in ohms.
- **Visual Labels**: Read the first band, Read the second band, Read the third band, Write the value in ohms
- **SVG Content**: Present (2134 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B7.4.2.2.1. Simplified method for four band resistors only: bands one and two are digits, band three is the number of zeros (black to white), band four is the tolerance (gold about five percent, silver about ten percent). Gold or silver as a third band, and five band resistors, are outside this lesson, so choose resistors accordingly. Pupils only need to name the fourth band; they do not calculate with it. Check any resistor with a multimeter if one is available.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpB` (retryRule: 2 attempts, then show the answer with the explanation):
    - [sequence] `cpB.1`: Put the steps for reading a resistor in order. — Order: st2 -> st4 -> st1 -> st3
    - [mcq] `cpB.2`: Which colour stands for five? — Correct: a (a: Green | b: Yellow | c: Violet | d: Orange)
    - [mcq] `cpB.3`: A four band resistor is brown, black, orange, gold. What is its value? — Correct: a (a: Ten thousand ohms | b: One thousand ohms | c: One hundred ohms | d: Ten ohms)

## Slide 9: `s09` — The Diode
- **Learning Objective / Purpose**: Describe the diode (indicator 3).
- **Indicators**: B7.4.2.2.3
- **On-Screen Educational Text**:
  - A diode lets current flow easily one way
  - P and N are regions of the diode
  - A band marks the N end
- **Key Ideas**: A diode lets current flow easily one way. | P and N are two regions inside the diode, not battery terminals. | A band on a real diode marks the N end.
- **Complete Narration Text**: A diode is a small part with two ends. It lets current flow easily in one direction, and it blocks almost all current in the other. Inside it, two joined pieces of material form a P N junction, called the P region and the N region. These are parts of the diode, not the battery terminals. On a real diode, a silver or coloured band near one end marks the N end, and the plain end is the P end. Current flows easily from P to N, like a gate that opens one way.
- **Audio Asset Reference**: `audio/s09.2cbff9fa24ee.mp3` (38s, source: tts)
- **Visual Type**: `svg` · **Description**: Diode: Current flows easily one way. A diode has: P region, N region, Band marks N end.
- **Image Asset Reference**: `None` · **Alt Text**: Diode: current flows one way only. A diode has: P region, N region, Band marks N end.
- **Visual Labels**: Diode, Current flows easily one way, P region, N region, Band marks N end
- **SVG Content**: Present (1622 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 of B7.4.2.2.2 and exemplar 1 of B7.4.2.2.3. P and N name the two types of material in the junction; doping is not taught. A real diode in reverse lets a tiny leakage current through and breaks down at a high reverse voltage; neither is taught, so say blocks almost all current rather than no current. On a real silicon diode the band marks the cathode, which is the N end. For an LED, the longer leg is the anode (P side) and the flat edge marks the cathode (N side). [VERIFY] Simplified description of the P N junction.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcC1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qC.1`: What do the letters P and N on a diode name? — Correct: d (a: The two terminals of a battery | b: Two colours that an LED can make | c: The two legs of a resistor | d: Two regions inside the diode)

## Slide 10: `s10` — Diode Direction
- **Learning Objective / Purpose**: Forward and reverse direction.
- **Indicators**: B7.4.2.2.2, B7.4.2.2.3
- **On-Screen Educational Text**:
  - P and N are the two ends of a diode
  - Forward: battery positive to the P end
  - Reverse: battery positive to the N end
- **Key Ideas**: P and N are regions of the diode. | Forward connection lets current flow. | Reverse connection blocks current.
- **Complete Narration Text**: Look at the diode carefully. The P region is one end of the diode. The N region is the other end. These are not the same as the battery terminals, which are also called positive and negative. When the positive terminal of the battery is joined to the P end, the diode is in the forward direction, and current flows. If we turn the diode round, the positive terminal meets the N end, the diode is in reverse, and almost no current flows. This is why the direction matters.
- **Audio Asset Reference**: `audio/s10.4fd4a71da143.mp3` (36s, source: tts)
- **Visual Type**: `svg` · **Description**: Four rows with arrows: P region, one end of the diode; N region, the other end; forward, positive to P, current flows; reverse, positive to N, blocked.
- **Image Asset Reference**: `None` · **Alt Text**: Four rows with arrows: P region, one end of the diode; N region, the other end; forward, positive to P, current flows; reverse, positive to N, blocked.
- **Visual Labels**: P region, N region, Forward, Reverse, One end of the diode, The other end, Positive to P, flows, Positive to N, blocked
- **SVG Content**: Present (2868 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: The tap item in the third section check uses this slide. Keep two ideas apart: P and N are regions inside the diode; positive and negative are the battery terminals. Forward means the battery positive goes to the P end (on a real diode, the plain end, away from the band). Reverse means it goes to the N end (the banded end). Say blocks almost all current for reverse: a real diode lets a tiny leakage current through, which is not taught.
- **Existing Checkpoints After This Slide**: None

## Slide 11: `s11` — The Inductor
- **Learning Objective / Purpose**: Describe the inductor (indicator 3).
- **Indicators**: B7.4.2.2.3
- **On-Screen Educational Text**:
  - An inductor is a coil of wire
  - It opposes sudden changes in current
  - It is found in radios and chargers
- **Key Ideas**: An inductor is a coil of wire. | It opposes sudden changes in current. | It is found in radios and chargers.
- **Complete Narration Text**: An inductor is a coil of wire. When current flows through it, it stores a little energy in a magnetic field. An inductor opposes sudden changes in the current. So it can slow down how fast the current rises or falls. Inductors are found in radios, phone chargers and many other gadgets. An inductor often looks like a small coil.
- **Audio Asset Reference**: `audio/s11.d03d2eed7130.mp3` (25s, source: tts)
- **Visual Type**: `svg` · **Description**: Inductor: A coil that resists change. Found in: Radios, Chargers, Filters.
- **Image Asset Reference**: `None` · **Alt Text**: Inductor: a coil that resists change. Found in: Radios, Chargers, Filters.
- **Visual Labels**: Inductor, A coil that resists change, Radios, Chargers, Filters
- **SVG Content**: Present (1612 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B7.4.2.2.3. [VERIFY] Simplified: magnetic field storage is kept to one sentence.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcC2` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qC.2`: What is an inductor? — Correct: d (a: A type of battery cell | b: A kind of LED light | c: A switch that opens a circuit | d: A coil of wire)

## Slide 12: `s12` — The Capacitor
- **Learning Objective / Purpose**: Describe the capacitor (exemplar 1).
- **Indicators**: B7.4.2.2.1, B7.4.2.2.3
- **On-Screen Educational Text**:
  - A capacitor stores charge
  - It can release the charge again
  - Never touch a large one in a gadget
- **Key Ideas**: A capacitor stores electric charge. | It can smooth the power supply. | Large capacitors can hold dangerous charge.
- **Complete Narration Text**: Next is the capacitor. It stores electric charge for a short time. When the circuit needs it, the capacitor releases the charge, which can smooth out changes in the power supply. A capacitor can also keep a small LED glowing for a moment after the power is switched off. Never touch a large capacitor in a gadget that has just been switched off, because it may still hold charge.
- **Audio Asset Reference**: `audio/s12.a2a51d29f91d.mp3` (29s, source: tts)
- **Visual Type**: `svg` · **Description**: Capacitor: Stores electric charge. It can: Store charge, Release it, Smooth power, Keep LED on.
- **Image Asset Reference**: `None` · **Alt Text**: Capacitor: stores electric charge. It can: Store charge, Release it, Smooth power, Keep LED on.
- **Visual Labels**: Capacitor, Stores electric charge, Store charge, Release it, Smooth power, Keep LED on
- **SVG Content**: Present (1879 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B7.4.2.2.1. Safety message included on purpose.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpC` (retryRule: 2 attempts, then show the answer with the explanation):
    - [tapDiagram] `cpC.1`: Tap what happens when a diode is in reverse. — Hotspot: h4
    - [mcq] `cpC.2`: What does a capacitor do? — Correct: a (a: Stores electric charge | b: Gives out coloured light | c: Opens and closes a circuit | d: Limits current with coloured bands)
    - [mcq] `cpC.3`: Which part is a coil of wire? — Correct: c (a: Resistor | b: Capacitor | c: Inductor | d: Diode)

## Slide 13: `s13` — An Electric Circuit
- **Learning Objective / Purpose**: Describe a simple circuit (exemplar 2).
- **Indicators**: B7.4.2.2.1, B7.4.2.2.2
- **On-Screen Educational Text**:
  - A circuit is a closed path
  - Two dry cells give three volts
  - A red LED with a suitable resistor
- **Key Ideas**: A circuit is a closed path. | Two dry cells in series give three volts. | The teacher gives a suitable resistor for the LED.
- **Complete Narration Text**: Let us build a simple circuit. An electric circuit is a closed path that current can flow around. Our circuit will use two dry cells joined end to end, which we call in series, so together they give three volts. We add a switch, a resistor and an LED. A red LED works well with a resistor of about two hundred and twenty ohms, and your teacher will give you the right one. The current flows around the loop when everything is joined.
- **Audio Asset Reference**: `audio/s13.ce4ffee16f2a.mp3` (34s, source: tts)
- **Visual Type**: `svg` · **Description**: Circuit: A closed path for current. Parts: Battery, Switch, Resistor, LED.
- **Image Asset Reference**: `None` · **Alt Text**: Circuit: a closed path for current. Parts: Battery, Switch, Resistor, LED.
- **Visual Labels**: Circuit, A closed path for current, Battery, Switch, Resistor, LED
- **SVG Content**: Present (1856 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 of B7.4.2.2.2. Teacher-approved combination for the three volt supply (two fresh dry cells): a standard red LED with a resistor of about 220 ohms (colour bands red, red, brown, gold), which gives roughly 5 milliamps, a safe and clearly visible glow. Yellow or green LEDs also work. Do not use blue or white LEDs: they need about 3.0 to 3.3 volts and will not light on two dry cells, especially if a diode is added later. The exact resistor depends on the LED and the supply; about 150 to 330 ohms is acceptable for a standard 5 mm LED. Test the circuit yourself before the lesson.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcD1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qD.1`: How many volts do two dry cells in series give? — Correct: b (a: Thirty volts | b: Three volts | c: One point five volts | d: Nine volts)

## Slide 14: `s14` — The LED Circuit
- **Learning Objective / Purpose**: Circuit diagram (exemplar 2).
- **Indicators**: B7.4.2.2.2
- **On-Screen Educational Text**:
  - Battery, switch, resistor and LED
  - Trace the path from the positive side
  - Three volts from two dry cells
- **Key Ideas**: The parts are joined in a loop. | The battery gives three volts. | A break anywhere stops the current.
- **Complete Narration Text**: Here is the circuit. A battery of two dry cells gives three volts, and the long plate marked plus is the positive side. Current leaves the positive side and flows through the switch. Next it passes through the resistor. Then it flows through the LED, with the triangle pointing the way of the current. Finally it returns to the negative side of the battery. The path forms a complete loop, so if the loop is broken anywhere, the LED goes off. Trace the path with your finger to check it.
- **Audio Asset Reference**: `audio/s14.a9fa038be8e1.mp3` (37s, source: tts)
- **Visual Type**: `svg` · **Description**: One closed loop. On the left, two dry cells in series with the plus side at the top. On top, a closed switch. On the right, a resistor. At the bottom, an LED with its triangle pointing left, towards the negative side of the battery, giving out light.
- **Image Asset Reference**: `None` · **Alt Text**: One closed loop. On the left, two dry cells in series with the plus side at the top. On top, a closed switch. On the right, a resistor. At the bottom, an LED with its triangle pointing left, towards the negative side of the battery, giving out light.
- **Visual Labels**: Two dry cells, Switch, Resistor, LED, 3 V, +, −
- **SVG Content**: Present (3424 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 of B7.4.2.2.2. Redrawn so that every part sits in the wire path as one continuous loop. The long plate of the battery is positive. The LED triangle points the way conventional current flows, from positive to negative. The resistor may sit on either side of the LED; the order does not change the current. The switch is drawn closed. Use a red, yellow or green LED, not blue or white, for the three volt supply. The LED symbol points left on purpose: conventional current leaves the battery positive, goes through the switch and resistor, and travels right to left along the bottom branch, so the triangle points left and the anode faces the resistor. Do not reverse it.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcD2` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qD.2`: What does a circuit need so that current can flow? — Correct: b (a: A deliberate gap in the wire | b: A complete closed loop | c: Only an LED and nothing else | d: A battery pointing away from the LED)

## Slide 15: `s15` — Building the Circuit
- **Learning Objective / Purpose**: Safe practical work (exemplar 2).
- **Indicators**: B7.4.2.2.2
- **On-Screen Educational Text**:
  - Keep the switch open while you join
  - Use only the dry cells you are given
  - Never use a wall socket
- **Key Ideas**: Use only dry cells from the teacher. | Never use a wall socket. | Close the switch only after the teacher checks.
- **Complete Narration Text**: Now it is time to build. Work in small groups, and keep the teacher close. Use only the dry cells that your teacher gives you. Never connect any circuit to a wall socket, because mains electricity is dangerous. Join the parts neatly with the switch open, so the LED stays off while you work. Ask your teacher to check every join, and close the switch only after the check.
- **Audio Asset Reference**: `audio/s15.22a05ec51d12.mp3` (29s, source: tts)
- **Visual Type**: `illustration` · **Description**: Pupils in a small group join a battery holder, an open switch, a resistor and an unlit LED on a bench while the teacher checks the joins.
- **Image Asset Reference**: `images/s15.612fcfeec9d0.webp` · **Alt Text**: Pupils in a small group join a battery holder, an open switch, a resistor and an unlit LED on a bench while the teacher checks the joins.
- **Visual Labels**: None
- **SVG Content**: None
- **Existing Interactive Configuration**: None
- **Teacher Note**: Safety slide. The switch stays open while the circuit is joined; the teacher checks the LED direction and the joins; only then is the switch closed. AI image placement is approximate.
- **Existing Checkpoints After This Slide**: None

## Slide 16: `s16` — Steps for the Circuit
- **Learning Objective / Purpose**: Circuit building steps (exemplar 2).
- **Indicators**: B7.4.2.2.2
- **On-Screen Educational Text**:
  - Join two dry cells in series
  - Add the resistor and the LED
  - Close the switch
- **Key Ideas**: Join the cells in series. | Add the resistor and the LED. | Close the switch to light the LED.
- **Complete Narration Text**: Here are the steps. First, join two dry cells in series to make three volts. Second, connect the switch, and keep it open. Third, add the resistor and the LED, with the longer leg of the LED towards the positive side. Now ask your teacher to check every join. Last, close the switch and watch the LED light. Then open the switch and watch it go off.
- **Audio Asset Reference**: `audio/s16.96d51dcf45ba.mp3` (27s, source: tts)
- **Visual Type**: `svg` · **Description**: Four numbered steps: join two dry cells in series, connect the switch, add the resistor and LED, close the switch.
- **Image Asset Reference**: `None` · **Alt Text**: Four numbered steps: join two dry cells in series, connect the switch, add the resistor and LED, close the switch.
- **Visual Labels**: Join two dry cells in series, Connect the switch, Add the resistor and LED, Close the switch
- **SVG Content**: Present (2139 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 of B7.4.2.2.2. The teacher checks the polarity and the joins before the switch is closed.
- **Existing Checkpoints After This Slide**: None

## Slide 17: `s17` — Switch Closed, Switch Open
- **Learning Objective / Purpose**: Explain the switch (exemplar 3).
- **Indicators**: B7.4.2.2.2
- **On-Screen Educational Text**:
  - Closed switch: the circuit is complete
  - Open switch: the circuit is broken
  - Current needs a closed path
- **Key Ideas**: Closed means the circuit is complete. | Open means the circuit is broken. | Current needs a closed path.
- **Complete Narration Text**: What does the switch do? When the switch is closed, the circuit is complete, and current flows, so the LED lights. When the switch is opened, the circuit is broken, so the current stops and the LED goes off. A current needs a closed path to flow. That is why we call a switch an on and off control.
- **Audio Asset Reference**: `audio/s17.b1ee849d486b.mp3` (25s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 3 rows: Closed, Circuit complete, LED on; Open, Circuit broken, LED off; Why, Current needs a closed path.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 3 rows: Closed, Circuit complete, LED on; Open, Circuit broken, LED off; Why, Current needs a closed path.
- **Visual Labels**: Switch, What happens, Closed, Open, Why, Circuit complete, LED on, Circuit broken, LED off, Current needs a closed path
- **SVG Content**: Present (2244 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 3 of B7.4.2.2.2.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpD` (retryRule: 2 attempts, then show the answer with the explanation):
    - [sequence] `cpD.1`: Put the steps for building the circuit in order. — Order: st2 -> st4 -> st1 -> st3
    - [mcq] `cpD.2`: Should we connect our circuit to a wall socket? — Correct: a (a: No, mains electricity is dangerous | b: Yes, it makes the LED brighter | c: Yes, if the teacher is not looking | d: Yes, as long as we wear dry shoes)
    - [mcq] `cpD.3`: Which way round does the LED go? — Correct: b (a: Longer leg towards the negative side | b: Longer leg towards the positive side | c: Either way round, it makes no difference | d: Shorter leg towards the positive side)
    - [mcq] `cpD.4`: What happens when the switch is closed? — Correct: d (a: The circuit is broken and the LED stays off | b: The current stops and the LED goes off at once | c: The battery is taken out and the LED glows | d: The circuit is complete and the LED lights)

## Slide 18: `s18` — Looking Inside a Gadget
- **Learning Objective / Purpose**: Dismantle a spoilt gadget safely (exemplar 1 of indicator 2).
- **Indicators**: B7.4.2.2.2
- **On-Screen Educational Text**:
  - Only battery gadgets, with the teacher
  - Take the batteries out first
  - Never open a mains gadget
- **Key Ideas**: Gadgets are built from components. | Batteries come out first. | Never open mains gadgets.
- **Complete Narration Text**: Many gadgets are built from these same parts. Under your teacher's care, you may look inside a spoilt battery gadget, such as a small radio, a toy or an electronic watch. First the batteries are taken out. Then the teacher opens it and you name the parts you know on the circuit board. Never open a gadget that plugs into the mains, such as a television, because it can hold dangerous electricity.
- **Audio Asset Reference**: `audio/s18.2dcbfb4829eb.mp3` (30s, source: tts)
- **Visual Type**: `illustration` · **Description**: A teacher shows pupils the circuit board inside an opened small battery radio, with its batteries removed and a spoilt electronic watch beside it.
- **Image Asset Reference**: `images/s18.016d50efef8e.webp` · **Alt Text**: A teacher shows pupils the circuit board inside an opened small battery radio, with its batteries removed and a spoilt electronic watch beside it.
- **Visual Labels**: None
- **SVG Content**: None
- **Existing Interactive Configuration**: None
- **Teacher Note**: Safety slide. AI image placement is approximate. [VERIFY] The syllabus lists radios, televisions, phones and watches; this lesson limits the work to teacher-led dismantling of spoilt battery gadgets (radio, toy, electronic watch) and never mains devices.
- **Existing Checkpoints After This Slide**: None

## Slide 19: `s19` — Parts Inside Gadgets
- **Learning Objective / Purpose**: Parts found in gadgets.
- **Indicators**: B7.4.2.2.2
- **On-Screen Educational Text**:
  - A radio has a coil and a capacitor
  - A torch has cells, a switch and an LED
  - A charger has a diode and a capacitor
- **Key Ideas**: A radio has a coil, a capacitor and resistors. | A torch has cells, a switch and an LED. | A phone charger has diodes, capacitors and coils.
- **Complete Narration Text**: Different gadgets use different parts. A radio has a coil, a capacitor and resistors that help it pick a station. A torch has cells, a switch and an LED. A phone charger has diodes, capacitors and coils that change mains electricity into a small, steady current. Which parts can you name in a gadget at home?
- **Audio Asset Reference**: `audio/s19.ef8d9bd1295c.mp3` (23s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 3 rows: Radio, Coil, capacitor, resistor; Torch, Cells, switch, LED; Phone charger, Diode, capacitor, coil.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 3 rows: Radio, Coil, capacitor, resistor; Torch, Cells, switch, LED; Phone charger, Diode, capacitor, coil.
- **Visual Labels**: Gadget, Some parts inside, Radio, Torch, Phone charger, Coil, capacitor, resistor, Cells, switch, LED, Diode, capacitor, coil
- **SVG Content**: Present (2244 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [VERIFY] The parts listed are typical, not complete; check against the gadgets your class opens.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcE1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qE.1`: Which gadget is safe to open with a teacher? — Correct: c (a: A television connected to the mains | b: A kettle plugged into a wall | c: A spoilt battery radio | d: A fan running on mains power)

## Slide 20: `s20` — Parts Working Together
- **Learning Objective / Purpose**: Interdependence of components (exemplar 3).
- **Indicators**: B7.4.2.2.2
- **On-Screen Educational Text**:
  - Parts depend on each other
  - If one fails, the circuit may fail
  - This is interdependence
- **Key Ideas**: Parts depend on each other. | Each part has its own job. | If one part fails, the circuit may fail.
- **Complete Narration Text**: The parts in a circuit depend on each other. The battery gives the energy. The switch opens or closes the path. The resistor limits the current to protect the LED. The LED gives out light. If one part is missing or fails, the whole circuit may stop working. This is what we mean by interdependence.
- **Audio Asset Reference**: `audio/s20.ab1e55b12902.mp3` (23s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 4 rows: Battery, Gives the energy; Switch, Opens or closes the path; Resistor, Limits the current; LED, Gives out light.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 4 rows: Battery, Gives the energy; Switch, Opens or closes the path; Resistor, Limits the current; LED, Gives out light.
- **Visual Labels**: Part, Its job, Battery, Switch, Resistor, LED, Gives the energy, Opens or closes the path, Limits the current, Gives out light
- **SVG Content**: Present (2736 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B7.4.2.2.2 and exemplar 1 of B7.4.2.2.3.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpE` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `cpE.1`: What is the job of a switch? — Correct: d (a: To store electric charge for later | b: To limit the current with bands | c: To give out coloured light and heat | d: To open or close the circuit)
    - [mcq] `cpE.2`: Why do the parts of a circuit depend on each other? — Correct: b (a: Each part works fine even if the others are missing | b: If one fails, the circuit may stop working | c: Only the battery matters and the rest are for show | d: They depend on each other only when it is switched off)
    - [mcq] `cpE.3`: A radio has a coil, a capacitor and which other part? — Correct: c (a: A television tube | b: A petrol engine | c: Resistors | d: A solar panel)

## Slide 21: `s21` — Resistors and Brightness
- **Learning Objective / Purpose**: Effect of resistors on LED brightness (exemplar 2).
- **Indicators**: B7.4.2.2.3
- **On-Screen Educational Text**:
  - More resistance, less current
  - A resistor that is too small is not safe
  - A suitable resistor gives a safe light
- **Key Ideas**: No resistor, or one that is too small, can burn out the LED. | A suitable resistor gives a bright, safe light. | A bigger resistor means a dimmer LED.
- **Complete Narration Text**: Let us see how a resistor changes the brightness of an LED. With no resistor, too much current flows and the LED may burn out. A resistor that is too small is not automatically safe, because it may still let too much current through. A suitable resistor, such as about two hundred and twenty ohms for a red LED on three volts, gives a bright and safe light. A larger resistor lets less current through, so the LED is dimmer, and a very large one may leave it almost off.
- **Audio Asset Reference**: `audio/s21.14c9785c9f0c.mp3` (38s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 4 rows: None, Too bright, may burn out; Too small, May still burn it out; Suitable, Bright and safe; Very large, Dim or almost off.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 4 rows: None, too bright, may burn out; Too small, may still burn it out; Suitable, bright and safe; Very large, dim or almost off.
- **Visual Labels**: Resistor, LED brightness, None, Too small, Suitable, Very large, Too bright, may burn out, May still burn it out, Bright and safe, Dim or almost off
- **SVG Content**: Present (2760 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 of B7.4.2.2.3. Do not test with no resistor or a very small one in class: the LED can be damaged. Demonstrate only the approved resistor of about 220 ohms and larger values (for example 470 and 1000 ohms), which make a red LED on three volts dimmer.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcF1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qF.1`: What happens with a larger resistor? — Correct: a (a: The LED is dimmer | b: The LED is brighter | c: The LED turns blue | d: The LED burns out)

## Slide 22: `s22` — Diodes, Inductors and Brightness
- **Learning Objective / Purpose**: Effect of a diode or inductor on brightness (exemplar 2).
- **Indicators**: B7.4.2.2.3
- **On-Screen Educational Text**:
  - A forward diode makes the LED dimmer
  - A reversed diode switches it off
  - An inductor changes little once current is steady
- **Key Ideas**: A forward diode makes the LED dimmer. | A reversed diode switches the LED off. | An inductor changes little once the current is steady.
- **Complete Narration Text**: Now we add other parts. In a circuit like this, the three volts from the battery is shared between the parts. A forward diode takes a voltage drop of about seven tenths of a volt, so less is left for the resistor and the LED, and the LED is dimmer, perhaps much dimmer. A diode in reverse blocks almost all the current, so the LED stays off. An inductor opposes changes in the current, but once the current is steady, it hardly changes the brightness.
- **Audio Asset Reference**: `audio/s22.fffc87dddc3f.mp3` (35s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 3 rows: Diode, forward, Dimmer; Diode, reversed, LED stays off; Inductor, Almost no change.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 3 rows: Diode, forward, dimmer; Diode, reversed, LED stays off; Inductor, almost no change.
- **Visual Labels**: Added part, LED brightness, Diode, forward, Diode, reversed, Inductor, Dimmer, LED stays off, Almost no change
- **SVG Content**: Present (2241 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 of B7.4.2.2.3. A forward silicon diode has a voltage drop of about 0.7 volts: in a series circuit the supply voltage is shared, so the diode takes about 0.7 volts and leaves less for the resistor and LED. On a three volt supply a red LED glows only dimly and a blue or white LED will not light. Use a red, yellow or green LED and test first. Do not expect a visible delay from an inductor: once the current is steady it has little effect. The diode and inductor tests are optional teacher demonstrations. [VERIFY] Both effects are simplified.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcF2` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qF.2`: What happens with a reversed diode? — Correct: a (a: The LED stays off | b: The LED gets very bright | c: The LED flashes quickly | d: The LED turns a different colour)

## Slide 23: `s23` — What Decides Brightness
- **Learning Objective / Purpose**: Link brightness to current.
- **Indicators**: B7.4.2.2.3
- **On-Screen Educational Text**:
  - Brightness depends on the current
  - More current, a brighter LED
  - Each part acts on the current
- **Key Ideas**: Brightness depends on current. | More current means a brighter LED. | Resistors, diodes and inductors act on the current in different ways.
- **Complete Narration Text**: The brightness of an LED depends on the current flowing through it. More current makes the LED brighter, and less current makes it dimmer. Here is how each part acts. A resistor limits the current, and a larger resistor gives a dimmer LED. A forward diode has a voltage drop, which leaves less voltage for the LED and resistor, and a reversed diode blocks almost all the current. An inductor changes the current only when the current is changing, so it has little effect when the current is steady.
- **Audio Asset Reference**: `audio/s23.9cb14e8659b6.mp3` (36s, source: tts)
- **Visual Type**: `svg` · **Description**: Brightness: More current, brighter LED. How parts act: Resistors, Diodes, Inductors.
- **Image Asset Reference**: `None` · **Alt Text**: Brightness: more current, brighter LED. How parts act: Resistors, Diodes, Inductors.
- **Visual Labels**: Brightness, More current, brighter LED, How parts act, Resistors, Diodes, Inductors
- **SVG Content**: Present (1624 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 of B7.4.2.2.3.
- **Existing Checkpoints After This Slide**: None

## Slide 24: `s24` — Steps to Test Brightness
- **Learning Objective / Purpose**: Brightness experiment steps.
- **Indicators**: B7.4.2.2.3
- **On-Screen Educational Text**:
  - Light the LED with the approved resistor
  - Switch off, then swap in a bigger one
  - Compare and record
- **Key Ideas**: Test one resistor, then a bigger one. | Compare the brightness. | Switch off before changing parts.
- **Complete Narration Text**: Here is how to test it. First, light the LED with the resistor your teacher approves, and look at the brightness. Second, open the switch, then swap in a bigger resistor chosen by your teacher. Third, close the switch and compare the brightness with the first one. Last, record what you see in a table. Your teacher may also test a diode in both directions, or show a simulation of an inductor with changing current. Never use a resistor smaller than the one you were given, and always switch off before changing parts.
- **Audio Asset Reference**: `audio/s24.8d302bf7f643.mp3` (38s, source: tts)
- **Visual Type**: `svg` · **Description**: Four numbered steps: light the LED with one resistor, swap in a bigger resistor, compare the brightness, record what you see.
- **Image Asset Reference**: `None` · **Alt Text**: Four numbered steps: light the LED with one resistor, swap in a bigger resistor, compare the brightness, record what you see.
- **Visual Labels**: Light the LED with one resistor, Swap in a bigger resistor, Compare the brightness, Record what you see
- **SVG Content**: Present (2150 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 of B7.4.2.2.3. The teacher supplies the approved resistor (about 220 ohms) and bigger ones (for example 470 and 1000 ohms). Do not supply resistors below about 100 ohms. Use a red, yellow or green LED. Optional inductor demonstration (teacher only, not assessed): show a circuit simulation in which current through an inductor is plotted when a switch is closed; the current rises smoothly over a short time instead of jumping, and falls smoothly when the source is removed. In a real small-coil battery circuit the effect is too quick to see, so do not promise or expect a visible delay in the LED. Do not open a coil circuit suddenly with pupils nearby: it can produce a voltage spike.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpF` (retryRule: 2 attempts, then show the answer with the explanation):
    - [sequence] `cpF.1`: Put the steps of the brightness test in order. — Order: st2 -> st4 -> st1 -> st3
    - [mcq] `cpF.2`: What decides the brightness of an LED? — Correct: d (a: The colour of the wires used in it | b: The size of the room around it | c: The time of day when it is lit | d: The current flowing through it)
    - [mcq] `cpF.3`: How does an inductor affect an LED in a steady battery circuit? — Correct: d (a: It makes the LED much brighter | b: It switches the LED off | c: It changes the LED colour | d: Almost no change in brightness)

## Slide 25: `s25` — Recap: Electronics
- **Learning Objective / Purpose**: Recap.
- **Indicators**: B7.4.2.2.1, B7.4.2.2.2, B7.4.2.2.3
- **On-Screen Educational Text**:
  - Components have different jobs
  - A switch opens and closes the circuit
  - Resistors and diodes change brightness
- **Key Ideas**: Each component has its own job. | A closed switch lets current flow. | Resistors and diodes change LED brightness.
- **Complete Narration Text**: Let us recap. Electronic components include the LED, resistor, diode, inductor and capacitor, and each has its own job. We join a battery, a switch, a suitable resistor and an LED to make a circuit. When the switch is closed, current flows and the LED lights. A larger resistor makes the LED dimmer, a forward diode may dim it, a reversed diode switches it off, and an inductor has little effect once the current is steady.
- **Audio Asset Reference**: `audio/s25.9a6936b875a8.mp3` (32s, source: tts)
- **Visual Type**: `svg` · **Description**: A recap: electronics split into components, with LED, resistor and diode, and the circuit, with battery, switch and LED brightness.
- **Image Asset Reference**: `None` · **Alt Text**: A top box, electronics, with arrows to two columns: components with LED, resistor and diode; circuit with battery, switch and LED brightness.
- **Visual Labels**: Electronics, Components, Circuit, LED, Resistor, Diode, Battery, Switch, LED brightness
- **SVG Content**: Present (2784 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Final slide before the mastery check.
- **Existing Checkpoints After This Slide**: None

## End-of-Lesson Mastery Check (Pass Mark: 4)
- [mcq] `mastery.1`: What does a resistor do? — Correct: c (a: Stores electric charge for later | b: Gives out light when current flows | c: Limits the flow of current | d: Lets current flow one way only)
- [mcq] `mastery.2`: A four band resistor is brown, black, red, gold. What is its value? — Correct: b (a: Ten thousand ohms | b: One thousand ohms | c: One hundred ohms | d: One hundred and two ohms)
- [mcq] `mastery.3`: What happens when the switch is opened? — Correct: d (a: The circuit is complete and the LED gets brighter | b: The current speeds up and the LED glows more | c: The battery charges up and the LED stays on | d: The circuit is broken and the LED goes off)
- [mcq] `mastery.4`: A diode is connected in reverse in an LED circuit. What happens? — Correct: a (a: The LED stays off | b: The LED gets brighter | c: The LED glows dimmer | d: The LED flashes on and off)
- [mcq] `mastery.5`: What happens to the LED when a bigger resistor is added? — Correct: c (a: It becomes much brighter | b: Nothing changes at all | c: It becomes dimmer | d: It burns out at once)

# Living Cells: Animal and Plant Cells (`b7-sci-t1-living-cells`)

- **CDN packagePath**: `packages/b7-sci-t1-living-cells.ad64775a290c.json` (hash `ad64775a290c`, updated `2026-11-22T08:10:20.410Z`)
- **Curriculum**: ges · **Class**: Basic 7 · **Subject**: Science · **Term**: 1
- **Content Standard**: B7.1.2.1
- **Indicators**: B7.1.2.1.1, B7.1.2.1.2
- **Total Slides**: 27 · **Checkpoints**: 14 · **Mastery Check Items**: 5

## Slide 1: `s01` — Building Blocks
- **Learning Objective / Purpose**: Hook: compare a block wall to a living thing made of cells.
- **Indicators**: B7.1.2.1.1, B7.1.2.1.2
- **On-Screen Educational Text**:
  - A wall is made of blocks
  - Living things are made of cells
  - Let us look inside
- **Key Ideas**: A wall is made of blocks. | Living things are made of cells. | We will study animal and plant cells.
- **Complete Narration Text**: Good morning, class. Think about a wall at a building site. A mason lays one block on top of another until the whole wall is built. Living things are built in a similar way. A goat, a mango tree and you are all made from tiny units called cells. In this lesson you will meet the cell, look inside it and learn the jobs of its small parts. You will also find out how an animal cell and a plant cell are alike and how they are different.
- **Audio Asset Reference**: `audio/s01.a9002ee527fb.mp3` (37s, source: tts)
- **Visual Type**: `illustration` · **Description**: A Ghanaian mason laying blocks to build a wall beside a farm with a goat and a mango tree.
- **Image Asset Reference**: `images/s01.0b6c2bea87c0.webp` · **Alt Text**: A mason laying blocks to build a wall, with a goat and a mango tree nearby and a child watching.
- **Visual Labels**: None
- **SVG Content**: None
- **Existing Interactive Configuration**: None
- **Teacher Note**: AI image placement is approximate; do not rely on exact positions.
- **Existing Checkpoints After This Slide**: None

## Slide 2: `s02` — What Is a Cell?
- **Learning Objective / Purpose**: Define cell and organism using the wall-and-block comparison.
- **Indicators**: B7.1.2.1.1, B7.1.2.1.2
- **On-Screen Educational Text**:
  - A cell is the smallest living unit
  - An organism is a living thing
  - Most cells need a microscope
- **Key Ideas**: A cell is the smallest living unit. | An organism is a living thing. | Most cells are too small to see by eye.
- **Complete Narration Text**: A wall is made of many blocks. A living thing is made of many cells. A cell is the smallest living unit of an organism. An organism is any living thing, such as a plant, an animal or a person. Some organisms are just one cell. Most plants and animals you know have very many cells working together. Most cells are too small to see with our eyes alone, and a hand magnifier is not strong enough to show them clearly. A microscope is generally needed, but charts and videos can show cells too.
- **Audio Asset Reference**: `audio/s02.d889ab442bdb.mp3` (39s, source: tts)
- **Visual Type**: `svg` · **Description**: Two rows: a block is to a wall as a cell is to a body.
- **Image Asset Reference**: `None` · **Alt Text**: Two rows with arrows: block to wall, and cell to body.
- **Visual Labels**: Block, Wall, Cell, Body
- **SVG Content**: Present (1512 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 3 (both indicators): conclude that animals and plants are made of cells. Most cells need a microscope; a hand magnifier is not strong enough. Use charts and videos if no microscope is available.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcA1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qA.1`: In the wall comparison, what is a cell like? — Correct: b (a: The whole wall | b: A block in the wall | c: The mason who builds it | d: The paint on the wall)

## Slide 3: `s03` — Cells in All Living Things
- **Learning Objective / Purpose**: Show that all plants and animals are made of cells and that cells are alive.
- **Indicators**: B7.1.2.1.1, B7.1.2.1.2
- **On-Screen Educational Text**:
  - Plants and animals have cells
  - Cells are alive
  - The cell is the basic unit of life
- **Key Ideas**: All plants and animals are made of cells. | A stone is not made of cells. | The cell is the basic unit of life.
- **Complete Narration Text**: Look at these living things: a goat, a maize plant, a fish and a child. Each one is made of cells. Scientists have looked at living things from all over the world and found that every plant and every animal is made of cells. A stone is not made of cells at all. Wood comes from a tree, so it may contain the remains of plant cells. Cells in living things are alive. They take in food, release energy and grow. That is why we call the cell the basic unit of life.
- **Audio Asset Reference**: `audio/s03.c3b66fbc9cc3.mp3` (38s, source: tts)
- **Visual Type**: `illustration` · **Description**: A goat, a maize plant, a fish and a child, each with a small magnified bubble showing tiny cells.
- **Image Asset Reference**: `images/s03.3e4026fdc199.webp` · **Alt Text**: A goat, a maize plant, a fish and a child, each with a small round bubble showing many tiny cells packed together.
- **Visual Labels**: None
- **SVG Content**: None
- **Existing Interactive Configuration**: None
- **Teacher Note**: AI image placement is approximate; the magnified bubbles are illustrative, not to scale. Stones and other non-living things are not made of cells; wood and paper may contain the remains of plant cells.
- **Existing Checkpoints After This Slide**: None

## Slide 4: `s04` — Seeing Cells
- **Learning Objective / Purpose**: Describe how cells can be seen (microscope, chart, video) and how to use them safely.
- **Indicators**: B7.1.2.1.1, B7.1.2.1.2
- **On-Screen Educational Text**:
  - A microscope is generally needed
  - Videos and charts help too
  - Handle glass and the microscope with care
- **Key Ideas**: A microscope is generally needed. | Videos and charts also show cells. | Handle the microscope with two hands.
- **Complete Narration Text**: How can we see cells? A hand magnifier makes small things look bigger, but most cells are too small to see clearly with one, so a microscope is generally needed. In class your teacher may show you a prepared slide, a thin piece of onion skin or a chart. If there is no microscope, a video or a picture works well. Carry a microscope with two hands, never point it at the sun, and touch glass slides only when your teacher says. Never collect samples from people.
- **Audio Asset Reference**: `audio/s04.7dbe4626853c.mp3` (36s, source: tts)
- **Visual Type**: `illustration` · **Description**: Pupils sharing a microscope with a teacher-prepared slide on a classroom table, a hand magnifier beside it and a chart of cells on the wall.
- **Image Asset Reference**: `images/s04.591eb86abf91.webp` · **Alt Text**: Pupils looking at a prepared slide through a microscope, with a hand magnifier on the table and a cell chart on the wall.
- **Visual Labels**: None
- **SVG Content**: None
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 and 3 (both indicators). Safety: prefer teacher-prepared slides, and supervise all microscope and glass handling. Do not collect samples from people, including cheek swabs. Use charts and videos if no microscope is available.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcA2` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qA.2`: Which tool shows cells most clearly? — Correct: b (a: A ruler | b: A microscope | c: A thermometer | d: A weighing scale)

## Slide 5: `s05` — Cells in Different Parts of an Animal
- **Learning Objective / Purpose**: Observe that different parts of an animal are made of cells and conclude animals are made of cells.
- **Indicators**: B7.1.2.1.1
- **On-Screen Educational Text**:
  - Skin, blood and muscle
  - All are made of cells
  - Animals are made of cells
- **Key Ideas**: Different parts of an animal are made of cells. | Cells have different shapes for different jobs. | Animals are made up of cells.
- **Complete Narration Text**: Let us look at samples from different parts of an animal. Skin, blood and muscle all look different to the eye. Under a microscope, each one is made of cells. The cells have different shapes because they do different jobs, but they share basic features, such as a cell membrane and cytoplasm. From these observations we can draw a conclusion. Animals are made up of cells. Plants, too, are made up of cells, and we will see that later.
- **Audio Asset Reference**: `audio/s05.1bca1381c353.mp3` (33s, source: tts)
- **Visual Type**: `svg` · **Description**: Three arrows: skin, blood and muscle each lead to cells.
- **Image Asset Reference**: `None` · **Alt Text**: Three rows: skin to cells, blood to cells and muscle to cells.
- **Visual Labels**: Skin, Blood, Muscle, Cells
- **SVG Content**: Present (2174 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 3 (B7.1.2.1.1): draw the conclusion that animals are made up of cells. Use a video or pictures if no microscope slides are available. Use prepared slides, videos or pictures only; do not collect samples from people.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpA` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `cpA.1`: What is a cell? — Correct: a (a: The smallest living unit of an organism | b: A tiny non-living particle of all matter | c: The smallest living part of an animal only | d: A small empty room inside the body)
    - [mcq] `cpA.2`: Which statement is true? — Correct: c (a: Only animals and people are made of cells | b: Only plants and trees are made of cells | c: All plants and animals are made of cells | d: Only very small living things have cells)
    - [mcq] `cpA.3`: A pupil sees many tiny units packed together in a thin piece of leaf under a microscope. What can she conclude? — Correct: c (a: The leaf is made of one big cell | b: The leaf is made of non-living dust | c: The leaf is made of cells | d: The leaf has no organelles)

## Slide 6: `s06` — Organelles: Parts With Jobs
- **Learning Objective / Purpose**: Introduce organelles with a school analogy.
- **Indicators**: B7.1.2.1.1
- **On-Screen Educational Text**:
  - Organelles are tiny parts of a cell
  - Each organelle has a job
  - Like the parts of a school
- **Key Ideas**: Organelles are tiny parts with jobs. | The cell membrane is like a gate. | The nucleus is like the office.
- **Complete Narration Text**: Inside a cell are tiny parts called organelles. Each organelle has its own job, just like the parts of a school. A school has a gate that controls who comes in and goes out. A cell has a cell membrane that does a similar job. A school office gives instructions, and the nucleus gives instructions to the cell. A generator provides power, and mitochondria release energy. A workshop makes useful things, and ribosomes make proteins.
- **Audio Asset Reference**: `audio/s06.d846ffd2c691.mp3` (31s, source: tts)
- **Visual Type**: `svg` · **Description**: A school gate, office, generator and workshop each linked to a cell part: cell membrane, nucleus, mitochondria and ribosomes.
- **Image Asset Reference**: `None` · **Alt Text**: Four rows linking the parts of a school to parts of a cell: gate to cell membrane, office to nucleus, generator to mitochondria and workshop to ribosomes.
- **Visual Labels**: Gate, Office, Generator, Workshop, Cell membrane, Nucleus, Mitochondria, Ribosomes
- **SVG Content**: Present (2867 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: The tap-diagram checkpoint (cpB.1) uses this slide: four rectangles at x 60, width 320, height 120, at y 45, 215, 385 and 555. The arrows on this slide show which school part matches which cell part, so cpB.1 is a recognition check. The school comparison is an analogy only.
- **Existing Checkpoints After This Slide**: None

## Slide 7: `s07` — The Animal Cell
- **Learning Objective / Purpose**: Identify the structure of an animal cell on a labelled diagram.
- **Indicators**: B7.1.2.1.1
- **On-Screen Educational Text**:
  - A typical animal cell
  - Five main parts
  - Cell membrane to ribosomes
- **Key Ideas**: The cell membrane is the outer layer. | Cytoplasm fills the cell. | Nucleus, mitochondria and ribosomes are organelles.
- **Complete Narration Text**: This is a simple drawing of a typical animal cell. Notice that it has a thin outer layer, the cell membrane. Inside is a jelly-like fluid called cytoplasm. The round part near the middle is the nucleus. The bean-shaped parts are mitochondria. The tiny dots are ribosomes. Many animal cells have these five parts, but some specialised cells, such as mature red blood cells, have no nucleus or mitochondria. Next, we will study each part and learn what it does.
- **Audio Asset Reference**: `audio/s07.56864c25b24b.mp3` (34s, source: tts)
- **Visual Type**: `svg` · **Description**: A simplified labelled drawing of a typical animal cell showing the cell membrane, cytoplasm, nucleus, mitochondria and ribosomes.
- **Image Asset Reference**: `None` · **Alt Text**: A simplified oval animal cell with leader lines to five labels: cell membrane, cytoplasm, nucleus, mitochondria and ribosomes.
- **Visual Labels**: Mitochondria, Cytoplasm, Cell membrane, Nucleus, Ribosomes
- **SVG Content**: Present (3259 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1: identify and describe the structure of an animal cell from a video, a chart or a microscope. The diagram is a simplified typical animal cell; not every animal cell has all five parts.
- **Existing Checkpoints After This Slide**: None

## Slide 8: `s08` — The Cell Membrane
- **Learning Objective / Purpose**: Describe the structure and function of the cell membrane.
- **Indicators**: B7.1.2.1.1
- **On-Screen Educational Text**:
  - The cell membrane
  - The gate of the cell
  - Controls what enters and leaves
- **Key Ideas**: The membrane surrounds the cell. | It controls what enters and leaves. | It keeps the cell's contents inside.
- **Complete Narration Text**: First, the cell membrane. It is a thin layer around the whole cell. You can think of it as the cell's gate. It controls which substances enter the cell and which leave. Food and water can pass in. Waste can pass out. It also holds the cell together, so the cell's contents stay inside. Without a membrane, the contents of the cell would spill out.
- **Audio Asset Reference**: `audio/s08.fcf8eb272bd2.mp3` (27s, source: tts)
- **Visual Type**: `svg` · **Description**: A simplified animal cell with its cell membrane highlighted and its job written beside it.
- **Image Asset Reference**: `None` · **Alt Text**: A simplified animal cell with the cell membrane highlighted, and the name and job on the right.
- **Visual Labels**: Cell membrane, Controls what, enters and leaves
- **SVG Content**: Present (2003 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2: state the function of each organelle.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcB1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qB.1`: What is the main job of the cell membrane? — Correct: d (a: Makes proteins for growth and repair | b: Releases energy from the food we eat | c: Holds the cell's instructions | d: Controls what enters and leaves)

## Slide 9: `s09` — The Cytoplasm
- **Learning Objective / Purpose**: Describe the structure and function of the cytoplasm.
- **Indicators**: B7.1.2.1.1
- **On-Screen Educational Text**:
  - The cytoplasm
  - A jelly-like fluid
  - Holds the organelles
- **Key Ideas**: Cytoplasm is a jelly-like fluid. | Organelles float in it. | Many chemical reactions happen there.
- **Complete Narration Text**: Next, the cytoplasm. This is the jelly-like fluid that fills the cell. All the other organelles float in it. Many of the cell's chemical reactions happen in the cytoplasm. It is mostly made of water. Think of it as the busy room of the cell where the workers are kept. Without cytoplasm, the organelles would have nowhere to stay.
- **Audio Asset Reference**: `audio/s09.813a2d0dca72.mp3` (25s, source: tts)
- **Visual Type**: `svg` · **Description**: A simplified animal cell with its cytoplasm highlighted and its job written beside it.
- **Image Asset Reference**: `None` · **Alt Text**: A simplified animal cell with the cytoplasm shaded strongly, and the name and job on the right.
- **Visual Labels**: Cytoplasm, Fills the cell, Holds organelles
- **SVG Content**: Present (1994 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2.
- **Existing Checkpoints After This Slide**: None

## Slide 10: `s10` — The Nucleus
- **Learning Objective / Purpose**: Describe the structure and function of the nucleus.
- **Indicators**: B7.1.2.1.1
- **On-Screen Educational Text**:
  - The nucleus
  - The control centre
  - Holds the instructions
- **Key Ideas**: The nucleus controls the cell. | It holds the genetic instructions. | How easily we see it depends on the cell.
- **Complete Narration Text**: Now the nucleus. In most animal cells it is the control centre. It holds the genetic instructions that tell the cell how to grow and what to do. These instructions are passed on when the cell divides to make new cells. In many cells the nucleus is one of the larger parts, but how easily we can see it depends on the cell and on how the sample is prepared. If the nucleus is damaged, the cell cannot work properly. Some cells, such as mature red blood cells, have no nucleus.
- **Audio Asset Reference**: `audio/s10.efac25b724a5.mp3` (38s, source: tts)
- **Visual Type**: `svg` · **Description**: A simplified animal cell with its nucleus highlighted and its job written beside it.
- **Image Asset Reference**: `None` · **Alt Text**: A simplified animal cell with the nucleus outlined, and the name and job on the right.
- **Visual Labels**: Nucleus, Controls the cell, Holds instructions
- **SVG Content**: Present (2113 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2. Keep to the school level: instructions, not DNA detail. Diagrams may show a darker spot inside the nucleus; it is the nucleolus, which is beyond this lesson. The nucleus is not always the largest or easiest part to see.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcB2` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qB.2`: Which part is the control centre of the cell? — Correct: c (a: Cytoplasm | b: Ribosomes | c: Nucleus | d: Cell membrane)

## Slide 11: `s11` — The Mitochondria
- **Learning Objective / Purpose**: Describe the structure and function of the mitochondria.
- **Indicators**: B7.1.2.1.1
- **On-Screen Educational Text**:
  - The mitochondria
  - The powerhouses of the cell
  - Release energy from food
- **Key Ideas**: Mitochondria release energy from food. | They are the powerhouses of the cell. | Active cells have many mitochondria.
- **Complete Narration Text**: Now the mitochondria. These are bean-shaped parts that release energy from food. We call them the powerhouses of the cell. Your body needs energy to run, to think and to grow. Cells that use a lot of energy, such as muscle cells, have many mitochondria. When you eat food and breathe in oxygen, your mitochondria use them to release the energy you need.
- **Audio Asset Reference**: `audio/s11.35bc20deaf49.mp3` (26s, source: tts)
- **Visual Type**: `svg` · **Description**: A simplified animal cell with its mitochondria highlighted and their job written beside them.
- **Image Asset Reference**: `None` · **Alt Text**: A simplified animal cell with the two bean-shaped mitochondria outlined, and the name and job on the right.
- **Visual Labels**: Mitochondria, Release energy, from food
- **SVG Content**: Present (2229 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2. Singular is mitochondrion; the lesson uses the plural.
- **Existing Checkpoints After This Slide**: None

## Slide 12: `s12` — The Ribosomes
- **Learning Objective / Purpose**: Describe the structure and function of the ribosomes.
- **Indicators**: B7.1.2.1.1
- **On-Screen Educational Text**:
  - The ribosomes
  - Tiny dots
  - Make proteins
- **Key Ideas**: Ribosomes are tiny dots. | They make proteins. | Proteins help growth and repair.
- **Complete Narration Text**: Last, the ribosomes. Ribosomes are very tiny dots. Their job is to make proteins. Proteins are used for growth and for repairing the body. Your hair, your muscles and your skin all need proteins. Some ribosomes float in the cytoplasm. Others are attached to other parts of the cell. Because ribosomes are so small, we cannot see them with an ordinary school microscope.
- **Audio Asset Reference**: `audio/s12.f4c18357887d.mp3` (26s, source: tts)
- **Visual Type**: `svg` · **Description**: A simplified animal cell with its ribosomes highlighted and their job written beside them.
- **Image Asset Reference**: `None` · **Alt Text**: A simplified animal cell with a cluster of tiny dots outlined, and the name and job on the right.
- **Visual Labels**: Ribosomes, Make proteins, for growth
- **SVG Content**: Present (2105 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2. The diagram shows only a few ribosomes; real cells have thousands.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcB3` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qB.3`: What do ribosomes make? — Correct: a (a: Proteins for growth | b: Energy for the cell | c: Water for the cell | d: Oxygen for breathing)

## Slide 13: `s13` — Parts and Their Jobs
- **Learning Objective / Purpose**: Summarise the function of each organelle in an animal cell.
- **Indicators**: B7.1.2.1.1
- **On-Screen Educational Text**:
  - Name each cell part
  - Say its job
  - Cover and test yourself
- **Key Ideas**: Five cell parts, five jobs. | Say the job aloud. | Test yourself.
- **Complete Narration Text**: Let us put the jobs together. The cell membrane controls what enters and leaves. The cytoplasm fills the cell and holds the organelles. The nucleus controls the cell. The mitochondria release energy. The ribosomes make proteins. Say each cell part and its job aloud, then cover the job column and test yourself. This is a good way to learn for your next test.
- **Audio Asset Reference**: `audio/s13.f151e8135b4d.mp3` (26s, source: tts)
- **Visual Type**: `svg` · **Description**: A table pairing each animal cell part with its job.
- **Image Asset Reference**: `None` · **Alt Text**: A table: cell membrane controls entry, cytoplasm fills the cell, nucleus controls the cell, mitochondria release energy and ribosomes make proteins.
- **Visual Labels**: Cell part, Job, Cell membrane, Cytoplasm, Nucleus, Mitochondria, Ribosomes, Controls entry, Fills the cell, Controls the cell, Release energy, Make proteins
- **SVG Content**: Present (3272 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2. This is a simplified typical animal cell; some specialised cells lack some of these parts.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpB` (retryRule: 2 attempts, then show the answer with the explanation):
    - [tapDiagram] `cpB.1`: Tap the part of the school that works like the nucleus. — Hotspot: h2
    - [mcq] `cpB.2`: Which organelle releases energy from food? — Correct: a (a: Mitochondria | b: The nucleus | c: The ribosomes | d: The cytoplasm)
    - [mcq] `cpB.3`: Which part is NOT found in an animal cell? — Correct: d (a: The nucleus | b: The ribosomes | c: The cytoplasm | d: A chloroplast)
    - [mcq] `cpB.4`: Which sentence matches an organelle with its job? — Correct: b (a: The nucleus releases energy | b: Ribosomes make proteins | c: The cytoplasm controls the cell | d: The cell membrane makes proteins)

## Slide 14: `s14` — Drawing an Animal Cell
- **Learning Objective / Purpose**: Draw and label an animal cell (exemplar 4).
- **Indicators**: B7.1.2.1.1
- **On-Screen Educational Text**:
  - Draw the outline
  - Add the parts
  - Label with straight lines
- **Key Ideas**: Draw the outline first. | Add the organelles. | A drawing is simplified and not to scale.
- **Complete Narration Text**: Now let us draw an animal cell. Use a sharp pencil and a clean page. First, draw a large oval for the outline. This is the cell membrane. Second, draw a circle for the nucleus inside. Third, add the cytoplasm, the mitochondria and the ribosomes. Last, label each part with straight lines that do not cross, write the names neatly and add a title. Your drawing is a simplified diagram. It is not to scale, and it cannot show everything in a real cell.
- **Audio Asset Reference**: `audio/s14.9f3a7858259b.mp3` (35s, source: tts)
- **Visual Type**: `svg` · **Description**: Four numbered steps for drawing and labelling an animal cell.
- **Image Asset Reference**: `None` · **Alt Text**: Four numbered steps: draw a large oval outline, draw the nucleus inside, add the other organelles, label with straight lines.
- **Visual Labels**: Draw a large oval outline, Draw the nucleus inside, Add the other organelles, Label with straight lines
- **SVG Content**: Present (2177 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 4: draw and label an animal cell. The sequence checkpoint uses these steps. Remind pupils that the drawing is a simplified diagram, not to scale.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcC1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qC.1`: What should you do when you label a drawing of a cell? — Correct: b (a: Draw lines that cross each other freely | b: Use straight lines that do not cross | c: Write the names inside the cell parts | d: Skip labels if the drawing looks neat)

## Slide 15: `s15` — Making a Model of an Animal Cell
- **Learning Objective / Purpose**: Develop a model to represent an animal cell (exemplar 5).
- **Indicators**: B7.1.2.1.1
- **On-Screen Educational Text**:
  - Plan your model
  - Choose safe materials
  - Explain each part
- **Key Ideas**: A model stands for the real thing. | Each material stands for one organelle. | A model is simplified and not to scale.
- **Complete Narration Text**: You can also make a model of an animal cell. In this picture, pupils use a clear plastic bag as the cell membrane. They fill it with jelly for the cytoplasm. A small ball is the nucleus. Beans stand for the mitochondria, and tiny beads stand for the ribosomes. Work in groups and use only safe, clean materials. A model is simplified and not to scale, and a real membrane is not a sealed bag. When you finish, explain what each part stands for and one way the model is unlike a real cell.
- **Audio Asset Reference**: `audio/s15.4cf315daf78b.mp3` (40s, source: tts)
- **Visual Type**: `illustration` · **Description**: Pupils making an animal cell model with a clear plastic bag, jelly, a ball, beans and beads.
- **Image Asset Reference**: `images/s15.5da38402c41f.webp` · **Alt Text**: Pupils making a model of an animal cell using a clear plastic bag filled with jelly, a ball, beans and beads.
- **Visual Labels**: None
- **SVG Content**: None
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 5. Use clean, safe materials, check for allergies and plan hand-washing. A model cannot show every real structure or function. AI image placement is approximate.
- **Existing Checkpoints After This Slide**: None

## Slide 16: `s16` — Checking Your Model
- **Learning Objective / Purpose**: Match each part of the model to the real cell part and note its limits.
- **Indicators**: B7.1.2.1.1
- **On-Screen Educational Text**:
  - Match each material
  - Say what it stands for
  - Name one limit
- **Key Ideas**: Each material stands for one part. | A model has limits. | A real membrane is not a sealed bag.
- **Complete Narration Text**: Check that each part of your model matches the real cell. The plastic bag stands for the cell membrane, because it holds everything in. But a real membrane is not a sealed bag. It lets some substances in and out and keeps others back. The jelly stands for the cytoplasm. The ball stands for the nucleus. The beans stand for the mitochondria, and the beads stand for the ribosomes. Every model is simplified and not to scale, so it cannot show everything a real cell does.
- **Audio Asset Reference**: `audio/s16.14115bb3643f.mp3` (35s, source: tts)
- **Visual Type**: `svg` · **Description**: Five rows: cell membrane is a plastic bag, cytoplasm is jelly, nucleus is a ball, mitochondria are beans and ribosomes are beads.
- **Image Asset Reference**: `None` · **Alt Text**: Five rows matching animal cell parts to model materials.
- **Visual Labels**: Cell membrane, Cytoplasm, Nucleus, Mitochondria, Ribosomes, Plastic bag, Jelly, Ball, Beans, Beads
- **SVG Content**: Present (3526 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 5 with CI 6.10 reflection. Materials are suggestions. Ask pupils to name one way the model is like a cell and one way it is unlike a cell.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpC` (retryRule: 2 attempts, then show the answer with the explanation):
    - [sequence] `cpC.1`: Put the steps for drawing an animal cell in the correct order. — Order: st2 -> st4 -> st3 -> st1
    - [mcq] `cpC.2`: In a model of an animal cell, what could a plastic bag stand for? — Correct: a (a: The cell membrane | b: The cell's nucleus | c: The bean-shaped mitochondria | d: The tiny ribosomes)

## Slide 17: `s17` — The Plant Cell
- **Learning Objective / Purpose**: Identify the structure of a plant cell on a labelled diagram.
- **Indicators**: B7.1.2.1.2
- **On-Screen Educational Text**:
  - The plant cell
  - Same basic parts as an animal cell
  - Three extra parts
- **Key Ideas**: A plant cell has the same basic parts as an animal cell. | It has three extra parts. | Cell wall, chloroplasts and a large vacuole.
- **Complete Narration Text**: Now let us look at a typical plant cell. It has the same basic parts as an animal cell: a cell membrane, cytoplasm, a nucleus, mitochondria and ribosomes. But it also has three extra parts. On the outside there is a strong cell wall. Many green plant cells have chloroplasts inside. And many mature cells have a large vacuole in the middle. A plant cell often has a regular, box-like shape.
- **Audio Asset Reference**: `audio/s17.1cdb3e1e4f2d.mp3` (29s, source: tts)
- **Visual Type**: `svg` · **Description**: A simplified labelled plant cell, a typical green leaf cell, with eight parts: nucleus, ribosomes, mitochondria, chloroplast, cell wall, cell membrane, large vacuole and cytoplasm.
- **Image Asset Reference**: `None` · **Alt Text**: A simplified box-shaped green leaf cell with leader lines to eight labels.
- **Visual Labels**: Nucleus, Ribosomes, Mitochondria, Chloroplast, Cell wall, Cell membrane, Large vacuole, Cytoplasm
- **SVG Content**: Present (4962 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 for B7.1.2.1.2: identify and describe the structure of a plant cell. The diagram is a simplified typical green leaf cell; not every plant cell has chloroplasts.
- **Existing Checkpoints After This Slide**: None

## Slide 18: `s18` — The Cell Wall
- **Learning Objective / Purpose**: Describe the structure and function of the cell wall.
- **Indicators**: B7.1.2.1.2
- **On-Screen Educational Text**:
  - The cell wall
  - Strong and stiff
  - Gives shape and support
- **Key Ideas**: The cell wall is outside the membrane. | With water pressure, it supports the plant. | Animal cells have no cell wall.
- **Complete Narration Text**: First, the cell wall. It is a strong, stiff layer outside the cell membrane. It is made mostly of a material called cellulose. The cell wall gives the plant cell its shape and strength. Water inside the cell pushes against the wall, and together the wall and the water pressure help a plant stand up without bones. Animal cells do not have a cell wall. That is one of the main differences between plant and animal cells.
- **Audio Asset Reference**: `audio/s18.d96937af7191.mp3` (32s, source: tts)
- **Visual Type**: `svg` · **Description**: A plant cell with its cell wall highlighted and its job written beside it.
- **Image Asset Reference**: `None` · **Alt Text**: A plant cell with the cell wall outlined thickly, and the name and job on the right.
- **Visual Labels**: Cell wall, Gives strength, and shape
- **SVG Content**: Present (2477 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 for B7.1.2.1.2. Plants are supported by the cell walls and water pressure together; do not say the wall alone holds a plant up.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcD1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qD.1`: Which part do plant cells have but animal cells do not? — Correct: d (a: Nucleus | b: Cell membrane | c: Cytoplasm | d: Cell wall)

## Slide 19: `s19` — The Chloroplasts
- **Learning Objective / Purpose**: Describe the structure and function of chloroplasts.
- **Indicators**: B7.1.2.1.2
- **On-Screen Educational Text**:
  - The chloroplasts
  - Contain chlorophyll
  - Make food from sunlight
- **Key Ideas**: Chloroplasts contain chlorophyll. | They help green cells make food. | Animal cells have no chloroplasts.
- **Complete Narration Text**: Next, the chloroplasts. These are small green parts that contain a green substance called chlorophyll. Chlorophyll traps energy from sunlight. The plant uses this energy, with water and a gas from the air called carbon dioxide, to make its own food, a sugar. This process is called photosynthesis. Chloroplasts are found mainly in green cells, such as leaf cells. Most root cells have none, because roots grow underground. Animal cells do not have chloroplasts.
- **Audio Asset Reference**: `audio/s19.7d83e12c29e8.mp3` (31s, source: tts)
- **Visual Type**: `svg` · **Description**: A plant cell with its chloroplasts highlighted and their job written beside them.
- **Image Asset Reference**: `None` · **Alt Text**: A plant cell with the green chloroplasts outlined, and the name and job on the right.
- **Visual Labels**: Chloroplast, Traps sunlight, to make food
- **SVG Content**: Present (3062 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 for B7.1.2.1.2. Photosynthesis is introduced simply; full treatment is in a later topic. Chloroplasts are found mainly in green cells; most root cells and onion bulb cells have none.
- **Existing Checkpoints After This Slide**: None

## Slide 20: `s20` — The Large Vacuole
- **Learning Objective / Purpose**: Describe the structure and function of the large vacuole.
- **Indicators**: B7.1.2.1.2
- **On-Screen Educational Text**:
  - The large vacuole
  - Full of cell sap
  - Stores water and helps keep the cell firm
- **Key Ideas**: Many mature cells have a large central vacuole. | It stores water, food and waste. | Water pressure helps keep the cell firm.
- **Complete Narration Text**: Third, the large vacuole. Many mature plant cells have one large central vacuole, a big space filled with a watery liquid called cell sap. The vacuole stores water, and it can also store food and waste. When it is full of water, it pushes against the cell wall, which helps keep the cell firm. That is why a plant wilts when it does not get enough water. Animal cells may have smaller storage compartments, but not a large central vacuole like this.
- **Audio Asset Reference**: `audio/s20.c0f95370a52a.mp3` (35s, source: tts)
- **Visual Type**: `svg` · **Description**: A plant cell with its large vacuole highlighted and its job written beside it.
- **Image Asset Reference**: `None` · **Alt Text**: A plant cell with the large central vacuole outlined, and the name and job on the right.
- **Visual Labels**: Large vacuole, Stores water and, helps cell stay firm
- **SVG Content**: Present (2626 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 for B7.1.2.1.2. Many mature plant cells, not every plant cell, have one large central vacuole. Avoid saying it is always there.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcD2` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qD.2`: What does the large vacuole store? — Correct: d (a: Sunlight and chlorophyll | b: The cell's instructions | c: Proteins for growth | d: Water, food and waste)

## Slide 21: `s21` — The Three Extra Parts
- **Learning Objective / Purpose**: Summarise the functions of the plant-only organelles.
- **Indicators**: B7.1.2.1.2
- **On-Screen Educational Text**:
  - Cell wall
  - Chloroplasts
  - Large vacuole
- **Key Ideas**: Cell wall gives strength. | Chloroplasts make food in green cells. | A large vacuole stores water.
- **Complete Narration Text**: Let us put the three extra parts together. The cell wall gives strength and shape. The chloroplasts, in green cells, make food using sunlight. In many mature cells the large vacuole stores water and helps keep the cell firm. All the other parts of a plant cell do the same jobs as in an animal cell. So the nucleus still controls the cell, and the mitochondria still release energy. Try saying the three extra parts and their jobs without looking.
- **Audio Asset Reference**: `audio/s21.96377c2b0bf5.mp3` (33s, source: tts)
- **Visual Type**: `svg` · **Description**: A table of the three extra plant cell parts and their jobs, and a row for the other parts.
- **Image Asset Reference**: `None` · **Alt Text**: A table: cell wall gives strength, chloroplasts make food in green cells, large vacuole stores water, and other parts do the same jobs as in animal cells.
- **Visual Labels**: Part, Job, Cell wall, Chloroplasts, Large vacuole, Other parts, Gives strength, Food in green cells, Stores water, Same as animal
- **SVG Content**: Present (2765 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 for B7.1.2.1.2. The three extra parts are in typical green leaf cells; not every plant cell has chloroplasts or a large vacuole.
- **Existing Checkpoints After This Slide**: None

## Slide 22: `s22` — Seeing Plant Cells
- **Learning Objective / Purpose**: Confirm that plants are made of cells by observation (exemplar 3).
- **Indicators**: B7.1.2.1.2
- **On-Screen Educational Text**:
  - Thin onion skin
  - Box-shaped cells
  - Plants are made of cells
- **Key Ideas**: Onion skin shows plant cells. | Cells look like bricks in a wall. | Plants are made up of cells.
- **Complete Narration Text**: How do we know plants are made of cells? Take a thin piece of onion skin and place it on a slide. Look at it under a microscope, because a hand magnifier is not strong enough to show cells clearly. You will see many small box-shaped cells packed together like bricks in a wall. With a good slide you may see a nucleus in some cells, but not every organelle. Onion bulb cells have no chloroplasts because the bulb grows underground. So we conclude that plants are made up of cells.
- **Audio Asset Reference**: `audio/s22.5ebd2632cee7.mp3` (38s, source: tts)
- **Visual Type**: `illustration` · **Description**: A pupil looking at a prepared slide of thin onion skin through a microscope, with a leaf and an onion on the table.
- **Image Asset Reference**: `images/s22.af0a3ec3f302.webp` · **Alt Text**: A pupil looking at a prepared slide of thin onion skin through a microscope, with an onion and a leaf on the table.
- **Visual Labels**: None
- **SVG Content**: None
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 3 for B7.1.2.1.2. Use a teacher-prepared slide and supervise microscope and glass handling; use a video or pictures if no microscope is available. Onion bulb cells grow underground and have no chloroplasts, so they are not green. AI image placement is approximate.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpD` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `cpD.1`: Which part gives a plant cell its strong, fixed shape? — Correct: d (a: Cell membrane | b: Cytoplasm | c: Nucleus | d: Cell wall)
    - [mcq] `cpD.2`: Which organelle makes food using sunlight? — Correct: b (a: Mitochondria | b: Chloroplast | c: Large vacuole | d: Ribosome)
    - [mcq] `cpD.3`: Why does a plant wilt when it does not get enough water? — Correct: b (a: Its chloroplasts stop making food and turn pale | b: Its vacuoles lose water and the cells go soft | c: Its nuclei become too big for the cell walls | d: Its cell walls melt away when the sun is hot)

## Slide 23: `s23` — Animal and Plant Cells Compared
- **Learning Objective / Purpose**: Compare animal and plant cells in a table.
- **Indicators**: B7.1.2.1.1, B7.1.2.1.2
- **On-Screen Educational Text**:
  - Compare the two cells
  - Shared parts
  - Plant-only parts
- **Key Ideas**: Both cells share five parts. | Plants have three extra parts, but not every plant cell has all three. | Use the table to compare.
- **Complete Narration Text**: Now compare a typical animal cell and a typical plant cell. Both have a cell membrane and a nucleus. Both also have cytoplasm, mitochondria and ribosomes. But plant cells have a cell wall. Green plant cells have chloroplasts, and many mature plant cells have a large vacuole. Look at the table. The word Yes means the part is present, and No means it is not. Green cells and many cells mean only some plant cells have it. Use this table to answer questions about differences and similarities.
- **Audio Asset Reference**: `audio/s23.72501d3fb3a8.mp3` (31s, source: tts)
- **Visual Type**: `svg` · **Description**: A table comparing a typical animal cell and a typical plant cell for five parts, with Yes, No, Green cells or Many cells for each.
- **Image Asset Reference**: `None` · **Alt Text**: A table: cell membrane and nucleus are Yes for both cells; cell wall is No for animal and Yes for plant; chloroplasts are No for animal and Green cells for plant; large vacuole is No for animal and Many cells for plant.
- **Visual Labels**: Part, Animal, Plant, Cell membrane, Nucleus, Cell wall, Chloroplasts, Large vacuole, Yes, No, Green cells, Many cells
- **SVG Content**: Present (4738 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Colour fills are backed by the text and the narration. Yellow cells mean only some plant cells have the part. Yes means present and No means not present.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcE1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qE.1`: Which pair of parts is found in both animal and plant cells? — Correct: a (a: Nucleus and cell membrane | b: Cell wall and chloroplasts | c: Chloroplasts and large vacuole | d: Cell wall and nucleus)

## Slide 24: `s24` — Why Plant Cells Are Different
- **Learning Objective / Purpose**: Link each extra plant part to a need of the plant.
- **Indicators**: B7.1.2.1.2
- **On-Screen Educational Text**:
  - Plants make their own food
  - Plants need to stay firm
  - Plants store water
- **Key Ideas**: Chloroplasts help green cells make food. | The cell wall and water pressure keep plants firm. | Many mature cells have a large vacuole.
- **Complete Narration Text**: Why do plant cells have extra parts? Plants make their own food by photosynthesis. Chloroplasts in green cells use sunlight, water and carbon dioxide to make sugar, and the plant uses this sugar for energy and growth. The cell wall and the water pressure inside the cells help hold the plant firm. Many mature cells also have a large vacuole that stores water. Each extra part helps the plant to live and grow. Animals get food by eating, so their cells have no chloroplasts.
- **Audio Asset Reference**: `audio/s24.60337644c51f.mp3` (35s, source: tts)
- **Visual Type**: `svg` · **Description**: Three rows linking what a plant needs to the plant cell part that helps: makes food to chloroplast, stays firm to cell wall, stores water to large vacuole.
- **Image Asset Reference**: `None` · **Alt Text**: Three rows: makes food to chloroplast, stays firm to cell wall, stores water to large vacuole.
- **Visual Labels**: Makes food, Stays firm, Stores water, Chloroplast, Cell wall, Large vacuole
- **SVG Content**: Present (2212 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Link structure to function; do not stress memorisation. Photosynthesis is introduced simply; only green cells have chloroplasts.
- **Existing Checkpoints After This Slide**: None

## Slide 25: `s25` — Drawing a Plant Cell
- **Learning Objective / Purpose**: Draw and label a plant cell (exemplar 4).
- **Indicators**: B7.1.2.1.2
- **On-Screen Educational Text**:
  - Draw the box shape
  - Add the three extra parts
  - Label with straight lines
- **Key Ideas**: Draw the box shape first. | Add the extra parts and label neatly. | A drawing is simplified and not to scale.
- **Complete Narration Text**: Now draw a plant cell. First, draw a large box shape for the cell wall, and draw a second line just inside it for the cell membrane. Second, draw the nucleus and the large vacuole. Third, add chloroplasts, mitochondria and ribosomes in the cytoplasm. Last, label every part with straight lines that do not cross. Compare it with your animal cell. This is a simplified diagram of a green leaf cell. It is not to scale, and real cells have more parts.
- **Audio Asset Reference**: `audio/s25.8ba04ac4b076.mp3` (34s, source: tts)
- **Visual Type**: `svg` · **Description**: Four numbered steps for drawing and labelling a plant cell.
- **Image Asset Reference**: `None` · **Alt Text**: Four numbered steps: draw a large box shape, draw the nucleus and vacuole, add chloroplasts and others, label with straight lines.
- **Visual Labels**: Draw a large box shape, Draw the nucleus and vacuole, Add chloroplasts and others, Label with straight lines
- **SVG Content**: Present (2180 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 4 for B7.1.2.1.2. The drawing is a simplified green leaf cell, not to scale; real cells have more parts.
- **Existing Checkpoints After This Slide**: None

## Slide 26: `s26` — Making a Model of a Plant Cell
- **Learning Objective / Purpose**: Develop a model to represent a plant cell (exemplar 5).
- **Indicators**: B7.1.2.1.2
- **On-Screen Educational Text**:
  - Plan your model
  - Match materials to parts
  - Say how it is like a real cell
- **Key Ideas**: Each material stands for one part. | A box can stand for the cell wall. | A model is simplified and not to scale.
- **Complete Narration Text**: Let us also make a model of a plant cell. In this picture, pupils use a small cardboard box as the cell wall. A clear plastic bag inside is the cell membrane. A balloon filled with water is the large vacuole, and green paper shapes are the chloroplasts. A ball is the nucleus. Plan your model together and say what each material stands for. The model is simplified and not to scale, and a real membrane is not a sealed bag. Say one way it is like a real cell and one way it is different.
- **Audio Asset Reference**: `audio/s26.d951c4187410.mp3` (40s, source: tts)
- **Visual Type**: `illustration` · **Description**: Pupils making a plant cell model with a cardboard box, a clear plastic bag, a water balloon, green paper shapes and a ball.
- **Image Asset Reference**: `images/s26.f154a4516034.webp` · **Alt Text**: Pupils making a model of a plant cell using a small cardboard box, a clear plastic bag, a balloon of water, green paper shapes and a ball.
- **Visual Labels**: None
- **SVG Content**: None
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 5 for B7.1.2.1.2. Use clean, safe materials and plan hand-washing. A model cannot show every real structure or function. AI image placement is approximate.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpE` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `cpE.1`: Which pair is found only in plant cells? — Correct: c (a: Nucleus and mitochondria | b: Cell membrane and ribosomes | c: Chloroplasts and cell wall | d: Cytoplasm and chloroplasts)
    - [mcq] `cpE.2`: Why can green plants make their own food but animals cannot? — Correct: c (a: Plants have a nucleus | b: Plants have mitochondria | c: Plants have chloroplasts | d: Plants have cytoplasm)
    - [mcq] `cpE.3`: Which statement about animal and plant cells is correct? — Correct: a (a: Both have mitochondria to release energy | b: Only plant cells have a nucleus in the middle | c: Only animal cells have a cell membrane around them | d: Animal cells have a cell wall too)

## Slide 27: `s27` — Bringing It All Together
- **Learning Objective / Purpose**: Recap the whole topic.
- **Indicators**: B7.1.2.1.1, B7.1.2.1.2
- **On-Screen Educational Text**:
  - Cells are the basic unit of life
  - Animal and plant cell parts
  - See, draw and model cells
- **Key Ideas**: Cells are the basic unit of life. | A typical animal cell has five main parts. | Typical plant cells add three extra parts.
- **Complete Narration Text**: Let us bring it all together. A cell is the basic unit of life, and all plants and animals are made of cells. Inside, small organelles each do a job. A typical animal cell has a cell membrane, cytoplasm, a nucleus, mitochondria and ribosomes. A typical plant cell also has a cell wall, and many have chloroplasts and a large vacuole. Diagrams and models are simplified. You can see cells with a microscope, draw them and model them. Well done, class!
- **Audio Asset Reference**: `audio/s27.966b02b8cdb6.mp3` (33s, source: tts)
- **Visual Type**: `svg` · **Description**: A diagram with Cells at the top, branching to the animal cell parts and the three extra plant parts.
- **Image Asset Reference**: `None` · **Alt Text**: A diagram with Cells at the top, an animal cell column with five parts, and a plant extras column with three parts.
- **Visual Labels**: Cells, Animal cell, Plant extras, Cell membrane, Cytoplasm, Nucleus, Mitochondria, Ribosomes, Cell wall, Chloroplast, Large vacuole
- **SVG Content**: Present (3334 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Use as a one-minute oral recap before the mastery check. Diagrams and models are simplified.
- **Existing Checkpoints After This Slide**: None

## End-of-Lesson Mastery Check (Pass Mark: 4)
- [mcq] `mastery.1`: Skin, blood and muscle cells look different. What do they have in common? — Correct: d (a: They all have exactly the same shape and size | b: They are all made of one single organelle | c: They are all non-living units of matter | d: They are all living cells with basic parts)
- [mcq] `mastery.2`: A pupil draws an animal cell with a cell wall and chloroplasts. What is wrong? — Correct: c (a: Animal cells have no cytoplasm inside them | b: The nucleus is missing from the drawing | c: Animal cells do not have these parts | d: The membrane should be much thicker)
- [mcq] `mastery.3`: Which organelle would you expect to be most numerous in a very active muscle cell? — Correct: a (a: Mitochondria | b: Chloroplasts | c: Cell walls | d: Large vacuoles)
- [mcq] `mastery.4`: Which part controls what enters and leaves both plant and animal cells? — Correct: b (a: The plant cell wall | b: Cell membrane | c: The nucleus | d: The cytoplasm)
- [mcq] `mastery.5`: A pupil makes a model of a plant cell. Which material best stands for the large vacuole? — Correct: c (a: A small round ball of clay | b: Green paper shapes cut as ovals | c: A balloon filled with water | d: A cardboard box with an open top)

# Cycles: The Carbon Cycle (`b8-sci-t1-the-carbon-cycle`)

- **CDN packagePath**: `packages/b8-sci-t1-the-carbon-cycle.39cb3b2ba786.json` (hash `39cb3b2ba786`, updated `2026-11-23T12:30:21.124Z`)
- **Curriculum**: ges · **Class**: Basic 8 · **Subject**: Science · **Term**: 1
- **Content Standard**: B8.2.1.1
- **Indicators**: B8.2.1.1.1, B8.2.1.1.2
- **Total Slides**: 26 · **Checkpoints**: 15 · **Mastery Check Items**: 5

## Slide 1: `s01` — Carbon Is All Around Us
- **Learning Objective / Purpose**: Hook: carbon in daily life.
- **Indicators**: B8.2.1.1.1
- **On-Screen Educational Text**:
  - Carbon is in living things
  - Carbon moves through nature
  - Today: the carbon cycle
- **Key Ideas**: Carbon is found in living things and in the air. | Carbon moves between the air, living things and the soil. | This movement is the carbon cycle.
- **Complete Narration Text**: Good morning, class. Look at this farm: maize is growing in the field. A woman is cooking on a charcoal stove. Leaves are rotting on the ground. All of these involve carbon, which moves between the air, living things and the soil again and again. We call this movement the carbon cycle.
- **Audio Asset Reference**: `audio/s01.f2dc72bb051f.mp3` (21s, source: tts)
- **Visual Type**: `illustration` · **Description**: A Ghanaian farm in morning light with green maize growing, a woman cooking on a charcoal stove, and a pile of rotting leaves.
- **Image Asset Reference**: `images/s01.ea731c815d0c.webp` · **Alt Text**: A Ghanaian farm in morning light with green maize growing, a woman cooking on a charcoal stove, and a pile of rotting leaves.
- **Visual Labels**: None
- **SVG Content**: None
- **Existing Interactive Configuration**: None
- **Teacher Note**: Content standard B8.2.1.1 is previewed here. The scene shows maize (photosynthesis), a charcoal stove (burning) and rotting leaves (decay); the four processes come later. AI image placement is approximate.
- **Existing Checkpoints After This Slide**: None

## Slide 2: `s02` — What Is Carbon?
- **Learning Objective / Purpose**: Carbon as an element (indicator 1, introduction).
- **Indicators**: B8.2.1.1.1
- **On-Screen Educational Text**:
  - Carbon is a chemical element
  - Its symbol is C
  - It is in all living things
- **Key Ideas**: Carbon is a chemical element with the symbol C. | All living things contain carbon. | Carbon (IV) oxide is a gas in the air that contains carbon.
- **Complete Narration Text**: Carbon is a chemical element, and its symbol is C. Every living thing contains carbon, in its food and in its body. Carbon is also in the air, joined with oxygen as a gas called carbon dioxide, whose chemical name is carbon (IV) oxide. Fuels such as charcoal and petrol contain carbon too.
- **Audio Asset Reference**: `audio/s02.4a9c88dca7ca.mp3` (21s, source: tts)
- **Visual Type**: `svg` · **Description**: Carbon: A chemical element, symbol C. Where carbon is: In living things, In the air, In fuels, charcoal, In dead matter.
- **Image Asset Reference**: `None` · **Alt Text**: Carbon: A chemical element, symbol C. Where carbon is: In living things, In the air, In fuels, charcoal, In dead matter.
- **Visual Labels**: Carbon, A chemical element, symbol C, In living things, In the air, In fuels, charcoal, In dead matter
- **SVG Content**: Present (1901 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Content standard B8.2.1.1, introduction. Carbon is an element from the periodic table lesson (B8.1.1.2), and carbon (IV) oxide was met there as a compound. The name carbon (IV) oxide follows the NaCCA wording; carbon dioxide is the common name.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcA1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qA.1`: Which gas in the air contains carbon? — Correct: a (a: Carbon (IV) oxide, a gas in the air | b: Oxygen, the gas we breathe in | c: Nitrogen, the most common gas | d: Water vapour from boiling water)

## Slide 3: `s03` — Where Carbon Is Stored
- **Learning Objective / Purpose**: Stores of carbon (indicator 1).
- **Indicators**: B8.2.1.1.1
- **On-Screen Educational Text**:
  - Carbon is stored in many places
  - Plants and animals contain carbon
  - Fuels store carbon too
- **Key Ideas**: Carbon is stored in the air, living things, dead matter and fuels. | In the air, carbon is in carbon (IV) oxide. | Fuels are stores of carbon.
- **Complete Narration Text**: Carbon is stored in several places. In the air, it is present as carbon (IV) oxide. Plants and animals hold carbon in their food and body parts. Dead matter in the soil still holds carbon as it rots. Fuels such as coal, oil and charcoal also store carbon.
- **Audio Asset Reference**: `audio/s03.7c523b7c9b95.mp3` (19s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 4 rows: Air, Carbon (IV) oxide; Plants and animals, Food and body; Dead matter in soil, Rotting remains; Fuels, Coal, oil, charcoal.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 4 rows: Air, Carbon (IV) oxide; Plants and animals, Food and body; Dead matter in soil, Rotting remains; Fuels, Coal, oil, charcoal.
- **Visual Labels**: Store, Carbon is in, Air, Plants and animals, Dead matter in soil, Fuels, Carbon (IV) oxide, Food and body, Rotting remains, Coal, oil, charcoal
- **SVG Content**: Present (2754 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Content standard B8.2.1.1. Carbon is also stored in the oceans and in some rocks; these are not required at this level.
- **Existing Checkpoints After This Slide**: None

## Slide 4: `s04` — A Cycle Repeats
- **Learning Objective / Purpose**: What a cycle is (indicator 1, exemplar 4).
- **Indicators**: B8.2.1.1.1
- **On-Screen Educational Text**:
  - A cycle repeats again and again
  - Carbon is reused, not lost
  - It circulates continuously
- **Key Ideas**: A cycle is a pattern that repeats. | Carbon is reused and not lost. | The carbon cycle is a repeated pattern in nature.
- **Complete Narration Text**: A cycle is a pattern that repeats again and again. Carbon begins in the air. Plants take it in, and animals get it by eating plants. Then carbon returns to the air, and the pattern starts again. This is why we call it a repeated pattern in nature.
- **Audio Asset Reference**: `audio/s04.862c6c9ac504.mp3` (19s, source: tts)
- **Visual Type**: `svg` · **Description**: Four numbered steps: carbon is in the air, plants take it in, animals eat plants, carbon returns to the air.
- **Image Asset Reference**: `None` · **Alt Text**: Four numbered steps: carbon is in the air, plants take it in, animals eat plants, carbon returns to the air.
- **Visual Labels**: Carbon is in the air, Plants take it in, Animals eat plants, Carbon returns to the air
- **SVG Content**: Present (2129 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 4 of B8.2.1.1.1 (give reasons why it is a repeated pattern) is introduced here and completed on s17. This is a simple first path only; the full cycle is on s16.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcA2` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qA.2`: Why is the carbon cycle called a cycle? — Correct: d (a: Carbon is used up once and then lost | b: Carbon only stays inside living things | c: Carbon only ever moves from animals to plants | d: Carbon is reused again and again)

## Slide 5: `s05` — Finding the Carbon Cycle
- **Learning Objective / Purpose**: Find and write notes (indicator 1, exemplar 1).
- **Indicators**: B8.2.1.1.1
- **On-Screen Educational Text**:
  - Use charts, pictures or the internet
  - Name each stage
  - Write short notes on each
- **Key Ideas**: Use charts, pictures or reliable websites. | Name each stage of the cycle. | Write a short note on what happens at each stage.
- **Complete Narration Text**: Now find the carbon cycle in a chart, a picture or a reliable website, with your teacher's help. First, find a clear chart or picture. Name each stage that you see. Then write a short note on what happens at each stage. Finally, check that your source is reliable, such as a textbook or a school website.
- **Audio Asset Reference**: `audio/s05.c9314db3c52b.mp3` (23s, source: tts)
- **Visual Type**: `svg` · **Description**: Four numbered steps: find a chart or picture, name each stage, write a short note on each, check your source.
- **Image Asset Reference**: `None` · **Alt Text**: Four numbered steps: find a chart or picture, name each stage, write a short note on each, check your source.
- **Visual Labels**: Find a chart or picture, Name each stage, Write a short note on each, Check your source
- **SVG Content**: Present (2139 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B8.2.1.1.1 (identify the carbon cycle from the internet, charts or pictures and write short notes on what happens at each stage). Pupils may use textbooks, charts or, if the school has it, the internet with the teacher present. The notes are written and teacher assessed; the app does not score them.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpA` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `cpA.1`: Where is carbon found in nature? — Correct: c (a: Only in the bodies of animals | b: Only in the air and in water | c: In air, living things, soil, fuels | d: Only in plants that grow in soil)
    - [mcq] `cpA.2`: Why is the carbon cycle an example of a repeated pattern in nature? — Correct: b (a: Carbon is made new every day by plants | b: The same carbon is circulated again and again | c: Carbon is destroyed and replaced by oxygen | d: Carbon stays in one place for ever)
    - [mcq] `cpA.3`: A pupil wants to find the carbon cycle for a project. What is the best first step? — Correct: a (a: Find a clear chart from a reliable source | b: Copy the first page found online without reading it | c: Guess the stages from memory without any source | d: Ask a friend to draw it and copy their work)
    - [mcq] `cpA.4`: Which list shows only stores of carbon? — Correct: d (a: Sand, salt, glass and pure water | b: Oxygen, nitrogen, hydrogen and helium | c: Aluminium, iron, copper and gold | d: Air, plants, animals and fuels)

## Slide 6: `s06` — Photosynthesis
- **Learning Objective / Purpose**: Photosynthesis in the cycle (indicator 1, exemplar 3a).
- **Indicators**: B8.2.1.1.1
- **On-Screen Educational Text**:
  - Plants make food by photosynthesis
  - They use sunlight and chlorophyll
  - Oxygen is given out
- **Key Ideas**: Photosynthesis makes glucose and oxygen inside the leaf. | It needs carbon (IV) oxide, water and sunlight. | Water moves from the roots up to the leaves.
- **Complete Narration Text**: Plants make their own food by photosynthesis. They need sunlight, which chlorophyll in the chloroplasts absorbs. The leaves take in carbon (IV) oxide from the air. The roots take in water from the soil, and it moves up the stem to the leaves. Inside the leaf, these are used to make glucose, which is food for the plant. Oxygen is given out into the air.
- **Audio Asset Reference**: `audio/s06.8fedac37111a.mp3` (26s, source: tts)
- **Visual Type**: `svg` · **Description**: A simple plant with a stem and two green leaves stands in brown soil with small roots. A sun shines at the top right. Labelled arrows show Sunlight reaching the leaf, Carbon (IV) oxide entering the leaf, Oxygen leaving the leaf, and Water (from roots) moving up the stem towards the leaves. A yellow dot inside the left leaf, joined by a line to the label Glucose (food) made in leaf, shows where glucose is made.
- **Image Asset Reference**: `None` · **Alt Text**: A simple plant with a stem and two green leaves stands in brown soil with small roots. A sun shines at the top right. Labelled arrows show Sunlight reaching the leaf, Carbon (IV) oxide entering the leaf, Oxygen leaving the leaf, and Water (from roots) moving up the stem towards the leaves. A yellow dot inside the left leaf, joined by a line to the label Glucose (food) made in leaf, shows where glucose is made.
- **Visual Labels**: Sunlight, Carbon (IV) oxide, Oxygen, Glucose (food), made in leaf, Water (from roots)
- **SVG Content**: Present (2667 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 3 of B8.2.1.1.1 (a: photosynthesis). Chloroplasts and chlorophyll link to the cells lesson (B8.1.2.1). Glucose is a product made inside the leaf, so it is shown with a line to a dot and not with an arrow going in. The blue arrow shows water moving up from the roots. In words: carbon (IV) oxide and water, with light and chlorophyll, make glucose and oxygen. The drawing is a simple model, not to scale.
- **Existing Checkpoints After This Slide**: None

## Slide 7: `s07` — Photosynthesis in Words
- **Learning Objective / Purpose**: Summary of photosynthesis (indicator 1, exemplar 3a).
- **Indicators**: B8.2.1.1.1
- **On-Screen Educational Text**:
  - Takes in carbon (IV) oxide and water
  - Needs sunlight and chlorophyll
  - Makes glucose and gives out oxygen
- **Key Ideas**: Photosynthesis takes in carbon (IV) oxide and water. | It makes glucose and gives out oxygen. | It removes carbon (IV) oxide from the air.
- **Complete Narration Text**: Let us summarise photosynthesis. The plant takes in carbon (IV) oxide and water, and it needs sunlight and chlorophyll, the green substance in chloroplasts. It makes glucose, a sugar that is the plant's food, and it gives out oxygen. In words: carbon (IV) oxide plus water gives glucose and oxygen, using sunlight and chlorophyll. So photosynthesis removes carbon (IV) oxide from the air.
- **Audio Asset Reference**: `audio/s07.d89b8bbcecb1.mp3` (25s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 4 rows: Takes in, Carbon (IV) oxide, water; Needs, Sunlight, chlorophyll; Makes, Glucose (food); Gives out, Oxygen.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 4 rows: Takes in, Carbon (IV) oxide, water; Needs, Sunlight, chlorophyll; Makes, Glucose (food); Gives out, Oxygen.
- **Visual Labels**: Part, Photosynthesis, Takes in, Needs, Makes, Gives out, Carbon (IV) oxide, water, Sunlight, chlorophyll, Glucose (food), Oxygen
- **SVG Content**: Present (2739 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 3 of B8.2.1.1.1 (a). Photosynthesis happens in green parts that contain chloroplasts, so it needs light and happens in the day. Carbon moves from the air into glucose. Word equation: carbon (IV) oxide plus water gives glucose and oxygen, using sunlight and chlorophyll.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcB1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qB.1`: Which two substances does photosynthesis make? — Correct: c (a: Carbon (IV) oxide and water | b: Glucose and carbon (IV) oxide | c: Glucose and oxygen | d: Oxygen and carbon (IV) oxide)

## Slide 8: `s08` — Respiration
- **Learning Objective / Purpose**: Respiration in the cycle (indicator 1, exemplar 3b).
- **Indicators**: B8.2.1.1.1
- **On-Screen Educational Text**:
  - Respiration releases energy from food
  - It uses oxygen
  - It gives out carbon (IV) oxide
- **Key Ideas**: Respiration releases energy from food. | It uses oxygen and gives out carbon (IV) oxide and water. | Respiration returns carbon to the air.
- **Complete Narration Text**: All living things respire, which means they release energy from food. In respiration, cells use food such as glucose, together with oxygen. Much of this work happens in the mitochondria of eukaryotic cells. In words: glucose plus oxygen gives carbon (IV) oxide, water and energy. So respiration returns carbon to the air.
- **Audio Asset Reference**: `audio/s08.26fcf0b86b59.mp3` (21s, source: tts)
- **Visual Type**: `svg` · **Description**: Three boxes joined by downward arrows. The top box says Food (glucose) and oxygen. The middle box says Respiration in living cells. The bottom box says Energy, carbon (IV) oxide, water.
- **Image Asset Reference**: `None` · **Alt Text**: Three boxes joined by downward arrows. The top box says Food (glucose) and oxygen. The middle box says Respiration in living cells. The bottom box says Energy, carbon (IV) oxide, water.
- **Visual Labels**: Food (glucose) and oxygen, Respiration in living cells, Energy, carbon (IV) oxide, water
- **SVG Content**: Present (1315 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 3 of B8.2.1.1.1 (b: respiration). This is respiration with oxygen. Word equation: glucose plus oxygen gives carbon (IV) oxide, water and energy. Respiration is not breathing: breathing moves air in and out of the body, and respiration releases energy from food in cells. Mitochondria were met in the cells lesson; bacteria and other cells without mitochondria also respire.
- **Existing Checkpoints After This Slide**: None

## Slide 9: `s09` — Plants Respire Too
- **Learning Objective / Purpose**: Plants photosynthesise and respire (indicator 1, exemplar 3).
- **Indicators**: B8.2.1.1.1
- **On-Screen Educational Text**:
  - Plants respire day and night
  - Photosynthesis needs light
  - Respiration happens all the time
- **Key Ideas**: Plants respire day and night. | Photosynthesis needs light. | Animals respire but do not photosynthesise.
- **Complete Narration Text**: Plants also respire. During the day, a plant photosynthesises and respires at the same time, but in bright light it makes much more food than it uses. At night there is no light, so photosynthesis stops, but respiration continues. Animals respire too, but they cannot photosynthesise. So all living things give out carbon (IV) oxide in respiration, and green plants take it in by photosynthesis.
- **Audio Asset Reference**: `audio/s09.08db229ee0d1.mp3` (26s, source: tts)
- **Visual Type**: `svg` · **Description**: Plants and respiration: Plants photosynthesise and respire. Remember: Plants make food, Plants respire too, Animals respire, Respiration: always.
- **Image Asset Reference**: `None` · **Alt Text**: Plants and respiration: Plants photosynthesise and respire. Remember: Plants make food, Plants respire too, Animals respire, Respiration: always.
- **Visual Labels**: Plants and respiration, Plants photosynthesise and respire, Plants make food, Plants respire too, Animals respire, Respiration: always
- **SVG Content**: Present (1942 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 3 of B8.2.1.1.1 (a, b) and the Note under B8.2.1.1.2 (discuss photosynthesis and respiration in plants as part of the carbon cycle). In bright light a plant takes in more carbon (IV) oxide than it gives out. Respiration is not breathing.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcB2` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qB.2`: What is the main job of respiration in a cell? — Correct: b (a: It makes food from sunlight | b: It releases energy from food | c: It takes in carbon (IV) oxide | d: It stores water in the cell)

## Slide 10: `s10` — Following the Carbon
- **Learning Objective / Purpose**: Trace carbon through a food path (indicator 1, exemplar 3).
- **Indicators**: B8.2.1.1.1
- **On-Screen Educational Text**:
  - Follow carbon through the steps
  - Carbon moves into plants first
  - Respiration sends it back to air
- **Key Ideas**: Carbon enters plants by photosynthesis. | Carbon passes to animals when they eat plants. | Respiration returns carbon to the air.
- **Complete Narration Text**: Let us follow carbon through one turn of the cycle. A maize plant takes in carbon (IV) oxide from the air. Photosynthesis turns it into glucose, which is food. A goat eats the maize, so the carbon enters the goat. Respiration then returns carbon (IV) oxide to the air.
- **Audio Asset Reference**: `audio/s10.8320984e02e3.mp3` (20s, source: tts)
- **Visual Type**: `svg` · **Description**: Four numbered steps: plant takes in carbon (IV) oxide, photosynthesis makes glucose, an animal eats the plant, respiration returns it to the air.
- **Image Asset Reference**: `None` · **Alt Text**: Four numbered steps: plant takes in carbon (IV) oxide, photosynthesis makes glucose, an animal eats the plant, respiration returns it to the air.
- **Visual Labels**: Plant takes in carbon (IV) oxide, Photosynthesis makes glucose, An animal eats the plant, Respiration returns it to the air
- **SVG Content**: Present (2171 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 3 of B8.2.1.1.1 (a, b). This order is also used as a sequence check item. Pupils may follow other food paths, such as grass, cow and person.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpB` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `cpB.1`: Which gas do plants take in for photosynthesis? — Correct: a (a: Carbon (IV) oxide from the air | b: Oxygen from the air we breathe | c: Nitrogen from the air around us | d: Water vapour from the clouds)
    - [tapDiagram] `cpB.2`: Tap the gas that a plant gives out during photosynthesis. — Hotspot: h1
    - [mcq] `cpB.3`: Why do plants give out carbon (IV) oxide at night? — Correct: b (a: They stop all life processes in the dark | b: They still respire, but cannot photosynthesise | c: They start photosynthesis in the dark | d: They change oxygen into carbon (IV) oxide)
    - [sequence] `cpB.4`: Put the steps in order to follow carbon from the air to a goat and back. — Order: st4 -> st2 -> st1 -> st3

## Slide 11: `s11` — Burning
- **Learning Objective / Purpose**: Burning returns carbon (indicator 1, exemplar 3c).
- **Indicators**: B8.2.1.1.1
- **On-Screen Educational Text**:
  - Combustion is burning a fuel in oxygen
  - Fuels contain carbon
  - Combustion releases carbon (IV) oxide
- **Key Ideas**: Combustion is burning a fuel in oxygen. | Combustion releases carbon (IV) oxide, heat and light. | Bush burning also releases carbon (IV) oxide.
- **Complete Narration Text**: Burning is another way that carbon returns to the air. The scientific name for burning a fuel in oxygen is combustion. During combustion, the carbon in the fuel joins with oxygen and carbon (IV) oxide is released. Firewood, charcoal, petrol and diesel are fuels that contain carbon. Bush burning does the same, and combustion also gives out heat and light.
- **Audio Asset Reference**: `audio/s11.2855cc4dfae1.mp3` (24s, source: tts)
- **Visual Type**: `svg` · **Description**: Burning: Burning releases carbon (IV) oxide. Examples: Firewood, Charcoal, Petrol and diesel, Bush burning.
- **Image Asset Reference**: `None` · **Alt Text**: Burning: Burning releases carbon (IV) oxide. Examples: Firewood, Charcoal, Petrol and diesel, Bush burning.
- **Visual Labels**: Burning, Burning releases carbon (IV) oxide, Firewood, Charcoal, Petrol and diesel, Bush burning
- **SVG Content**: Present (1889 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 3 of B8.2.1.1.1 (c: burning). Combustion is the scientific name for burning a fuel in oxygen. Pupils do not burn anything in this lesson; use pictures or a video. Burning in too little air also makes a poisonous gas, so a charcoal stove must never be used in a closed room.
- **Existing Checkpoints After This Slide**: None

## Slide 12: `s12` — Decay
- **Learning Objective / Purpose**: Decay returns carbon (indicator 1, exemplar 3d).
- **Indicators**: B8.2.1.1.1
- **On-Screen Educational Text**:
  - Decay is also called decomposition
  - Bacteria and fungi are decomposers
  - They give out carbon (IV) oxide
- **Key Ideas**: Decay is also called decomposition. | Decomposers respire and give out carbon (IV) oxide. | Decomposition also returns nutrients to the soil.
- **Complete Narration Text**: Decay is another way that carbon returns to the air. Decay is also called decomposition. When plants and animals die, decomposers such as bacteria and fungi feed on the dead matter. Decomposers respire, so they give out carbon (IV) oxide. They also return nutrients to the soil.
- **Audio Asset Reference**: `audio/s12.367f12b28fd4.mp3` (19s, source: tts)
- **Visual Type**: `svg` · **Description**: Four numbered steps: plants and animals die, decomposers feed on them, decomposers respire, carbon (IV) oxide goes to air.
- **Image Asset Reference**: `None` · **Alt Text**: Four numbered steps: plants and animals die, decomposers feed on them, decomposers respire, carbon (IV) oxide goes to air.
- **Visual Labels**: Plants and animals die, Decomposers feed on them, Decomposers respire, Carbon (IV) oxide goes to air
- **SVG Content**: Present (2133 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 3 of B8.2.1.1.1 (d: decay). Decay is also called decomposition. Decomposers, bacteria and fungi were met in the cells lesson. Decomposition by decomposers is respiration; some carbon also stays in the soil.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcC1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qC.1`: What do decomposers do? — Correct: d (a: They make food from sunlight and water | b: They burn dead plants to make heat | c: They turn dead matter into pure oxygen | d: They break down dead plants and animals)

## Slide 13: `s13` — The Four Processes
- **Learning Objective / Purpose**: Four processes together (indicator 1, exemplar 3).
- **Indicators**: B8.2.1.1.1
- **On-Screen Educational Text**:
  - Photosynthesis takes carbon from air
  - Three processes return it
  - Together they move carbon round
- **Key Ideas**: Photosynthesis takes carbon (IV) oxide from the air. | Respiration, burning and decay put it back. | The four processes work together.
- **Complete Narration Text**: Here are the four processes together. Photosynthesis takes carbon (IV) oxide from the air. Respiration puts it back into the air. Burning puts it into the air too. Decay, also called decomposition, puts it into the air as well, through the respiration of decomposers.
- **Audio Asset Reference**: `audio/s13.fafd1d37b1be.mp3` (18s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 4 rows: Photosynthesis, Taken from the air; Respiration, Put into the air; Burning, Put into the air; Decay, Put into the air.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 4 rows: Photosynthesis, Taken from the air; Respiration, Put into the air; Burning, Put into the air; Decay, Put into the air.
- **Visual Labels**: Process, Carbon (IV) oxide, Photosynthesis, Respiration, Burning, Decay, Taken from the air, Put into the air, Put into the air, Put into the air
- **SVG Content**: Present (2751 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 3 of B8.2.1.1.1 (a to d). Pupils should say which process takes carbon (IV) oxide from the air and which three return it.
- **Existing Checkpoints After This Slide**: None

## Slide 14: `s14` — Fossil Fuels
- **Learning Objective / Purpose**: Carbon stored for a long time (indicator 1, exemplar 3c).
- **Indicators**: B8.2.1.1.1
- **On-Screen Educational Text**:
  - Fossil fuels store old carbon
  - They formed over millions of years
  - Burning them releases carbon quickly
- **Key Ideas**: Fossil fuels formed from dead plants and animals. | Coal, crude oil and natural gas are fossil fuels. | Burning them releases stored carbon quickly.
- **Complete Narration Text**: Fossil fuels are another store of carbon. They formed from the remains of dead plants and animals buried for millions of years. Coal, crude oil and natural gas are fossil fuels. Ghana produces crude oil and natural gas from fields at sea. Burning fossil fuels quickly releases carbon that was stored for millions of years.
- **Audio Asset Reference**: `audio/s14.6e8a2c1d1747.mp3` (22s, source: tts)
- **Visual Type**: `svg` · **Description**: Fossil fuels: Old carbon stored underground. Examples: Coal, Crude oil, Natural gas, Petrol and diesel.
- **Image Asset Reference**: `None` · **Alt Text**: Fossil fuels: Old carbon stored underground. Examples: Coal, Crude oil, Natural gas, Petrol and diesel.
- **Visual Labels**: Fossil fuels, Old carbon stored underground, Coal, Crude oil, Natural gas, Petrol and diesel
- **SVG Content**: Present (1890 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 3 of B8.2.1.1.1 (c). Petrol and diesel are made from crude oil. Ghana produces crude oil and natural gas offshore (general knowledge, not from the curriculum). Charcoal and firewood are not fossil fuels, because they come from trees.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcC2` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qC.2`: Which of these is a fossil fuel? — Correct: c (a: Firewood from a living tree | b: Charcoal made from burnt wood | c: Crude oil from underground | d: Dried maize stalks from a farm)

## Slide 15: `s15` — Spot the Four Processes
- **Learning Objective / Purpose**: Identify the processes in a scene (indicator 1, exemplar 3).
- **Indicators**: B8.2.1.1.1
- **On-Screen Educational Text**:
  - Name the process in each part
  - Which take carbon from the air?
  - Which put carbon back?
- **Key Ideas**: The maize shows photosynthesis. | The goat and farmer show respiration. | The fire shows burning, and the rotting leaves show decay.
- **Complete Narration Text**: Look at the picture and name the four processes. The green maize is photosynthesising in the sunlight. The goat and the farmer are respiring. The charcoal fire is burning. The rotting leaves and mushrooms show decay. Which of these take carbon (IV) oxide from the air, and which put it back?
- **Audio Asset Reference**: `audio/s15.76f81d0bddd9.mp3` (20s, source: tts)
- **Visual Type**: `illustration` · **Description**: A Ghanaian farm scene with green maize in sunlight, a goat and a farmer, a charcoal fire, and rotting leaves with mushrooms.
- **Image Asset Reference**: `images/s15.16a554355264.webp` · **Alt Text**: A Ghanaian farm scene with green maize in sunlight, a goat and a farmer, a charcoal fire, and rotting leaves with mushrooms.
- **Visual Labels**: None
- **SVG Content**: None
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 3 of B8.2.1.1.1 (a to d). Pupils name each process and say whether it takes carbon (IV) oxide from the air or puts it back. The maize also respires; accept this as an extension answer. AI image placement is approximate.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpC` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `cpC.1`: Which process takes carbon (IV) oxide out of the air? — Correct: d (a: Respiration in all living things | b: Burning of firewood and charcoal | c: Decay of dead plants and animals | d: Photosynthesis in green plants)
    - [mcq] `cpC.2`: Which pair of processes both put carbon (IV) oxide into the air? — Correct: b (a: Photosynthesis and burning | b: Respiration and burning | c: Photosynthesis and decay | d: Photosynthesis and respiration)
    - [mcq] `cpC.3`: Rotting mango leaves under a tree give out carbon (IV) oxide. Which process is this? — Correct: a (a: Decay, as decomposers respire | b: Burning, as the leaves heat up | c: Photosynthesis, as the leaves make food | d: Evaporation, as the water leaves them)
    - [mcq] `cpC.4`: Why does burning fossil fuels add a lot of carbon (IV) oxide to the air? — Correct: c (a: It makes new carbon out of the oxygen in the air | b: It stops plants from giving out oxygen at night | c: It releases carbon stored for millions of years | d: It turns the carbon (IV) oxide into solid carbon)

## Slide 16: `s16` — The Carbon Cycle Flow Chart
- **Learning Objective / Purpose**: Trace the cycle in a flow chart (indicator 1, exemplar 2).
- **Indicators**: B8.2.1.1.1
- **On-Screen Educational Text**:
  - A flow chart traces the carbon cycle
  - Three pathways return carbon to the air
  - The pattern repeats
- **Key Ideas**: Plants take in carbon by photosynthesis, and animals get it by eating plants. | Respiration, decomposition and burning are three separate pathways that return carbon (IV) oxide to the air. | Carbon returns to the air, so the cycle repeats.
- **Complete Narration Text**: This flow chart shows how carbon moves. Plants take carbon (IV) oxide from the air by photosynthesis. Animals get carbon by eating the plants. Plants and animals both return carbon (IV) oxide to the air by respiration. Dead plants and animals decay, and decomposition by decomposers returns it too. Burning fuels returns it as well, without any animal eating a plant first.
- **Audio Asset Reference**: `audio/s16.5c4e581221b2.mp3` (25s, source: tts)
- **Visual Type**: `svg` · **Description**: A flow chart. A bar at the top says Carbon (IV) oxide in air. An arrow labelled Photosynthesis goes down to Plants, and an arrow labelled Eating goes down to Animals. An arrow labelled When they die goes down to Dead matter, and a second arrow joins Plants to Dead matter along the left side. On the right, Plants and Animals both have arrows to a box called Respiration, which has an arrow up to the air. Dead matter has an arrow to a box called Decomposition, and a separate box called Burning of fuels stands alone. Decomposition and Burning of fuels have arrows up the right side to the air.
- **Image Asset Reference**: `None` · **Alt Text**: A flow chart. A bar at the top says Carbon (IV) oxide in air. An arrow labelled Photosynthesis goes down to Plants, and an arrow labelled Eating goes down to Animals. An arrow labelled When they die goes down to Dead matter, and a second arrow joins Plants to Dead matter along the left side. On the right, Plants and Animals both have arrows to a box called Respiration, which has an arrow up to the air. Dead matter has an arrow to a box called Decomposition, and a separate box called Burning of fuels stands alone. Decomposition and Burning of fuels have arrows up the right side to the air.
- **Visual Labels**: Carbon (IV) oxide in air, Plants, Animals, Dead matter, Photosynthesis, Eating, When they die, Respiration, Burning of fuels, Decomposition
- **SVG Content**: Present (4377 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 of B8.2.1.1.1 (produce a flow chart to trace the process of the carbon cycle in nature). Plants and animals both respire, dead plants and animals are broken down by decomposers, and fuels are burned; these are separate pathways, and none of them needs an animal to eat a plant first. This is a simplified model: carbon is also stored in the oceans and in rocks.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcD1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qD.1`: In the flow chart, how does carbon (IV) oxide first enter living things? — Correct: b (a: By respiration in animals | b: By photosynthesis in plants | c: By decomposition of dead matter | d: By the burning of fuels)

## Slide 17: `s17` — Why It Is a Repeated Pattern
- **Learning Objective / Purpose**: Reasons for a repeated pattern (indicator 1, exemplar 4).
- **Indicators**: B8.2.1.1.1
- **On-Screen Educational Text**:
  - The carbon cycle is a repeated pattern
  - Carbon is circulated continuously
  - Same carbon, used again and again
- **Key Ideas**: The carbon is circulated continuously. | Carbon is not lost but reused. | Plants take it in and other processes return it.
- **Complete Narration Text**: Why do we call the carbon cycle a repeated pattern? It is because the carbon is circulated continuously in the environment. Plants take carbon (IV) oxide from the air, and respiration, decomposition and burning return it. Animals get their carbon by eating plants. The carbon is not lost, so the same carbon is used again and again.
- **Audio Asset Reference**: `audio/s17.d44f3e0e032a.mp3` (23s, source: tts)
- **Visual Type**: `svg` · **Description**: Repeated pattern: Carbon is circulated continuously. Why it repeats: Carbon is reused, Carbon is not lost, Plants take it in, Returned to the air.
- **Image Asset Reference**: `None` · **Alt Text**: Repeated pattern: Carbon is circulated continuously. Why it repeats: Carbon is reused, Carbon is not lost, Plants take it in, Returned to the air.
- **Visual Labels**: Repeated pattern, Carbon is circulated continuously, Carbon is reused, Carbon is not lost, Plants take it in, Returned to the air
- **SVG Content**: Present (1937 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 4 of B8.2.1.1.1 (compile information on the carbon cycle and give reasons why it is a repeated pattern, for example because the carbon is circulated continuously in the environment). Pupils write their reasons in a short paragraph; teacher assessed.
- **Existing Checkpoints After This Slide**: None

## Slide 18: `s18` — Short Notes on Each Stage
- **Learning Objective / Purpose**: Write notes on each stage (indicator 1, exemplar 1).
- **Indicators**: B8.2.1.1.1
- **On-Screen Educational Text**:
  - Write a short note on each stage
  - Say what happens to the carbon
  - Use your own words
- **Key Ideas**: Write a short note on each stage. | Say what happens to the carbon at each stage. | Use your own words.
- **Complete Narration Text**: Now write short notes on what happens at each stage. In the air, carbon is present as carbon (IV) oxide. In photosynthesis, plants take the carbon into food. In feeding, the carbon passes to animals. At the return stage, respiration, decomposition and burning send carbon back to the air. Use your own words.
- **Audio Asset Reference**: `audio/s18.c7bb425432ac.mp3` (21s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 4 rows: In the air, Carbon (IV) oxide gas; Photosynthesis, Takes carbon into food; Feeding, Carbon passes to animals; Return, Carbon goes back to air.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 4 rows: In the air, Carbon (IV) oxide gas; Photosynthesis, Takes carbon into food; Feeding, Carbon passes to animals; Return, Carbon goes back to air.
- **Visual Labels**: Stage, Note, In the air, Photosynthesis, Feeding, Return, Carbon (IV) oxide gas, Takes carbon into food, Carbon passes to animals, Carbon goes back to air
- **SVG Content**: Present (2767 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B8.2.1.1.1 (write short notes on what happens at each stage). Pupils write full short notes in their books. Teacher assessed; the app does not score notes.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcD2` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qD.2`: What do the arrows back to the air show? — Correct: a (a: The cycle repeats again and again | b: The carbon is used up in the cycle | c: The cycle stops when animals die | d: The cycle only happens one time)

## Slide 19: `s19` — Make Your Own Flow Chart
- **Learning Objective / Purpose**: Produce a flow chart (indicator 1, exemplar 2).
- **Indicators**: B8.2.1.1.1
- **On-Screen Educational Text**:
  - Draw boxes and arrows
  - Add arrows back to the air
  - Present your flow chart
- **Key Ideas**: List the stages in order. | Join the boxes with arrows. | Add arrows back to the air and label the processes.
- **Complete Narration Text**: Now make your own flow chart of the carbon cycle. List the stages in order. Draw a box for each stage and join the boxes with arrows. Add arrows from respiration, decomposition and burning back to the air, to show that the cycle repeats. Label the processes on the arrows, then present your flow chart to the class.
- **Audio Asset Reference**: `audio/s19.8343448fb46b.mp3` (23s, source: tts)
- **Visual Type**: `svg` · **Description**: Four numbered steps: list the stages in order, draw boxes joined by arrows, add arrows back to the air, label each arrow and present it.
- **Image Asset Reference**: `None` · **Alt Text**: Four numbered steps: list the stages in order, draw boxes joined by arrows, add arrows back to the air, label each arrow and present it.
- **Visual Labels**: List the stages in order, Draw boxes joined by arrows, Add arrows back to the air, Label each arrow and present it
- **SVG Content**: Present (2166 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 of B8.2.1.1.1. Teacher-assessed flow chart, 4 marks: 1 all stages included (air, plants, animals, dead matter, return pathways); 1 boxes in the correct order joined by arrows; 1 processes named (photosynthesis, respiration, decomposition, burning); 1 arrows back to the air and a short explanation. Not scored by the app.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpD` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `cpD.1`: Which set lists the four processes of the carbon cycle? — Correct: d (a: Photosynthesis, respiration, melting, freezing | b: Evaporation, condensation, melting, boiling | c: Photosynthesis, evaporation, burning, freezing | d: Photosynthesis, respiration, burning, decay)
    - [tapDiagram] `cpD.2`: Tap the pathway that returns carbon (IV) oxide to the air from dead plants and animals. — Hotspot: h1
    - [mcq] `cpD.3`: Why is the carbon cycle called a repeated pattern? — Correct: c (a: Carbon is made new by each animal that eats | b: Carbon is lost and then found again later | c: Carbon is circulated again and again | d: Carbon only moves when the sun is shining)
    - [sequence] `cpD.4`: Put these stages of the carbon cycle in order. — Order: st1 -> st3 -> st2 -> st4

## Slide 20: `s20` — Carbon (IV) Oxide in the Air
- **Learning Objective / Purpose**: Role in regulating carbon (IV) oxide (indicator 2, exemplar 1).
- **Indicators**: B8.2.1.1.2
- **On-Screen Educational Text**:
  - Photosynthesis removes carbon (IV) oxide
  - Respiration, decay and burning return it
  - It rises if additions exceed removal
- **Key Ideas**: Photosynthesis removes carbon (IV) oxide from the air. | Respiration, decomposition and burning return it. | The amount in the air rises when additions are more than removal.
- **Complete Narration Text**: Let us see how the carbon cycle helps to regulate carbon (IV) oxide in the air. Photosynthesis removes carbon (IV) oxide from the air. Respiration returns it, and so does decomposition by decomposers. Burning, or combustion, returns it too. When the additions are more than the removal, the amount of carbon (IV) oxide in the air increases.
- **Audio Asset Reference**: `audio/s20.0bfc2de15827.mp3` (23s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 4 rows: Photosynthesis, Removed from air; Respiration, Returned to air; Decomposition, Returned to air; Burning, Returned to air.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 4 rows: Photosynthesis, Removed from air; Respiration, Returned to air; Decomposition, Returned to air; Burning, Returned to air.
- **Visual Labels**: Process, Carbon (IV) oxide, Photosynthesis, Respiration, Decomposition, Burning, Removed from air, Returned to air, Returned to air, Returned to air
- **SVG Content**: Present (2764 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B8.2.1.1.2 (describe the role of the carbon cycle in maintaining balance in the composition of air). The carbon cycle helps to regulate carbon (IV) oxide in the air, but it does not hold the amount fixed: when additions (respiration, decomposition and the burning of fuels) are more than removal (photosynthesis, and uptake by the oceans), the amount in the air rises. The air contains about 21% oxygen and only about 0.04% carbon (IV) oxide; this is general knowledge and pupils need not memorise the numbers.
- **Existing Checkpoints After This Slide**: None

## Slide 21: `s21` — Plants and Animals Help Each Other
- **Learning Objective / Purpose**: Exchange of gases (indicator 2, exemplar 1).
- **Indicators**: B8.2.1.1.2
- **On-Screen Educational Text**:
  - Plants take in carbon (IV) oxide
  - Animals use the oxygen
  - Respiration gives carbon back
- **Key Ideas**: Plants take in carbon (IV) oxide and give out oxygen. | Animals use oxygen for respiration. | Respiration gives out carbon (IV) oxide for plants to use.
- **Complete Narration Text**: Plants and animals help each other. Plants take in carbon (IV) oxide from the air for photosynthesis. They give out oxygen, which living things use for respiration. Animals use the oxygen to respire. In return, respiration gives out carbon in the form of carbon (IV) oxide, which plants use again.
- **Audio Asset Reference**: `audio/s21.620e553753b2.mp3` (20s, source: tts)
- **Visual Type**: `svg` · **Description**: Four numbered steps: plants take in carbon (IV) oxide, plants give out oxygen, animals use oxygen to respire, animals return carbon (IV) oxide.
- **Image Asset Reference**: `None` · **Alt Text**: Four numbered steps: plants take in carbon (IV) oxide, plants give out oxygen, animals use oxygen to respire, animals return carbon (IV) oxide.
- **Visual Labels**: Plants take in carbon (IV) oxide, Plants give out oxygen, Animals use oxygen to respire, Animals return carbon (IV) oxide
- **SVG Content**: Present (2183 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B8.2.1.1.2 (plants absorb carbon in the form of carbon (IV) oxide for photosynthesis and oxygen is produced for respiration; in return, respiration gives out carbon in the form of carbon (IV) oxide). Photosynthesis and respiration in plants are discussed as part of the carbon cycle (Note under B8.2.1.1.2); plants also respire (s09).
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcE1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qE.1`: Which gas do animals use for respiration? — Correct: d (a: Carbon (IV) oxide from the air we breathe | b: Nitrogen, made by plants in the soil | c: Hydrogen from the water in the clouds | d: Oxygen, made by plants in photosynthesis)

## Slide 22: `s22` — Carbon and Food Chains
- **Learning Objective / Purpose**: Effect on food chains (indicator 2, exemplar 2).
- **Indicators**: B8.2.1.1.2
- **On-Screen Educational Text**:
  - Carbon moves along food chains
  - Plants take carbon from the air
  - Respiration returns it to the air
- **Key Ideas**: Plants bring carbon into a food chain. | Carbon passes to the animals that eat them. | Respiration returns carbon to the air.
- **Complete Narration Text**: The carbon cycle also affects food chains. The maize plant takes carbon (IV) oxide from the air and makes food. A goat eats the maize, and the carbon passes to the goat. A person eats the goat, and the carbon passes on again. Each of them respires and returns carbon (IV) oxide to the air. So carbon moves along the food chain and then back to the air.
- **Audio Asset Reference**: `audio/s22.acf7f06c1ec0.mp3` (27s, source: tts)
- **Visual Type**: `svg` · **Description**: Carbon (IV) oxide in the air is shown in a bar across the top. Below it a food chain shows Maize, Goat and Person joined by arrows. An arrow goes down from the air to the maize, and arrows go up from each of the three to the air. Two sentences at the bottom say Respiration returns it to the air and Carbon moves along the food chain.
- **Image Asset Reference**: `None` · **Alt Text**: Carbon (IV) oxide in the air is shown in a bar across the top. Below it a food chain shows Maize, Goat and Person joined by arrows. An arrow goes down from the air to the maize, and arrows go up from each of the three to the air. Two sentences at the bottom say Respiration returns it to the air and Carbon moves along the food chain.
- **Visual Labels**: Carbon (IV) oxide, Maize, Goat, Person, Respiration returns it to the air, Carbon moves along the food chain
- **SVG Content**: Present (2492 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 of B8.2.1.1.2 (explain the effect of the carbon cycle on food chains, using diagrams). Pupils draw their own food chains with carbon arrows, for example maize, goat and person, or grass, cow and person. The upward arrows from the maize show that plants respire too.
- **Existing Checkpoints After This Slide**: None

## Slide 23: `s23` — Greenhouse Gases
- **Learning Objective / Purpose**: Greenhouse gases and the carbon cycle (indicator 2, exemplar 3).
- **Indicators**: B8.2.1.1.2
- **On-Screen Educational Text**:
  - Greenhouse gases trap heat
  - The natural effect keeps Earth warm
  - Extra gases cause global warming
- **Key Ideas**: Greenhouse gases trap heat near the Earth. | The natural greenhouse effect keeps the Earth warm enough for life. | Extra greenhouse gases cause global warming.
- **Complete Narration Text**: Some gases in the air are called greenhouse gases. They trap heat near the Earth. Carbon (IV) oxide is one, and so are methane and water vapour. This natural greenhouse effect keeps the Earth warm enough for life. The carbon cycle helps to regulate how much carbon (IV) oxide is in the air. Extra greenhouse gases trap more heat, and this causes global warming.
- **Audio Asset Reference**: `audio/s23.a4aafea312a4.mp3` (26s, source: tts)
- **Visual Type**: `svg` · **Description**: Greenhouse gases: They trap heat near the Earth. Examples: Carbon (IV) oxide, Methane, Water vapour, Keep Earth warm.
- **Image Asset Reference**: `None` · **Alt Text**: Greenhouse gases: They trap heat near the Earth. Examples: Carbon (IV) oxide, Methane, Water vapour, Keep Earth warm.
- **Visual Labels**: Greenhouse gases, They trap heat near the Earth, Carbon (IV) oxide, Methane, Water vapour, Keep Earth warm
- **SVG Content**: Present (1908 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 3 of B8.2.1.1.2 (describe the relationship between greenhouse gases and the carbon cycle). Carbon (IV) oxide is added by respiration, decomposition and burning and removed by photosynthesis. The natural greenhouse effect is helpful. Extra greenhouse gases, mainly carbon (IV) oxide from burning fossil fuels and deforestation, enhance the effect and cause global warming. A steady carbon cycle does not by itself guarantee a steady temperature. Methane is named only as another greenhouse gas.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcE2` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qE.2`: Which of these is a greenhouse gas? — Correct: b (a: Oxygen that we breathe in | b: Carbon (IV) oxide in the air | c: Nitrogen, the main air gas | d: Helium used in balloons)

## Slide 24: `s24` — Actions and Their Effects
- **Learning Objective / Purpose**: Human effects on the carbon cycle (indicator 2, exemplar 3).
- **Indicators**: B8.2.1.1.2
- **On-Screen Educational Text**:
  - Burning and deforestation add carbon
  - Forests and oceans are carbon sinks
  - Extra gases cause global warming
- **Key Ideas**: Burning fuels and bush burning add carbon (IV) oxide. | Deforestation reduces photosynthesis, and forests and oceans are carbon sinks. | Global warming is the rise in the Earth's average temperature.
- **Complete Narration Text**: People can change the carbon cycle. Burning fuels and bush burning add more carbon (IV) oxide to the air. Deforestation, which is the clearing of forests, means less photosynthesis, so less carbon (IV) oxide is removed. Planting trees helps, because forests and oceans are carbon sinks that absorb and store carbon (IV) oxide. Extra carbon (IV) oxide enhances the greenhouse effect and causes global warming, which is the rise in the Earth's average temperature.
- **Audio Asset Reference**: `audio/s24.a8524fc2ca34.mp3` (30s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 4 rows: Burning fuels, More carbon in air; Bush burning, More carbon in air; Deforestation, Less photosynthesis; Planting trees, More photosynthesis.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 4 rows: Burning fuels, More carbon in air; Bush burning, More carbon in air; Deforestation, Less photosynthesis; Planting trees, More photosynthesis.
- **Visual Labels**: Action, Effect on carbon, Burning fuels, Bush burning, Deforestation, Planting trees, More carbon in air, More carbon in air, Less photosynthesis, More photosynthesis
- **SVG Content**: Present (2779 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 3 of B8.2.1.1.2. Extra carbon (IV) oxide from burning fossil fuels and deforestation enhances the greenhouse effect, which causes global warming and climate change. Forests and the oceans are carbon sinks because they absorb and store carbon (IV) oxide. Keep to cause and effect at this level.
- **Existing Checkpoints After This Slide**: None

## Slide 25: `s25` — Protecting the Carbon Cycle
- **Learning Objective / Purpose**: Actions to protect the carbon cycle (indicator 2, exemplar 3).
- **Indicators**: B8.2.1.1.2
- **On-Screen Educational Text**:
  - Afforestation means planting trees
  - Avoid bush burning
  - Save fuel and use clean stoves
- **Key Ideas**: Afforestation means planting trees. | Avoid bush burning, and save fuel and electricity. | Share these ideas with your family and community.
- **Complete Narration Text**: We can help to protect the carbon cycle. Afforestation, which means planting trees, helps because the trees take in carbon (IV) oxide by photosynthesis. Avoid bush burning, which releases carbon (IV) oxide and destroys plants. Save fuel by walking short distances and by switching off lights and fans that you are not using. Use clean cooking stoves where you can. Share these ideas with your family and community.
- **Audio Asset Reference**: `audio/s25.24fd9762413a.mp3` (27s, source: tts)
- **Visual Type**: `svg` · **Description**: Protect the cycle: Small actions help our environment. Ideas: Afforestation, Stop bush burning, Save fuel and power, Use clean stoves.
- **Image Asset Reference**: `None` · **Alt Text**: Protect the cycle: Small actions help our environment. Ideas: Afforestation, Stop bush burning, Save fuel and power, Use clean stoves.
- **Visual Labels**: Protect the cycle, Small actions help our environment, Afforestation, Stop bush burning, Save fuel and power, Use clean stoves
- **SVG Content**: Present (1926 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 3 of B8.2.1.1.2. Teacher-assessed class discussion; pupils may also make a short poster or talk. Tree planting is encouraged in Ghana, for example on the Green Ghana tree-planting day (general knowledge; VERIFY the details with the school).
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpE` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `cpE.1`: What happens to carbon (IV) oxide in the air if there is much less photosynthesis? — Correct: a (a: More carbon (IV) oxide stays in the air | b: More oxygen is made for animals to use | c: Less carbon (IV) oxide is made by animals | d: All of the carbon is removed from the air)
    - [sequence] `cpE.2`: Put the steps in order to show how carbon moves along a food chain. — Order: st1 -> st3 -> st2 -> st4
    - [mcq] `cpE.3`: Why does deforestation add to the greenhouse effect? — Correct: c (a: Trees give out the greenhouse gas oxygen | b: Cleared land makes new carbon (IV) oxide | c: Fewer trees take in carbon (IV) oxide | d: Forests trap heat and cleared land does not)
    - [mcq] `cpE.4`: A school wants to protect the carbon cycle. Which plan is best? — Correct: a (a: Plant trees, avoid bush fires and save power | b: Cut down the school trees and burn all the waste | c: Burn rubbish every day and leave the lights on | d: Use more petrol generators for all the lessons)

## Slide 26: `s26` — Recap: The Carbon Cycle
- **Learning Objective / Purpose**: Recap.
- **Indicators**: B8.2.1.1.1, B8.2.1.1.2
- **On-Screen Educational Text**:
  - Carbon moves in a repeated cycle
  - Four processes move the carbon
  - The cycle helps protect the environment
- **Key Ideas**: The carbon cycle is a repeated pattern. | Photosynthesis takes carbon from the air, and three processes return it. | The cycle helps to regulate carbon (IV) oxide in the air, so we protect it.
- **Complete Narration Text**: Let us recap. The carbon cycle is a repeated pattern in which carbon moves between the air, living things, the soil and fuels. Photosynthesis takes carbon (IV) oxide from the air, and respiration, burning and decay return it. The cycle helps to regulate carbon (IV) oxide in the air and moves carbon along food chains. Extra carbon (IV) oxide enhances the greenhouse effect and causes global warming, so we protect the cycle by planting trees and saving fuel.
- **Audio Asset Reference**: `audio/s26.59fa7b37d8f7.mp3` (31s, source: tts)
- **Visual Type**: `svg` · **Description**: A top box, Carbon cycle, with arrows to two columns. Processes: Photosynthesis, Respiration, Burning and decay. Role in nature: Carbon in air, Food chains, Greenhouse gas.
- **Image Asset Reference**: `None` · **Alt Text**: A top box, Carbon cycle, with arrows to two columns. Processes: Photosynthesis, Respiration, Burning and decay. Role in nature: Carbon in air, Food chains, Greenhouse gas.
- **Visual Labels**: Carbon cycle, Processes, Role in nature, Photosynthesis, Respiration, Burning, decay, Carbon in air, Food chains, Greenhouse gas
- **SVG Content**: Present (2857 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Final slide before the mastery check.
- **Existing Checkpoints After This Slide**: None

## End-of-Lesson Mastery Check (Pass Mark: 4)
- [mcq] `mastery.1`: Which statement best explains why the carbon cycle is a repeated pattern? — Correct: c (a: Carbon is destroyed and made again each year | b: Carbon moves only in one direction for ever | c: Carbon is circulated continuously and reused | d: Carbon stays inside plants and never leaves)
- [mcq] `mastery.2`: Which processes put carbon (IV) oxide into the air? — Correct: d (a: Photosynthesis, burning and decay | b: Photosynthesis and respiration only | c: Burning and photosynthesis only | d: Respiration, burning and decay)
- [mcq] `mastery.3`: A pupil says plants only take in carbon (IV) oxide and never give it out. What is wrong? — Correct: b (a: Plants do not take in any of the gas | b: Plants respire, so they also give it out | c: Plants give it out only when they burn | d: Plants give out nitrogen instead of it)
- [mcq] `mastery.4`: How does the carbon cycle help to regulate the carbon (IV) oxide in the air? — Correct: a (a: Photosynthesis removes it, respiration returns it | b: Photosynthesis adds it, and respiration removes it | c: Respiration removes it, and burning also removes it | d: Burning removes it, and decomposition adds oxygen)
- [mcq] `mastery.5`: Which action would help to reduce extra carbon (IV) oxide in the air? — Correct: d (a: Clearing forests to plant maize | b: Burning more charcoal for cooking | c: Starting bush fires to clear land | d: Planting trees and saving fuel)

# Forces and Energy: Force and Motion (Simple Machines, Levers and Efficiency) (`b7-sci-t4-simple-machines-and-efficiency`)

- **CDN packagePath**: `packages/b7-sci-t4-simple-machines-and-efficiency.d0f1bf3db8d2.json` (hash `d0f1bf3db8d2`, updated `2026-11-23T07:06:02.571Z`)
- **Curriculum**: ges · **Class**: Basic 7 · **Subject**: Science · **Term**: 3
- **Content Standard**: B7.4.4.2
- **Indicators**: B7.4.4.2.1, B7.4.4.2.2, B7.4.4.2.3
- **Total Slides**: 25 · **Checkpoints**: 16 · **Mastery Check Items**: 5

## Slide 1: `s01` — Machines That Make Work Easier
- **Learning Objective / Purpose**: Hook: simple machines in daily life.
- **Indicators**: B7.4.4.2.1, B7.4.4.2.2, B7.4.4.2.3
- **On-Screen Educational Text**:
  - Tools can make work easier
  - Simple machines help us every day
  - Today we study levers and efficiency
- **Key Ideas**: Tools can make work easier. | Simple machines help us every day. | We will study levers and efficiency.
- **Complete Narration Text**: Good morning, class. A farmer pushes a wheelbarrow full of cassava to the market. A woman lifts a bucket of water from a well using a rope and a wheel. Two children play on a seesaw. All of these tools are simple machines that make work easier. Today we will name simple machines, study levers, and find out how to tell whether a machine wastes energy.
- **Audio Asset Reference**: `audio/s01.873ec573b34d.mp3` (28s, source: tts)
- **Visual Type**: `illustration` · **Description**: A tidy Accra neighbourhood with a farmer pushing a wheelbarrow of cassava, a woman drawing water from a well with a pulley, and children on a seesaw in a school playground.
- **Image Asset Reference**: `images/s01.8d2a82652363.webp` · **Alt Text**: A tidy Accra neighbourhood with a farmer pushing a wheelbarrow of cassava, a woman drawing water from a well with a pulley, and children on a seesaw in a school playground.
- **Visual Labels**: None
- **SVG Content**: None
- **Existing Interactive Configuration**: None
- **Teacher Note**: AI image placement is approximate.
- **Existing Checkpoints After This Slide**: None

## Slide 2: `s02` — What Is a Machine?
- **Learning Objective / Purpose**: Define a simple machine (indicator 1).
- **Indicators**: B7.4.4.2.1
- **On-Screen Educational Text**:
  - A machine makes work easier
  - A simple machine has few moving parts
  - It does not make energy
- **Key Ideas**: A machine makes work easier. | A simple machine has few moving parts. | A machine does not make energy.
- **Complete Narration Text**: A machine is a device that makes work easier. A simple machine has few or no moving parts. It can help us to lift a load, to move it, to cut something or to hold things together. A simple machine does not make energy. It lets us use a smaller push or pull, or lets us push in a more convenient direction. Many tools in your home are simple machines.
- **Audio Asset Reference**: `audio/s02.5421460a0300.mp3` (29s, source: tts)
- **Visual Type**: `svg` · **Description**: Simple machine: Makes work easier. It can help us: Lift loads, Cut things, Move loads, Join things.
- **Image Asset Reference**: `None` · **Alt Text**: Simple machine: makes work easier. It can help us: Lift loads, Cut things, Move loads, Join things.
- **Visual Labels**: Simple machine, Makes work easier, Lift loads, Cut things, Move loads, Join things
- **SVG Content**: Present (1888 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B7.4.4.2.1.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcA1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qA.1`: What does a simple machine do? — Correct: d (a: It makes new energy for us to use | b: It does the work without any effort at all | c: It works only when it has many moving parts | d: It makes work easier)

## Slide 3: `s03` — Six Simple Machines
- **Learning Objective / Purpose**: The six simple machines (indicator 1).
- **Indicators**: B7.4.4.2.1
- **On-Screen Educational Text**:
  - There are six simple machines
  - Lever, pulley and ramp are three
  - Big machines are made of these
- **Key Ideas**: There are six simple machines. | A lever, a pulley and a ramp are three of them. | Complicated machines are made of simple parts.
- **Complete Narration Text**: There are six types of simple machine. They are the lever, the pulley, the inclined plane, the wedge, the screw, and the wheel and axle. A lever is a bar that turns on a point. A pulley is a wheel with a rope. An inclined plane is a ramp. Every complicated machine is made up of these simple parts.
- **Audio Asset Reference**: `audio/s03.d8b10e22f704.mp3` (25s, source: tts)
- **Visual Type**: `svg` · **Description**: Six cards, each with a simple drawing: a lever with a fulcrum and a load, a pulley with a rope and a box, an inclined plane with a box on a ramp, a wedge splitting a log, a screw with a thread, and a wheel and axle.
- **Image Asset Reference**: `None` · **Alt Text**: Six cards, each with a simple drawing: a lever with a fulcrum and a load, a pulley with a rope and a box, an inclined plane with a box on a ramp, a wedge splitting a log, a screw with a thread, and a wheel and axle.
- **Visual Labels**: Lever, Pulley, Inclined plane, Wedge, Screw, Wheel and axle
- **SVG Content**: Present (4699 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B7.4.4.2.1. The drawings are simple and unlabelled apart from the machine names. Ask pupils to point to the fulcrum, the rope or the thread.
- **Existing Checkpoints After This Slide**: None

## Slide 4: `s04` — Simple Machines Around Us
- **Learning Objective / Purpose**: Examples of simple machines (indicator 1).
- **Indicators**: B7.4.4.2.1
- **On-Screen Educational Text**:
  - A ramp is an inclined plane
  - An axe is a wedge
  - A well uses a pulley
- **Key Ideas**: A ramp is an inclined plane. | An axe is a wedge. | A well uses a pulley.
- **Complete Narration Text**: Let us match simple machines to real tools. An inclined plane is a ramp, like the one used to roll barrels onto a lorry. A wedge is a blade that splits things, such as an axe or a cutlass. A screw is a slope wrapped round a rod, like a bottle top or a bolt. A pulley is a wheel with a rope, like the one at a well.
- **Audio Asset Reference**: `audio/s04.9104f920ba9a.mp3` (29s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 4 rows: Inclined plane, A ramp for loading; Wedge, An axe or cutlass blade; Screw, A bottle top or bolt; Pulley, A bucket at a well.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 4 rows: Inclined plane, A ramp for loading; Wedge, An axe or cutlass blade; Screw, A bottle top or bolt; Pulley, A bucket at a well.
- **Visual Labels**: Machine, Everyday example, Inclined plane, Wedge, Screw, Pulley, A ramp for loading, An axe or cutlass blade, A bottle top or bolt, A bucket at a well
- **SVG Content**: Present (2763 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B7.4.4.2.1.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcA2` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qA.2`: Which simple machine is a ramp? — Correct: b (a: A wedge | b: An inclined plane | c: A pulley | d: A wheel and an axle)

## Slide 5: `s05` — How Machines Help
- **Learning Objective / Purpose**: How machines help us (indicator 1).
- **Indicators**: B7.4.4.2.1
- **On-Screen Educational Text**:
  - Machines can lower the effort needed
  - Machines can change direction
  - Machines can give more speed
- **Key Ideas**: Machines can lower the effort or change the direction of a force. | They can trade force for distance or speed. | Useful work out can never be more than work in.
- **Complete Narration Text**: Machines help in three main ways. Some let us use a smaller force to move a heavy load, but then we must move the effort over a longer distance. Some change the direction of the force, as when we pull down on a rope to lift a bucket up. Others give us more speed, but then we need a bigger force. A machine does not create energy, though. The useful work we get out can never be more than the work we put in.
- **Audio Asset Reference**: `audio/s05.26ced27c8c8a.mp3` (35s, source: tts)
- **Visual Type**: `svg` · **Description**: Machines help: they make work easier. In ways: less effort, change direction, more speed.
- **Image Asset Reference**: `None` · **Alt Text**: Machines help: they make work easier. In ways: less effort, change direction, more speed.
- **Visual Labels**: Machines help, They make work easier, Less effort, Change direction, More speed
- **SVG Content**: Present (1632 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B7.4.4.2.1. A machine trades force for distance, direction or speed. It never creates energy, so the useful work output cannot exceed the work input.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpA` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `cpA.1`: How many types of simple machine are there? — Correct: c (a: Two | b: Three | c: Six | d: Ten)
    - [mcq] `cpA.2`: Which simple machine is an axe blade? — Correct: d (a: An inclined plane | b: A pulley | c: A wheel and axle | d: A wedge)
    - [mcq] `cpA.3`: Why do we pull down on a rope to lift a bucket from a well? — Correct: d (a: The bucket is lighter when we pull downwards | b: The rope makes extra energy for the lifting | c: The well pulls the bucket up for us for free | d: A pulley changes the direction of the force)
    - [mcq] `cpA.4`: What is true about the energy that a machine gives out? — Correct: b (a: It can be much greater than the energy put in | b: It is never more than the energy put in | c: It is always exactly zero for every machine | d: It is made by the machine out of nothing)

## Slide 6: `s06` — What Is a Lever?
- **Learning Objective / Purpose**: Describe a lever (indicator 2).
- **Indicators**: B7.4.4.2.2
- **On-Screen Educational Text**:
  - A lever is a bar that turns
  - The fixed point is the fulcrum
  - Effort moves the load
- **Key Ideas**: A lever turns on a fulcrum. | The force we apply is the effort. | The object we move is the load.
- **Complete Narration Text**: A lever is a stiff bar that turns around a fixed point. The fixed point is called the fulcrum. The force we apply is called the effort. The object we want to move is called the load. A crowbar prying up a stone is a good example. We push down on one end, the bar turns on the fulcrum, and the stone at the other end moves.
- **Audio Asset Reference**: `audio/s06.553fd04fe4e8.mp3` (28s, source: tts)
- **Visual Type**: `svg` · **Description**: Lever: A bar that turns. Three parts: Fulcrum, Effort, Load.
- **Image Asset Reference**: `None` · **Alt Text**: Lever: a bar that turns. Three parts: Fulcrum, Effort, Load.
- **Visual Labels**: Lever, A bar that turns, Fulcrum, Effort, Load
- **SVG Content**: Present (1595 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B7.4.4.2.2.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcB1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qB.1`: What is the fulcrum of a lever? — Correct: b (a: The force that we apply to the bar | b: The fixed point it turns on | c: The object that we want to move along | d: The stiff bar that we use for the job)

## Slide 7: `s07` — Parts of a Lever
- **Learning Objective / Purpose**: Diagram of a lever (indicator 2).
- **Indicators**: B7.4.4.2.2
- **On-Screen Educational Text**:
  - The bar turns on the fulcrum
  - We push on the effort side
  - The load goes up
- **Key Ideas**: The fulcrum is the turning point. | The effort pushes down on one side. | The load goes up on the other side.
- **Complete Narration Text**: Look at the lever. The triangle is the fulcrum, the point the bar turns on. On the left, the arrow pushes down. That is the effort. On the right, the box is the load. When we push down on the effort side, the bar turns on the fulcrum and the load goes up. This is how a lever can let a small effort move a load.
- **Audio Asset Reference**: `audio/s07.25b37b8fc5f4.mp3` (27s, source: tts)
- **Visual Type**: `svg` · **Description**: A bar resting on a triangle, labelled fulcrum, closer to the load. A downward arrow on the left is labelled effort, and a box on the right is labelled load.
- **Image Asset Reference**: `None` · **Alt Text**: A bar resting on a triangle, labelled fulcrum, closer to the load. A downward arrow on the left is labelled effort, and a box on the right is labelled load.
- **Visual Labels**: Effort, Load, Fulcrum
- **SVG Content**: Present (1089 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B7.4.4.2.2. The fulcrum is nearer the load, so a small effort can move the load, but the effort moves further than the load.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcB2` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qB.2`: In a lever, what is the object that we want to move? — Correct: c (a: The effort | b: The fulcrum | c: The load | d: The lever bar)

## Slide 8: `s08` — Three Classes of Levers
- **Learning Objective / Purpose**: Classes of levers (indicator 2, exemplar 2).
- **Indicators**: B7.4.4.2.2
- **On-Screen Educational Text**:
  - Levers have three classes
  - The middle part decides the class
  - One part is always in the middle
- **Key Ideas**: There are three classes of lever. | The middle point decides the class. | Fulcrum, load or effort can be in the middle.
- **Complete Narration Text**: Levers are sorted into three classes by the position of the fulcrum, the effort and the load. In a first class lever, the fulcrum is in the middle. In a second class lever, the load is in the middle. In a third class lever, the effort is in the middle. In every class, one point is between the other two.
- **Audio Asset Reference**: `audio/s08.fc64df6a8180.mp3` (25s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 3 rows: First class, Fulcrum in the middle; Second class, Load in the middle; Third class, Effort in the middle.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 3 rows: First class, Fulcrum in the middle; Second class, Load in the middle; Third class, Effort in the middle.
- **Visual Labels**: Class, Middle point, First class, Second class, Third class, Fulcrum in the middle, Load in the middle, Effort in the middle
- **SVG Content**: Present (2246 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 of B7.4.4.2.2.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpB` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `cpB.1`: What is the effort? — Correct: a (a: The force we apply to the lever | b: The object that we want to move along | c: The fixed point that the bar turns on | d: The work that is wasted as heat and sound)
    - [mcq] `cpB.2`: How many classes of lever are there? — Correct: a (a: Three | b: Two | c: Four | d: Six)
    - [mcq] `cpB.3`: In a second class lever, what is in the middle? — Correct: c (a: The fulcrum | b: The effort | c: The load | d: Nothing at all)

## Slide 9: `s09` — First Class Levers
- **Learning Objective / Purpose**: First class levers (indicator 2).
- **Indicators**: B7.4.4.2.2
- **On-Screen Educational Text**:
  - The fulcrum is in the middle
  - A seesaw is a first class lever
  - Fulcrum position gives force or speed
- **Key Ideas**: The fulcrum is in the middle. | A seesaw is a first class lever. | It changes direction, and can give less effort or more speed.
- **Complete Narration Text**: In a first class lever, the fulcrum sits between the effort and the load. A seesaw is a good example, with the fulcrum in the middle. Scissors, pliers and a crowbar are also first class levers. Pushing down on one side lifts the other side, so a first class lever changes the direction of the force. If the fulcrum is nearer the load, a small effort can lift a big load. If it is nearer the effort, the load moves further and faster, but we need a bigger effort.
- **Audio Asset Reference**: `audio/s09.1ceafd95f7c7.mp3` (37s, source: tts)
- **Visual Type**: `svg` · **Description**: First class: Fulcrum is in the middle. Examples: Seesaw, Scissors, Crowbar, Pliers.
- **Image Asset Reference**: `None` · **Alt Text**: First class: fulcrum is in the middle. Examples: Seesaw, Scissors, Crowbar, Pliers.
- **Visual Labels**: First class, Fulcrum is in the middle, Seesaw, Scissors, Crowbar, Pliers
- **SVG Content**: Present (1869 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 of B7.4.4.2.2. A first class lever can reduce the effort (fulcrum nearer the load) or increase speed and reach (fulcrum nearer the effort). It always changes the direction of the force.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcC1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qC.1`: Which tool is a first class lever? — Correct: a (a: A seesaw | b: A wheelbarrow | c: A long-handled broom | d: A fishing rod)

## Slide 10: `s10` — Second Class Levers
- **Learning Objective / Purpose**: Second class levers (indicator 2).
- **Indicators**: B7.4.4.2.2
- **On-Screen Educational Text**:
  - The load is in the middle
  - A wheelbarrow is a second class lever
  - The effort is far from the fulcrum
- **Key Ideas**: The load is in the middle. | A wheelbarrow is a second class lever. | It makes the load easier to lift.
- **Complete Narration Text**: In a second class lever, the load is between the fulcrum and the effort. In a wheelbarrow, the wheel is the fulcrum, the load sits in the middle, and our hands lift at the handles as the effort. A nutcracker and a bottle opener are also second class levers, with the fulcrum at one end and the effort at the other. The effort is further from the fulcrum than the load, so a smaller effort can lift the load.
- **Audio Asset Reference**: `audio/s10.c8c51a22e07d.mp3` (33s, source: tts)
- **Visual Type**: `svg` · **Description**: Second class: Load is in the middle. Examples: Wheelbarrow, Nutcracker, Bottle opener.
- **Image Asset Reference**: `None` · **Alt Text**: Second class: load is in the middle. Examples: Wheelbarrow, Nutcracker, Bottle opener.
- **Visual Labels**: Second class, Load is in the middle, Wheelbarrow, Nutcracker, Bottle opener
- **SVG Content**: Present (1628 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 of B7.4.4.2.2. Wheelbarrow: fulcrum = wheel, load = the barrow contents, effort = hands at the handles. Nutcracker: fulcrum = hinge, load = the nut, effort = hands at the ends. Bottle opener: fulcrum = the edge resting on the cap, load = the cap, effort = the handle. A tool's class depends on how it is used.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcC2` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qC.2`: Why is a wheelbarrow a second class lever? — Correct: b (a: The effort is between the wheel and the load | b: The load is between the wheel and the handles | c: The fulcrum is between the load and the effort | d: There is no fulcrum anywhere on a wheelbarrow)

## Slide 11: `s11` — Third Class Levers
- **Learning Objective / Purpose**: Third class levers (indicator 2).
- **Indicators**: B7.4.4.2.2
- **On-Screen Educational Text**:
  - The effort is in the middle
  - A broom can be a third class lever
  - They give speed and reach
- **Key Ideas**: The effort is in the middle. | A broom is a third class lever. | They give speed and reach, not less effort.
- **Complete Narration Text**: In a third class lever, the effort is between the fulcrum and the load. A long-handled broom is a good example: the top hand is the fulcrum, the lower hand pushing in the middle is the effort, and the brush moving the dust is the load. Tweezers, a fishing rod and the human forearm are also third class levers. These levers do not make the load easier to lift, because the effort is closer to the fulcrum than the load. Instead, they move the load a long way or quickly with a small movement of the hand.
- **Audio Asset Reference**: `audio/s11.e449e46cce3f.mp3` (41s, source: tts)
- **Visual Type**: `svg` · **Description**: Third class: Effort is in the middle. Examples: Broom, Tweezers, Fishing rod, Human arm.
- **Image Asset Reference**: `None` · **Alt Text**: Third class: effort is in the middle. Examples: Broom, Tweezers, Fishing rod, Human arm.
- **Visual Labels**: Third class, Effort is in the middle, Broom, Tweezers, Fishing rod, Human arm
- **SVG Content**: Present (1874 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 of B7.4.4.2.2. Broom (top hand steady): fulcrum = top hand, effort = lower hand, load = the brush. Forearm: fulcrum = elbow, effort = the biceps pulling near the elbow, load = the hand and what it holds. The class depends on how a tool is used.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcC3` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qC.3`: In a third class lever, where is the effort? — Correct: a (a: Between the fulcrum and the load | b: At the end, further from the fulcrum than the load | c: At the fulcrum, where the lever turns round | d: On the load itself, as part of the object)

## Slide 12: `s12` — Sorting Levers
- **Learning Objective / Purpose**: Classify levers (indicator 2, exemplar 2).
- **Indicators**: B7.4.4.2.2
- **On-Screen Educational Text**:
  - A seesaw is first class
  - A wheelbarrow is second class
  - A fishing rod is third class
- **Key Ideas**: A seesaw is first class. | A wheelbarrow is second class, and a fishing rod is third class. | The class depends on how the tool is used.
- **Complete Narration Text**: Now let us sort real tools. A seesaw is a first class lever, because the fulcrum is in the middle. A wheelbarrow is a second class lever, because the load is in the middle. A fishing rod is a third class lever, because the effort is in the middle. Scissors are first class again, with the fulcrum at the screw. Remember, the class depends on how the tool is used.
- **Audio Asset Reference**: `audio/s12.a979fcd5548a.mp3` (29s, source: tts)
- **Visual Type**: `svg` · **Description**: Four rows, each with an arrow from a tool to a box asking which class: seesaw, wheelbarrow, fishing rod and scissors.
- **Image Asset Reference**: `None` · **Alt Text**: Four rows, each with an arrow from a tool to a box asking which class: seesaw, wheelbarrow, fishing rod and scissors.
- **Visual Labels**: Seesaw, Wheelbarrow, Fishing rod, Scissors, Which class?
- **SVG Content**: Present (2863 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: The tap item in section C uses this slide, so the class labels are hidden and each row shows 'Which class?'. The classes are given in the narration and on-screen text. A tool can change class with use: a broom held with the top hand steady is third class. The hotspots match the four rows exactly.
- **Existing Checkpoints After This Slide**: None

## Slide 13: `s13` — Levers at Work
- **Learning Objective / Purpose**: Levers in a community (indicator 2).
- **Indicators**: B7.4.4.2.2
- **On-Screen Educational Text**:
  - Children use a first class lever
  - A gardener uses a second class lever
  - A sweeper uses a third class lever
- **Key Ideas**: A seesaw is a first class lever. | A wheelbarrow is a second class lever. | A broom is a third class lever.
- **Complete Narration Text**: Look around a Ghanaian community and you will find levers everywhere. Children on a seesaw use a first class lever. A gardener with a wheelbarrow uses a second class lever. A woman sweeping the compound with a long-handled broom uses a third class lever, with her top hand as the fulcrum. Each lever has a fulcrum, an effort and a load. Which levers have you used today?
- **Audio Asset Reference**: `audio/s13.f67efb4b20c5.mp3` (28s, source: tts)
- **Visual Type**: `illustration` · **Description**: Children on a seesaw, a gardener with a wheelbarrow and a woman sweeping with a long-handled broom, one hand at the top and one in the middle, in an Accra school compound.
- **Image Asset Reference**: `images/s13.5657951ac958.webp` · **Alt Text**: Children on a seesaw, a gardener with a wheelbarrow and a woman sweeping with a long-handled broom, one hand at the top and one in the middle, in an Accra school compound.
- **Visual Labels**: None
- **SVG Content**: None
- **Existing Interactive Configuration**: None
- **Teacher Note**: AI image placement is approximate.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpC` (retryRule: 2 attempts, then show the answer with the explanation):
    - [tapDiagram] `cpC.1`: Tap the tool that is a second class lever. — Hotspot: h2
    - [mcq] `cpC.2`: A long-handled broom is used with the top hand steady and the lower hand pushing in the middle. What class is it? — Correct: a (a: Third class | b: First class | c: Second class | d: Fourth class)
    - [mcq] `cpC.3`: Which pair is correct? — Correct: a (a: Seesaw, first class | b: Seesaw, third class | c: Fishing rod, first class | d: Wheelbarrow, third class)
    - [mcq] `cpC.4`: What is a third class lever good for? — Correct: c (a: Lifting a load with the least possible effort | b: Changing the direction of the force only | c: Moving a load far or quickly | d: Making extra energy for the person using it)

## Slide 14: `s14` — Work Input
- **Learning Objective / Purpose**: Work input (indicator 3, exemplar 1).
- **Indicators**: B7.4.4.2.3
- **On-Screen Educational Text**:
  - Work is done when a force moves an object
  - Work input is measured in joules
  - Effort is a force, measured in newtons
- **Key Ideas**: Work is done when a force moves an object in its own direction. | Work input is energy we transfer, measured in joules. | Effort is a force, measured in newtons.
- **Complete Narration Text**: Work is done when a force moves an object in the direction of the force. The work we put into a machine is called the work input, and it is measured in joules, the same unit as energy. Effort is different: it is the force we apply, and it is measured in newtons. When you pull a rope to lift a bucket from a well, energy from your body is transferred to the bucket, so you do work. Every machine needs some work input before it can do its job.
- **Audio Asset Reference**: `audio/s14.8c1f46073b93.mp3` (38s, source: tts)
- **Visual Type**: `svg` · **Description**: Work input: the work we put in. Key facts: work in joules, effort in newtons, energy transferred.
- **Image Asset Reference**: `None` · **Alt Text**: Work input: the work we put in. Key facts: work in joules, effort in newtons, energy transferred.
- **Visual Labels**: Work input, The work we put in, Work: joules, Effort: newtons, Energy transferred
- **SVG Content**: Present (1633 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B7.4.4.2.3. Work is done when a force moves an object in the direction of the force, and it is measured in joules. Effort is a force, measured in newtons. Work = force x distance moved (for example, 1 newton through 1 metre is 1 joule); the lesson does not calculate with it.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcD1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qD.1`: What is work input? — Correct: a (a: The work we put into a machine | b: The useful work that comes out of the machine | c: The work that is wasted as heat and sound | d: The weight of the load that is being moved)

## Slide 15: `s15` — Work Output
- **Learning Objective / Purpose**: Work output (indicator 3, exemplar 1).
- **Indicators**: B7.4.4.2.3
- **On-Screen Educational Text**:
  - Work output is the useful work
  - Example: lifting a bucket up a well
  - It is measured in joules and is less than the input
- **Key Ideas**: Work output is the useful work. | Example: lifting a bucket through the height of a well. | It is measured in joules and is less than the work input.
- **Complete Narration Text**: The useful work that a machine gives out is called the work output. It is also measured in joules. When a pulley lifts a bucket of water up through the height of a well, the work done on the bucket is the work output. Some of the work input is wasted, mostly as heat. So the work output is always less than the work input in a real machine.
- **Audio Asset Reference**: `audio/s15.fa0f34f658ed.mp3` (29s, source: tts)
- **Visual Type**: `svg` · **Description**: Work output: The useful work we get. Properties: Joules, Useful, Always less.
- **Image Asset Reference**: `None` · **Alt Text**: Work output: the useful work we get. Properties: Joules, Useful, Always less.
- **Visual Labels**: Work output, The useful work we get, Joules, Useful, Always less
- **SVG Content**: Present (1618 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B7.4.4.2.3. Lifting a load through a height is clear useful work: the force lifts the bucket in the direction it moves. Carrying a load level along the ground is not used as the example.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcD2` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qD.2`: What is the unit of work? — Correct: b (a: The newton | b: The joule | c: The metre | d: The second)

## Slide 16: `s16` — Input, Output and Waste
- **Learning Objective / Purpose**: Diagram of work in and out (indicator 3).
- **Indicators**: B7.4.4.2.3
- **On-Screen Educational Text**:
  - 100 joules go in
  - 80 joules do useful work
  - 20 joules are wasted as heat
- **Key Ideas**: The work input is 100 joules. | The work output is 80 joules. | 20 joules are wasted as heat.
- **Complete Narration Text**: This diagram shows a machine. One hundred joules of work go in. This is the work input. Eighty joules come out as useful work. This is the work output. The other twenty joules are wasted, mostly as heat. Add them up, and the total is still one hundred joules, so no energy is destroyed. Not all of it does the job we want, though.
- **Audio Asset Reference**: `audio/s16.90eac49da97a.mp3` (27s, source: tts)
- **Visual Type**: `svg` · **Description**: A flow diagram: work input, 100 joules, enters a machine, which gives work output, 80 joules, and wasted heat, 20 joules.
- **Image Asset Reference**: `None` · **Alt Text**: A flow diagram: work input, 100 joules, enters a machine, which gives work output, 80 joules, and wasted heat, 20 joules.
- **Visual Labels**: Work input, Machine, Work output, Wasted heat, 100 J, 80 J, 20 J, 100 J in, 80 J out, 20 J wasted
- **SVG Content**: Present (2314 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B7.4.4.2.3. [VERIFY] The 100, 80 and 20 joule figures are examples, not measured values.
- **Existing Checkpoints After This Slide**: None

## Slide 17: `s17` — Efficiency
- **Learning Objective / Purpose**: Define efficiency (indicator 3, exemplars 2 and 3).
- **Indicators**: B7.4.4.2.3
- **On-Screen Educational Text**:
  - Efficiency tells how well a machine works
  - Divide output by input
  - Multiply by 100 for a percentage
- **Key Ideas**: Efficiency shows how well a machine works. | Efficiency is output divided by input, times 100. | A high efficiency means little waste.
- **Complete Narration Text**: Efficiency tells us how well a machine turns work input into useful work output. To find it, divide the work output by the work input. Then multiply by one hundred to write the answer as a percentage. The formula is efficiency equals work output over work input, times one hundred per cent. A machine with a high efficiency wastes very little of the work put into it.
- **Audio Asset Reference**: `audio/s17.170add2fc2d6.mp3` (28s, source: tts)
- **Visual Type**: `svg` · **Description**: Efficiency: Output divided by input. Written as: Per cent, Times 100, Below 100.
- **Image Asset Reference**: `None` · **Alt Text**: Efficiency: output divided by input. Written as: Per cent, Times 100, Below 100.
- **Visual Labels**: Efficiency, Output divided by input, Per cent, Times 100, Below 100
- **SVG Content**: Present (1620 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplars 2 and 3 of B7.4.4.2.3.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcD3` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qD.3`: How do we find efficiency? — Correct: d (a: Divide input by output and multiply by 100 | b: Add the input and the output together | c: Subtract the output from the input only | d: Divide output by input and multiply by 100)

## Slide 18: `s18` — Working Out Efficiency
- **Learning Objective / Purpose**: Worked examples (indicator 3, exemplar 2).
- **Indicators**: B7.4.4.2.3
- **On-Screen Educational Text**:
  - 100 J in and 80 J out gives 80%
  - 200 J in and 150 J out gives 75%
  - 50 J in and 40 J out gives 80%
- **Key Ideas**: 80 divided by 100, times 100, is 80 per cent. | 150 out of 200 in is 75 per cent. | 40 out of 50 in is 80 per cent.
- **Complete Narration Text**: Let us work some out. If the work input is one hundred joules and the work output is eighty joules, the efficiency is eighty divided by one hundred, times one hundred, which is eighty per cent. With two hundred joules in and one hundred and fifty out, the efficiency is seventy-five per cent. With fifty joules in and forty out, it is eighty per cent.
- **Audio Asset Reference**: `audio/s18.45e34130ed38.mp3` (27s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 3 rows: 100 J in, 80 J out, 80%; 200 J in, 150 J out, 75%; 50 J in, 40 J out, 80%.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 3 rows: 100 J in, 80 J out, 80%; 200 J in, 150 J out, 75%; 50 J in, 40 J out, 80%.
- **Visual Labels**: Input and output, Efficiency, 100 J in, 80 J out, 200 J in, 150 J out, 50 J in, 40 J out, 80%, 75%, 80%
- **SVG Content**: Present (2224 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 of B7.4.4.2.3. Arithmetic: 80/100 = 80%, 150/200 = 75%, 40/50 = 80%.
- **Existing Checkpoints After This Slide**: None

## Slide 19: `s19` — Steps for Efficiency
- **Learning Objective / Purpose**: Steps for calculating efficiency (indicator 3).
- **Indicators**: B7.4.4.2.3
- **On-Screen Educational Text**:
  - Find the work input
  - Find the work output
  - Divide, then multiply by 100
- **Key Ideas**: Find the input and the output. | Divide output by input. | Multiply by 100 to get a percentage.
- **Complete Narration Text**: Here are the steps. First, find the work input in joules. Second, find the work output in joules. Third, divide the work output by the work input. Last, multiply your answer by one hundred to get a percentage. An ideal machine with no losses would be one hundred per cent efficient, but a real machine has losses, so check that your answer is below one hundred per cent.
- **Audio Asset Reference**: `audio/s19.338aaf8c1f2e.mp3` (29s, source: tts)
- **Visual Type**: `svg` · **Description**: Four numbered steps: find the work input, find the work output, divide output by input, multiply by 100.
- **Image Asset Reference**: `None` · **Alt Text**: Four numbered steps: find the work input, find the work output, divide output by input, multiply by 100.
- **Visual Labels**: Find the work input, Find the work output, Divide output by input, Multiply by 100
- **SVG Content**: Present (2129 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 of B7.4.4.2.3. A perfectly efficient machine (100 per cent) is an ideal model with no losses. Real machines have losses, so their efficiency is below 100 per cent.
- **Existing Checkpoints After This Slide**: None

## Slide 20: `s20` — Why Not 100 Per Cent?
- **Learning Objective / Purpose**: Efficiency of real machines (indicator 3, exemplar 3).
- **Indicators**: B7.4.4.2.3
- **On-Screen Educational Text**:
  - No real machine wastes nothing
  - Work is wasted as heat and sound
  - Output is less than input
- **Key Ideas**: No real machine is 100 per cent efficient. | Waste is heat, sound and other forms, not only friction. | Output is always less than input.
- **Complete Narration Text**: No real machine is one hundred per cent efficient. Some of the work input is always wasted. Moving parts rub together, and friction turns some of the work into heat. Some work is also lost as sound, and as heat in other ways, such as air resistance. This is why the work output is always less than the work input. We can only try to make the waste smaller.
- **Audio Asset Reference**: `audio/s20.e4ae79a58524.mp3` (29s, source: tts)
- **Visual Type**: `svg` · **Description**: Real machines: Always waste some work. Wasted by: Friction, Heat, Sound, Wear.
- **Image Asset Reference**: `None` · **Alt Text**: Real machines: always waste some work. Wasted by: Friction, Heat, Sound, Wear.
- **Visual Labels**: Real machines, Always waste some work, Friction, Heat, Sound, Wear
- **SVG Content**: Present (1866 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 3 of B7.4.4.2.3. Wasted energy is not destroyed. It spreads out into the surroundings, mostly as heat, and also as sound. Friction is one cause; air resistance and bending parts are others.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpD` (retryRule: 2 attempts, then show the answer with the explanation):
    - [sequence] `cpD.1`: Put the steps for working out efficiency in order. — Order: st2 -> st4 -> st1 -> st3
    - [mcq] `cpD.2`: A machine has a work input of 200 joules and a work output of 150 joules. What is its efficiency? — Correct: d (a: 25 per cent | b: 133 per cent | c: 50 per cent | d: 75 per cent)
    - [mcq] `cpD.3`: A machine takes in 50 joules and gives out 40 joules of useful work. How much work is wasted? — Correct: b (a: 40 joules | b: 10 joules | c: 50 joules | d: 90 joules)
    - [mcq] `cpD.4`: Why is the efficiency of a real machine below 100 per cent? — Correct: c (a: The machine makes too much useful energy | b: The work input is always less than the output | c: Some work is always wasted as heat | d: Friction adds extra work to the output)

## Slide 21: `s21` — Friction Wastes Work
- **Learning Objective / Purpose**: Friction and efficiency (indicator 3, exemplar 4).
- **Indicators**: B7.4.4.2.3
- **On-Screen Educational Text**:
  - Friction wastes work as heat
  - Oil and grease reduce friction
  - Less friction means more efficiency
- **Key Ideas**: Friction wastes work as heat. | Oil and grease reduce friction. | Less friction means higher efficiency.
- **Complete Narration Text**: Friction is one main reason that machines waste work. When two rough surfaces rub, the work is turned into heat. We can reduce friction to make a machine more efficient. Putting oil or grease on moving parts helps them move past each other. Smoothing and cleaning the parts also helps. A machine with less friction wastes less work, so its efficiency can go up.
- **Audio Asset Reference**: `audio/s21.5277d0d4c060.mp3` (26s, source: tts)
- **Visual Type**: `svg` · **Description**: Friction: Wastes work as heat. Reduce it by: Oiling, Greasing, Smoothing, Cleaning.
- **Image Asset Reference**: `None` · **Alt Text**: Friction: wastes work as heat. Reduce it by: Oiling, Greasing, Smoothing, Cleaning.
- **Visual Labels**: Friction, Wastes work as heat, Oiling, Greasing, Smoothing, Cleaning
- **SVG Content**: Present (1866 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 4 of B7.4.4.2.3.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcE1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qE.1`: Why does oiling the moving parts help a machine? — Correct: d (a: It makes the machine produce its own energy | b: It makes the parts rub together harder | c: It makes the load of the machine lighter | d: It reduces friction, so less work is wasted)

## Slide 22: `s22` — Improving Machines
- **Learning Objective / Purpose**: Ways to improve efficiency (indicator 3, exemplar 4).
- **Indicators**: B7.4.4.2.3
- **On-Screen Educational Text**:
  - Oil moving parts
  - Sharpening is not oiling
  - Only adults handle sharp tools
- **Key Ideas**: Oil and grease reduce friction in moving parts. | Sharpening reduces the effort a blade needs. | Only an adult sharpens and handles sharp tools.
- **Complete Narration Text**: Here are ways to improve simple machines. Oil a door hinge so that it turns freely. Clean and grease a bicycle chain so that it does not drag. A sharp cutlass or axe cuts with less effort, so less work is wasted tearing through wood, but only an adult should sharpen or handle it. Grease the axle of a wheelbarrow wheel so that it spins easily. Oil and grease reduce friction in moving parts, while sharpening reduces the effort a blade needs, and in both cases the efficiency can go up.
- **Audio Asset Reference**: `audio/s22.9df6924ca068.mp3` (39s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 4 rows: Door hinge, Put oil on it; Bicycle chain, Clean and grease it; Cutlass or axe, An adult sharpens it; Wheelbarrow wheel, Grease the axle.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 4 rows: Door hinge, Put oil on it; Bicycle chain, Clean and grease it; Cutlass or axe, An adult sharpens it; Wheelbarrow wheel, Grease the axle.
- **Visual Labels**: Machine, How to improve it, Door hinge, Bicycle chain, Cutlass or axe, Wheelbarrow wheel, Put oil on it, Clean and grease it, An adult sharpens it, Grease the axle
- **SVG Content**: Present (2769 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 4 of B7.4.4.2.3. Lubricating (oil, grease) reduces friction between moving parts. Sharpening a cutting edge reduces the force needed to cut and the work wasted deforming and tearing the material. They are different ideas. Sharp tools stay with adults; no pupil handling.
- **Existing Checkpoints After This Slide**: None

## Slide 23: `s23` — Steps for the Oiling Test
- **Learning Objective / Purpose**: Oiling investigation (indicator 3, exemplar 4).
- **Indicators**: B7.4.4.2.3
- **On-Screen Educational Text**:
  - Teacher rolls a toy truck down a ramp
  - Oil the axles lightly
  - Compare how far it goes each time
- **Key Ideas**: Roll the truck from the same place and mark where it stops. | Oil the axles and roll it again. | Less friction may let it go further, but the result depends on the toy.
- **Complete Narration Text**: Let us test oiling, as a demonstration led by the teacher. First, roll a toy truck down a ramp from the same place, several times, and mark where it stops. Second, the teacher puts a tiny drop of oil on its axles. Third, roll it again from the same place, in the same way, on the same surface. Last, record the distances and compare them. Oil may let it roll further, but the result depends on the toy and its friction, so wipe up spills and never oil toys that could be damaged.
- **Audio Asset Reference**: `audio/s23.ecbd0696dec8.mp3` (39s, source: tts)
- **Visual Type**: `svg` · **Description**: Four numbered steps: roll a toy truck on a ramp, put a drop of oil on its axles, roll it again the same way, compare how far it goes.
- **Image Asset Reference**: `None` · **Alt Text**: Four numbered steps: roll a toy truck on a ramp, put a drop of oil on its axles, roll it again the same way, compare how far it goes.
- **Visual Labels**: Roll a toy truck on a ramp, Put a drop of oil on axles, Roll it again the same way, Compare how far it goes
- **SVG Content**: Present (2154 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 4 of B7.4.4.2.3. Teacher-led demonstration. Keep the same truck, ramp, starting position, surface and release method; repeat each trial three times and record the distances. Oil only the axles, with a tiny drop, never the wheel surface, and only on a toy that will not be damaged. The result depends on the toy's construction and friction; it may be small or none. Alternative demonstration: lift a bicycle wheel off the ground, give it the same spin three times and time how long it turns, then oil the axle (teacher only) and repeat. Or swing a stiff metal hinge on a board before and after one drop of oil. Work over a tray and wipe up all spills.
- **Existing Checkpoints After This Slide**: None

## Slide 24: `s24` — Caring for Tools
- **Learning Objective / Purpose**: Maintenance in daily life (indicator 3, exemplar 4).
- **Indicators**: B7.4.4.2.3
- **On-Screen Educational Text**:
  - Oil keeps machines working well
  - Oil safely, with an adult watching
  - Well kept tools last longer
- **Key Ideas**: Oil keeps machines working well. | Oil safely, with an adult watching. | Well kept tools last longer.
- **Complete Narration Text**: Looking after machines saves effort and money. A boy oils his bicycle chain with a parent or teacher watching, and he wipes off the extra oil. A farmer greases the axle of his wheelbarrow before market day. A teacher shows pupils how to oil a squeaky door hinge safely. A well cared for machine lasts longer and wastes less work. What tool at home could use a little oil, with an adult to help?
- **Audio Asset Reference**: `audio/s24.0e25df179bf9.mp3` (30s, source: tts)
- **Visual Type**: `illustration` · **Description**: A boy oiling a bicycle chain with an adult watching, a farmer greasing a wheelbarrow axle and a teacher showing pupils how to oil a door hinge.
- **Image Asset Reference**: `images/s24.994734c554e1.webp` · **Alt Text**: A boy oiling a bicycle chain with an adult watching, a farmer greasing a wheelbarrow axle and a teacher showing pupils how to oil a door hinge.
- **Visual Labels**: None
- **SVG Content**: None
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 4 of B7.4.4.2.3. Adult supervision is modelled in every scene. Keep oil off tyres, brake blocks and floors; wipe spills; keep fingers clear of the chain; wash hands afterwards. AI image placement is approximate.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpE` (retryRule: 2 attempts, then show the answer with the explanation):
    - [sequence] `cpE.1`: Put the steps of the oiling test in order. — Order: st2 -> st4 -> st1 -> st3
    - [mcq] `cpE.2`: A bicycle chain is dry and stiff. How can we improve it? — Correct: d (a: Leave it dry so that it will rub more | b: Add sand to it for a better grip | c: Tie it tighter with a strong string | d: Clean it and put grease on it)
    - [mcq] `cpE.3`: What happens to the efficiency of a machine when friction is reduced? — Correct: c (a: It goes down | b: It stays the same | c: It goes up | d: It becomes zero)
    - [mcq] `cpE.4`: What safety step should we take after oiling the axles? — Correct: b (a: Leave the oil on the floor to dry | b: Wipe up any spilt oil | c: Rub the oil on the soles of our shoes | d: Pour more oil on the floor to be safe)

## Slide 25: `s25` — Recap: Simple Machines
- **Learning Objective / Purpose**: Recap.
- **Indicators**: B7.4.4.2.1, B7.4.4.2.2, B7.4.4.2.3
- **On-Screen Educational Text**:
  - Levers have three classes
  - Efficiency is output over input
  - Less friction means less waste
- **Key Ideas**: A lever has a fulcrum, an effort and a load. | Efficiency is output over input, times 100. | Oil reduces friction and improves efficiency.
- **Complete Narration Text**: Let us recap. Simple machines make work easier. A lever turns on a fulcrum and has three classes, depending on whether the fulcrum, the load or the effort is in the middle. Work input is what we put in, and work output is the useful work we get out. Efficiency is output divided by input, times one hundred per cent. Oiling the moving parts reduces friction and improves efficiency.
- **Audio Asset Reference**: `audio/s25.a1f57e5b46d9.mp3` (29s, source: tts)
- **Visual Type**: `svg` · **Description**: A recap: simple machines split into levers, with three classes, fulcrum, effort and load, and efficiency, with output over input, times 100, and oil cuts waste.
- **Image Asset Reference**: `None` · **Alt Text**: A top box, simple machines, with arrows to two columns: levers with three classes, fulcrum, and effort and load; efficiency with output over input, times 100, and oil cuts waste.
- **Visual Labels**: Simple Machines, Levers, Efficiency, Three classes, Fulcrum, Effort, load, Out over in, Times 100, Oil cuts waste
- **SVG Content**: Present (2814 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Final slide before the mastery check.
- **Existing Checkpoints After This Slide**: None

## End-of-Lesson Mastery Check (Pass Mark: 4)
- [mcq] `mastery.1`: Which of these is a simple machine? — Correct: d (a: A wooden pencil | b: A sheet of paper | c: A plastic cup | d: A pulley)
- [mcq] `mastery.2`: Which class of lever has the fulcrum in the middle? — Correct: a (a: First class | b: Second class | c: Third class | d: None of them)
- [mcq] `mastery.3`: A wheelbarrow is which class of lever? — Correct: c (a: First class | b: Third class | c: Second class | d: It is not a lever)
- [mcq] `mastery.4`: A machine takes in 100 joules and gives out 60 joules of useful work. What is its efficiency? — Correct: c (a: 40 per cent | b: 167 per cent | c: 60 per cent | d: 160 per cent)
- [mcq] `mastery.5`: How can the efficiency of a machine be improved? — Correct: b (a: Add more friction to all of its moving parts | b: Oil its moving parts to reduce friction | c: Give it a much bigger load than before | d: Leave its parts dirty and stiff)

# Diversity of Matter: Materials (Mixtures, Solutions and Their Separation) (`b8-sci-t1-mixtures-and-separation`)

- **CDN packagePath**: `packages/b8-sci-t1-mixtures-and-separation.536fa4b65774.json` (hash `536fa4b65774`, updated `2026-11-23T09:27:03.383Z`)
- **Curriculum**: ges · **Class**: Basic 8 · **Subject**: Science · **Term**: 1
- **Content Standard**: B8.1.1.1
- **Indicators**: B8.1.1.1.1, B8.1.1.1.2
- **Total Slides**: 26 · **Checkpoints**: 17 · **Mastery Check Items**: 5

## Slide 1: `s01` — Mixtures All Around Us
- **Learning Objective / Purpose**: Hook: mixtures in daily life.
- **Indicators**: B8.1.1.1.1, B8.1.1.1.2
- **On-Screen Educational Text**:
  - Many things we use are mixtures
  - Some mixtures can be separated
  - Today we study mixtures and separation
- **Key Ideas**: Many things we use are mixtures. | Some mixtures can be separated. | We will study types of mixtures and how to separate them.
- **Complete Narration Text**: Good morning, class. A woman sifts gari to take out the lumps. A girl stirs sugar into a glass of water. A man pours muddy water through a cloth. Each of these is a mixture, and we can separate some of them. Today we will name the types of mixtures and learn how to separate them.
- **Audio Asset Reference**: `audio/s01.8d4de8ee1226.mp3` (22s, source: tts)
- **Visual Type**: `illustration` · **Description**: A busy Accra market stall where a woman sifts gari through a sieve, a girl stirs sugar into a glass of water, and a man pours muddy water through a cloth into a bucket.
- **Image Asset Reference**: `images/s01.553808b1c941.webp` · **Alt Text**: A busy Accra market stall where a woman sifts gari through a sieve, a girl stirs sugar into a glass of water, and a man pours muddy water through a cloth into a bucket.
- **Visual Labels**: None
- **SVG Content**: None
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B8.1.1.1.2 is previewed here. AI image placement is approximate.
- **Existing Checkpoints After This Slide**: None

## Slide 2: `s02` — Solids and Liquids
- **Learning Objective / Purpose**: Group materials as solids or liquids (indicator 1, exemplar 1).
- **Indicators**: B8.1.1.1.1
- **On-Screen Educational Text**:
  - Materials can be solids or liquids
  - Solids keep their shape
  - Liquids take the shape of a container
- **Key Ideas**: Pebbles, salt, sugar, sand and gari are solids. | Water, oil and vinegar are liquids. | A powder is made of tiny solid grains.
- **Complete Narration Text**: Let us group some materials. Pebbles, bottle tops, salt, sugar, sand, gari and gravel are solids. Water, cooking oil and vinegar are liquids. A solid keeps its own shape, but a liquid takes the shape of the container that holds it. Powders, such as flour, are tiny solid grains.
- **Audio Asset Reference**: `audio/s02.946893c233a7.mp3` (20s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 2 rows: Solids, Pebbles, salt, sugar, gari; Liquids, Water, oil, vinegar.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 2 rows: Solids, Pebbles, salt, sugar, gari; Liquids, Water, oil, vinegar.
- **Visual Labels**: Group, Examples, Solids, Liquids, Pebbles, salt, sugar, gari, Water, oil, vinegar
- **SVG Content**: Present (1709 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B8.1.1.1.1. Pupils group materials such as powder, pebbles, bottle tops, salt, sugar, sand, gari, gravel, oil and water into solids and liquids. A powder is a solid that has been ground very fine.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcA1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qA.1`: Which group has only solids? — Correct: b (a: Oil, salt and sand | b: Pebbles, salt and sand | c: Water, gari and sugar | d: Vinegar, pebbles and salt)

## Slide 3: `s03` — What Is a Mixture?
- **Learning Objective / Purpose**: Define a mixture (indicator 1).
- **Indicators**: B8.1.1.1.1
- **On-Screen Educational Text**:
  - Substances are physically combined
  - Each part keeps its identity
  - A mixture can be separated
- **Key Ideas**: A mixture is substances physically combined. | Each part keeps its own identity. | The parts can be separated by physical methods.
- **Complete Narration Text**: A mixture is two or more substances physically combined, with no new substance formed. Each part keeps its own chemical identity, so sand mixed with gravel is still sand and still gravel. But the mixture can look and behave differently from its parts. We can separate the parts by physical methods, and the amounts can vary.
- **Audio Asset Reference**: `audio/s03.cf1b6b608157.mp3` (22s, source: tts)
- **Visual Type**: `svg` · **Description**: Mixture: Two or more substances together. Properties: Parts keep identity, No new substance, Can be separated, Any amounts.
- **Image Asset Reference**: `None` · **Alt Text**: Mixture: Two or more substances together. Properties: Parts keep identity, No new substance, Can be separated, Any amounts.
- **Visual Labels**: Mixture, Two or more substances together, Parts keep identity, No new substance, Can be separated, Any amounts
- **SVG Content**: Present (1905 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 of B8.1.1.1.1 is introduced here: put two materials together and describe the product. The product of mixing is a mixture, not a new substance.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcA2` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qA.2`: What is a mixture? — Correct: a (a: Substances combined without forming a new one | b: A new substance with different properties | c: One kind of particle, like pure sugar | d: Any liquid held in a container)

## Slide 4: `s04` — Mixing Two Materials
- **Learning Objective / Purpose**: Describe the product of mixing two materials (indicator 1, exemplar 2).
- **Indicators**: B8.1.1.1.1
- **On-Screen Educational Text**:
  - Mix two materials and look closely
  - Immiscible liquids form layers
  - Miscible liquids mix completely
- **Key Ideas**: Immiscible liquids form layers, like oil and water. | Miscible liquids mix completely, like vinegar and water. | Dissolved salt is still there as tiny particles.
- **Complete Narration Text**: Let us mix two materials and describe the product. Sand and gravel stay as two solids that we can see. Oil and water are immiscible liquids, so they form two layers. Vinegar and water are miscible liquids, so they mix completely into one liquid. Salt stirred into water seems to vanish, but it is still there as tiny particles. Mixtures can also be gases, like air, or solids, like sand and gravel.
- **Audio Asset Reference**: `audio/s04.1373b3b0c20e.mp3` (29s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 4 rows: Sand and gravel, Two solids, both seen; Oil and water, Immiscible: two layers; Vinegar and water, Miscible: one liquid; Salt and water, Clear; salt dissolves.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 4 rows: Sand and gravel, Two solids, both seen; Oil and water, Immiscible: two layers; Vinegar and water, Miscible: one liquid; Salt and water, Clear; salt dissolves.
- **Visual Labels**: Mixed together, What we see, Sand and gravel, Oil and water, Vinegar and water, Salt and water, Two solids, both seen, Immiscible: two layers, Miscible: one liquid, Clear; salt dissolves
- **SVG Content**: Present (2794 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 2 of B8.1.1.1.1. Pupils put two materials together and describe the product. Gas-gas (air) and solid-solid (sand and gravel) mixtures are brief enrichment. Never taste laboratory materials. Evaporating a little salt solution on a dish shows that the salt is still present.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpA` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `cpA.1`: Oil poured into water forms two layers. What word describes liquids like these? — Correct: d (a: Miscible | b: Soluble | c: Homogeneous | d: Immiscible)
    - [mcq] `cpA.2`: Salt is stirred into water until it seems to vanish. What is true? — Correct: c (a: The salt has been destroyed by the water | b: A new substance has formed that is not salt | c: The salt is still there as tiny particles | d: The salt has changed into more water)
    - [mcq] `cpA.3`: Why can the parts of a mixture be separated by physical methods? — Correct: b (a: The parts are joined by strong bonds that heat breaks | b: No new substance forms, so each part keeps its identity | c: The parts change into one new substance first | d: The parts are always the same size and colour)
    - [mcq] `cpA.4`: Which of these is a mixture? — Correct: d (a: One pebble on the ground | b: A spoon of pure sugar | c: One bottle top on a table | d: Sand and gravel in a bucket)

## Slide 5: `s05` — Heterogeneous Mixtures
- **Learning Objective / Purpose**: Heterogeneous mixtures (indicator 1, exemplar 3).
- **Indicators**: B8.1.1.1.1
- **On-Screen Educational Text**:
  - The composition is not uniform
  - Different parts are often visible
  - Sand and gravel is one example
- **Key Ideas**: The composition is not uniform. | Different parts are often visible. | Sand and gravel, sand and water, and oil and water are examples.
- **Complete Narration Text**: In a heterogeneous mixture, the composition is not uniform: one part of the sample differs from another. Often we can see the different parts, as in sand and gravel, or sand and water, where the sand sinks. Oil and water form two layers. Soil has sand, clay and bits of plants. Heterogeneous means made up of different kinds.
- **Audio Asset Reference**: `audio/s05.52af80942cbc.mp3` (23s, source: tts)
- **Visual Type**: `svg` · **Description**: Heterogeneous mixture: Composition is not uniform. Examples: Sand and gravel, Sand and water, Oil and water, Soil.
- **Image Asset Reference**: `None` · **Alt Text**: Heterogeneous mixture: Composition is not uniform. Examples: Sand and gravel, Sand and water, Oil and water, Soil.
- **Visual Labels**: Heterogeneous mixture, Composition is not uniform, Sand and gravel, Sand and water, Oil and water, Soil
- **SVG Content**: Present (1910 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 3 of B8.1.1.1.1. Pupils draw observable conclusions on homogeneous and heterogeneous characteristics from sand and gravel, sand and water, and oil and water.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcB1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qB.1`: Which mixture is heterogeneous? — Correct: c (a: Salt dissolved in water | b: Sugar dissolved in water | c: Sand and water | d: Clear vinegar)

## Slide 6: `s06` — Homogeneous Mixtures
- **Learning Objective / Purpose**: Homogeneous mixtures (indicator 1, exemplar 3).
- **Indicators**: B8.1.1.1.1
- **On-Screen Educational Text**:
  - The composition is uniform throughout
  - Appearance alone can mislead
  - Salt in water is one example
- **Key Ideas**: The composition is uniform throughout. | Looks alone can mislead; judge by uniform composition. | Homogeneous does not mean pure.
- **Complete Narration Text**: In a homogeneous mixture, the composition is uniform: every part of the sample is the same. A salt solution, a sugar solution and vinegar are examples, and so is air, a mixture of gases. A fruit juice with pulp is not uniform. Looks alone can mislead us, so we judge by uniform composition. Homogeneous does not mean pure, because it still has two or more substances.
- **Audio Asset Reference**: `audio/s06.6f6c46b35b2a.mp3` (26s, source: tts)
- **Visual Type**: `svg` · **Description**: Homogeneous mixture: Uniform composition throughout. Examples: Salt solution, Sugar solution, Vinegar, Clear fruit juice.
- **Image Asset Reference**: `None` · **Alt Text**: Homogeneous mixture: Uniform composition throughout. Examples: Salt solution, Sugar solution, Vinegar, Clear fruit juice.
- **Visual Labels**: Homogeneous mixture, Uniform composition throughout, Salt solution, Sugar solution, Vinegar, Clear fruit juice
- **SVG Content**: Present (1915 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 3 of B8.1.1.1.1. Fruit juice with pulp is heterogeneous; only a clear, strained juice is treated as a solution. Coloured solutions, such as juice or tea, are still solutions.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcB2` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qB.2`: What does homogeneous mean? — Correct: a (a: Uniform composition throughout | b: The parts can be seen separately | c: Made of one pure material | d: Always a solid)

## Slide 7: `s07` — Sorting Mixtures
- **Learning Objective / Purpose**: Classify mixtures (indicator 1, exemplar 3).
- **Indicators**: B8.1.1.1.1
- **On-Screen Educational Text**:
  - Ask: is the composition uniform?
  - Sand and gravel is heterogeneous
  - Salt in water is homogeneous
- **Key Ideas**: Ask whether the composition is uniform. | Sand and gravel, oil and water, and sand and water are heterogeneous. | Salt in water is homogeneous.
- **Complete Narration Text**: Now let us sort some mixtures by asking whether the composition is uniform. Sand and gravel is heterogeneous, because the parts differ from place to place. Oil and water is heterogeneous, because two layers form. Sand and water is heterogeneous, because the sand sinks. Salt in water is homogeneous, because it is uniform throughout.
- **Audio Asset Reference**: `audio/s07.8b8bbcd19b2b.mp3` (22s, source: tts)
- **Visual Type**: `svg` · **Description**: Four rows, each with an arrow from a mixture to a box asking which type: sand and gravel, oil and water, sand and water, and salt in water.
- **Image Asset Reference**: `None` · **Alt Text**: Four rows, each with an arrow from a mixture to a box asking which type: sand and gravel, oil and water, sand and water, and salt in water.
- **Visual Labels**: Sand and gravel, Which type?, Oil and water, Which type?, Sand and water, Which type?, Salt in water, Which type?
- **SVG Content**: Present (2878 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 3 of B8.1.1.1.1. The tap item in section B uses this slide, so the type labels are hidden and each row shows "Which type?". The types are given in the narration and on-screen text. The hotspots match the four rows exactly.
- **Existing Checkpoints After This Slide**: None

## Slide 8: `s08` — Solute, Solvent and Solution
- **Learning Objective / Purpose**: Define solute, solvent and solution (indicator 1, exemplar 4).
- **Indicators**: B8.1.1.1.1
- **On-Screen Educational Text**:
  - Soluble means it can dissolve
  - The solvent is usually a liquid
  - Solute plus solvent makes a solution
- **Key Ideas**: A soluble substance can dissolve. | The solvent is usually a liquid that does the dissolving. | A solute and a solvent form a solution.
- **Complete Narration Text**: Sugar dissolves in water, so sugar is soluble in water. The substance that dissolves is the solute. The solvent is the substance, usually a liquid, that does the dissolving. When they mix evenly, they form a solution. In sugar water, the sugar is the solute, the water is the solvent and the sugar water is the solution. The dissolved sugar is still there as tiny particles.
- **Audio Asset Reference**: `audio/s08.90badb19ef5c.mp3` (26s, source: tts)
- **Visual Type**: `svg` · **Description**: Making a solution: solute plus solvent equals solution. For example, sugar plus water gives sugar water. The solute dissolves in the solvent.
- **Image Asset Reference**: `None` · **Alt Text**: Making a solution: solute plus solvent equals solution. For example, sugar plus water gives sugar water. The solute dissolves in the solvent.
- **Visual Labels**: Making a solution, Solute, +, Solvent, =, Solution, Sugar, Water, Sugar water, The solute dissolves in the solvent
- **SVG Content**: Present (2514 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 4 of B8.1.1.1.1. A solution is a homogeneous mixture of a solute dissolved in a solvent.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcB3` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qB.3`: In a sugar solution, which is the solvent? — Correct: d (a: Sugar | b: The spoon | c: The glass | d: Water)

## Slide 9: `s09` — Solutes and Solvents Compared
- **Learning Objective / Purpose**: Compare solutes and solvents by physical characteristics (indicator 1, exemplar 4).
- **Indicators**: B8.1.1.1.1
- **On-Screen Educational Text**:
  - A solute is dissolved
  - A solvent does the dissolving
  - Amount alone does not decide
- **Key Ideas**: A solute is the soluble substance that is dissolved. | A solvent does the dissolving and is usually a liquid. | Amount alone does not decide which is which.
- **Complete Narration Text**: Let us compare a solute and a solvent. A solute is the soluble substance that gets dissolved and spreads out. A solvent does the dissolving, and it is usually a liquid. We do not decide by amount alone, because the amounts can be close. Salt and sugar are common solutes, and water is a common solvent. A solution is homogeneous, and it may be coloured.
- **Audio Asset Reference**: `audio/s09.5e09ce210432.mp3` (26s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 3 rows: Is dissolved, Does the dissolving; Soluble in solvent, Usually a liquid; Salt or sugar, Water.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 3 rows: Is dissolved, Does the dissolving; Soluble in solvent, Usually a liquid; Salt or sugar, Water.
- **Visual Labels**: Solute, Solvent, Is dissolved, Soluble in solvent, Salt or sugar, Does the dissolving, Usually a liquid, Water
- **SVG Content**: Present (2238 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 4 of B8.1.1.1.1. Compare solutes and solvents based on their physical characteristics. Enrichment: a solvent is not always a liquid, and the amounts can be close, so amount alone does not decide.
- **Existing Checkpoints After This Slide**: None

## Slide 10: `s10` — Solutions We Know
- **Learning Objective / Purpose**: Examples of solutions (indicator 1, exemplar 5).
- **Indicators**: B8.1.1.1.1
- **On-Screen Educational Text**:
  - Solutions are homogeneous
  - Solutions may be coloured
  - Clear alone does not prove a solution
- **Key Ideas**: A solution is homogeneous and may be coloured. | Vinegar is acetic acid dissolved in water. | Looking clear does not prove a true solution.
- **Complete Narration Text**: Here are some solutions we know. A solution is homogeneous, and it may be coloured. A salt solution has soluble salt dissolved in water. A sugar solution has soluble sugar dissolved in water. Vinegar is a solution of acetic acid in water. Clear fruit juice has sugars dissolved in water. Looking clear is not proof of a true solution, because some colloids also look clear, so we use more tests.
- **Audio Asset Reference**: `audio/s10.f74745452c49.mp3` (28s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 4 rows: Salt solution, Salt in water; Sugar solution, Sugar in water; Vinegar, Acetic acid in water; Clear fruit juice, Sugars in water.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 4 rows: Salt solution, Salt in water; Sugar solution, Sugar in water; Vinegar, Acetic acid in water; Clear fruit juice, Sugars in water.
- **Visual Labels**: Solution, Solute and solvent, Salt solution, Sugar solution, Vinegar, Clear fruit juice, Salt in water, Sugar in water, Acetic acid in water, Sugars in water
- **SVG Content**: Present (2762 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 5 of B8.1.1.1.1 (identifying solutions such as salt solution, sugar solution, fruit juice and vinegar solution). Vinegar is a dilute solution of acetic acid in water. Fruit juice with pulp is not a solution. Clear appearance alone does not prove a true solution.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpB` (retryRule: 2 attempts, then show the answer with the explanation):
    - [tapDiagram] `cpB.1`: Tap the mixture that is homogeneous. — Hotspot: h4
    - [mcq] `cpB.2`: Which pair are both homogeneous mixtures? — Correct: a (a: Sugar solution and vinegar | b: Sand and gravel; oil and water | c: Muddy water and sugar solution | d: Oil and water; salt solution)
    - [mcq] `cpB.3`: Why is water called the solvent in a salt solution? — Correct: b (a: It is the smaller amount | b: It does the dissolving | c: It disappears into the salt | d: It is a solid)
    - [mcq] `cpB.4`: Which statement about a solution is correct? — Correct: c (a: The solute settles at the bottom after an hour | b: The solute pieces are easy to see | c: The solute is spread evenly in the solvent | d: The solvent is always a solid)

## Slide 11: `s11` — Suspensions
- **Learning Objective / Purpose**: Define a suspension (indicator 1, exemplar 6).
- **Indicators**: B8.1.1.1.1
- **On-Screen Educational Text**:
  - A suspension is cloudy
  - Insoluble solid settles by sedimentation
  - Muddy water is an example
- **Key Ideas**: A suspension is a cloudy mixture of insoluble bits in a liquid. | The bits settle by sedimentation, quickly or slowly. | Chalk, muddy water and groundnut paste in water are examples.
- **Complete Narration Text**: Stir chalk powder or soil into water in a glass. The mixture looks cloudy because the solid is insoluble, so it does not dissolve. If we leave it to stand, the solid settles by sedimentation, quickly or slowly. This is a suspension. Filter paper can hold back the solid. Groundnut paste in water is more complex, since it has oil and bits, but we treat it as a suspension. Some medicines say shake well, because they are suspensions.
- **Audio Asset Reference**: `audio/s11.dfbcc09a8b1d.mp3` (31s, source: tts)
- **Visual Type**: `svg` · **Description**: Suspension: Solid bits spread in a liquid. Signs: Cloudy mixture, Settles slowly, Can be filtered, Shake before use.
- **Image Asset Reference**: `None` · **Alt Text**: Suspension: Solid bits spread in a liquid. Signs: Cloudy mixture, Settles slowly, Can be filtered, Shake before use.
- **Visual Labels**: Suspension, Solid bits spread in a liquid, Cloudy mixture, Settles slowly, Can be filtered, Shake before use
- **SVG Content**: Present (1901 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 6 of B8.1.1.1.1. A suspension is a heterogeneous mixture. Chalk or muddy water is the clearer first example. Groundnut paste also contains oil and is complex, so for this lesson it is treated as a suspension of solid bits in water. Not every suspension settles immediately; very fine bits take a long time. Check for groundnut allergy before any pupil handles groundnut paste.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcC1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qC.1`: Chalk powder in water slowly settles to the bottom. What is this called? — Correct: b (a: Condensation | b: Sedimentation | c: Evaporation | d: Dissolving)

## Slide 12: `s12` — Colloids
- **Learning Objective / Purpose**: Define a colloid (indicator 1, exemplar 7).
- **Indicators**: B8.1.1.1.1
- **On-Screen Educational Text**:
  - A colloid does not settle quickly
  - It looks smooth and even
  - Milk and fog are colloids
- **Key Ideas**: A colloid does not settle quickly. | Many colloidal particles can pass through ordinary filter paper; it depends on particle size and filter pores. | Milk, fog, smoke and jelly are colloids.
- **Complete Narration Text**: A colloid looks smooth and even, but its particles are bigger than those in a solution. They are small enough to stay spread out, so a colloid does not settle quickly, and many colloidal particles can pass through ordinary filter paper, depending on particle size and the filter pores. Milk is a colloid. So are fog, smoke and jelly. A colloid is not a suspension, which settles, and it is not a solution, because its particles scatter light.
- **Audio Asset Reference**: `audio/s12.29c72c991562.mp3` (31s, source: tts)
- **Visual Type**: `svg` · **Description**: Colloid: Particles stay spread out. Examples: Milk, Fog, Jelly, Smoke.
- **Image Asset Reference**: `None` · **Alt Text**: Colloid: Particles stay spread out. Examples: Milk, Fog, Jelly, Smoke.
- **Visual Labels**: Colloid, Particles stay spread out, Milk, Fog, Jelly, Smoke
- **SVG Content**: Present (1852 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 7 of B8.1.1.1.1. Colloid particles are larger than the particles in a solution, do not settle quickly, and many colloidal particles can pass through ordinary filter paper; it depends on particle size and filter pores. Some colloids can slowly separate over time (for example cream rising in milk), so avoid saying colloids stay mixed forever.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcC2` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qC.2`: Which of these is a colloid? — Correct: d (a: Salt solution | b: Sand in water | c: Vinegar | d: Milk)

## Slide 13: `s13` — The Colloidal (Tyndall) Effect
- **Learning Objective / Purpose**: Show the colloidal effect (indicator 1, exemplar 7).
- **Indicators**: B8.1.1.1.1
- **On-Screen Educational Text**:
  - Shine a torch through each mixture
  - Colloid particles scatter light
  - Use other tests too
- **Key Ideas**: Colloid particles scatter light, so the beam path shows. | This is the colloidal effect, also known as the Tyndall effect. | A cloudy suspension may also scatter and absorb light, so use other tests too.
- **Complete Narration Text**: Here is a test, led by the teacher. Shine a torch beam through a solution, such as salt water. You cannot see the beam inside it. Now shine it through diluted milk, a colloid. The particles scatter the light, so the path of the beam shows up. This is the colloidal effect, also known as the Tyndall effect. A cloudy suspension may also scatter and absorb light, so less light is transmitted. So we use this test together with the standing and filtering tests.
- **Audio Asset Reference**: `audio/s13.f8796fae1c82.mp3` (34s, source: tts)
- **Visual Type**: `svg` · **Description**: Three jars with a torch beam. A solution shows no beam path. A colloid scatters the light, so the beam path shows (the colloidal or Tyndall effect). A cloudy suspension is labelled Light scattered; transmission reduced, because it can scatter and absorb light. This test alone does not separate every colloid from every suspension.
- **Image Asset Reference**: `None` · **Alt Text**: Three jars with a torch beam. A solution shows no beam path. A colloid scatters the light, so the beam path shows (the colloidal or Tyndall effect). A cloudy suspension is labelled Light scattered; transmission reduced, because it can scatter and absorb light. This test alone does not separate every colloid from every suspension.
- **Visual Labels**: Beam not seen, Solution, Beam seen, Colloid, Suspension, Light scattered; transmission reduced
- **SVG Content**: Present (2332 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 7 of B8.1.1.1.1. Teacher demonstration in a dim room with a torch. Never shine a torch or a laser pointer into anyone's eyes. Dilute milk or starch in water gives a clear effect. The Tyndall effect shows that particles are large enough to scatter light, but a coarse suspension can scatter light too, so it is never a conclusive test by itself.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcC3` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qC.3`: What is the scattering of light by a colloid called? — Correct: a (a: The Tyndall effect | b: Sedimentation of solids | c: Condensation of vapour | d: Decantation of a liquid)

## Slide 14: `s14` — Three Kinds of Mixture
- **Learning Objective / Purpose**: Compare solution, suspension and colloid (indicator 1, exemplar 7).
- **Indicators**: B8.1.1.1.1
- **On-Screen Educational Text**:
  - A solution is homogeneous
  - A suspension settles by sedimentation
  - A colloid often shows the Tyndall effect
- **Key Ideas**: A solution is homogeneous and does not settle. | A suspension is usually cloudy and settles by sedimentation. | A colloid often shows the Tyndall effect; use several tests.
- **Complete Narration Text**: Let us compare the three kinds. A solution is homogeneous, and it may be coloured. Its particles are too small to see, they do not settle, and they pass through filter paper. A suspension is usually cloudy. Its insoluble bits settle by sedimentation, and filter paper holds them back. A colloid stays mixed and often shows the Tyndall effect, and many of its particles can pass through ordinary filter paper. Looking clear is not proof of a solution, so we use several tests.
- **Audio Asset Reference**: `audio/s14.a3d7d4d62f12.mp3` (33s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 3 rows: Solution, Uniform, no settling; Suspension, Cloudy, settles; Colloid, Often shows Tyndall effect.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 3 rows: Solution, Uniform, no settling; Suspension, Cloudy, settles; Colloid, Often shows Tyndall effect.
- **Visual Labels**: Type, Main sign, Solution, Suspension, Colloid, Uniform, no settling, Cloudy, settles, Often shows Tyndall effect
- **SVG Content**: Present (2234 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 7 of B8.1.1.1.1. Differentiate a colloid from a suspension and show the colloidal effect.
- **Existing Checkpoints After This Slide**: None

## Slide 15: `s15` — Telling Them Apart
- **Learning Objective / Purpose**: Steps for telling three kinds of mixture apart (indicator 1, exemplar 7).
- **Indicators**: B8.1.1.1.1
- **On-Screen Educational Text**:
  - Look: clear or cloudy?
  - Check for sediment and residue
  - Look for the Tyndall effect
- **Key Ideas**: Look at the mixture first. | Leave it to stand, then filter and check the residue. | Look for the Tyndall effect with a torch, and use all four tests together.
- **Complete Narration Text**: Here are the steps. First, look at the mixture. Is it clear or cloudy? Second, leave it to stand and see whether any sediment settles. Third, pour it through filter paper and see what residue is left behind. Last, shine a torch through it to look for the Tyndall effect. Use all four tests together, because one test alone can mislead us.
- **Audio Asset Reference**: `audio/s15.cc0b9ab699b0.mp3` (25s, source: tts)
- **Visual Type**: `svg` · **Description**: Four numbered steps: look: clear or cloudy?, leave it to stand, pour it through a filter, shine a torch through it.
- **Image Asset Reference**: `None` · **Alt Text**: Four numbered steps: look: clear or cloudy?, leave it to stand, pour it through a filter, shine a torch through it.
- **Visual Labels**: Look: clear or cloudy?, Leave it to stand, Pour it through a filter, Shine a torch through it
- **SVG Content**: Present (2139 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplars 6 and 7 of B8.1.1.1.1. A very fine suspension may look like a colloid at first, so the standing test and the filter test help. Keep the torch beam away from eyes.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpC` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `cpC.1`: A cloudy liquid has solid bits settling to the bottom. What is it most likely to be? — Correct: c (a: A solution | b: A colloid | c: A suspension | d: A pure liquid)
    - [mcq] `cpC.2`: A liquid is clear, does not settle and shows no beam path. What is the best conclusion? — Correct: d (a: It is a colloid, because colloids are always clear | b: It is a suspension, because it shows no beam | c: It is oil and water, because it is clear | d: It is most likely a solution)
    - [mcq] `cpC.3`: Why does a colloid not settle quickly? — Correct: b (a: Its particles are fully dissolved like salt | b: Its particles are small enough to stay spread out | c: It contains no particles, only liquid | d: Its particles are bigger than those of a suspension)
    - [mcq] `cpC.4`: How does a colloid differ from a suspension? — Correct: a (a: A colloid stays mixed, but a suspension settles | b: A colloid settles, but a suspension stays mixed | c: Both settle, but at different speeds | d: A colloid is clear, and a suspension is a solution)

## Slide 16: `s16` — Ways of Separating Mixtures
- **Learning Objective / Purpose**: Introduce separation methods (indicator 2, exemplar 1).
- **Indicators**: B8.1.1.1.1, B8.1.1.1.2
- **On-Screen Educational Text**:
  - We use a difference between the parts
  - Each method fits a kind of mixture
  - Choose the method with care
- **Key Ideas**: We separate a mixture using a difference between its parts. | Sieving, filtration, decantation, evaporation, distillation and the separating funnel are methods. | First find the difference, then choose the method.
- **Complete Narration Text**: To separate a mixture, we use a difference between its parts, such as size, solubility or boiling point. Today we study sieving, filtration, decantation, evaporation, distillation and the separating funnel. There are others too. A magnet picks out iron, winnowing blows light chaff away from grain, and chromatography separates coloured dyes in ink, which is an enrichment idea. First find the difference, then choose the method.
- **Audio Asset Reference**: `audio/s16.cb888edfbe81.mp3` (26s, source: tts)
- **Visual Type**: `svg` · **Description**: Separating mixtures: Use a difference between the parts. Methods: Sieving, Filtration, Decantation, Evaporation, Distillation, Separating funnel.
- **Image Asset Reference**: `None` · **Alt Text**: Separating mixtures: Use a difference between the parts. Methods: Sieving, Filtration, Decantation, Evaporation, Distillation, Separating funnel.
- **Visual Labels**: Separating mixtures, Use a difference between the parts, Sieving, Filtration, Decantation, Evaporation, Distillation, Separating funnel
- **SVG Content**: Present (2428 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B8.1.1.1.2 (perform activities such as distilling, filtering, sieving and others). Exemplar 5 of B8.1.1.1.1 is also prepared here. Magnet, winnowing and chromatography are mentioned as other methods; chromatography is enrichment only.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcD1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qD.1`: Which method separates sand from gravel? — Correct: c (a: Distillation | b: Evaporation | c: Sieving | d: Using a separating funnel)

## Slide 17: `s17` — Sieving, Filtering, Decanting
- **Learning Objective / Purpose**: Methods that use size and settling (indicator 2, exemplar 1).
- **Indicators**: B8.1.1.1.2
- **On-Screen Educational Text**:
  - Sieving uses the size of pieces
  - Filtration holds back insoluble solid
  - Decanting pours off the liquid
- **Key Ideas**: Sieving separates solids by the size of the pieces. | Filtration holds back an insoluble solid. | Decanting pours off the liquid after sedimentation.
- **Complete Narration Text**: Sieving separates solids of different sizes, such as sand from gravel. Filtration separates an insoluble solid from a liquid. The liquid that passes through is the filtrate, and the solid left on the paper is the residue. Sedimentation lets an insoluble solid settle at the bottom as sediment. Decanting then pours off the clear liquid on top, leaving the sediment behind.
- **Audio Asset Reference**: `audio/s17.817426296684.mp3` (24s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 3 rows: Sieving, Size of the pieces; Filtration, Solid is insoluble; Decanting, Solid settles first.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 3 rows: Sieving, Size of the pieces; Filtration, Solid is insoluble; Decanting, Solid settles first.
- **Visual Labels**: Method, Difference used, Sieving, Filtration, Decanting, Size of the pieces, Solid is insoluble, Solid settles first
- **SVG Content**: Present (2244 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B8.1.1.1.2. A sieve works for gari with lumps, or for sand and gravel. Filtering works only for a solid that does not dissolve.
- **Existing Checkpoints After This Slide**: None

## Slide 18: `s18` — Evaporation, Distillation, Funnel
- **Learning Objective / Purpose**: Methods that use heat and layers (indicator 2, exemplar 1).
- **Indicators**: B8.1.1.1.2
- **On-Screen Educational Text**:
  - Evaporation leaves the solute behind
  - Distillation condenses the vapour
  - A funnel separates immiscible liquids
- **Key Ideas**: Evaporation leaves the dissolved solid behind. | Distillation boils, then condenses the vapour to collect the liquid. | A separating funnel separates immiscible liquids.
- **Complete Narration Text**: Evaporation turns a liquid into vapour at its surface and leaves a dissolved solid behind. Boiling is faster, with bubbles all through the liquid. Distillation boils a liquid, then condenses the vapour to collect it, using different boiling points. Condensation is vapour turning back into liquid. A separating funnel separates immiscible liquids, such as oil and water. We open the tap and let the lower layer run out.
- **Audio Asset Reference**: `audio/s18.2b9647ea1c13.mp3` (27s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 3 rows: Evaporation, Liquid becomes vapour; Distillation, Boiling points differ; Separating funnel, Immiscible layers.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 3 rows: Evaporation, Liquid becomes vapour; Distillation, Boiling points differ; Separating funnel, Immiscible layers.
- **Visual Labels**: Method, Difference used, Evaporation, Distillation, Separating funnel, Liquid becomes vapour, Boiling points differ, Immiscible layers
- **SVG Content**: Present (2266 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B8.1.1.1.2. The separating funnel is shown as a teacher demonstration or picture. In oil and water, the oil floats on top, so the water runs out of the tap first. Evaporation (at the surface), boiling (bubbles throughout), condensation and distillation are distinguished here.
- **Existing Checkpoints After This Slide**: None

## Slide 19: `s19` — Filtering Step by Step
- **Learning Objective / Purpose**: Filtering diagram (indicator 2, exemplar 1).
- **Indicators**: B8.1.1.1.2
- **On-Screen Educational Text**:
  - Pour the mixture through filter paper
  - The insoluble solid stays as residue
  - The liquid that passes is the filtrate
- **Key Ideas**: The mixture is poured through filter paper in a funnel. | The insoluble solid left on the paper is the residue. | The liquid that passes through is the filtrate.
- **Complete Narration Text**: Look at the funnel. We pour the mixture through the filter paper. The insoluble solid is held back on the paper, and it is called the residue. The liquid that passes into the beaker is called the filtrate. A soluble solute passes through with the filtrate, so filtering cannot remove it. Clear filtered water may still be unsafe to drink.
- **Audio Asset Reference**: `audio/s19.61d683f885c2.mp3` (24s, source: tts)
- **Visual Type**: `svg` · **Description**: A funnel with filter paper holds a mixture poured from the top left. The insoluble solid stays on the paper as the residue, and the liquid drips into a beaker below as the filtrate.
- **Image Asset Reference**: `None` · **Alt Text**: A funnel with filter paper holds a mixture poured from the top left. The insoluble solid stays on the paper as the residue, and the liquid drips into a beaker below as the filtrate.
- **Visual Labels**: Mixture, Filter paper, Residue, Filtrate
- **SVG Content**: Present (2053 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B8.1.1.1.2. A cut plastic bottle and a clean cloth or coffee filter can replace a funnel and filter paper. Pour slowly so that the liquid does not overflow the paper. Filtered water that looks clear is not necessarily safe to drink.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcD2` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qD.2`: What is the liquid that passes through the filter paper called? — Correct: b (a: The residue | b: The filtrate | c: The solute | d: The solvent)

## Slide 20: `s20` — Salt from the Sun
- **Learning Objective / Purpose**: Evaporation in everyday life (indicator 2, exemplar 1).
- **Indicators**: B8.1.1.1.2
- **On-Screen Educational Text**:
  - Salt is made from sea water
  - The sun evaporates the water
  - Salt crystallises as water is lost
- **Key Ideas**: Salt is made by evaporating sea or lagoon water. | The sun turns the water into vapour. | Salt crystallises and is left behind.
- **Complete Narration Text**: Look at the salt pans near Ada and Keta. Workers let sea water or lagoon water run into shallow pans. The heat of the sun makes the water evaporate as vapour. As the water becomes less, the dissolved salt forms white crystals, in a process called crystallisation. The salt does not evaporate, so it is left behind. This is how evaporation separates dissolved salt from water.
- **Audio Asset Reference**: `audio/s20.8cf0e067cd54.mp3` (26s, source: tts)
- **Visual Type**: `illustration` · **Description**: Workers at shallow salt pans near a lagoon, raking white salt crystals into piles under the hot sun in the Ada area of Ghana.
- **Image Asset Reference**: `images/s20.fd3577de8d36.webp` · **Alt Text**: Workers at shallow salt pans near a lagoon, raking white salt crystals into piles under the hot sun in the Ada area of Ghana.
- **Visual Labels**: None
- **SVG Content**: None
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B8.1.1.1.2 and exemplar 5 of B8.1.1.1.1. In class, evaporate a little salt solution in a shallow dish in the sun. AI image placement is approximate.
- **Existing Checkpoints After This Slide**: None

## Slide 21: `s21` — Distillation
- **Learning Objective / Purpose**: Distillation diagram (indicator 2, exemplar 1).
- **Indicators**: B8.1.1.1.2
- **On-Screen Educational Text**:
  - Heat the salt water
  - Vapour condenses in the condenser
  - The distillate is collected
- **Key Ideas**: Salt water is heated and the water becomes vapour. | The condenser cools the vapour so it condenses into the distillate. | The salt stays behind in the flask.
- **Complete Narration Text**: Look at the set-up. The teacher heats the salt water in the flask. The water boils and turns to vapour, but the salt stays behind. The vapour passes into the slanting condenser, where cold water enters at the lower end and leaves at the upper end. The cooling makes the vapour condense into liquid water, called the distillate. It drips into the beaker. A school set-up gives water that is much purer, though not perfectly pure. Evaporation lets water escape, but distillation collects it.
- **Audio Asset Reference**: `audio/s21.01c8cae0a938.mp3` (34s, source: tts)
- **Visual Type**: `svg` · **Description**: A flask of salt water is heated by the teacher. Vapour travels through a tube into a condenser that slants downwards towards a beaker. Cold water enters at the lower end of the condenser and leaves at the upper end. The liquid that drips into the beaker is the distillate (collected water).
- **Image Asset Reference**: `None` · **Alt Text**: A flask of salt water is heated by the teacher. Vapour travels through a tube into a condenser that slants downwards towards a beaker. Cold water enters at the lower end of the condenser and leaves at the upper end. The liquid that drips into the beaker is the distillate (collected water).
- **Visual Labels**: Salt water, Vapour, Heat, Condenser, Distillate (collected water), Cold water out, Cold water in
- **SVG Content**: Present (2767 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B8.1.1.1.2. Teacher demonstration or picture only. Do not allow pupils to heat glassware or handle hot vapour. The condenser slants downwards so that the liquid runs into the beaker. Cold water enters at the lower end and leaves at the upper end. Distillate from a school set-up is much purer but not perfectly pure.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcD3` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qD.3`: What is the liquid collected in the beaker after distillation called? — Correct: c (a: The residue | b: The filtrate | c: The distillate | d: The sediment)

## Slide 22: `s22` — Choosing a Method
- **Learning Objective / Purpose**: Match mixtures with methods (indicator 2, exemplar 1; indicator 1, exemplar 5).
- **Indicators**: B8.1.1.1.1, B8.1.1.1.2
- **On-Screen Educational Text**:
  - Look for the difference first
  - Then choose the method
  - Sand is insoluble, so filter it
- **Key Ideas**: Sieve solids of different sizes. | Filter an insoluble solid from a liquid. | Evaporate or distil a solution, and use a funnel for immiscible liquids.
- **Complete Narration Text**: Let us match mixtures with methods. Sand and gravel differ in size, so we sieve them. Sand is insoluble in water, so we filter sand and water. In a salt solution the salt is soluble, so we evaporate the water, or distil it if we want the water. Oil and water are immiscible, so we use a separating funnel. Always say which difference you are using.
- **Audio Asset Reference**: `audio/s22.06b552150726.mp3` (26s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 4 rows: Sand and gravel, Sieve: sizes differ; Sand and water, Filter: insoluble sand; Salt solution, Evaporate or distil; Oil and water, Funnel: immiscible.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 4 rows: Sand and gravel, Sieve: sizes differ; Sand and water, Filter: insoluble sand; Salt solution, Evaporate or distil; Oil and water, Funnel: immiscible.
- **Visual Labels**: Mixture, Method, Sand and gravel, Sand and water, Salt solution, Oil and water, Sieve: sizes differ, Filter: insoluble sand, Evaporate or distil, Funnel: immiscible
- **SVG Content**: Present (2769 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B8.1.1.1.2 and exemplar 5 of B8.1.1.1.1. Pupils identify and separate sand and sugar, sugar and salt, and solutions such as salt solution, sugar solution, fruit juice and vinegar solution.
- **Existing Checkpoints After This Slide**: None

## Slide 23: `s23` — Sand, Sugar and Salt
- **Learning Objective / Purpose**: Separating mixtures of solids (indicator 1, exemplar 5).
- **Indicators**: B8.1.1.1.1, B8.1.1.1.2
- **On-Screen Educational Text**:
  - Dissolve the sugar, filter out the sand
  - Crystals need suitable conditions
  - Sugar and salt both dissolve in water
- **Key Ideas**: Dissolve the sugar in water, then filter out the sand. | Concentrating and cooling the filtrate aims for crystals, but does not guarantee them. | Sugar and salt both dissolve, so ordinary filtration cannot separate them.
- **Complete Narration Text**: Sand and sugar can be separated. Sugar is soluble and sand is not, so dissolve the sugar in water and filter out the sand. Then the teacher gently heats the filtrate to concentrate it, and cools it, aiming for sugar crystals. Crystals form only under suitable conditions, so concentrating and cooling do not guarantee them. Too much heat can burn sugar, and any crystals may not be perfectly pure. Sugar and salt both dissolve in water, so ordinary filtration cannot separate them. For fruit juice, filter out the pulp first. Never taste any mixture.
- **Audio Asset Reference**: `audio/s23.48bba40a7b32.mp3` (38s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 4 rows: Sand and sugar, Add water, then filter; Sugar solution, Concentrate, crystallise; Sugar and salt, Filtering cannot do it; Fruit juice, Filter pulp first.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 4 rows: Sand and sugar, Add water, then filter; Sugar solution, Concentrate, crystallise; Sugar and salt, Filtering cannot do it; Fruit juice, Filter pulp first.
- **Visual Labels**: Mixture, How to separate, Sand and sugar, Sugar solution, Sugar and salt, Fruit juice, Add water, then filter, Concentrate, crystallise, Filtering cannot do it, Filter pulp first
- **SVG Content**: Present (2786 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 5 of B8.1.1.1.1 and exemplar 1 of B8.1.1.1.2. Sequence: dissolve the sugar, filter out the sand, then the teacher concentrates the filtrate by controlled gentle heating and cools it, aiming for crystals. Crystallisation depends on suitable conditions (enough concentration, slow cooling, no overheating); concentration and cooling alone do not guarantee crystals, and any crystals may not be perfectly pure. Overheating can caramelise or burn the sugar. Pupils identify why filtration cannot separate sugar from salt. OPTIONAL TEACHER BACKGROUND (not for pupils, no procedure given): separating two soluble solids needs more advanced chemistry methods beyond this lesson, and it is not easy.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpD` (retryRule: 2 attempts, then show the answer with the explanation):
    - [sequence] `cpD.1`: Put the steps for filtering muddy water in order. — Order: st3 -> st4 -> st2 -> st1
    - [mcq] `cpD.2`: Why is evaporation, not filtration, used to get salt from salt solution? — Correct: d (a: The salt is insoluble, so it stays on the paper | b: The salt is a liquid, so it cannot be filtered | c: The salt is too large to pass through paper | d: The salt is soluble, so it passes through filter paper)
    - [mcq] `cpD.3`: Sugar is dissolved in water. What is the best way to try to recover the sugar without burning it? — Correct: a (a: Heat gently to concentrate, then cool so crystals can form | b: Boil it dry on a strong flame until it is brown | c: Pour it through filter paper and keep the filtrate | d: Leave it to stand and pour off the top layer)
    - [mcq] `cpD.4`: Why can filter paper not separate sugar from salt? — Correct: c (a: Both are insoluble, so both stay as residue | b: Both are liquids, so they cannot be filtered | c: Both are soluble, so both pass through | d: Both are too large to pass through the paper)

## Slide 24: `s24` — Pupils Separate a Mixture
- **Learning Objective / Purpose**: Safe separation activity (indicator 2, exemplar 1).
- **Indicators**: B8.1.1.1.2
- **On-Screen Educational Text**:
  - Work in supervised groups
  - Filter muddy water safely
  - Hot apparatus stays with the teacher
- **Key Ideas**: Pupils filter muddy water in supervised groups. | Clear filtered water may still be unsafe to drink. | Hot apparatus and distillation stay with the teacher.
- **Complete Narration Text**: Look at this class. Pupils work in small groups while the teacher supervises. Each group pours muddy water slowly through a cloth or filter paper in a funnel into a beaker on a tray, and names the residue and the filtrate. Clear filtered water may still be unsafe to drink, so nobody drinks it. Afterwards, everyone wipes the table and washes their hands. Anything hot, and distillation, stay with the teacher, and we never taste any material.
- **Audio Asset Reference**: `audio/s24.afba770b9e31.mp3` (31s, source: tts)
- **Visual Type**: `illustration` · **Description**: Pupils in school uniform work in small supervised groups. Each group pours muddy water slowly through a cut plastic bottle funnel lined with a clean cloth into a clear beaker on a tray, while the teacher walks between the groups.
- **Image Asset Reference**: `images/s24.d88c6d595fa2.webp` · **Alt Text**: Pupils in school uniform work in small supervised groups. Each group pours muddy water slowly through a cut plastic bottle funnel lined with a clean cloth into a clear beaker on a tray, while the teacher walks between the groups.
- **Visual Labels**: None
- **SVG Content**: None
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B8.1.1.1.2. Learner-performed filtration in groups of about four, supervised. Smooth the edges of cut plastic bottles beforehand. No tasting or drinking. Heating and distillation remain teacher-controlled. AI image placement is approximate.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcE1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qE.1`: What should happen before anything is heated in a separation activity? — Correct: a (a: The teacher leads the heating | b: We heat it quickly to save time | c: We hold the container in our hands | d: We taste it to check)

## Slide 25: `s25` — Plan, Do and Report
- **Learning Objective / Purpose**: Plan, carry out and report a separation (indicator 2, exemplar 1).
- **Indicators**: B8.1.1.1.2
- **On-Screen Educational Text**:
  - Choose a method that fits
  - Fill in the observation table
  - Add a labelled diagram and explanation
- **Key Ideas**: Name the parts, then choose a method that fits. | Record in a table: mixture, method, observation, conclusion. | Add a labelled diagram and explain why the method works.
- **Complete Narration Text**: Here is how to report a separation activity. First, name the parts of the mixture and choose a method that fits. Then do it safely and fill in an observation table with four columns: mixture, method, observation and conclusion. Here is a sample row: sand and water, filtration, the sand stays on the paper, so the sand is insoluble. Last, make a labelled diagram and write why your method works, using the difference between the parts. A good report also says what else might have changed the result.
- **Audio Asset Reference**: `audio/s25.81b148466c50.mp3` (35s, source: tts)
- **Visual Type**: `svg` · **Description**: A table with 4 rows: Mixture, Sand and water; Method, Filtration; Observation, Sand stays on the paper; Conclusion, Sand is insoluble.
- **Image Asset Reference**: `None` · **Alt Text**: A table with 4 rows: Mixture, Sand and water; Method, Filtration; Observation, Sand stays on the paper; Conclusion, Sand is insoluble.
- **Visual Labels**: Column, Sample row, Mixture, Method, Observation, Conclusion, Sand and water, Filtration, Sand stays on the paper, Sand is insoluble
- **SVG Content**: Present (2739 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Exemplar 1 of B8.1.1.1.2 (present a report on your findings using drawing and written work). The slide shows one sample row of the four-column table (Mixture, Method, Observation, Conclusion), written down the page so that it fits at 48 px. Learners draw the full four-column table themselves, add a labelled diagram and write why the method works. Learners write their own table and explanation; the app only shows how.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpE` (retryRule: 2 attempts, then show the answer with the explanation):
    - [sequence] `cpE.1`: Put the steps of a separation activity in order. — Order: st1 -> st2 -> st4 -> st3
    - [mcq] `cpE.2`: A pupil wants to clear muddy water. Which plan is best, and why? — Correct: b (a: Boil it dry, because the mud will evaporate | b: Settle, decant, then filter, since mud is insoluble | c: Add salt and stir, because salt dissolves mud | d: Shake it hard, because the mud will dissolve)
    - [mcq] `cpE.3`: What should a good report include? — Correct: d (a: Only the final answer, written neatly in your book | b: A list of the materials and where we bought them | c: A guess about the result that was never tested | d: A diagram, a table, a conclusion and why the method works)
    - [mcq] `cpE.4`: Why do we record what we observe during the activity? — Correct: a (a: So that we can check and explain the results | b: So that the mixture separates faster | c: So that the teacher can do the work | d: Because records change the result)

## Slide 26: `s26` — Recap: Mixtures and Separation
- **Learning Objective / Purpose**: Recap.
- **Indicators**: B8.1.1.1.1, B8.1.1.1.2
- **On-Screen Educational Text**:
  - Mixtures can be homogeneous or heterogeneous
  - Solution, suspension and colloid differ
  - Choose a method to fit the difference
- **Key Ideas**: A mixture can be homogeneous or heterogeneous. | The Tyndall effect helps tell a colloid from a solution and a suspension. | Find the difference, then choose the separation method.
- **Complete Narration Text**: Let us recap. A mixture has two or more substances physically combined, and each keeps its identity. It can be homogeneous or heterogeneous, depending on whether its composition is uniform. A solution, a suspension and a colloid are three kinds of mixture, and the Tyndall effect helps tell them apart. To separate a mixture, find a difference, then choose sieving, filtration, decantation, evaporation, crystallisation or distillation. Always work safely.
- **Audio Asset Reference**: `audio/s26.0ce100bc5210.mp3` (28s, source: tts)
- **Visual Type**: `svg` · **Description**: A top box, mixtures, with arrows to two columns: types, with homogeneous, heterogeneous and three kinds; and separation, with find a difference, choose a method and work safely.
- **Image Asset Reference**: `None` · **Alt Text**: A top box, mixtures, with arrows to two columns: types, with homogeneous, heterogeneous and three kinds; and separation, with find a difference, choose a method and work safely.
- **Visual Labels**: Mixtures, Types, Separation, Homogeneous, Heterogeneous, Three kinds, Find a difference, Choose a method, Work safely
- **SVG Content**: Present (2853 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Final slide before the mastery check.
- **Existing Checkpoints After This Slide**: None

## End-of-Lesson Mastery Check (Pass Mark: 4)
- [mcq] `mastery.1`: Salt and sand are mixed together. Which plan recovers both, and why does it work? — Correct: b (a: Sieve the mixture, because salt and sand are both solids of the same size | b: Dissolve the salt, filter out the sand, then evaporate the filtrate to recover the salt | c: Filter the dry mixture, then evaporate the sand to leave the salt | d: Dissolve the salt, filter out the sand, then filter the filtrate again to recover the salt)
- [mcq] `mastery.2`: Sugar is stirred into water until the liquid is clear. Which statement is true? — Correct: c (a: Sugar is the solvent and water is the solute | b: Both sugar and water are solutes | c: Sugar is the solute and water is the solvent | d: Both sugar and water are solvents)
- [mcq] `mastery.3`: Diluted milk does not settle quickly, passes through ordinary filter paper and scatters a torch beam. Which kind of mixture is it most likely to be? — Correct: d (a: A solution | b: A suspension | c: A pure liquid | d: A colloid)
- [mcq] `mastery.4`: Salt water is boiled and the vapour is condensed to collect the distillate. Which method is this? — Correct: a (a: Distillation | b: Filtration | c: Sieving | d: Decantation)
- [mcq] `mastery.5`: Why is salt left behind at the salt pans? — Correct: d (a: The salt turns to vapour too | b: The sun filters the salt out | c: The salt floats and is skimmed off | d: Only the water evaporates)
