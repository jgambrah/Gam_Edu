# 12 — Curriculum Source References (Actually Recorded in Live CDN Lessons)

Zero indicator codes or syllabus references have been invented. Every entry below is extracted directly from the live CDN lesson JSONs.

## A-Level Chemistry (Cambridge International AS & A Level)
- `a-level-chem-halogenoalkanes` — **Halogenoalkanes (Cambridge International AS & A Level Chemistry)**: `contentStandard`: `Halogenoalkanes (syllabus code to be confirmed)`, `indicators`: `HAL.1, HAL.2, HAL.3, HAL.4, HAL.5, HAL.6, HAL.7`
- `cambridge-as-a-level-chemistry-hydrocarbons` — **Hydrocarbons: Alkanes and Alkenes (Cambridge International AS & A Level Chemistry)**: `contentStandard`: `Cambridge International AS & A Level Chemistry 9701 (2025–2027 syllabus), Coursebook Chapter 15`, `indicators`: `H15.1, H15.2, H15.3, H15.4, H15.5, H15.6, H15.7, H15.8, H15.9, H15.10, H15.11, H15.12, H15.13, H15.14`

## JHS Science (NaCCA Basic 7 & Basic 8 — All 34 Seeded Lessons)
- `bs7-sci-t1-water-cycle` (Basic 7, T1) — **The Water Cycle**: `contentStandard`: `B7.2.1.1`, `indicators`: `B7.2.1.1.1; B7.2.1.1.2`
- `b7-sci-t1-materials-states-periodic-table` (Basic 7, T1) — **Materials, States of Matter and the Periodic Table**: `contentStandard`: `B7.1.1.1; B7.1.1.2`, `indicators`: `B7.1.1.1.1; B7.1.1.1.2; B7.1.1.1.3; B7.1.1.2.1`
- `b7-sci-t1-living-cells` (Basic 7, T1) — **Living Cells: Animal and Plant Cells**: `contentStandard`: `B7.1.2.1`, `indicators`: `B7.1.2.1.1; B7.1.2.1.2`
- `b8-sci-t1-animal-feed-and-water` (Basic 8, T1) — **Animal Production: Feed and Water for Growth**: `contentStandard`: `B8.2.4.1; B8.2.4.2`, `indicators`: `B8.2.4.1.1; B8.2.4.2.1`
- `b7-sci-t2-cycles-earth-science` (Basic 7, T2) — **The Water Cycle**: `contentStandard`: `B7.2.1.1`, `indicators`: `B7.2.1.1.1; B7.2.1.1.2`
- `b7-sci-t2-cycles-life-cycle-housefly` (Basic 7, T2) — **Cycles: Life Cycle of Organisms (The Housefly)**: `contentStandard`: `B7.2.2.1`, `indicators`: `B7.2.2.1.1; B7.2.2.1.2`
- `b7-sci-t2-cycles-crop-production` (Basic 7, T2) — **Cycles: Crop Production (Plant Nutrients and Fertilisers)**: `contentStandard`: `B7.2.3.1`, `indicators`: `B7.2.3.1.1; B7.2.3.1.2`
- `b7-sci-t2-cycles-animal-production` (Basic 7, T2) — **Cycles: Animal Production (Domestic Animals and Their Uses)**: `contentStandard`: `B7.2.4.1; B7.2.4.2`, `indicators`: `B7.2.4.1.1; B7.2.4.1.2; B7.2.4.2.1; B7.2.4.2.2`
- `b7-sci-t3-systems-human-body` (Basic 7, T3) — **Systems: The Human Body System (Food and Digestion)**: `contentStandard`: `B7.3.1.1`, `indicators`: `B7.3.1.1.1; B7.3.1.1.2; B7.3.1.1.3`
- `b7-sci-t3-systems-solar-system` (Basic 7, T3) — **Systems: The Solar System (Inner Planets, Mercury and Venus)**: `contentStandard`: `B7.3.2.1`, `indicators`: `B7.3.2.1.1; B7.3.2.1.2`
- `b7-sci-t3-systems-farming-systems` (Basic 7, T3) — **Systems: Farming Systems (Five Systems Used in Ghana)**: `contentStandard`: `B7.3.4.1`, `indicators`: `B7.3.4.1.1; B7.3.4.1.2; B7.3.4.1.3`
- `b7-sci-t4-energy-forms-and-mechanical` (Basic 7, T3) — **Forces and Energy: Energy (Forms, Uses and Mechanical Energy)**: `contentStandard`: `B7.4.1.1`, `indicators`: `B7.4.1.1.1; B7.4.1.1.2`
- `b7-sci-t4-energy-heat-and-light` (Basic 7, T3) — **Forces and Energy: Energy (Heat and Light)**: `contentStandard`: `B7.4.1.2, B7.4.1.3`, `indicators`: `B7.4.1.2.1; B7.4.1.3.1`
- `b7-sci-t4-electricity-generation-and-environment` (Basic 7, T3) — **Forces and Energy: Electricity and Electronics (Generation and the Environment)**: `contentStandard`: `B7.4.2.1`, `indicators`: `B7.4.2.1.1; B7.4.2.1.2`
- `b7-sci-t4-electronic-components-and-circuits` (Basic 7, T3) — **Forces and Energy: Electricity and Electronics (Electronic Components and Circuits)**: `contentStandard`: `B7.4.2.2`, `indicators`: `B7.4.2.2.1; B7.4.2.2.2; B7.4.2.2.3`
- `b7-sci-t4-conversion-and-conservation-of-energy` (Basic 7, T3) — **Forces and Energy: Conversion and Conservation of Energy**: `contentStandard`: `B7.4.3.1`, `indicators`: `B7.4.3.1.1; B7.4.3.1.2; B7.4.3.1.3`
- `b7-sci-t4-forces-magnets-and-newtons-first-law` (Basic 7, T3) — **Forces and Energy: Force and Motion (Forces, Newton's First Law and Magnets)**: `contentStandard`: `B7.4.4.1`, `indicators`: `B7.4.4.1.1; B7.4.4.1.2; B7.4.4.1.3; B7.4.4.1.4`
- `b7-sci-t4-simple-machines-and-efficiency` (Basic 7, T3) — **Forces and Energy: Force and Motion (Simple Machines, Levers and Efficiency)**: `contentStandard`: `B7.4.4.2`, `indicators`: `B7.4.4.2.1; B7.4.4.2.2; B7.4.4.2.3`
- `b7-sci-t4-agricultural-tools-handling-and-maintenance` (Basic 7, T3) — **Forces and Energy: Agricultural Tools (Handling and Maintenance of Simple Tools)**: `contentStandard`: `B7.4.5.1`, `indicators`: `B7.4.5.1.1; B7.4.5.1.2`
- `b7-sci-t5-waste-management` (Basic 7, T3) — **Humans and the Environment: Waste Management (Types of Waste and Good Management Practices)**: `contentStandard`: `B7.5.1.1`, `indicators`: `B7.5.1.1.1`
- `b7-sci-t5-nutrients-and-deficiency-diseases` (Basic 7, T3) — **Humans and the Environment: Human Health (Nutrients and Deficiency Diseases)**: `contentStandard`: `B7.5.2.1`, `indicators`: `B7.5.2.1.1`
- `b7-sci-t5-viral-diseases` (Basic 7, T3) — **Humans and the Environment: Human Health (Viral Diseases: COVID-19, Ebola and H1N1)**: `contentStandard`: `B7.5.2.2`, `indicators`: `B7.5.2.2.1`
- `b7-sci-t5-science-careers-and-scientists` (Basic 7, T3) — **Humans and the Environment: Science and Industry (Careers in Science and Great Scientists)**: `contentStandard`: `B7.5.3.1`, `indicators`: `B7.5.3.1.1`
- `b7-sci-t5-climate-change-and-sustainable-energy` (Basic 7, T3) — **Humans and the Environment: Climate Change and Green Economy (Greenhouse Effect and Sustainable Energy)**: `contentStandard`: `B7.5.4.1`, `indicators`: `B7.5.4.1.1`
- `b7-sci-t5-landforms-plants-and-animals` (Basic 7, T3) — **Humans and the Environment: Understanding the Environment (Plants and Animals of Ghana's Landforms)**: `contentStandard`: `B7.5.5.1`, `indicators`: `B7.5.5.1.1`
- `b7-sci-t5-associations-among-plants-and-animals` (Basic 7, T3) — **Humans and the Environment: Understanding the Environment (Associations among Plants and Animals)**: `contentStandard`: `B7.5.5.1`, `indicators`: `B7.5.5.1.2`
- `b7-sci-t1-materials-solids-liquids-gases` (Basic 7, T1) — **Diversity of Matter: Materials (Solids, Liquids and Gases)**: `contentStandard`: `B7.1.1.1`, `indicators`: `B7.1.1.1.1; B7.1.1.1.2; B7.1.1.1.3`
- `b7-sci-t3-systems-ecosystem` (Basic 7, T3) — **Systems: Ecosystem (Components and Interactions)**: `contentStandard`: `B7.3.3.1`, `indicators`: `B7.3.3.1.1`
- `b8-sci-t1-mixtures-and-separation` (Basic 8, T1) — **Diversity of Matter: Materials (Mixtures, Solutions and Their Separation)**: `contentStandard`: `B8.1.1.1`, `indicators`: `B8.1.1.1.1; B8.1.1.1.2`
- `b8-sci-t1-atoms-and-the-periodic-table` (Basic 8, T1) — **Diversity of Matter: Atoms and the Periodic Table**: `contentStandard`: `B8.1.1.2`, `indicators`: `B8.1.1.2.1; B8.1.1.2.2`
- `b8-sci-t1-cells-prokaryotic-and-eukaryotic` (Basic 8, T1) — **Diversity of Matter: Living Cells (Prokaryotic and Eukaryotic Cells)**: `contentStandard`: `B8.1.2.1`, `indicators`: `B8.1.2.1.1; B8.1.2.1.2`
- `b8-sci-t1-the-carbon-cycle` (Basic 8, T1) — **Cycles: The Carbon Cycle**: `contentStandard`: `B8.2.1.1`, `indicators`: `B8.2.1.1.1; B8.2.1.1.2`
- `b8-sci-t1-the-anopheles-mosquito-life-cycle` (Basic 8, T1) — **Cycles: The Anopheles Mosquito Life Cycle**: `contentStandard`: `B8.2.2.1`, `indicators`: `B8.2.2.1.1; B8.2.2.1.2`
- `b8-sci-t1-seed-beds-and-planting-crops` (Basic 8, T1) — **Cycles: Seed Beds and Planting Crops**: `contentStandard`: `B8.2.3.1`, `indicators`: `B8.2.3.1.1; B8.2.3.1.2`
