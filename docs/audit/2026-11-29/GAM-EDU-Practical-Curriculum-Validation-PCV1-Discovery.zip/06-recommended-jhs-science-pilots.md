# 06 — Recommended Representative JHS Science Pilot Lessons (6 Lessons: 3 Basic 7 + 3 Basic 8)

> **Important Catalogue Fact**: The live CDN catalogue (`catalogueVersion: 96`) contains **27 Basic 7** Science lessons, **7 Basic 8** Science lessons, and **0 Basic 9** Science lessons (total 34 genuinely seeded JHS Science lessons). Preview fixtures in `public/preview-fixtures/` are strictly separate dev-only engine test fixtures and are NOT counted as seeded lessons.

## Diversity of Matter: Atoms and the Periodic Table (`b8-sci-t1-atoms-and-the-periodic-table`) — Chemistry (Basic 8)
- **Class / Term**: Basic 8, Term 1 · **Slides**: 26 · **Published Hash**: `15080192a16a`
- **Why suitable**: Strong 26-slide narration + notes pack covering atomic structure, Bohr shells, periodic groups/periods, and ions — directly enhanced by concrete Bohr atom building rather than passive diagrams.
- **Proposed existing engines**: `construction-lab (atom-bond-builder 1.2.0 LIVE)`, `diagram-hotspots (1.0.0 LIVE)`, `sort-classify (1.0.0 DEV)`
- **Concepts to make interactive**: Protons/neutrons/electrons, electron shell filling (2,8,8), atomic vs mass number, ion formation, metals vs non-metals.
- **Practical student activities**: Build Boron/Carbon/Sodium/Chlorine atoms & ions in Atom-Bond Lab; classify first 20 elements by family.
- **Known limitations**: Atom-Bond Lab is bounded to Z = 1..20 (an exact match for JHS NaCCA B8!); `sort-classify` requires production activation.

## Forces and Energy: Electricity and Electronics (Electronic Components and Circuits) (`b7-sci-t4-electronic-components-and-circuits`) — Physics (Basic 7)
- **Class / Term**: Basic 7, Term 3 · **Slides**: 25 · **Published Hash**: `42ac37a6f2f1`
- **Why suitable**: 25 slides + 3 illustrations + 22 SVGs + notes pack teaching LEDs, resistors, switches, batteries, and series/parallel circuits — ideal for authentic DC circuit construction.
- **Proposed existing engines**: `construction-lab (electrical-circuit 1.1.0 LIVE)`, `diagram-hotspots (1.0.0 LIVE)`, `rule-explorer (1.0.0 LIVE)`, `sort-classify (1.0.0 DEV)`
- **Concepts to make interactive**: Closed vs open circuits, LED polarity, current-limiting resistors, switches, series vs parallel paths.
- **Practical student activities**: Construct a working LED + resistor + switch circuit; predict what happens when LED polarity is reversed.
- **Known limitations**: Bounded DC topologies only (no AC/oscilloscope, not needed for B7).

## Living Cells: Animal and Plant Cells (`b7-sci-t1-living-cells`) — Biology (Basic 7)
- **Class / Term**: Basic 7, Term 1 · **Slides**: 27 · **Published Hash**: `ad64775a290c`
- **Why suitable**: 27 slides with 6 rich illustrations + 21 SVGs covering animal vs plant cells and organelles — perfect for interactive organelle exploration and overlapping-set classification.
- **Proposed existing engines**: `diagram-hotspots (1.0.0 LIVE)`, `process-stepper (1.0.0 LIVE)`, `sort-classify (1.0.0 DEV)`
- **Concepts to make interactive**: Cell membrane, cytoplasm, nucleus, mitochondria, cell wall, chloroplast, permanent vacuole, specialised cells.
- **Practical student activities**: Identify organelles by function on interactive plant/animal cell diagrams; sort organelles into Animal-only, Plant-only, or Both.
- **Known limitations**: `sort-classify` requires production activation for the overlapping-set Venn/bucket activity; `diagram-hotspots` is already LIVE.

## Cycles: The Carbon Cycle (`b8-sci-t1-the-carbon-cycle`) — Earth & Environmental Science (Basic 8)
- **Class / Term**: Basic 8, Term 1 · **Slides**: 26 · **Published Hash**: `39cb3b2ba786`
- **Why suitable**: 26 slides + notes pack linking photosynthesis, respiration, combustion, decomposition, and climate change — directly strengthened by dynamic process stepping and source/sink balance.
- **Proposed existing engines**: `process-stepper (1.0.0 LIVE)`, `graph-slider (1.0.0 LIVE)`, `construction-lab (equation-balancer 1.1.0 LIVE)`, `sort-classify (1.0.0 DEV)`
- **Concepts to make interactive**: Carbon reservoirs, photosynthesis vs respiration equations, fossil fuel combustion, greenhouse balance.
- **Practical student activities**: Step through carbon transfers with live atmospheric CO2 state; balance photosynthesis equation; adjust emission vs reforestation sliders.
- **Known limitations**: Carbon balance graph uses a bounded pedagogical model (clearly labelled as an educational model).

## Forces and Energy: Force and Motion (Simple Machines, Levers and Efficiency) (`b7-sci-t4-simple-machines-and-efficiency`) — Physics, Scientific Measurement & Quantitative Reasoning (Basic 7)
- **Class / Term**: Basic 7, Term 3 · **Slides**: 25 · **Published Hash**: `d0f1bf3db8d2`
- **Why suitable**: 25 slides + 3 illustrations + notes pack covering levers, Mechanical Advantage, Velocity Ratio, Work Done, and Efficiency — ideal for testing quantitative math, sliders, and measurement.
- **Proposed existing engines**: `graph-slider (1.0.0 LIVE)`, `math-evaluator (1.1.0 LIVE)`, `construction-lab (measurement-lab 1.4.0 DEV)`, `sort-classify (1.0.0 DEV)`
- **Concepts to make interactive**: 1st/2nd/3rd class levers, MA = Load/Effort, VR, Efficiency = (Work out/Work in) × 100%, friction losses.
- **Practical student activities**: Adjust fulcrum/effort sliders to explore MA; solve efficiency calculations with SI units (N, J, %); read ruler/force scale.
- **Known limitations**: `measurement-lab` (1.4.0) requires activation before live publish; full rigid-body physics simulation awaits Step 5G.

## Diversity of Matter: Materials (Mixtures, Solutions and Their Separation) (`b8-sci-t1-mixtures-and-separation`) — Chemistry, Practical Investigation & Measurement (Basic 8)
- **Class / Term**: Basic 8, Term 1 · **Slides**: 26 · **Published Hash**: `536fa4b65774`
- **Why suitable**: 26 slides + 3 illustrations + notes pack teaching filtration, evaporation, distillation, chromatography, and magnetic separation — tests procedural experimental reasoning and lab measurement.
- **Proposed existing engines**: `process-stepper (1.0.0 LIVE)`, `diagram-hotspots (1.0.0 LIVE)`, `construction-lab (measurement-lab 1.4.0 DEV)`, `sort-classify (1.0.0 DEV)`
- **Concepts to make interactive**: Homogeneous vs heterogeneous mixtures, selecting separation techniques by physical property, boiling point & meniscus reading.
- **Practical student activities**: Step through distillation & filtration apparatus; read thermometer boiling point & measuring cylinder meniscus; match mixtures to methods.
- **Known limitations**: `measurement-lab` (1.4.0) and `sort-classify` (1.0.0) are dev-only until activated; `process-stepper` and `diagram-hotspots` are LIVE.
