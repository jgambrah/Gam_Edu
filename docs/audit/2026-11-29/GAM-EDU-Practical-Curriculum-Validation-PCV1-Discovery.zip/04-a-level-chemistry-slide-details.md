# 04 — Complete A-Level Chemistry Slide-by-Slide Inventory (105 Slides)

# Halogenoalkanes (Cambridge International AS & A Level Chemistry) (`a-level-chem-halogenoalkanes`)

- **CDN packagePath**: `packages/a-level-chem-halogenoalkanes.30c94f3bca64.json` (hash `30c94f3bca64`, updated `2026-11-24T15:40:34.915Z`)
- **Curriculum**: cambridge · **Class**: A Level · **Subject**: Chemistry · **Term**: 1
- **Content Standard**: Halogenoalkanes (syllabus code to be confirmed)
- **Indicators**: HAL.1, HAL.2, HAL.3, HAL.4, HAL.5, HAL.6, HAL.7
- **Total Slides**: 34 · **Checkpoints**: 17 · **Mastery Check Items**: 8

## Slide 1: `s01` — Same Atoms, Good and Bad
- **Learning Objective / Purpose**: Hook: halogenoalkanes help and harm.
- **Indicators**: HAL.1, HAL.7
- **On-Screen Educational Text**:
  - Halogenoalkanes: useful compounds
  - They helped medicine and cooling
  - They also damaged the ozone layer
- **Key Ideas**: Halogenoalkanes have many uses. | Some uses caused environmental harm. | We will learn why they react as they do.
- **Complete Narration Text**: Welcome to this lesson on halogenoalkanes. One family of compounds is behind a surprising story. Doctors have used one of them, halothane, as an anaesthetic to put patients to sleep for surgery. Others kept refrigerators cold and powered aerosol cans. Then scientists discovered that some of them were damaging the ozone layer. To understand why, we need to learn how these molecules are built, why they react, and how their reactions work, step by step.
- **Audio Asset Reference**: `audio/s01.bceafa987a4f.mp3` (33s, source: tts)
- **Visual Type**: `illustration` · **Description**: A modern, well-equipped school chemistry laboratory in Accra. A teacher in a lab coat stands by a fume cupboard where a flask is heated under reflux with a vertical condenser. Three Year 12 students in neat uniforms and safety goggles watch and take notes. A large window shows the Accra skyline.
- **Image Asset Reference**: `images/s01.92a82dc47208.webp` · **Alt Text**: A modern, well-equipped school chemistry laboratory in Accra. A teacher in a lab coat stands by a fume cupboard where a flask is heated under reflux with a vertical condenser. Three Year 12 students in neat uniforms and safety goggles watch and take notes. A large window shows the Accra skyline.
- **Visual Labels**: None
- **SVG Content**: None
- **Existing Interactive Configuration**: None
- **Teacher Note**: Hook slide. Cambridge A Level Chemistry (9701) halogen compounds topic. The illustration is a lab scene with no text.
- **Existing Checkpoints After This Slide**: None

## Slide 2: `s02` — What Is a Halogenoalkane?
- **Learning Objective / Purpose**: Define halogenoalkanes (HAL.1).
- **Indicators**: HAL.1
- **On-Screen Educational Text**:
  - Alkane with H replaced by halogen
  - General formula CₙH₂ₙ₊₁X
  - X is F, Cl, Br or I
- **Key Ideas**: A halogen atom replaces a hydrogen atom. | One halogen: general formula CnH2n+1X. | The C–X bond makes the molecule reactive.
- **Complete Narration Text**: A halogenoalkane is an alkane in which one or more hydrogen atoms have been replaced by halogen atoms. The halogens are fluorine, chlorine, bromine and iodine, from Group 17. If only one hydrogen is replaced, the general formula is C n H 2 n plus 1 X, where X stands for the halogen. Ethane becomes chloroethane when one hydrogen is replaced by chlorine. The halogen atom changes the reactivity of the molecule greatly, compared with the alkane.
- **Audio Asset Reference**: `audio/s02.15092698a9fd.mp3` (33s, source: tts)
- **Visual Type**: `svg` · **Description**: What Is a Halogenoalkane?: Alkane + halogen replaces H; CₙH₂ₙ₊₁X; X = F, Cl, Br, I; Halogens are in Group 17; The C–X bond makes them reactive.
- **Image Asset Reference**: `None` · **Alt Text**: What Is a Halogenoalkane?: Alkane + halogen replaces H; CₙH₂ₙ₊₁X; X = F, Cl, Br, I; Halogens are in Group 17; The C–X bond makes them reactive.
- **Visual Labels**: Halogenoalkane, Alkane + halogen replaces H, CₙH₂ₙ₊₁X, X = F, Cl, Br, I, Halogens are in Group 17, The C–X bond makes them reactive
- **SVG Content**: Present (1751 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [CONTEXT] Many CFCs and similar compounds are very unreactive under normal conditions because of strong C–F bonds; this is covered in the uses section.
- **Existing Checkpoints After This Slide**: None

## Slide 3: `s03` — Naming Halogenoalkanes
- **Learning Objective / Purpose**: Name simple halogenoalkanes (HAL.1).
- **Indicators**: HAL.1
- **On-Screen Educational Text**:
  - Prefix: fluoro, chloro, bromo, iodo
  - Number the longest carbon chain
  - List prefixes in alphabetical order
- **Key Ideas**: Halogen is a prefix before the stem. | Lowest numbers for the substituents. | Alphabetical order for different prefixes.
- **Complete Narration Text**: To name a halogenoalkane, find the longest carbon chain and use the alkane name as the stem. The halogen is a prefix: fluoro, chloro, bromo or iodo. Number the chain so that the substituents get the lowest possible numbers. Use di, tri or tetra for repeats, and list different prefixes in alphabetical order. So the compound with one chlorine on the end carbon of a three-carbon chain is 1-chloropropane, and the compound with bromine on the middle carbon of a three-carbon chain is 2-bromopropane. The anaesthetic halothane is 2-bromo-2-chloro-1,1,1-trifluoroethane.
- **Audio Asset Reference**: `audio/s03.d6e3f9c11a4a.mp3` (39s, source: tts)
- **Visual Type**: `svg` · **Description**: Naming Halogenoalkanes: Structure; Name; CH₃CH₂Br; bromoethane; CH₃CH₂CH₂Cl; 1-chloropropane; CH₃CHBrCH₃; 2-bromopropane; (CH₃)₃CBr; 2-bromo-2-methylpropane; CF₃CHBrCl; halothane.
- **Image Asset Reference**: `None` · **Alt Text**: Naming Halogenoalkanes: Structure; Name; CH₃CH₂Br; bromoethane; CH₃CH₂CH₂Cl; 1-chloropropane; CH₃CHBrCH₃; 2-bromopropane; (CH₃)₃CBr; 2-bromo-2-methylpropane; CF₃CHBrCl; halothane.
- **Visual Labels**: Naming examples, Structure, Name, CH₃CH₂Br, bromoethane, CH₃CH₂CH₂Cl, 1-chloropropane, CH₃CHBrCH₃, 2-bromopropane, (CH₃)₃CBr, 2-bromo-2-methylpropane, CF₃CHBrCl, halothane
- **SVG Content**: Present (3495 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Practise naming with the structures on the slide, then with structures chosen by the teacher. Halothane is CF₃CHBrCl, 2-bromo-2-chloro-1,1,1-trifluoroethane; the full name is spoken in the narration, not shown, because it is too long for the table.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcA1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qA.1`: What is the general formula of a halogenoalkane with one halogen atom? — Correct: b (a: CₙHₙX | b: CₙH₂ₙ₊₁X | c: CₙH₂ₙ₊₂ | d: CₙH₂ₙX)

## Slide 4: `s04` — Primary, Secondary, Tertiary
- **Learning Objective / Purpose**: Classify halogenoalkanes (HAL.1).
- **Indicators**: HAL.1, HAL.5
- **On-Screen Educational Text**:
  - Count alkyl groups on the C–X carbon
  - Methyl halide: no alkyl group
  - 1 primary, 2 secondary, 3 tertiary
- **Key Ideas**: Look at the carbon bonded to the halogen. | Count the alkyl groups on that carbon. | Methyl halides have none.
- **Complete Narration Text**: We classify a halogenoalkane by looking only at the carbon atom that carries the halogen. Count the alkyl groups attached to that carbon. A methyl halide, such as bromomethane, has no alkyl group on that carbon, only hydrogen atoms, so we keep it separate. One alkyl group makes the compound primary, as in 1-chloropropane. Two make it secondary, as in 2-bromopropane. Three make it tertiary, as in 2-bromo-2-methylpropane. A common examination mistake is to count all the carbon atoms in the molecule instead of the alkyl groups on the carbon bonded to the halogen. The class helps us predict the usual mechanism later in this lesson.
- **Audio Asset Reference**: `audio/s04.fb2637683a12.mp3` (46s, source: tts)
- **Visual Type**: `svg` · **Description**: Primary, Secondary, Tertiary: Type; Alkyl groups; Example; Methyl; 0; CH₃Br; Primary; 1; CH₃CH₂CH₂Cl; Secondary; 2; CH₃CHBrCH₃; Tertiary; 3; (CH₃)₃CBr.
- **Image Asset Reference**: `None` · **Alt Text**: Primary, Secondary, Tertiary: Type; Alkyl groups; Example; Methyl; 0; CH₃Br; Primary; 1; CH₃CH₂CH₂Cl; Secondary; 2; CH₃CHBrCH₃; Tertiary; 3; (CH₃)₃CBr.
- **Visual Labels**: Classifying halogenoalkanes, Type, Alkyl groups, Example, Methyl, 0, CH₃Br, Primary, 1, CH₃CH₂CH₂Cl, Secondary, 2, CH₃CHBrCH₃, Tertiary, 3, (CH₃)₃CBr
- **SVG Content**: Present (4218 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [CONTEXT: methyl halide grouping] Methyl halides are kept separate here; some textbooks group them with primary compounds, so follow the school's convention. The syllabus outcome asks for classification as primary, secondary or tertiary. The Cambridge syllabus edition and examination year still need to be confirmed by the teacher.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpA` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `cpA.4`: Which statement about bromomethane, CH₃Br, is correct? — Correct: d (a: It is tertiary | b: It is secondary | c: It has three alkyl groups because it has three hydrogens | d: Its C–Br carbon has no alkyl group, so it is a methyl halide)
    - [mcq] `cpA.1`: What is the name of CH₃CH₂CH₂Br? — Correct: d (a: 2-bromopropane | b: 1-bromobutane | c: bromoethane | d: 1-bromopropane)
    - [mcq] `cpA.2`: How is 2-bromo-2-methylpropane classified? — Correct: d (a: Primary | b: Quaternary | c: Secondary | d: Tertiary)
    - [mcq] `cpA.3`: Which of these is a secondary halogenoalkane? — Correct: b (a: CH₃CH₂CH₂CH₂Br | b: CH₃CHBrCH₃ | c: (CH₃)₃CBr | d: CH₃CH₂CH₂Br)

## Slide 5: `s05` — Making Them: Alkanes
- **Learning Objective / Purpose**: Free-radical substitution of alkanes (HAL.2).
- **Indicators**: HAL.2
- **On-Screen Educational Text**:
  - Alkane + Cl₂ or Br₂
  - Ultraviolet light is needed
  - Gives a mixture of products
- **Key Ideas**: Alkane + Cl2 or Br2, with UV light. | Hydrogen halide is the other product. | It gives a mixture of products.
- **Complete Narration Text**: There are three main ways to make halogenoalkanes. Start with an alkane such as ethane. The reagent is chlorine or bromine, with no solvent, and the condition is ultraviolet light, which supplies the energy to split the halogen molecule into free radicals. One hydrogen atom is replaced by one halogen atom, so ethane and chlorine give chloroethane and hydrogen chloride. The weakness is that it is difficult to control. Once one hydrogen is replaced, others can be replaced too, so we get a mixture of products. A common examination mistake is to leave out ultraviolet light, or to present this as a clean laboratory route.
- **Audio Asset Reference**: `audio/s05.11f547d582a9.mp3` (46s, source: tts)
- **Visual Type**: `svg` · **Description**: Making Them: Alkanes: C₂H₆ + Cl₂ → C₂H₅Cl + HCl; Conditions: ultraviolet light; HCl is the other product; Further substitution gives a mixture.
- **Image Asset Reference**: `None` · **Alt Text**: Making Them: Alkanes: C₂H₆ + Cl₂ → C₂H₅Cl + HCl; Conditions: ultraviolet light; HCl is the other product; Further substitution gives a mixture.
- **Visual Labels**: Free-radical substitution, C₂H₆ + Cl₂ → C₂H₅Cl + HCl, Conditions: ultraviolet light, HCl is the other product, Further substitution gives a mixture
- **SVG Content**: Present (1535 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Cross-reference to the hydrocarbons chapter for initiation, propagation and termination. Not repeated here.
- **Existing Checkpoints After This Slide**: None

## Slide 6: `s06` — Making Them: Alkenes
- **Learning Objective / Purpose**: Electrophilic addition to alkenes (HAL.2).
- **Indicators**: HAL.2
- **On-Screen Educational Text**:
  - Alkene + Br₂ or HBr(g)
  - Room temperature
  - Ethene: one addition product
- **Key Ideas**: Alkene + halogen or hydrogen halide. | Room temperature, no heating. | Symmetrical alkene gives one product.
- **Complete Narration Text**: The second route is electrophilic addition to an alkene. Start with ethene. The reagent is bromine, or hydrogen bromide gas, and no heating is needed, because the electron-rich double bond is easily attacked by the electrophile. The double bond opens and atoms add on. Ethene and bromine give 1,2-dibromoethane, and ethene and hydrogen bromide give bromoethane. Ethene is symmetrical, so with these reagents only one addition product is possible. With an unsymmetrical alkene such as propene, hydrogen bromide can add in two ways, giving two different products, and one is usually the major product. The syllabus asks mainly for the reagents and conditions, so treat the major-product rule as enrichment. A common examination mistake is to leave out the state symbol, because the syllabus writes the hydrogen halide as a gas.
- **Audio Asset Reference**: `audio/s06.61cef7a9a32d.mp3` (57s, source: tts)
- **Visual Type**: `svg` · **Description**: Making Them: Alkenes: C₂H₄ + Br₂ → CH₂BrCH₂Br; C₂H₄ + HBr → C₂H₅Br; Reagents X₂ or HX(g), room temperature; Unsymmetrical alkenes: two products possible.
- **Image Asset Reference**: `None` · **Alt Text**: Making Them: Alkenes: C₂H₄ + Br₂ → CH₂BrCH₂Br; C₂H₄ + HBr → C₂H₅Br; Reagents X₂ or HX(g), room temperature; Unsymmetrical alkenes: two products possible.
- **Visual Labels**: Electrophilic addition, C₂H₄ + Br₂ → CH₂BrCH₂Br, C₂H₄ + HBr → C₂H₅Br, Reagents X₂ or HX(g), room temperature, Unsymmetrical alkenes: two products possible
- **SVG Content**: Present (1539 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [ENRICHMENT: propene/Markovnikov part] Do not teach that addition 'always gives one product'. The mechanism and the major-product (Markovnikov) rule belong to the hydrocarbons chapter; confirm with the school whether they are required at this point. [VERIFY]
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcB1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qB.1`: Ethene reacts with HBr(g) at room temperature to form bromoethane. What type of reaction is this? — Correct: c (a: Free-radical substitution | b: Elimination | c: Electrophilic addition | d: Nucleophilic substitution)

## Slide 7: `s07` — Making Them: Alcohols
- **Learning Objective / Purpose**: Substitution of an alcohol (HAL.2).
- **Indicators**: HAL.2
- **On-Screen Educational Text**:
  - Replace the –OH group of an alcohol
  - H₃PO₄ does not oxidise Br⁻ or I⁻
  - Teacher demonstration only
- **Key Ideas**: Alcohol + HX, PCl₅, PCl₃ or SOCl₂. | H₃PO₄ is not an oxidising acid. | Teacher demonstration only.
- **Complete Narration Text**: The third route replaces the OH group of an alcohol with a halogen. Start with an alcohol such as ethanol. One reagent is a hydrogen halide, made in the flask from a potassium halide and a concentrated acid. For hydrogen chloride you can use potassium chloride with concentrated sulfuric acid. Concentrated sulfuric acid is an oxidising agent. It oxidises iodide ions to iodine, and it partly oxidises bromide ions to bromine, so concentrated phosphoric acid, which is not oxidising, is used for hydrogen iodide, and is often used for hydrogen bromide too. The other reagents are phosphorus pentachloride at room temperature, phosphorus trichloride with heat, and thionyl chloride, which also reacts at room temperature. Thionyl chloride is convenient because its by-products, sulfur dioxide and hydrogen chloride, are both gases. These reagents are corrosive and give toxic fumes, so they are for teacher demonstration only. A common examination mistake is to treat the acid as only a catalyst: it is a reagent that generates the hydrogen halide.
- **Audio Asset Reference**: `audio/s07.796ed5dd638f.mp3` (72s, source: tts)
- **Visual Type**: `svg` · **Description**: Making Them: Alcohols: Reagent; Conditions; By-products; KCl, conc. H₂SO₄; varies; KHSO₄ + H₂O; KBr/KI, conc. H₃PO₄; heat; KH₂PO₄ + H₂O; PCl₅; room temp.; POCl₃ + HCl; PCl₃; heat; H₃PO₃; SOCl₂; room temp.; SO₂ + HCl.
- **Image Asset Reference**: `None` · **Alt Text**: Making Them: Alcohols: Reagent; Conditions; By-products; KCl, conc. H₂SO₄; varies; KHSO₄ + H₂O; KBr/KI, conc. H₃PO₄; heat; KH₂PO₄ + H₂O; PCl₅; room temp.; POCl₃ + HCl; PCl₃; heat; H₃PO₃; SOCl₂; room temp.; SO₂ + HCl.
- **Visual Labels**: From ethanol, C₂H₅OH, Reagent, Conditions, By-products, KCl, conc. H₂SO₄, varies, KHSO₄ + H₂O, KBr/KI, conc. H₃PO₄, heat, KH₂PO₄ + H₂O, PCl₅, room temp., POCl₃ + HCl, PCl₃, heat, H₃PO₃, SOCl₂, room temp., SO₂ + HCl
- **SVG Content**: Present (5013 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Syllabus (both 2025–2027 and 2028–2030 editions read) lists HX(g); KCl with concentrated H₂SO₄ or H₃PO₄; PCl₃ with heat; PCl₅; SOCl₂. The KBr/KI row with H₃PO₄ is enrichment. Equations cross-checked against Chemguide, LibreTexts and Doc Brown: 3ROH + PCl₃ → 3RCl + H₃PO₃; ROH + PCl₅ → RCl + POCl₃ + HCl; ROH + SOCl₂ → RCl + SO₂ + HCl; KCl + H₂SO₄ → KHSO₄ + HCl. The syllabus gives no conditions for the KCl route; sources differ, so the table says 'varies'. PCl₅ reacts violently with water and alcohols; SOCl₂ and PCl₅ are for teacher demonstration only.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpB` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `cpB.4`: Why is concentrated phosphoric acid, not concentrated sulfuric acid, used with KI to make HI? — Correct: c (a: Phosphoric acid is a stronger acid | b: Sulfuric acid does not react with KI | c: Sulfuric acid is an oxidising agent and oxidises iodide ions to iodine | d: Phosphoric acid acts as a catalyst only)
    - [mcq] `cpB.1`: What condition is needed for chlorine to substitute into an alkane? — Correct: b (a: Reflux with ethanol | b: Ultraviolet light | c: Aqueous sodium hydroxide | d: A nickel catalyst)
    - [mcq] `cpB.2`: Why is free-radical substitution a poor way to make one pure halogenoalkane? — Correct: a (a: More than one hydrogen can be replaced, giving a mixture | b: The reaction does not occur | c: The alkane is too reactive | d: Only fluorine will react)
    - [mcq] `cpB.3`: Which reagent turns an alcohol into a chloroalkane and gives only gaseous by-products? — Correct: b (a: NaCl alone | b: SOCl₂ | c: Cl₂ with UV light | d: PCl₃)

## Slide 8: `s08` — Why the C–X Bond Is Polar
- **Learning Objective / Purpose**: Bond polarity (HAL.3).
- **Indicators**: HAL.3
- **On-Screen Educational Text**:
  - Halogen is more electronegative
  - Carbon becomes δ+
  - δ+ carbon attracts nucleophiles
- **Key Ideas**: The halogen is more electronegative than carbon. | Carbon is δ+, the halogen is δ−. | The δ+ carbon is the site of attack.
- **Complete Narration Text**: In an alkane the bonds are almost non-polar. In a halogenoalkane, the halogen is more electronegative than carbon, so it pulls the bonding pair of electrons towards itself. The halogen becomes partially negative, delta minus, and the carbon becomes partially positive, delta plus. This delta plus carbon attracts species that donate electron pairs. Notice something odd, though. The carbon iodine bond is only slightly polar, yet iodoalkanes are the most reactive of the halogenoalkanes. We shall explain that shortly.
- **Audio Asset Reference**: `audio/s08.d36fd8278b88.mp3` (34s, source: tts)
- **Visual Type**: `svg` · **Description**: Why the C–X Bond Is Polar: C–X: Cδ+ and Xδ−; Halogen pulls the bonding pair; Cδ+ is attacked by nucleophiles; C–I is only slightly polar.
- **Image Asset Reference**: `None` · **Alt Text**: Why the C–X Bond Is Polar: C–X: Cδ+ and Xδ−; Halogen pulls the bonding pair; Cδ+ is attacked by nucleophiles; C–I is only slightly polar.
- **Visual Labels**: A polar C–X bond, C–X: Cδ+ and Xδ−, Halogen pulls the bonding pair, Cδ+ is attacked by nucleophiles, C–I is only slightly polar
- **SVG Content**: Present (1506 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Pauling electronegativities (approximate): C 2.6, F 4.0, Cl 3.2, Br 3.0, I 2.7. Used only to show that C–I is only slightly polar. Verify values against the school's data booklet.
- **Existing Checkpoints After This Slide**: None

## Slide 9: `s09` — What Is a Nucleophile?
- **Learning Objective / Purpose**: Define nucleophile (HAL.3).
- **Indicators**: HAL.3
- **On-Screen Educational Text**:
  - Nucleophile: electron-pair donor
  - It has a lone pair
  - Attracted to δ+ atoms
- **Key Ideas**: A nucleophile donates a lone pair. | Examples: OH⁻, CN⁻, NH₃, H₂O. | Curly arrows start at the lone pair.
- **Complete Narration Text**: A nucleophile is a species that donates a pair of electrons to form a new covalent bond. It must have a lone pair of electrons, and it is attracted to electron-deficient, delta plus, atoms. Some nucleophiles are negative ions, such as hydroxide and cyanide. Others are neutral molecules with a lone pair, such as ammonia and water. In mechanisms, a curly arrow shows the movement of a pair of electrons, and it starts from the lone pair of the nucleophile.
- **Audio Asset Reference**: `audio/s09.eaba22443fe5.mp3` (35s, source: tts)
- **Visual Type**: `svg` · **Description**: What Is a Nucleophile?: Donates a lone pair to a δ+ atom; OH⁻ (hydroxide); CN⁻ (cyanide); NH₃ (ammonia); H₂O (water); Nucleophiles can be negative or neutral.
- **Image Asset Reference**: `None` · **Alt Text**: What Is a Nucleophile?: Donates a lone pair to a δ+ atom; OH⁻ (hydroxide); CN⁻ (cyanide); NH₃ (ammonia); H₂O (water); Nucleophiles can be negative or neutral.
- **Visual Labels**: Nucleophiles, Donates a lone pair to a δ+ atom, OH⁻ (hydroxide), CN⁻ (cyanide), NH₃ (ammonia), H₂O (water), Nucleophiles can be negative or neutral
- **SVG Content**: Present (2008 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: The word nucleophile means nucleus-loving. Link to the earlier chapter where nucleophiles were first defined.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcC1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qC.1`: Which of these is a nucleophile? — Correct: d (a: AlCl₃ | b: H⁺ | c: CH₄ | d: NH₃)

## Slide 10: `s10` — Two Families of Reactions
- **Learning Objective / Purpose**: Preview substitution and elimination (HAL.3, HAL.6).
- **Indicators**: HAL.3, HAL.6
- **On-Screen Educational Text**:
  - Substitution: X replaced
  - Elimination: HX removed
  - Conditions decide which one
- **Key Ideas**: Substitution replaces the halogen. | Elimination removes HX to give an alkene. | Conditions decide which reaction occurs.
- **Complete Narration Text**: Halogenoalkanes can react in two main ways. In substitution, the halogen is replaced by another group, such as a hydroxyl, cyano or amino group. In elimination, a small molecule, hydrogen halide, is removed and an alkene forms. The same halogenoalkane can do either, so the conditions matter. We shall study substitution first, because it gives us most of the reactions, then the mechanisms, and then elimination. At the end we shall compare the conditions so that you can predict which reaction occurs.
- **Audio Asset Reference**: `audio/s10.58b2dc03a47d.mp3` (36s, source: tts)
- **Visual Type**: `svg` · **Description**: Two Families of Reactions: Substitution: X is replaced by Nu; Elimination: HX is removed, giving an alkene; Aqueous alkali favours substitution; Ethanolic alkali favours elimination.
- **Image Asset Reference**: `None` · **Alt Text**: Two Families of Reactions: Substitution: X is replaced by Nu; Elimination: HX is removed, giving an alkene; Aqueous alkali favours substitution; Ethanolic alkali favours elimination.
- **Visual Labels**: Two possible reactions, Substitution: X is replaced by Nu, Elimination: HX is removed, giving an alkene, Aqueous alkali favours substitution, Ethanolic alkali favours elimination
- **SVG Content**: Present (1563 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Preview slide only. Mechanisms and conditions are developed later.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpC` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `cpC.1`: In the C–Br bond, which atom is partially positive? — Correct: d (a: Bromine | b: Both are partly positive | c: Neither, the bond is non-polar | d: Carbon)
    - [mcq] `cpC.2`: What does a curly arrow show? — Correct: b (a: The movement of an atom | b: The movement of an electron pair | c: The direction of the reaction | d: The movement of a proton only)
    - [mcq] `cpC.3`: Which reaction removes HX from a halogenoalkane? — Correct: c (a: Substitution | b: Hydrolysis only | c: Elimination | d: Addition)

## Slide 11: `s11` — Substitution with Aqueous Alkali
- **Learning Objective / Purpose**: Hydrolysis with NaOH(aq) (HAL.3).
- **Indicators**: HAL.3
- **On-Screen Educational Text**:
  - NaOH(aq), heated under reflux
  - Halogen replaced by –OH
  - Product: an alcohol
- **Key Ideas**: OH⁻ replaces the halogen. | The product is an alcohol. | This reaction is called hydrolysis.
- **Complete Narration Text**: Start with a halogenoalkane such as bromoethane. The reagent is aqueous sodium hydroxide, so the solvent is water. We heat under reflux, because the reaction is slow at room temperature and the liquids are volatile. The hydroxide ion is the nucleophile. It replaces the bromine, so the carbon-bromine bond is replaced by a carbon-oxygen bond. The organic product is an alcohol, ethanol, and the bromide ion is released. A reaction in which water or hydroxide breaks a bond is called hydrolysis. A common examination mistake is to write sodium hydroxide without saying aqueous, because sodium hydroxide in ethanol causes a different reaction, which we meet later. The mechanism comes later in this lesson.
- **Audio Asset Reference**: `audio/s11.7ec2287cfba3.mp3` (49s, source: tts)
- **Visual Type**: `svg` · **Description**: Substitution with Aqueous Alkali: CH₃CH₂Br + NaOH → CH₃CH₂OH + NaBr; Ionic: CH₃CH₂Br + OH⁻ → CH₃CH₂OH + Br⁻; Reagent: NaOH(aq), heat under reflux; OH⁻ is the nucleophile.
- **Image Asset Reference**: `None` · **Alt Text**: Substitution with Aqueous Alkali: CH₃CH₂Br + NaOH → CH₃CH₂OH + NaBr; Ionic: CH₃CH₂Br + OH⁻ → CH₃CH₂OH + Br⁻; Reagent: NaOH(aq), heat under reflux; OH⁻ is the nucleophile.
- **Visual Labels**: Hydrolysis with OH⁻(aq), CH₃CH₂Br + NaOH → CH₃CH₂OH + NaBr, Ionic: CH₃CH₂Br + OH⁻ → CH₃CH₂OH + Br⁻, Reagent: NaOH(aq), heat under reflux, OH⁻ is the nucleophile
- **SVG Content**: Present (1546 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Do not confuse with ethanolic NaOH, which favours elimination (later slide). Teaching order used: starting compound, reagent and solvent, purpose of conditions, structural change, named product, mechanism, common mistake.
- **Existing Checkpoints After This Slide**: None

## Slide 12: `s12` — Reflux and the Role of Water
- **Learning Objective / Purpose**: Reflux and hydrolysis with water (HAL.3).
- **Indicators**: HAL.3
- **On-Screen Educational Text**:
  - Reflux: heat without losing vapour
  - Water is a weaker nucleophile
  - OH⁻ reacts faster than H₂O
- **Key Ideas**: Reflux heats without losing vapour. | OH⁻ is a stronger nucleophile than H₂O. | Water hydrolysis is slower.
- **Complete Narration Text**: Reactions of halogenoalkanes are usually carried out under reflux. A condenser fitted vertically on the flask turns vapours back into liquid, so we can heat the mixture for a long time without losing volatile compounds. Anti-bumping granules help the liquid boil smoothly. Halogenoalkanes also react with water, but more slowly than with hydroxide ions. Water is a neutral molecule, with only a partial negative charge on oxygen, while hydroxide carries a full negative charge, so it is a better nucleophile. Water hydrolysis releases hydrogen ions as well as the halide ion.
- **Audio Asset Reference**: `audio/s12.ca38c5c8c8ef.mp3` (40s, source: tts)
- **Visual Type**: `svg` · **Description**: Reflux and the Role of Water: Reflux: condenser returns the vapour; Anti-bumping granules give smooth boiling; H₂O is a neutral, weaker nucleophile; Hydrolysis with water is slower.
- **Image Asset Reference**: `None` · **Alt Text**: Reflux and the Role of Water: Reflux: condenser returns the vapour; Anti-bumping granules give smooth boiling; H₂O is a neutral, weaker nucleophile; Hydrolysis with water is slower.
- **Visual Labels**: Reflux and water, Reflux: condenser returns the vapour, Anti-bumping granules give smooth boiling, H₂O is a neutral, weaker nucleophile, Hydrolysis with water is slower
- **SVG Content**: Present (1547 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: A standard condenser, flask and heat source are enough. No reflux practical is required here.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcD1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qD.1`: Which reagent and conditions turn bromoethane into ethanol? — Correct: a (a: NaOH(aq), heat under reflux | b: Concentrated H₂SO₄ at room temperature | c: KCN in ethanol, reflux | d: NaOH in ethanol, heat)

## Slide 13: `s13` — Substitution with Cyanide
- **Learning Objective / Purpose**: Nitrile formation (HAL.3).
- **Indicators**: HAL.3
- **On-Screen Educational Text**:
  - KCN in ethanol, heat under reflux
  - CN⁻ replaces the halogen
  - The chain gets one carbon longer
- **Key Ideas**: KCN in ethanol, heat under reflux. | The carbon chain gets one carbon longer. | Cyanides are highly toxic.
- **Complete Narration Text**: Start with bromoethane. The reagent is potassium cyanide dissolved in ethanol, and the mixture is heated under reflux. Ethanol is the solvent, because with water present the nucleophile water could compete and give an alcohol as well. The cyanide ion is the nucleophile. It replaces the bromine, so a carbon-bromine bond is replaced by a new carbon-carbon bond. The organic product is propanenitrile. Count the carbons: two go in and three come out, so the chain is one carbon longer, which is why this reaction is useful in synthesis. A nitrile can later be changed into a carboxylic acid or an amine. A common examination mistake is to forget the extra carbon when naming the nitrile. Cyanides are highly toxic, so this reaction is theory only.
- **Audio Asset Reference**: `audio/s13.6166b3f38336.mp3` (55s, source: tts)
- **Visual Type**: `svg` · **Description**: Substitution with Cyanide: CH₃CH₂Br + CN⁻ → CH₃CH₂CN + Br⁻; Reagent: KCN in ethanol; Conditions: heat under reflux; Product: propanenitrile (3 carbons).
- **Image Asset Reference**: `None` · **Alt Text**: Substitution with Cyanide: CH₃CH₂Br + CN⁻ → CH₃CH₂CN + Br⁻; Reagent: KCN in ethanol; Conditions: heat under reflux; Product: propanenitrile (3 carbons).
- **Visual Labels**: Forming a nitrile, CH₃CH₂Br + CN⁻ → CH₃CH₂CN + Br⁻, Reagent: KCN in ethanol, Conditions: heat under reflux, Product: propanenitrile (3 carbons)
- **SVG Content**: Present (1523 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Safety: cyanide is acutely toxic. Treat as theory only; do not suggest practical work. Worked example: 1-bromopropane gives butanenitrile; 1-bromobutane gives pentanenitrile.
- **Existing Checkpoints After This Slide**: None

## Slide 14: `s14` — Substitution with Ammonia
- **Learning Objective / Purpose**: Primary amine formation (HAL.3).
- **Indicators**: HAL.3
- **On-Screen Educational Text**:
  - Excess NH₃ in ethanol
  - Heat in a sealed tube, under pressure
  - Product: a primary amine
- **Key Ideas**: Excess NH3 gives the primary amine. | Heat under pressure in ethanol. | Limited NH3 gives a mixture of amines.
- **Complete Narration Text**: Start with bromoethane. The reagent is ammonia dissolved in ethanol, in large excess. We heat in a sealed tube under pressure, because ammonia is a gas and the mixture is heated above its boiling point. Ammonia is the nucleophile, using the lone pair on nitrogen. It replaces the bromine, and the product is the primary amine, ethylamine. The hydrogen bromide produced is taken up by a second ammonia molecule, so ammonium bromide forms, which is why the equation shows two ammonia molecules. If ammonia is not in excess, the amine, which is also a nucleophile, reacts again and a mixture of secondary and tertiary amines forms. A common examination mistake is to forget the word excess. You will see amines again in a later chapter.
- **Audio Asset Reference**: `audio/s14.6d4561f09bca.mp3` (54s, source: tts)
- **Visual Type**: `svg` · **Description**: Substitution with Ammonia: CH₃CH₂Br + 2NH₃ → CH₃CH₂NH₂ + NH₄Br; Excess ammonia in ethanol; Heat in a sealed tube under pressure; Less NH₃ gives a mixture of amines.
- **Image Asset Reference**: `None` · **Alt Text**: Substitution with Ammonia: CH₃CH₂Br + 2NH₃ → CH₃CH₂NH₂ + NH₄Br; Excess ammonia in ethanol; Heat in a sealed tube under pressure; Less NH₃ gives a mixture of amines.
- **Visual Labels**: Forming an amine, CH₃CH₂Br + 2NH₃ → CH₃CH₂NH₂ + NH₄Br, Excess ammonia in ethanol, Heat in a sealed tube under pressure, Less NH₃ gives a mixture of amines
- **SVG Content**: Present (1533 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: The textbook shows CH₃CH₂Br + NH₃ → CH₃CH₂NH₂ + HBr. With excess NH₃ the HBr forms NH₄Br, so both forms are acceptable if explained.
- **Existing Checkpoints After This Slide**: None

## Slide 15: `s15` — Reagents and Conditions
- **Learning Objective / Purpose**: Summary table of reactions (HAL.3, HAL.6).
- **Indicators**: HAL.3, HAL.6
- **On-Screen Educational Text**:
  - Learn each reagent with its conditions
  - Product type depends on reagent
  - Ethanolic NaOH gives elimination
- **Key Ideas**: Each reagent has its own conditions. | Solvent matters: aqueous or ethanolic. | Always state the conditions in an answer.
- **Complete Narration Text**: Here is a summary table that you should learn. Aqueous sodium hydroxide, heated under reflux, gives an alcohol. Potassium cyanide in ethanol, heated under reflux, gives a nitrile. Excess ammonia in ethanol, heated under pressure, gives a primary amine. Water gives an alcohol too, but slowly. The last row is different: sodium hydroxide in ethanol, with heat, causes elimination and gives an alkene. In an exam, always give the reagent, the solvent and the conditions.
- **Audio Asset Reference**: `audio/s15.7d7ced94feb0.mp3` (33s, source: tts)
- **Visual Type**: `svg` · **Description**: Reagents and Conditions: Reagent; Conditions; Product; NaOH(aq); reflux; alcohol; KCN, ethanol; reflux; nitrile; excess NH₃; pressure; amine; H₂O; slow; alcohol; NaOH, ethanol; heat; alkene.
- **Image Asset Reference**: `None` · **Alt Text**: Reagents and Conditions: Reagent; Conditions; Product; NaOH(aq); reflux; alcohol; KCN, ethanol; reflux; nitrile; excess NH₃; pressure; amine; H₂O; slow; alcohol; NaOH, ethanol; heat; alkene.
- **Visual Labels**: Halogenoalkane reactions, Reagent, Conditions, Product, NaOH(aq), reflux, alcohol, KCN, ethanol, reflux, nitrile, excess NH₃, pressure, amine, H₂O, slow, alcohol, NaOH, ethanol, heat, alkene
- **SVG Content**: Present (4987 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: High-yield exam table. Pupils should be able to rewrite it from memory.
- **Existing Checkpoints After This Slide**: None

## Slide 16: `s16` — Worked Examples
- **Learning Objective / Purpose**: Apply substitution reactions (HAL.3).
- **Indicators**: HAL.3
- **On-Screen Educational Text**:
  - Same method every time
  - Check solvent: aqueous or ethanolic
  - Recount the carbon atoms
- **Key Ideas**: Use the same method each time. | Aqueous or ethanolic changes the product. | Recount carbons for nitriles.
- **Complete Narration Text**: Let us work through five examples using the same method. Name the starting compound, state the reagent and solvent, decide between substitution and elimination, replace the halogen, then name the product and recount the carbons. First, 1-bromobutane has four carbons. With potassium cyanide in ethanol under reflux, the nitrile has five carbons, so it is pentanenitrile. Second, 2-bromopropane with aqueous sodium hydroxide gives propan-2-ol, because the hydroxyl group replaces bromine on the same carbon. Third, bromoethane with excess ammonia in ethanol gives ethylamine. Fourth, bromoethane with sodium hydroxide in ethanol gives ethene, by elimination, not an alcohol. Fifth, 1-iodopropane with aqueous sodium hydroxide gives propan-1-ol. Watch the solvent each time. That one word changes the product.
- **Audio Asset Reference**: `audio/s16.2e213e64e33f.mp3` (50s, source: tts)
- **Visual Type**: `svg` · **Description**: Worked Examples: Start; Reagent; Product; 1-bromobutane; KCN, ethanol; pentanenitrile; 2-bromopropane; NaOH(aq); propan-2-ol; bromoethane; excess NH₃; ethylamine; bromoethane; NaOH, ethanol; ethene; 1-iodopropane; NaOH(aq); propan-1-ol.
- **Image Asset Reference**: `None` · **Alt Text**: Worked Examples: Start; Reagent; Product; 1-bromobutane; KCN, ethanol; pentanenitrile; 2-bromopropane; NaOH(aq); propan-2-ol; bromoethane; excess NH₃; ethylamine; bromoethane; NaOH, ethanol; ethene; 1-iodopropane; NaOH(aq); propan-1-ol.
- **Visual Labels**: Worked examples, Start, Reagent, Product, 1-bromobutane, KCN, ethanol, pentanenitrile, 2-bromopropane, NaOH(aq), propan-2-ol, bromoethane, excess NH₃, ethylamine, bromoethane, NaOH, ethanol, ethene, 1-iodopropane, NaOH(aq), propan-1-ol
- **SVG Content**: Present (5029 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: These examples are new and not taken from the textbook exercises.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpD` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `cpD.1`: What is the organic product of 1-bromobutane with KCN in ethanol under reflux? — Correct: d (a: Butanenitrile | b: Pentan-1-ol | c: Pentylamine | d: Pentanenitrile)
    - [mcq] `cpD.2`: Why is ammonia used in excess to make a primary amine? — Correct: c (a: To produce an alcohol | b: To neutralise the solvent | c: To stop the amine reacting again to form secondary and tertiary amines | d: To make the reaction faster only)
    - [mcq] `cpD.3`: Why is hydroxide a faster nucleophile than water? — Correct: b (a: It is a stronger acid | b: It has a full negative charge | c: It has no lone pair | d: It is a larger molecule)

## Slide 17: `s17` — The Trend in Reactivity
- **Learning Objective / Purpose**: Relative rates of hydrolysis (HAL.4).
- **Indicators**: HAL.4
- **On-Screen Educational Text**:
  - Iodoalkanes react fastest
  - Chloroalkanes are slower
  - Fluoroalkanes are least reactive
- **Key Ideas**: Reactivity order: I > Br > Cl > F. | Fluoroalkanes are the least reactive. | Polarity does not explain this trend.
- **Complete Narration Text**: When we compare halogenoalkanes of the same type, with the same carbon skeleton and under the same conditions, their reactivity in substitution follows a clear trend. Iodoalkanes react fastest, then bromoalkanes, then chloroalkanes, and fluoroalkanes are the least reactive, so unreactive that they hardly react under these conditions. The question is why. Polarity points the other way, because fluorine is the most electronegative, so polarity does not explain the trend. The explanation we use at this level is bond strength, which we look at next.
- **Audio Asset Reference**: `audio/s17.96624ff0de97.mp3` (37s, source: tts)
- **Visual Type**: `svg` · **Description**: The Trend in Reactivity: Iodoalkanes: most reactive; Bromoalkanes; Chloroalkanes; Fluoroalkanes: least reactive.
- **Image Asset Reference**: `None` · **Alt Text**: The Trend in Reactivity: Iodoalkanes: most reactive; Bromoalkanes; Chloroalkanes; Fluoroalkanes: least reactive.
- **Visual Labels**: Reactivity of R–X, Iodoalkanes: most reactive, Bromoalkanes, Chloroalkanes, Fluoroalkanes: least reactive
- **SVG Content**: Present (1485 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Compare compounds with the same carbon skeleton and the same conditions.
- **Existing Checkpoints After This Slide**: None

## Slide 18: `s18` — Bond Strength Explains It
- **Learning Objective / Purpose**: Bond energies and rates (HAL.4).
- **Indicators**: HAL.4
- **On-Screen Educational Text**:
  - C–F is the strongest bond
  - C–I is the weakest bond
  - Weakest bond breaks most easily
- **Key Ideas**: C–X bond energy falls from F to I. | The weakest bond breaks most easily. | The rate trend follows bond strength, not polarity.
- **Complete Narration Text**: The substitution reaction involves breaking the carbon-halogen bond, so the energy needed to break it matters. These values are from the coursebook. The carbon-fluorine bond is the strongest, at 467 kilojoules per mole, so fluoroalkanes react very slowly. The carbon-iodine bond is the weakest, at 228, so iodoalkanes react fastest. Bond energies in other data sources differ slightly, but the trend is the same. Bond energy is the main factor we use at this level, though it does not predict every reaction rate by itself, because the mechanism, solvent and stability of the ions formed also matter. In an exam, do not say that iodine is more electronegative. The correct reason is that the carbon-iodine bond is weaker and breaks more easily.
- **Audio Asset Reference**: `audio/s18.06be4f032222.mp3` (53s, source: tts)
- **Visual Type**: `svg` · **Description**: Bond Strength Explains It: Bond; Energy / kJ mol⁻¹; C–F; 467 (strongest); C–Cl; 346; C–Br; 290; C–I; 228 (weakest).
- **Image Asset Reference**: `None` · **Alt Text**: Bond Strength Explains It: Bond; Energy / kJ mol⁻¹; C–F; 467 (strongest); C–Cl; 346; C–Br; 290; C–I; 228 (weakest).
- **Visual Labels**: Carbon–halogen bond energies, Bond, Energy / kJ mol⁻¹, C–F, 467 (strongest), C–Cl, 346, C–Br, 290, C–I, 228 (weakest)
- **SVG Content**: Present (2967 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Values are the coursebook values (467, 346, 290, 228 kJ/mol). The Cambridge data booklet may list slightly different values: use the school's booklet in tests.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcE1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qE.1`: Why is 1-iodobutane hydrolysed faster than 1-chlorobutane? — Correct: c (a: The C–I bond is more polar | b: Iodine is more electronegative than chlorine | c: The C–I bond is weaker, so it breaks more easily | d: Iodine atoms are smaller than chlorine atoms)

## Slide 19: `s19` — Testing the Rates: Silver Nitrate
- **Learning Objective / Purpose**: Practical: rates of hydrolysis (HAL.4).
- **Indicators**: HAL.4
- **On-Screen Educational Text**:
  - Silver nitrate in ethanol and water
  - Time how long the precipitate takes
  - Colour shows which halide
- **Key Ideas**: Water hydrolyses R–X, releasing X⁻. | Ag⁺ + X⁻ gives a silver halide precipitate. | C–F is very strong; AgF is soluble.
- **Complete Narration Text**: We can compare how quickly halogenoalkanes are hydrolysed with a simple test tube experiment. Use halogenoalkanes of the same type with the same carbon chain, for example the 1-chloro, 1-bromo and 1-iodo compounds. Put the same volume of each in separate test tubes standing in the same warm water bath. Add the same volume of silver nitrate solution made up in ethanol and water. The ethanol helps the halogenoalkane mix with the aqueous silver nitrate, and the water is the nucleophile that hydrolyses it. Halide ions are released and combine with silver ions to form a precipitate. The precipitate is white for chloride, cream for bromide, and pale yellow for iodide. A fluoroalkane gives no precipitate for two reasons. The carbon-fluorine bond is so strong that hydrolysis is extremely slow. And even if fluoride ions were released, silver fluoride is soluble in water, so no solid would form.
- **Audio Asset Reference**: `audio/s19.3bb7e3b8fb7c.mp3` (64s, source: tts)
- **Visual Type**: `svg` · **Description**: Testing the Rates: Silver Nitrate: Halide; Precipitate; Chloride; white; Bromide; cream; Iodide; pale yellow.
- **Image Asset Reference**: `None` · **Alt Text**: Testing the Rates: Silver Nitrate: Halide; Precipitate; Chloride; white; Bromide; cream; Iodide; pale yellow.
- **Visual Labels**: Silver halide precipitates, Halide, Precipitate, Chloride, white, Bromide, cream, Iodide, pale yellow
- **SVG Content**: Present (2462 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Syllabus wording is aqueous silver nitrate in ethanol. Use equal volumes and concentrations, the same temperature (a warm water bath, no naked flames) and the same carbon chain. Safety: ethanol is flammable, silver nitrate stains skin and irritates, halogenoalkanes are harmful. Eye protection throughout. Teacher demonstration or closely supervised.
- **Existing Checkpoints After This Slide**: None

## Slide 20: `s20` — Reading the Results
- **Learning Objective / Purpose**: Interpret the rate results (HAL.4).
- **Indicators**: HAL.4
- **On-Screen Educational Text**:
  - Iodo gives a precipitate first
  - Chloro gives one last
  - Time to cloudiness is a rough guide
- **Key Ideas**: Shorter time suggests a faster reaction. | The endpoint is subjective, so only rank the tubes. | Control temperature, volumes and carbon chain.
- **Complete Narration Text**: The time to visible cloudiness is a comparative measure only, so we use it to rank the tubes, not to measure an exact rate. A shorter time suggests a faster reaction. The expected order of the three tubes is iodo first, then bromo, then chloro, which is consistent with the bond energies. We should not turn the times into a ratio of rates, for several reasons. The endpoint depends on how much precipitate the observer can see. The precipitates differ in colour and how opaque they are. The rate changes as the reactants are used up, and lighting and the mark under the tube also affect what we see. To make it a fair test, keep the volumes, the concentrations, the temperature and the carbon chain the same, and change only the halogen. Repeat the test, and use a mark on paper under the tube. Bond strength is the main explanation at this level, though not the only factor in reaction rates.
- **Audio Asset Reference**: `audio/s20.182c5fab3f47.mp3` (70s, source: tts)
- **Visual Type**: `svg` · **Description**: Reading the Results: Shorter time: faster (comparison only); Expected order: I > Br > Cl; Keep temperature and volumes the same; Same carbon chain in all three.
- **Image Asset Reference**: `None` · **Alt Text**: Reading the Results: Shorter time: faster (comparison only); Expected order: I > Br > Cl; Keep temperature and volumes the same; Same carbon chain in all three.
- **Visual Labels**: Interpreting the test, Shorter time: faster (comparison only), Expected order: I > Br > Cl, Keep temperature and volumes the same, Same carbon chain in all three
- **SVG Content**: Present (1551 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: No experimental results are given in the lesson; students record their own. Do not convert times into rate ratios.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpE` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `cpE.1`: A halogenoalkane is warmed with aqueous silver nitrate in ethanol and a cream precipitate forms. Which halogen does it contain? — Correct: d (a: Chlorine | b: Fluorine | c: Iodine | d: Bromine)
    - [mcq] `cpE.2`: In the silver nitrate test on halogenoalkanes with the same carbon chain, which gives a precipitate first? — Correct: d (a: The chloroalkane | b: The bromoalkane | c: All at exactly the same time | d: The iodoalkane)
    - [mcq] `cpE.3`: Which variable should be kept the same in a fair test of the three halogenoalkanes? — Correct: a (a: The carbon chain | b: The time taken | c: The halogen | d: The colour of the precipitate)
    - [mcq] `cpE.5`: Why does a fluoroalkane give no precipitate in the silver nitrate test? — Correct: d (a: The C–F bond is the weakest | b: Silver fluoride is a cream solid | c: Fluorine is not a halogen | d: The C–F bond is very strong and silver fluoride is soluble in water)
    - [tapDiagram] `cpE.4`: Tap the least reactive type of halogenoalkane. — Hotspot: h4

## Slide 21: `s21` — The SN2 Mechanism: Meaning
- **Learning Objective / Purpose**: Decode SN2 (HAL.5).
- **Indicators**: HAL.5
- **On-Screen Educational Text**:
  - S: substitution, N: nucleophilic
  - 2: two species in the slow step
  - Rate = k [R–X][OH⁻]
- **Key Ideas**: The 2 means two species in the slow step. | Rate depends on halogenoalkane and OH⁻. | One step, no intermediate.
- **Complete Narration Text**: Primary halogenoalkanes, and methyl halides, usually react with hydroxide ions by the SN2 mechanism. This is a characteristic trend, not a universal rule. Decode the name. S stands for substitution. N stands for nucleophilic. The number two is the molecularity: the number of species involved in the rate-determining step, the slowest step. These are the halogenoalkane and the nucleophile. Experiments show that the rate depends on the concentration of both, so the rate equals k times the halogenoalkane concentration times the nucleophile concentration. At constant temperature and in the same solvent, doubling the hydroxide concentration doubles the rate. The reaction happens in one step, with no intermediate. A common examination mistake is to read the two as the number of steps.
- **Audio Asset Reference**: `audio/s21.f6a5d33812f9.mp3` (53s, source: tts)
- **Visual Type**: `svg` · **Description**: The SN2 Mechanism: Meaning: S = substitution, N = nucleophilic; 2 = two species in the slow step; One step, no intermediate; Rate = k [R–X][OH⁻], second order.
- **Image Asset Reference**: `None` · **Alt Text**: The SN2 Mechanism: Meaning: S = substitution, N = nucleophilic; 2 = two species in the slow step; One step, no intermediate; Rate = k [R–X][OH⁻], second order.
- **Visual Labels**: What SN2 means, S = substitution, N = nucleophilic, 2 = two species in the slow step, One step, no intermediate, Rate = k [R–X][OH⁻], second order
- **SVG Content**: Present (1523 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Pupils often think 1 and 2 count the steps. SN1 has two steps; SN2 has one.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcF1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qF.1`: What does the 2 in SN2 tell us? — Correct: b (a: Two products are formed | b: Two species are in the rate-determining step | c: The mechanism has two steps | d: Two halogen atoms are involved)

## Slide 22: `s22` — SN2: The Curly Arrows
- **Learning Objective / Purpose**: Draw the SN2 mechanism (HAL.5).
- **Indicators**: HAL.5
- **On-Screen Educational Text**:
  - Arrow 1: lone pair to the δ+ carbon
  - Arrow 2: C–Br bond to Br
  - Transition state in square brackets
- **Key Ideas**: Arrow from the lone pair to the carbon. | Arrow from the C–Br bond to Br. | Transition state shown in brackets.
- **Complete Narration Text**: Here is the SN2 mechanism for bromoethane. The hydroxide ion attacks the delta plus carbon. The first curly arrow starts at the lone pair on oxygen and points to the carbon. At the same time, the second arrow starts at the carbon-bromine bond and points to bromine, because the bromine takes both electrons of the bond. In the transition state, the oxygen-carbon bond is partly formed and the carbon-bromine bond is partly broken. Then the bromide ion leaves, and ethanol forms. Show the lone pair, the charges and the arrows clearly. A common examination mistake is to start the arrow at the negative charge instead of at the lone pair.
- **Audio Asset Reference**: `audio/s22.3f62f733ecc0.mp3` (48s, source: tts)
- **Visual Type**: `svg` · **Description**: SN2 mechanism for bromoethane. A hydroxide ion with a lone pair on oxygen sends a curly arrow from that lone pair to the delta-plus carbon. A second curly arrow goes from the carbon-bromine bond to bromine, which is delta minus. A dashed box shows the transition state with partial bonds, then the products ethanol and bromide ion.
- **Image Asset Reference**: `None` · **Alt Text**: SN2 mechanism for bromoethane. A hydroxide ion with a lone pair on oxygen sends a curly arrow from that lone pair to the delta-plus carbon. A second curly arrow goes from the carbon-bromine bond to bromine, which is delta minus. A dashed box shows the transition state with partial bonds, then the products ethanol and bromide ion.
- **Visual Labels**: SN2: hydrolysis of bromoethane, HO⁻, CH₃, CH₂, Br, δ+, δ−, lone pair on O, transition state: both bonds partly formed, CH₃CH₂OH + Br⁻
- **SVG Content**: Present (3320 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [ENRICHMENT: back-side attack detail] Enrichment: the nucleophile attacks from the side opposite the leaving group, which matters later for chiral carbons. Keep arrow heads touching atoms or bonds.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpF` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `cpF.1`: How many steps does the SN2 mechanism have? — Correct: c (a: Two | b: Three | c: One | d: It depends on the solvent)
    - [mcq] `cpF.2`: Where does the first curly arrow start in the SN2 reaction with OH⁻? — Correct: b (a: At the bromine atom | b: At a lone pair on oxygen | c: At the hydrogen atom | d: At the carbon atom)
    - [mcq] `cpF.3`: What is shown in square brackets in the SN2 diagram? — Correct: b (a: The reactants | b: The transition state | c: A stable intermediate | d: The products)
    - [mcq] `cpF.4`: In an SN2 reaction at constant temperature and in the same solvent, the hydroxide concentration is doubled. What happens to the rate? — Correct: a (a: It doubles | b: It stays the same | c: It halves | d: It quadruples)

## Slide 23: `s23` — SN1: Step 1
- **Learning Objective / Purpose**: Tertiary mechanism step 1 (HAL.5).
- **Indicators**: HAL.5
- **On-Screen Educational Text**:
  - Tertiary halogenoalkanes use SN1
  - Step 1 is slow: C–Br breaks
  - A carbocation forms
- **Key Ideas**: Step 1 is slow bond breaking. | A carbocation forms. | Only the halogenoalkane is in the slow step.
- **Complete Narration Text**: A tertiary halogenoalkane such as 2-bromo-2-methylpropane usually reacts by a different mechanism, called SN1. The first step is slow. The carbon-bromine bond breaks heterolytically, so the bromine takes both the bonding electrons and leaves as a bromide ion. That leaves a positive ion on carbon, called a carbocation. The curly arrow starts at the bond and points to bromine. Only the halogenoalkane is involved in this slow step, because the hydroxide ion has not yet reacted. In the carbocation the positive carbon has only three bonds.
- **Audio Asset Reference**: `audio/s23.f4b92f8cae30.mp3` (37s, source: tts)
- **Visual Type**: `svg` · **Description**: SN1 step 1 (slow). In 2-bromo-2-methylpropane a curly arrow goes from the carbon-bromine bond to bromine. The products are the tertiary carbocation with a positive charge on carbon and a bromide ion. Notes say that bromine takes both electrons and only the halogenoalkane is in the slow step.
- **Image Asset Reference**: `None` · **Alt Text**: SN1 step 1 (slow). In 2-bromo-2-methylpropane a curly arrow goes from the carbon-bromine bond to bromine. The products are the tertiary carbocation with a positive charge on carbon and a bromide ion. Notes say that bromine takes both electrons and only the halogenoalkane is in the slow step.
- **Visual Labels**: SN1 step 1 (slow): the bond breaks, (CH₃)₃C, Br, slow, (CH₃)₃C⁺, +, Br⁻, Heterolytic fission: Br takes both electrons, Carbocation forms: (CH₃)₃C⁺ is a positive ion, Only the halogenoalkane is in this slow step
- **SVG Content**: Present (3169 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Heterolytic fission was defined in the earlier chapter on organic reactions.
- **Existing Checkpoints After This Slide**: None

## Slide 24: `s24` — SN1: Step 2 and the Rate
- **Learning Objective / Purpose**: Tertiary mechanism step 2 and rate (HAL.5).
- **Indicators**: HAL.5
- **On-Screen Educational Text**:
  - Step 2 is fast: OH⁻ attacks C⁺
  - Rate = k [halogenoalkane]
  - The 1 means one species in the slow step
- **Key Ideas**: Step 2 is fast. | Rate depends only on the halogenoalkane, at constant conditions. | SN1 has two steps; the 1 is not the step count.
- **Complete Narration Text**: In step two, the carbocation is attacked immediately by the hydroxide ion. The curly arrow starts at the lone pair on oxygen and points to the positive carbon, forming the alcohol. This step is fast. Because the slow step involves only the halogenoalkane, the rate depends on its concentration only: rate equals k times the halogenoalkane concentration. This holds under otherwise constant conditions, with the same temperature and the same solvent. Under those conditions, changing the concentration of hydroxide does not change the rate. That is what the one in SN1 tells us: one species in the slow step. The number does not mean one step. SN1 is a two-step mechanism. A common examination mistake is to include hydroxide in the SN1 rate equation.
- **Audio Asset Reference**: `audio/s24.a2e28471cd28.mp3` (54s, source: tts)
- **Visual Type**: `svg` · **Description**: SN1 step 2 (fast). A hydroxide ion with a lone pair on oxygen sends a curly arrow from that lone pair to the positive carbon of the tertiary carbocation, forming 2-methylpropan-2-ol. Notes give rate equals k times the halogenoalkane concentration; hydroxide is not in the rate equation.
- **Image Asset Reference**: `None` · **Alt Text**: SN1 step 2 (fast). A hydroxide ion with a lone pair on oxygen sends a curly arrow from that lone pair to the positive carbon of the tertiary carbocation, forming 2-methylpropan-2-ol. Notes give rate equals k times the halogenoalkane concentration; hydroxide is not in the rate equation.
- **Visual Labels**: SN1 step 2 (fast): the ion is attacked, (CH₃)₃C⁺, HO⁻, lone pair on O, fast, (CH₃)₃C–OH, Rate = k [halogenoalkane] (first order), At constant conditions, OH⁻ is not in it, Slow step 1 decides the rate
- **SVG Content**: Present (3189 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Common exam trap: the 1 and 2 describe the species in the rate-determining step.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcG1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qG.1`: What is the rate equation for the SN1 hydrolysis of (CH₃)₃CBr? — Correct: a (a: rate = k[(CH₃)₃CBr] | b: rate = k[OH⁻] | c: rate = k[(CH₃)₃CBr][OH⁻] | d: rate = k[(CH₃)₃CBr]²)

## Slide 25: `s25` — Why Tertiary Favours SN1
- **Learning Objective / Purpose**: Carbocation stability (HAL.5).
- **Indicators**: HAL.5
- **On-Screen Educational Text**:
  - Alkyl groups push electrons
  - Positive inductive effect
  - Tertiary carbocations are most stable
- **Key Ideas**: Alkyl groups release electrons: +I effect. | Stability: tertiary > secondary > primary. | Primary halogenoalkanes use SN2 instead.
- **Complete Narration Text**: Why do tertiary halogenoalkanes usually react by SN1? Alkyl groups release electrons towards the carbon they are attached to. This is called the positive inductive effect. A tertiary carbocation has three alkyl groups pushing electrons onto the positive carbon, which spreads out the charge and makes the ion more stable. A primary carbocation has only one, so it is much less stable, and primary halogenoalkanes usually react by SN2 instead. Two other factors support the same trend. Three alkyl groups crowd the carbon, which makes attack by a nucleophile difficult, and polar solvents such as water help to stabilise the ions formed. These are trends, not universal rules, because the nucleophile, the solvent and the temperature also matter.
- **Audio Asset Reference**: `audio/s25.a524063ef82a.mp3` (51s, source: tts)
- **Visual Type**: `svg` · **Description**: Why Tertiary Favours SN1: Tertiary: three alkyl groups; Secondary: two alkyl groups; Primary: one alkyl group; Alkyl groups release electrons (+I effect).
- **Image Asset Reference**: `None` · **Alt Text**: Why Tertiary Favours SN1: Tertiary: three alkyl groups; Secondary: two alkyl groups; Primary: one alkyl group; Alkyl groups release electrons (+I effect).
- **Visual Labels**: Carbocation stability, Tertiary: three alkyl groups, Secondary: two alkyl groups, Primary: one alkyl group, Alkyl groups release electrons (+I effect)
- **SVG Content**: Present (1534 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: The syllabus point is the inductive effect of alkyl groups. Steric hindrance and solvent effects are enrichment for context only; do not go beyond this into university-level treatment.
- **Existing Checkpoints After This Slide**: None

## Slide 26: `s26` — SN1 and SN2 Compared
- **Learning Objective / Purpose**: Compare the mechanisms (HAL.5).
- **Indicators**: HAL.5
- **On-Screen Educational Text**:
  - Primary and methyl: usually SN2
  - Tertiary: usually SN1
  - Secondary: a mixture of both
- **Key Ideas**: SN2: primary, one step, second order. | SN1: tertiary, two steps, first order. | Secondary can use both.
- **Complete Narration Text**: Now compare the two mechanisms. SN2 is characteristic of primary halogenoalkanes. It takes one step, the slow step involves the halogenoalkane and the nucleophile, and the rate equation includes both. SN1 is characteristic of tertiary halogenoalkanes. It takes two steps, the slow step involves only the halogenoalkane, and a carbocation intermediate forms. Secondary halogenoalkanes can use a mixture of both, depending on their structure and the conditions. As a worked example, 1-bromobutane is primary, so we expect SN2, with the halogenoalkane and hydroxide in the slow step. 2-bromo-2-methylpropane is tertiary, so we expect SN1, with only the halogenoalkane in the slow step. In an exam, say first the type of halogenoalkane, then the usual mechanism, then the species in the slow step.
- **Audio Asset Reference**: `audio/s26.d25ea51f06cb.mp3` (53s, source: tts)
- **Visual Type**: `svg` · **Description**: SN1 and SN2 Compared: ; SN2; SN1; Typically; primary; tertiary; Steps; 1; 2; Slow step; R–X + OH⁻; R–X only; Rate; k[RX][OH⁻]; k[RX]; Ion formed; none; carbocation.
- **Image Asset Reference**: `None` · **Alt Text**: SN1 and SN2 Compared: ; SN2; SN1; Typically; primary; tertiary; Steps; 1; 2; Slow step; R–X + OH⁻; R–X only; Rate; k[RX][OH⁻]; k[RX]; Ion formed; none; carbocation.
- **Visual Labels**: SN2 and SN1, , SN2, SN1, Typically, primary, tertiary, Steps, 1, 2, Slow step, R–X + OH⁻, R–X only, Rate, k[RX][OH⁻], k[RX], Ion formed, none, carbocation
- **SVG Content**: Present (4944 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Comparison slide for revision. Pupils should be able to complete the table from memory.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpG` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `cpG.1`: Which mechanism is typical for 2-bromo-2-methylpropane reacting with hydroxide? — Correct: c (a: Electrophilic addition | b: Free-radical substitution | c: SN1 | d: SN2)
    - [mcq] `cpG.2`: Why is a tertiary carbocation more stable than a primary one? — Correct: a (a: Three alkyl groups release electrons and reduce the charge density | b: It has a negative charge | c: It has a lone pair | d: It has more hydrogen atoms)
    - [sequence] `cpG.3`: Put the SN1 hydrolysis steps in order. — Order: st2 -> st4 -> st1 -> st3
    - [mcq] `cpG.5`: The SN1 hydrolysis of (CH₃)₃CBr is repeated at the same temperature and in the same solvent, with double the hydroxide concentration. What happens to the rate? — Correct: c (a: It halves | b: It doubles | c: It does not change | d: It quadruples)
    - [tapDiagram] `cpG.4`: Tap the most stable carbocation. — Hotspot: h1

## Slide 27: `s27` — Elimination Reactions
- **Learning Objective / Purpose**: Elimination of HX (HAL.6).
- **Indicators**: HAL.6
- **On-Screen Educational Text**:
  - Reagent: NaOH in ethanol, heat
  - HX is removed
  - An alkene forms
- **Key Ideas**: Elimination removes HX. | Reagent: NaOH in ethanol, heat. | The product is an alkene.
- **Complete Narration Text**: In an elimination reaction, a small molecule is lost from the original molecule. Start with bromoethane. The reagent is sodium hydroxide dissolved in ethanol, and the mixture is heated. The ethanol solvent and the heat favour elimination, because the hydroxide ion then acts as a base rather than a nucleophile. A hydrogen atom is removed from the carbon next to the one bonded to bromine, and the bromine leaves, so a carbon-carbon double bond forms. The organic product is ethene, together with water and sodium bromide. The mechanism is on the next slide. A common examination mistake is to write aqueous sodium hydroxide here, which would give an alcohol by substitution.
- **Audio Asset Reference**: `audio/s27.7c95029c5d53.mp3` (48s, source: tts)
- **Visual Type**: `svg` · **Description**: Elimination Reactions: CH₃CH₂Br + NaOH → CH₂=CH₂ + H₂O + NaBr; Reagent: NaOH in ethanol; Conditions: heat; Products: alkene, water, halide.
- **Image Asset Reference**: `None` · **Alt Text**: Elimination Reactions: CH₃CH₂Br + NaOH → CH₂=CH₂ + H₂O + NaBr; Reagent: NaOH in ethanol; Conditions: heat; Products: alkene, water, halide.
- **Visual Labels**: Elimination, CH₃CH₂Br + NaOH → CH₂=CH₂ + H₂O + NaBr, Reagent: NaOH in ethanol, Conditions: heat, Products: alkene, water, halide
- **SVG Content**: Present (1502 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Use the same word 'ethanolic' consistently with learners. Aqueous and ethanolic must not be confused.
- **Existing Checkpoints After This Slide**: None

## Slide 28: `s28` — Elimination: The Mechanism
- **Learning Objective / Purpose**: Elimination mechanism (HAL.6).
- **Indicators**: HAL.6
- **On-Screen Educational Text**:
  - OH⁻ acts as a base
  - It removes an H next to the C–Br
  - C=C forms and Br⁻ leaves
- **Key Ideas**: OH⁻ acts as a base here. | Three curly arrows are needed. | H must be on the carbon next to C–Br.
- **Complete Narration Text**: In elimination, the hydroxide ion acts as a base, not as a nucleophile. It uses a lone pair to accept a hydrogen ion from the carbon next to the carbon-bromine bond. The electrons of the carbon-hydrogen bond move to form the carbon-carbon double bond. At the same time, the carbon-bromine bond breaks and bromine leaves as a bromide ion. So there are three curly arrows, and they all happen in one concerted step. The hydrogen must be on a carbon adjacent to the one carrying the halogen. The products are an alkene, water and a bromide ion. A common examination mistake is to draw the first arrow from the negative charge, or to point it at carbon instead of at hydrogen.
- **Audio Asset Reference**: `audio/s28.e50f758454b5.mp3` (53s, source: tts)
- **Visual Type**: `svg` · **Description**: Elimination from bromoethane with hydroxide in ethanol and heat. Three curly arrows: from the oxygen lone pair of hydroxide to a hydrogen on the carbon next to the carbon-bromine bond, from that carbon-hydrogen bond to form the carbon-carbon double bond, and from the carbon-bromine bond to bromine. Products are ethene, water and bromide ion.
- **Image Asset Reference**: `None` · **Alt Text**: Elimination from bromoethane with hydroxide in ethanol and heat. Three curly arrows: from the oxygen lone pair of hydroxide to a hydrogen on the carbon next to the carbon-bromine bond, from that carbon-hydrogen bond to form the carbon-carbon double bond, and from the carbon-bromine bond to bromine. Products are ethene, water and bromide ion.
- **Visual Labels**: Elimination: OH⁻ acts as a base, HO⁻, H, CH₂, Br, (ethanol, heat), CH₂=CH₂ + H₂O + Br⁻, The H comes from the carbon next to C–Br, Arrows: lone pair to H, C–H to C=C, C–Br to Br
- **SVG Content**: Present (3380 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [ENRICHMENT: E2 mechanism; outcome 15.1.4 asks for reagent, conditions and product] This is the E2 pattern: one concerted step. The syllabus asks for the reagent, conditions and product; naming E2 is enrichment. Arrow heads must start at a lone pair or a bond and end at an atom or bond.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcH1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qH.1`: What is the role of OH⁻ in elimination? — Correct: a (a: It acts as a base and accepts H⁺ | b: It acts as a nucleophile and attacks carbon | c: It acts as a catalyst only | d: It acts as an acid)

## Slide 29: `s29` — Substitution or Elimination?
- **Learning Objective / Purpose**: Distinguish the conditions (HAL.3, HAL.6).
- **Indicators**: HAL.3, HAL.6
- **On-Screen Educational Text**:
  - Aqueous NaOH: substitution
  - Ethanolic NaOH: elimination
  - OH⁻ is a nucleophile or a base
- **Key Ideas**: Aqueous: substitution, alcohol. | Ethanolic: elimination, alkene. | More than one alkene can form.
- **Complete Narration Text**: The same halogenoalkane can give two different products. With aqueous sodium hydroxide and heat, the hydroxide ion acts as a nucleophile, and substitution gives an alcohol. With sodium hydroxide in ethanol and heat, the hydroxide acts as a base, and elimination gives an alkene. Both reactions can compete, but the conditions favour one or the other. To predict the product, first read the solvent, then name the reaction, then write the product. If the halogenoalkane has more than one possible adjacent hydrogen, more than one alkene may form. For example, 2-bromobutane can give but-1-ene, with the double bond at the end of the chain, and but-2-ene, with the double bond in the middle. But-2-ene is usually the major product, because it is the more substituted and more stable alkene, and it has cis and trans forms. But-1-ene has no cis and trans forms, because one end of its double bond carries two hydrogens. The syllabus example is only bromoethane, so treat this as enrichment.
- **Audio Asset Reference**: `audio/s29.b5266e2cbe91.mp3` (71s, source: tts)
- **Visual Type**: `svg` · **Description**: Substitution or Elimination?: Conditions; Reaction; Product; NaOH(aq), heat; substitution; alcohol; NaOH, ethanol; elimination; alkene.
- **Image Asset Reference**: `None` · **Alt Text**: Substitution or Elimination?: Conditions; Reaction; Product; NaOH(aq), heat; substitution; alcohol; NaOH, ethanol; elimination; alkene.
- **Visual Labels**: Same reagent, different conditions, Conditions, Reaction, Product, NaOH(aq), heat, substitution, alcohol, NaOH, ethanol, elimination, alkene
- **SVG Content**: Present (2757 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [ENRICHMENT: but-1-ene/but-2-ene, Zaitsev] Structures checked: but-1-ene CH₂=CHCH₂CH₃ (no geometric isomers); but-2-ene CH₃CH=CHCH₃ with cis (Z) and trans (E) forms. Zaitsev-type major product (but-2-ene, mostly trans) checked against Chemguide, LibreTexts and university notes; an exact ratio depends on the base and conditions and is not quoted. Enrichment, not a syllabus requirement.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpH` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `cpH.1`: Which conditions convert bromoethane into ethene? — Correct: d (a: KCN in ethanol, reflux | b: NaOH(aq), reflux | c: Cl₂ and UV light | d: NaOH in ethanol, heat)
    - [mcq] `cpH.2`: What are the products of bromoethane with NaOH in ethanol? — Correct: d (a: Ethylamine and sodium bromide | b: Ethanol and sodium bromide | c: Propanenitrile and sodium bromide | d: Ethene, water and sodium bromide)
    - [mcq] `cpH.3`: Why can 2-bromobutane give more than one alkene? — Correct: c (a: It is a tertiary compound | b: It has two bromine atoms | c: There are different adjacent carbons with hydrogens to lose | d: It forms a carbocation only)

## Slide 30: `s30` — Uses of Halogenoalkanes
- **Learning Objective / Purpose**: Uses and strong C–F bonds (HAL.7).
- **Indicators**: HAL.7
- **On-Screen Educational Text**:
  - Halothane: a volatile anaesthetic
  - CFCs: refrigerants and propellants
  - Each compound has its own risks
- **Key Ideas**: Halothane is a volatile anaesthetic with risks. | CFCs were unreactive near the ground. | Never generalise about safety.
- **Complete Narration Text**: Many halogenoalkanes have been used industrially, but each use depends on the properties of that particular compound. Halothane is a historically important volatile anaesthetic, a vapour that is breathed in to put patients to sleep during surgery. It is pharmacologically active, which is why it works as an anaesthetic. It also has recognised risks, including rare but serious liver damage, and in many countries it has been largely replaced by newer anaesthetics. Its medical use is a different matter from the behaviour of CFCs in the atmosphere. Chlorofluorocarbons were widely used as refrigerants, aerosol propellants and solvents, because they are volatile, non-flammable and unreactive in the lower atmosphere. That unreactivity let them reach the stratosphere. Do not say that all halogenoalkanes, or all CFCs, are non-toxic or safe.
- **Audio Asset Reference**: `audio/s30.56afa9ddef40.mp3` (56s, source: tts)
- **Visual Type**: `svg` · **Description**: Uses of Halogenoalkanes: Halothane: historic volatile anaesthetic; Largely replaced; it has recognised risks; CFCs: refrigerants, propellants, solvents; Do not generalise: each compound differs.
- **Image Asset Reference**: `None` · **Alt Text**: Uses of Halogenoalkanes: Halothane: historic volatile anaesthetic; Largely replaced; it has recognised risks; CFCs: refrigerants, propellants, solvents; Do not generalise: each compound differs.
- **Visual Labels**: Uses, Halothane: historic volatile anaesthetic, Largely replaced; it has recognised risks, CFCs: refrigerants, propellants, solvents, Do not generalise: each compound differs
- **SVG Content**: Present (1541 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [CONTEXT: not in the verified Topic 15.1 outcomes] Corrected from an earlier version that said strong C–F bonds make halothane inert and safe in the body. Medical statements (anaesthetic, replaced by newer agents, rare serious liver injury) are from public medical references listed in the report; they are not clinical advice. Do not give dosage or handling information.
- **Existing Checkpoints After This Slide**: None

## Slide 31: `s31` — CFCs and the Ozone Layer
- **Learning Objective / Purpose**: Ozone depletion (HAL.7).
- **Indicators**: HAL.7
- **On-Screen Educational Text**:
  - UV breaks the C–Cl bond high up
  - Chlorine radicals Cl• form
  - Cl• destroys ozone in a chain
- **Key Ideas**: UV breaks the C–Cl bond. | Cl• catalyses ozone destruction. | The ozone layer absorbs harmful UV.
- **Complete Narration Text**: CFCs are unreactive in the lower atmosphere, so they persist for decades and drift up into the stratosphere. There, high-energy ultraviolet radiation breaks the carbon-chlorine bond, which is weaker than the carbon-fluorine bond. This is homolytic fission and forms a chlorine radical, written Cl dot, an atom with an unpaired electron. In step one, the chlorine radical reacts with ozone to make chlorine monoxide and oxygen. In step two, chlorine monoxide reacts with an oxygen atom to give oxygen and re-form the chlorine radical. Because the radical is regenerated, it acts as a catalyst, and one radical can destroy many ozone molecules. Overall, ozone plus an oxygen atom gives two oxygen molecules. The ozone layer absorbs harmful ultraviolet radiation, so less ozone lets more reach the surface.
- **Audio Asset Reference**: `audio/s31.c31eb6cf42a9.mp3` (55s, source: tts)
- **Visual Type**: `svg` · **Description**: CFCs and the Ozone Layer: UV breaks C–Cl, giving Cl•; Cl• + O₃ → ClO• + O₂; ClO• + O → Cl• + O₂; Cl• is regenerated: a catalyst.
- **Image Asset Reference**: `None` · **Alt Text**: CFCs and the Ozone Layer: UV breaks C–Cl, giving Cl•; Cl• + O₃ → ClO• + O₂; ClO• + O → Cl• + O₂; Cl• is regenerated: a catalyst.
- **Visual Labels**: CFCs and ozone, UV breaks C–Cl, giving Cl•, Cl• + O₃ → ClO• + O₂, ClO• + O → Cl• + O₂, Cl• is regenerated: a catalyst
- **SVG Content**: Present (1494 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [CONTEXT: not in the verified Topic 15.1 outcomes] Radical equations written with Cl• and ClO•. Do not quote a figure for ozone molecules destroyed per radical unless the school's source states it; the coursebook estimate is not given in the narration. [VERIFY]
- **Existing Checkpoints After This Slide**: None

## Slide 32: `s32` — Fixing the Problem
- **Learning Objective / Purpose**: Replacements and responses (HAL.7).
- **Indicators**: HAL.7
- **On-Screen Educational Text**:
  - CFCs phased out: Montreal Protocol
  - HFCs: no chlorine, low ozone damage
  - Many HFCs are strong greenhouse gases
- **Key Ideas**: The Montreal Protocol phased out CFCs. | Low ozone damage is not the same as low warming. | Ozone is recovering if policies continue.
- **Complete Narration Text**: Governments responded under an international agreement, the Montreal Protocol, which phased out the production and use of CFCs and other ozone-depleting substances. Replacements include hydrofluorocarbons, HFCs. They contain no chlorine or bromine, so they have a low ozone depletion potential. However, ozone depletion and global warming are different problems. Many HFCs are strong greenhouse gases and some have a high global warming potential, so they are now being phased down as well. Scientific assessments report that the ozone layer is recovering, and expect it to return to 1980 levels in most of the world around the middle of this century, with the polar regions later, provided policies continue. Science can bring both benefits and problems, and we must weigh them.
- **Audio Asset Reference**: `audio/s32.c11d8c676fb7.mp3` (52s, source: tts)
- **Visual Type**: `svg` · **Description**: Fixing the Problem: CFCs phased out: Montreal Protocol; HFCs: no chlorine, so low ozone damage; But many HFCs are strong greenhouse gases; Ozone is recovering if policies continue.
- **Image Asset Reference**: `None` · **Alt Text**: Fixing the Problem: CFCs phased out: Montreal Protocol; HFCs: no chlorine, so low ozone damage; But many HFCs are strong greenhouse gases; Ozone is recovering if policies continue.
- **Visual Labels**: Responses, CFCs phased out: Montreal Protocol, HFCs: no chlorine, so low ozone damage, But many HFCs are strong greenhouse gases, Ozone is recovering if policies continue
- **SVG Content**: Present (1542 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [CONTEXT: not in the verified Topic 15.1 outcomes] Checked against UNEP/WMO 2022 assessment summaries (see report): recovery to 1980 values expected around 2040 for the near-global average, around 2045 in the Arctic and around 2066 in the Antarctic if policies continue. Dates are not given in the narration. The Kigali Amendment (HFC phase-down) is named only in this note. [VERIFY] before teaching details.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpI` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `cpI.4`: Which statement about halothane is correct? — Correct: c (a: Its strong C–F bonds make it safe in the body | b: All halogenoalkanes are safe to breathe | c: It is a pharmacologically active volatile anaesthetic with recognised risks | d: It is a CFC that is used to make ozone)
    - [mcq] `cpI.5`: Why can an HFC have little effect on ozone but still be a concern? — Correct: c (a: Ozone depletion and global warming are the same problem | b: It contains chlorine, so it breaks down ozone | c: It contains no chlorine or bromine, but it can be a strong greenhouse gas | d: All HFCs are completely harmless)
    - [mcq] `cpI.1`: Why did UV break C–Cl and not C–F in the stratosphere? — Correct: c (a: UV cannot affect fluorine | b: C–F is more polar so it breaks easily | c: C–Cl is weaker than C–F | d: Chlorine is a gas)
    - [mcq] `cpI.2`: Why is Cl• described as a catalyst in ozone destruction? — Correct: c (a: It absorbs UV light | b: It is used up in the first step | c: It is regenerated and can react again | d: It makes ozone)
    - [mcq] `cpI.3`: Why are HFCs less damaging to ozone than CFCs? — Correct: b (a: They are not manufactured | b: They contain no chlorine | c: They are not gases | d: They contain more fluorine)

## Slide 33: `s33` — Exam Skills
- **Learning Objective / Purpose**: Apply skills to exam questions (all).
- **Indicators**: HAL.5, HAL.4
- **On-Screen Educational Text**:
  - Name the type of reaction
  - Give reagent, solvent and conditions
  - Draw arrows from lone pairs or bonds
- **Key Ideas**: Reagent, solvent and conditions every time. | Arrows start at lone pairs or bonds. | Explain rates using bond energy.
- **Complete Narration Text**: Here is a checklist for exam questions on this topic. First, name the type of reaction and the mechanism. Second, always give the reagent, the solvent and the conditions, for example aqueous or ethanolic. Third, in mechanisms, start curly arrows at a lone pair or a bond and end at an atom or a bond, show partial charges, and show lone pairs on nucleophiles. Fourth, when explaining rates, use bond energy and say that the carbon-iodine bond is the weakest, not that iodine is the most electronegative. Fifth, quote the rate equation for the mechanism, and remember that the one and two refer to the species in the slow step. Sixth, describe mechanisms as the usual trend, not a rule that never has exceptions.
- **Audio Asset Reference**: `audio/s33.a06061467a27.mp3` (54s, source: tts)
- **Visual Type**: `svg` · **Description**: Exam Skills: Name the mechanism and the type; Reagent + solvent + conditions; Curly arrows: start at lone pair or bond; Explain rates using bond energy.
- **Image Asset Reference**: `None` · **Alt Text**: Exam Skills: Name the mechanism and the type; Reagent + solvent + conditions; Curly arrows: start at lone pair or bond; Explain rates using bond energy.
- **Visual Labels**: Exam checklist, Name the mechanism and the type, Reagent + solvent + conditions, Curly arrows: start at lone pair or bond, Explain rates using bond energy
- **SVG Content**: Present (1531 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Skills slide linking all the learning outcomes.
- **Existing Checkpoints After This Slide**: None

## Slide 34: `s34` — Recap: Halogenoalkanes
- **Learning Objective / Purpose**: Recap the lesson (all).
- **Indicators**: HAL.1, HAL.2, HAL.3, HAL.4, HAL.5, HAL.6, HAL.7
- **On-Screen Educational Text**:
  - Classify, name and make them
  - Substitution, SN1 and SN2
  - Elimination, rates and ozone
- **Key Ideas**: Classification decides the mechanism. | Bond energy decides the rate. | Conditions decide substitution or elimination.
- **Complete Narration Text**: Let us recap. Halogenoalkanes are alkanes with hydrogen replaced by halogen. They are classed as methyl, primary, secondary or tertiary. They are made from alkanes, alkenes or alcohols. The polar carbon-halogen bond makes the carbon attractive to nucleophiles, giving alcohols, nitriles and amines. The rate trend follows bond energy, so iodoalkanes are the most reactive. Primary compounds usually react by SN2 and tertiary compounds usually by SN1. Ethanolic hydroxide causes elimination to alkenes. And CFCs show how useful compounds can damage the ozone layer, while HFCs remind us that ozone depletion and global warming are separate problems.
- **Audio Asset Reference**: `audio/s34.d440e5da683c.mp3` (42s, source: tts)
- **Visual Type**: `svg` · **Description**: Recap: Halogenoalkanes: Primary, secondary, tertiary; Nucleophilic substitution: OH⁻, CN⁻, NH₃; Rates: weakest C–X bond is fastest; SN1, SN2, elimination, ozone.
- **Image Asset Reference**: `None` · **Alt Text**: Recap: Halogenoalkanes: Primary, secondary, tertiary; Nucleophilic substitution: OH⁻, CN⁻, NH₃; Rates: weakest C–X bond is fastest; SN1, SN2, elimination, ozone.
- **Visual Labels**: Recap, Primary, secondary, tertiary, Nucleophilic substitution: OH⁻, CN⁻, NH₃, Rates: weakest C–X bond is fastest, SN1, SN2, elimination, ozone
- **SVG Content**: Present (1511 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: Recap slide.
- **Existing Checkpoints After This Slide**: None

## End-of-Lesson Mastery Check (Pass Mark: 6)
- [mcq] `mastery.1`: What is the classification of 1-chloropropane? — Correct: d (a: Tertiary | b: Halogenated alkene | c: Secondary | d: Primary)
- [mcq] `mastery.2`: Which reagent and conditions convert ethene into bromoethane? — Correct: a (a: HBr(g) at room temperature | b: Br₂ with ultraviolet light | c: NaBr(aq) and heat | d: NaOH(aq) under reflux)
- [mcq] `mastery.3`: What is the product of bromoethane with excess NH₃ in ethanol, heated under pressure? — Correct: b (a: Propanenitrile | b: Ethylamine | c: Ethanol | d: Ethene)
- [mcq] `mastery.4`: Which explains why C–I reacts faster than C–Cl? — Correct: d (a: Higher polarity | b: Higher electronegativity of iodine | c: Smaller atoms | d: Lower bond energy)
- [mcq] `mastery.5`: Which mechanism is typical for 1-bromobutane reacting with hydroxide? — Correct: b (a: Electrophilic addition | b: SN2 | c: Free radical | d: SN1)
- [mcq] `mastery.6`: What is the rate equation for SN2 hydrolysis of a primary bromoalkane? — Correct: c (a: rate = k[RBr] | b: rate = k[OH⁻] | c: rate = k[RBr][OH⁻] | d: rate = k[RBr]²)
- [mcq] `mastery.7`: Which condition makes hydroxide act as a base and form an alkene? — Correct: d (a: Water as solvent | b: Ultraviolet light | c: Excess ammonia | d: Ethanol as solvent, with heat)
- [mcq] `mastery.8`: What makes CFCs harmful to ozone? — Correct: b (a: They dissolve in rain and wash ozone away | b: UV breaks C–Cl, giving Cl• radicals that catalyse ozone breakdown | c: They absorb UV and heat the ground | d: They react with oxygen to make ozone)

# Hydrocarbons: Alkanes and Alkenes (Cambridge International AS & A Level Chemistry) (`cambridge-as-a-level-chemistry-hydrocarbons`)

- **CDN packagePath**: `packages/cambridge-as-a-level-chemistry-hydrocarbons.739c1252e89e.json` (hash `739c1252e89e`, updated `2026-11-24T14:37:20.331Z`)
- **Curriculum**: cambridge · **Class**: A Level · **Subject**: Chemistry · **Term**: 1
- **Content Standard**: Cambridge International AS & A Level Chemistry 9701 (2025–2027 syllabus), Coursebook Chapter 15
- **Indicators**: H15.1, H15.2, H15.3, H15.4, H15.5, H15.6, H15.7, H15.8, H15.9, H15.10, H15.11, H15.12, H15.13, H15.14
- **Total Slides**: 71 · **Checkpoints**: 23 · **Mastery Check Items**: 20

## Slide 1: `a01` — What Is a Hydrocarbon?
- **Learning Objective / Purpose**: Define hydrocarbons and preview the chapter.
- **Indicators**: H15.1
- **On-Screen Educational Text**:
  - Hydrocarbon: carbon and hydrogen only
  - Alkanes: only C–C single bonds
  - Alkenes: contain a C=C double bond
- **Key Ideas**: Hydrocarbon: carbon and hydrogen only | Alkanes: only C–C single bonds | Alkenes: contain a C=C double bond
- **Complete Narration Text**: A hydrocarbon is a compound containing carbon and hydrogen only. Crude oil is our main source of hydrocarbons, and it is also the starting point for most plastics. Look at the two molecules on screen. Ethane has only single bonds between its carbon atoms, so we call it saturated. Ethene has a carbon to carbon double bond, so we call it unsaturated. More generally, an unsaturated hydrocarbon contains carbon to carbon double or triple bonds. In this chapter we meet alkanes, which are saturated, and alkenes, which have one double bond. We will study their structures, names, properties and reactions step by step.
- **Audio Asset Reference**: `audio/a01.ba0573bbaded.mp3` (45s, source: tts)
- **Visual Type**: `illustration` · **Description**: What Is a Hydrocarbon?: C; H; ethane, C₂H₆; ethene, C₂H₄; C–C single bond only; one C=C double bond; saturated; unsaturated.
- **Image Asset Reference**: `images/a01.ee8648894929.webp` · **Alt Text**: What Is a Hydrocarbon?: C; H; ethane, C₂H₆; ethene, C₂H₄; C–C single bond only; one C=C double bond; saturated; unsaturated.
- **Visual Labels**: Alkane and alkene: displayed formulae, C, H, ethane, C₂H₆, ethene, C₂H₄, C–C single bond only, one C=C double bond, saturated, unsaturated
- **SVG Content**: None
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p303–305] Learning intentions, hydrocarbons in use, key words saturated hydrocarbon and unsaturated hydrocarbon.
- **Existing Checkpoints After This Slide**: None

## Slide 2: `a01b` — Cycloalkanes
- **Learning Objective / Purpose**: Describe cycloalkanes and their general formula.
- **Indicators**: H15.1
- **On-Screen Educational Text**:
  - One ring and single bonds only: CₙH₂ₙ
  - Cyclobutane and but-1-ene are both C₄H₈
  - Formula alone cannot show ring or C=C
- **Key Ideas**: One ring and single bonds only: CₙH₂ₙ | Cyclobutane and but-1-ene are both C₄H₈ | Formula alone cannot show ring or C=C
- **Complete Narration Text**: Crude oil contains alkanes, cycloalkanes and arenes. Cycloalkanes are saturated hydrocarbons in which there is a ring of three or more carbon atoms. Imagine joining the two terminal carbon atoms of a straight chain alkane to form a ring. Each terminal carbon originally has three hydrogen atoms. When the new carbon to carbon bond forms, each terminal carbon has two hydrogen atoms instead of three. The molecule therefore has two fewer hydrogen atoms overall. That is why cycloalkanes do not follow the alkane formula. Their general formula is C n H 2 n, but only for saturated hydrocarbons with one ring; molecules with more rings do not follow it. Cyclohexane, C 6 H 12, is drawn as a skeletal hexagon, and cyclopentane, C 5 H 10, as a pentagon. Every corner is a carbon atom. Notice that cyclobutane and but 1 ene both have the formula C 4 H 8, so a molecular formula alone cannot tell a ring from an alkene.
- **Audio Asset Reference**: `audio/a01b.260f2d4ee8f2.mp3` (70s, source: tts)
- **Visual Type**: `svg` · **Description**: Cycloalkanes: cyclopentane, C₅H₁₀; cyclohexane, C₆H₁₂; One ring, single bonds only: CₙH₂ₙ; Cyclobutane and but-1-ene are both C₄H₈.
- **Image Asset Reference**: `None` · **Alt Text**: Cycloalkanes: cyclopentane, C₅H₁₀; cyclohexane, C₆H₁₂; One ring, single bonds only: CₙH₂ₙ; Cyclobutane and but-1-ene are both C₄H₈.
- **Visual Labels**: Cycloalkanes: a ring of carbon atoms, cyclopentane, C₅H₁₀, cyclohexane, C₆H₁₂, One ring, single bonds only: CₙH₂ₙ, Cyclobutane and but-1-ene are both C₄H₈
- **SVG Content**: Present (2411 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p304 Hydrocarbons in use, p305 Figure 15.2, p306 Question 1b–d] Cyclohexane and cyclopentane. Formula qualified: CₙH₂ₙ applies to saturated monocyclic hydrocarbons; an open-chain monoalkene has the same formula.
- **Existing Checkpoints After This Slide**: None

## Slide 3: `a02` — The Alkane Homologous Series
- **Learning Objective / Purpose**: Give the general formula and first members of the alkanes.
- **Indicators**: H15.1
- **On-Screen Educational Text**:
  - General formula for open-chain alkanes: CₙH₂ₙ₊₂
  - Names end in -ane
  - Each member adds one CH₂ unit
- **Key Ideas**: General formula for open-chain alkanes: CₙH₂ₙ₊₂ | Names end in -ane | Each member adds one CH₂ unit
- **Complete Narration Text**: The alkanes form a homologous series, which is a family of compounds with the same general formula. For open chain alkanes the general formula is C n H 2 n plus 2. If a molecule has three carbon atoms, n equals three, and it has two times three plus two, which is eight hydrogen atoms. That gives propane. Look at the table: each step down adds one carbon and two hydrogen atoms, which is a CH 2 unit. Names end in a-n-e. Learn the first five names now. Notice that the formula applies to open chain alkanes only. Ring alkanes, called cycloalkanes, have a different formula, which we meet next.
- **Audio Asset Reference**: `audio/a02.a68fdfdda337.mp3` (48s, source: tts)
- **Visual Type**: `svg` · **Description**: The Alkane Homologous Series: Name; Formula; Carbons; methane; CH₄; 1; ethane; C₂H₆; 2; propane; C₃H₈; 3; butane; C₄H₁₀; 4; pentane; C₅H₁₂; 5.
- **Image Asset Reference**: `None` · **Alt Text**: The Alkane Homologous Series: Name; Formula; Carbons; methane; CH₄; 1; ethane; C₂H₆; 2; propane; C₃H₈; 3; butane; C₄H₁₀; 4; pentane; C₅H₁₂; 5.
- **Visual Labels**: General formula CₙH₂ₙ₊₂, Name, Formula, Carbons, methane, CH₄, 1, ethane, C₂H₆, 2, propane, C₃H₈, 3, butane, C₄H₁₀, 4, pentane, C₅H₁₂, 5
- **SVG Content**: Present (4938 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p305] General formula CnH2n+2 and Table 14.2 reference.
- **Existing Checkpoints After This Slide**: None

## Slide 4: `a03` — Carbon-Count Prefixes
- **Learning Objective / Purpose**: Learn the stems meth- to dec-.
- **Indicators**: H15.1
- **On-Screen Educational Text**:
  - Stem tells the number of carbons
  - Learn 1 to 10 in order
  - Stems are used for every organic family
- **Key Ideas**: Stem tells the number of carbons | Learn 1 to 10 in order | Stems are used for every organic family
- **Complete Narration Text**: Organic names are built from a stem that tells you how many carbon atoms are in the longest chain. Meth means one, eth means two, prop means three, but means four and pent means five. Then hex is six, hept is seven, oct is eight, non is nine and dec is ten. Notice that the first four, meth, eth, prop and but, are historical names you simply have to memorise. From pent onwards the stems come from Greek number words. Once you know the stem, you add an ending such as a-n-e or e-n-e to show the family.
- **Audio Asset Reference**: `audio/a03.3b87b8e86eb9.mp3` (43s, source: tts)
- **Visual Type**: `svg` · **Description**: Carbon-Count Prefixes: meth = 1; hex = 6; eth = 2; hept = 7; prop = 3; oct = 8; but = 4; non = 9; pent = 5; dec = 10.
- **Image Asset Reference**: `None` · **Alt Text**: Carbon-Count Prefixes: meth = 1; hex = 6; eth = 2; hept = 7; prop = 3; oct = 8; but = 4; non = 9; pent = 5; dec = 10.
- **Visual Labels**: Stems for 1 to 10 carbons, meth = 1, hex = 6, eth = 2, hept = 7, prop = 3, oct = 8, but = 4, non = 9, pent = 5, dec = 10
- **SVG Content**: Present (2967 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [CONTEXT] Built from the photographed coursebook pages; explanations are written for this lesson.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcA1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qA.1`: An alkane has 7 carbon atoms. How many hydrogen atoms does it have? — Correct: b (a: 18 | b: 16 | c: 15 | d: 14)

## Slide 5: `a04` — Features of a Homologous Series
- **Learning Objective / Purpose**: State the shared features of a homologous series.
- **Indicators**: H15.1
- **On-Screen Educational Text**:
  - Same general formula
  - Same functional group, similar reactions
  - Physical properties change gradually
- **Key Ideas**: Same general formula | Same functional group, similar reactions | Physical properties change gradually
- **Complete Narration Text**: A homologous series has four features you must be able to state. First, all members share one general formula. Second, neighbouring members differ by one CH 2 unit. Third, they have the same functional group, so they react in similar ways. The functional group is the atom or group of atoms that decides how a molecule reacts. Fourth, the physical properties, such as boiling point, change gradually as the chain gets longer. In an exam, always link the similar chemistry to the shared functional group, and link the gradual change in physical properties to the increasing size of the molecule.
- **Audio Asset Reference**: `audio/a04.7ac939c9b3d7.mp3` (43s, source: tts)
- **Visual Type**: `svg` · **Description**: Features of a Homologous Series: Same general formula; Neighbours differ by one CH₂ unit; Same functional group: similar chemistry; Physical properties change gradually.
- **Image Asset Reference**: `None` · **Alt Text**: Features of a Homologous Series: Same general formula; Neighbours differ by one CH₂ unit; Same functional group: similar chemistry; Physical properties change gradually.
- **Visual Labels**: Homologous series: key features, Same general formula, Neighbours differ by one CH₂ unit, Same functional group: similar chemistry, Physical properties change gradually
- **SVG Content**: Present (1562 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [CONTEXT] Built from the photographed coursebook pages; explanations are written for this lesson.
- **Existing Checkpoints After This Slide**: None

## Slide 6: `a05` — Ways to Show a Molecule
- **Learning Objective / Purpose**: Distinguish molecular, empirical, structural, displayed and skeletal formulae.
- **Indicators**: H15.1
- **On-Screen Educational Text**:
  - Displayed shows every atom and bond
  - Skeletal: corners and ends are carbons
  - Condensed: CH₃CH₂CH₂CH₃
- **Key Ideas**: Displayed shows every atom and bond | Skeletal: corners and ends are carbons | Condensed: CH₃CH₂CH₂CH₃
- **Complete Narration Text**: We can show the same molecule in different ways. The molecular formula, C 4 H 10, gives the actual number of atoms. The empirical formula, C 2 H 5, gives the simplest whole number ratio. On screen you can see butane drawn as a displayed formula, with every atom and every bond. Next to it is the skeletal formula: every corner and every line end is a carbon atom, and the hydrogens are not drawn. The condensed structural formula writes the groups along the chain, C H 3, C H 2, C H 2, C H 3. Your exam may ask for any of these types, so practise converting between them.
- **Audio Asset Reference**: `audio/a05.6c77b796e307.mp3` (48s, source: tts)
- **Visual Type**: `svg` · **Description**: Ways to Show a Molecule: C; H; Displayed: all atoms and bonds; Skeletal; Molecular: C₄H₁₀     Empirical: C₂H₅; Condensed structural: CH₃CH₂CH₂CH₃; Each corner and line-end in a skeletal formula is a carbon.
- **Image Asset Reference**: `None` · **Alt Text**: Ways to Show a Molecule: C; H; Displayed: all atoms and bonds; Skeletal; Molecular: C₄H₁₀     Empirical: C₂H₅; Condensed structural: CH₃CH₂CH₂CH₃; Each corner and line-end in a skeletal formula is a carbon.
- **Visual Labels**: Butane in five ways, C, H, Displayed: all atoms and bonds, Skeletal, Molecular: C₄H₁₀     Empirical: C₂H₅, Condensed structural: CH₃CH₂CH₂CH₃, Each corner and line-end in a skeletal formula is a carbon
- **SVG Content**: Present (4826 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p305 Figure 15.3] Pentane in three ways; butane used here as original illustration.
- **Existing Checkpoints After This Slide**: None

## Slide 7: `a06` — Shape of Alkane Molecules
- **Learning Objective / Purpose**: Describe the tetrahedral shape and sigma bonding in alkanes.
- **Indicators**: H15.1
- **On-Screen Educational Text**:
  - Each carbon forms four single bonds
  - Tetrahedral, bond angle 109.5°
  - sp³ carbon: σ bonds, free rotation
- **Key Ideas**: Each carbon forms four single bonds | Tetrahedral, bond angle 109.5° | sp³ carbon: σ bonds, free rotation
- **Complete Narration Text**: Look at methane on screen. The carbon forms four single bonds, and the bonds point to the corners of a tetrahedron. A plain line is in the plane of the page. A solid wedge comes towards you, and dashes go away from you. The bond angle is about 109.5 degrees, because four bonding pairs repel each other as far apart as possible. Each bond is a sigma bond, formed by head on overlap of orbitals. An orbital is a region around a nucleus where an electron is likely to be found. Carbon mixes one s and three p orbitals into four equivalent sp 3 hybrid orbitals. This is called hybridisation. Single bonds can rotate freely.
- **Audio Asset Reference**: `audio/a06.4728ee957966.mp3` (50s, source: tts)
- **Visual Type**: `svg` · **Description**: Shape of Alkane Molecules: C; H; 109.5°; wedge = towards you; dashes = away from you.
- **Image Asset Reference**: `None` · **Alt Text**: Shape of Alkane Molecules: C; H; 109.5°; wedge = towards you; dashes = away from you.
- **Visual Labels**: Methane: tetrahedral, 109.5°, C, H, 109.5°, wedge = towards you; dashes = away from you
- **SVG Content**: Present (2511 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p305 Figure 15.4] 3D displayed formula, sp3 and 109.5 degrees. Orbital and hybridisation definitions are supplementary.
- **Existing Checkpoints After This Slide**: None

## Slide 8: `a07` — Structural Isomers and Skeletal Formulae
- **Learning Objective / Purpose**: Define structural isomers; read skeletal formulae.
- **Indicators**: H15.2
- **On-Screen Educational Text**:
  - Isomers: same molecular formula
  - Pentane has three structural isomers
  - Branching changes the skeleton
- **Key Ideas**: Isomers: same molecular formula | Pentane has three structural isomers | Branching changes the skeleton
- **Complete Narration Text**: Structural isomers have the same molecular formula but different structural formulae. Pentane, C 5 H 12, has exactly three isomers, and you can see them as skeletal formulae. Pentane has a straight chain of five carbons. In 2-methylbutane the longest chain has four carbons with a methyl branch on the second carbon. In 2,2-dimethylpropane the longest chain has three carbons and two methyl branches on the middle carbon. Check that each drawing has five carbon atoms: count every corner and every line end. Chain isomers like these differ in the way the carbon skeleton is arranged. Different structures give different physical properties, such as boiling point.
- **Audio Asset Reference**: `audio/a07.3b79d3275b8f.mp3` (46s, source: tts)
- **Visual Type**: `svg` · **Description**: Structural Isomers and Skeletal Formulae: pentane; 2-methylbutane; 2,2-dimethylpropane; All are C₅H₁₂: same formula, different structures.
- **Image Asset Reference**: `None` · **Alt Text**: Structural Isomers and Skeletal Formulae: pentane; 2-methylbutane; 2,2-dimethylpropane; All are C₅H₁₂: same formula, different structures.
- **Visual Labels**: The three structural isomers of pentane, pentane, 2-methylbutane, 2,2-dimethylpropane, All are C₅H₁₂: same formula, different structures
- **SVG Content**: Present (2470 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p320 Q1 isomerism] Three isomers of pentane are supplementary enrichment from standard syllabus content.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcB1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qB.1`: Which pair are structural isomers? — Correct: c (a: Methane and ethane | b: Ethane and ethene | c: Butane and 2-methylpropane | d: Propane and propene)

## Slide 9: `a08` — Naming Alkanes
- **Learning Objective / Purpose**: Apply the IUPAC rules to name branched alkanes.
- **Indicators**: H15.2
- **On-Screen Educational Text**:
  - Find the longest carbon chain
  - Number to give the lowest set of locants
  - List branches in alphabetical order
- **Key Ideas**: Find the longest carbon chain | Number to give the lowest set of locants | List branches in alphabetical order
- **Complete Narration Text**: Here are the naming rules. First, find the longest continuous carbon chain, which gives the parent name. Second, name the branches as alkyl groups, such as methyl and ethyl. Third, number the chain from the end that gives the lowest set of locants at the first point of difference. A locant is a number showing the position of a branch. On screen, numbering from the left puts the methyl on carbon two, but numbering from the right puts it on carbon four, so the left numbering is correct. Fourth, list the branches in alphabetical order and use di, tri or tetra for repeats. Di and tri are ignored when you alphabetise.
- **Audio Asset Reference**: `audio/a08.7d8358a5da79.mp3` (48s, source: tts)
- **Visual Type**: `svg` · **Description**: Naming Alkanes: 1; 2; 3; 4; 5; Correct: branch on C2; Wrong: branch on C4; Number from the end giving the lowest locant: 2-methylpentane.
- **Image Asset Reference**: `None` · **Alt Text**: Naming Alkanes: 1; 2; 3; 4; 5; Correct: branch on C2; Wrong: branch on C4; Number from the end giving the lowest locant: 2-methylpentane.
- **Visual Labels**: Numbering: lowest locant for the branch, 1, 2, 3, 4, 5, Correct: branch on C2, Wrong: branch on C4, Number from the end giving the lowest locant: 2-methylpentane
- **SVG Content**: Present (3620 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [CONTEXT] Built from the photographed coursebook pages; explanations are written for this lesson.
- **Existing Checkpoints After This Slide**: None

## Slide 10: `a08b` — Worked Naming Examples
- **Learning Objective / Purpose**: Convert between formula types for four alkanes.
- **Indicators**: H15.2
- **On-Screen Educational Text**:
  - 2-methylpentane, 3-ethylpentane
  - 2,3-dimethylbutane, 2,4-dimethylpentane
  - Count carbons to get the molecular formula
- **Key Ideas**: 2-methylpentane, 3-ethylpentane | 2,3-dimethylbutane, 2,4-dimethylpentane | Count carbons to get the molecular formula
- **Complete Narration Text**: Now practise naming with four alkanes from the exam style questions. Count the carbons in each skeletal formula on screen. Before listening to each answer, try writing the molecular formula on paper. 2-methylpentane has six carbons: C 6 H 14. Its condensed formula is C H 3, C H, open bracket C H 3 close bracket, C H 2, C H 2, C H 3. 3-ethylpentane has seven carbons: C 7 H 16, with an ethyl branch on the middle carbon of a five carbon chain. 2,3-dimethylbutane has a four carbon chain with a methyl on carbons two and three: C 6 H 14. 2,4-dimethylpentane is C 7 H 16, with methyl groups on carbons two and four. Notice that the longest chain is not always drawn straight.
- **Audio Asset Reference**: `audio/a08b.1d423f994685.mp3` (56s, source: tts)
- **Visual Type**: `svg` · **Description**: Worked Naming Examples: 2-methylpentane, C₆H₁₄; 3-ethylpentane, C₇H₁₆; 2,3-dimethylbutane, C₆H₁₄; 2,4-dimethylpentane, C₇H₁₆.
- **Image Asset Reference**: `None` · **Alt Text**: Worked Naming Examples: 2-methylpentane, C₆H₁₄; 3-ethylpentane, C₇H₁₆; 2,3-dimethylbutane, C₆H₁₄; 2,4-dimethylpentane, C₇H₁₆.
- **Visual Labels**: Four alkanes: molecular to skeletal formula, 2-methylpentane, C₆H₁₄, 3-ethylpentane, C₇H₁₆, 2,3-dimethylbutane, C₆H₁₄, 2,4-dimethylpentane, C₇H₁₆
- **SVG Content**: Present (3261 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p320 Exam-style Question 1] 2-methylpentane, 3-ethylpentane, 2,3-dimethylbutane; 2,4-dimethylpentane from Q1e.
- **Existing Checkpoints After This Slide**: None

## Slide 11: `a08c` — Chain and Position Isomerism
- **Learning Objective / Purpose**: Distinguish chain and position isomers.
- **Indicators**: H15.2
- **On-Screen Educational Text**:
  - Chain isomers: different carbon skeletons
  - Position isomers: group in a different position
  - Both have the same molecular formula
- **Key Ideas**: Chain isomers: different carbon skeletons | Position isomers: group in a different position | Both have the same molecular formula
- **Complete Narration Text**: There are two kinds of structural isomerism you need. Chain isomerism happens when the carbon skeleton is arranged differently. On screen, 2-methylpentane and 2,3-dimethylbutane both have the molecular formula C 6 H 14, but one has a methyl branch on carbon two of a five carbon chain, and the other has two methyl branches on a four carbon chain. Position isomerism happens when the carbon skeleton stays the same but a functional group is in a different position. But-1-ene and but-2-ene both have the formula C 4 H 8, and both have a four carbon chain, but the double bond is in a different place. In general, isomers have the same molecular formula but different arrangements of atoms. Structural isomers have different structural formulae. Stereoisomers have the same structural formula but a different arrangement in space.
- **Audio Asset Reference**: `audio/a08c.2225c944320d.mp3` (59s, source: tts)
- **Visual Type**: `svg` · **Description**: Chain and Position Isomerism: 2-methylpentane; 2,3-dimethylbutane; Chain isomers: both C₆H₁₄; but-1-ene; but-2-ene; Position isomers: C=C in a different place.
- **Image Asset Reference**: `None` · **Alt Text**: Chain and Position Isomerism: 2-methylpentane; 2,3-dimethylbutane; Chain isomers: both C₆H₁₄; but-1-ene; but-2-ene; Position isomers: C=C in a different place.
- **Visual Labels**: Chain isomers and position isomers, 2-methylpentane, 2,3-dimethylbutane, Chain isomers: both C₆H₁₄, but-1-ene, but-2-ene, Position isomers: C=C in a different place
- **SVG Content**: Present (3231 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p320 Q1c, d] Isomer type and definition.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpA` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `sA.1`: Which statement describes a homologous series? — Correct: a (a: Same general formula and functional group, with neighbours differing by CH₂ | b: Same molecular formula, different structures | c: Same boiling point for all members | d: Same number of carbon atoms in all members)
    - [mcq] `sA.2`: Which statement defines an unsaturated hydrocarbon? — Correct: a (a: Contains carbon and hydrogen only, with at least one C=C or C≡C bond | b: Contains carbon, hydrogen and oxygen | c: Contains only single carbon–carbon bonds | d: Any hydrocarbon that has a ring of carbon atoms)
    - [mcq] `sA.3`: How many structural isomers does C₅H₁₂ have, including pentane itself? — Correct: a (a: 3 | b: 2 | c: 5 | d: 4)
    - [mcq] `sA.4`: What is the molecular formula of 3-ethylpentane? — Correct: d (a: C₇H₁₄ | b: C₆H₁₄ | c: C₅H₁₂ | d: C₇H₁₆)
    - [mcq] `sA.5`: But-1-ene and but-2-ene are examples of which type of isomerism? — Correct: b (a: Functional group isomerism | b: Position isomerism | c: Optical isomerism | d: Chain isomerism)
    - [mcq] `sA.6`: What is the name of CH₃CH(CH₃)CH₂CH(CH₃)CH₃? — Correct: d (a: 2,3-dimethylpentane | b: 2,4-dimethylhexane | c: 3-ethylpentane | d: 2,4-dimethylpentane)

## Slide 12: `b01` — Boiling Points of Alkanes
- **Learning Objective / Purpose**: Explain the trend in boiling point with chain length.
- **Indicators**: H15.3
- **On-Screen Educational Text**:
  - Boiling point rises with chain length
  - More electrons give stronger induced dipoles
  - Small alkanes are gases
- **Key Ideas**: Boiling point rises with chain length | More electrons give stronger induced dipoles | Small alkanes are gases
- **Complete Narration Text**: Alkane molecules are non polar. The only forces between them are instantaneous dipole induced dipole forces. Electrons move constantly, so for a moment one side of a molecule is slightly negative, which is a temporary dipole. That temporary dipole induces an opposite dipole in a neighbouring molecule, and the two attract. On screen you can see the boiling point graph rising from methane to pentane. A longer chain has more electrons and a larger surface area, so the attractions are stronger. More energy is needed to separate the molecules, so the boiling point rises. When an alkane boils, no covalent bonds break.
- **Audio Asset Reference**: `audio/b01.e507a0e169b3.mp3` (44s, source: tts)
- **Visual Type**: `svg` · **Description**: Boiling Points of Alkanes: C₁; C₂; C₃; C₄; C₅; higher boiling point ↑; δ−; δ+; temporary; induced; attraction grows with size.
- **Image Asset Reference**: `None` · **Alt Text**: Boiling Points of Alkanes: C₁; C₂; C₃; C₄; C₅; higher boiling point ↑; δ−; δ+; temporary; induced; attraction grows with size.
- **Visual Labels**: Boiling point rises with chain length, C₁, C₂, C₃, C₄, C₅, higher boiling point ↑, δ−, δ+, temporary, induced, attraction grows with size
- **SVG Content**: Present (3647 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [VERIFY] Boiling points on the graph are standard approximate values written for this lesson (methane −162, ethane −89, propane −42, butane −1, pentane 36 °C); the coursebook pages photographed do not list them.
- **Existing Checkpoints After This Slide**: None

## Slide 13: `b02` — Effect of Branching
- **Learning Objective / Purpose**: Explain why branching lowers boiling point.
- **Indicators**: H15.3
- **On-Screen Educational Text**:
  - Same formula, different boiling points
  - Branched molecules are more compact
  - Less surface contact: weaker forces
- **Key Ideas**: Same formula, different boiling points | Branched molecules are more compact | Less surface contact: weaker forces
- **Complete Narration Text**: Compare two isomers with the same molecular formula. Butane has a straight chain, so its molecules can lie side by side with a large area in contact. That gives stronger instantaneous dipole induced dipole forces. 2-methylpropane is branched and more compact, almost spherical, so its molecules touch over a smaller surface. The forces between them are weaker, and so less energy is needed to separate them. Therefore the branched isomer has the lower boiling point. When you answer in an exam, mention surface area of contact and the strength of the intermolecular forces, not just the word branching.
- **Audio Asset Reference**: `audio/b02.312a59512990.mp3` (43s, source: tts)
- **Visual Type**: `svg` · **Description**: Effect of Branching: Straight chain: long, can lie close together; More surface contact: stronger forces; Branched: compact, less surface contact; Weaker forces: lower boiling point.
- **Image Asset Reference**: `None` · **Alt Text**: Effect of Branching: Straight chain: long, can lie close together; More surface contact: stronger forces; Branched: compact, less surface contact; Weaker forces: lower boiling point.
- **Visual Labels**: Straight chain versus branched, Straight chain: long, can lie close together, More surface contact: stronger forces, Branched: compact, less surface contact, Weaker forces: lower boiling point
- **SVG Content**: Present (1585 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [CONTEXT] Built from the photographed coursebook pages; explanations are written for this lesson.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcC1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qC.1`: Why does 2-methylpropane boil at a lower temperature than butane? — Correct: d (a: It forms hydrogen bonds | b: Its covalent bonds are weaker | c: It has fewer electrons | d: Branched molecules have less surface contact, so weaker induced dipole forces)

## Slide 14: `b03` — Why Alkanes Are Unreactive
- **Learning Objective / Purpose**: Explain low reactivity of alkanes and their solubility.
- **Indicators**: H15.3
- **On-Screen Educational Text**:
  - Strong C–C and C–H σ bonds
  - Low polarity; no functional group or π bond
  - High activation energies for many reactions
- **Key Ideas**: Strong C–C and C–H σ bonds | Low polarity; no functional group or π bond | High activation energies for many reactions
- **Complete Narration Text**: The coursebook explains that alkanes are generally unreactive. Several factors combine. The C to C and C to H sigma bonds are strong, so many reactions have high activation energies. Carbon and hydrogen differ very little in electronegativity. The carbon to hydrogen bonds are only weakly polar, so alkanes generally lack strongly electron deficient centres that attract nucleophiles. Alkanes also have no functional group and no exposed pi bond to attract electrophiles. In the test tube on screen, hexane, dyed purple, floats above water and the two layers do not mix, because non polar alkanes are immiscible with polar water. However, alkanes do react with oxygen in combustion, and with halogens in sunlight, as we shall see.
- **Audio Asset Reference**: `audio/b03.3d01793bcde2.mp3` (51s, source: tts)
- **Visual Type**: `svg` · **Description**: Why Alkanes Are Unreactive: hexane layer; (dyed purple); water layer; Non-polar alkanes are immiscible with polar water.
- **Image Asset Reference**: `None` · **Alt Text**: Why Alkanes Are Unreactive: hexane layer; (dyed purple); water layer; Non-polar alkanes are immiscible with polar water.
- **Visual Labels**: Hexane and water do not mix, hexane layer, (dyed purple), water layer, Non-polar alkanes are immiscible with polar water
- **SVG Content**: Present (1803 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p306 Figure 15.5] Hexane and water test tube, unreactivity explanation.
- **Existing Checkpoints After This Slide**: None

## Slide 15: `b04` — Crude Oil and Fractional Distillation
- **Learning Objective / Purpose**: Explain separation of crude oil into fractions.
- **Indicators**: H15.4
- **On-Screen Educational Text**:
  - Crude oil is separated by boiling point
  - Gasoline and naphtha are in high demand
  - Each fraction is still a mixture
- **Key Ideas**: Crude oil is separated by boiling point | Gasoline and naphtha are in high demand | Each fraction is still a mixture
- **Complete Narration Text**: At the refinery, crude oil is separated by fractional distillation in a tall column. The crude oil is heated, and the vapours rise up the column, which is hotter at the bottom and cooler at the top. Each fraction contains hydrocarbons with similar boiling points. Short chains condense near the top, as gases and gasoline, which gives us petrol. Naphtha is the starting material for many other chemicals. The longest chains, such as bitumen, stay at the bottom. Remember that every fraction is itself a mixture, and that this is a physical separation, not a chemical reaction.
- **Audio Asset Reference**: `audio/b04.83b06d7b3da7.mp3` (42s, source: tts)
- **Visual Type**: `svg` · **Description**: Crude Oil and Fractional Distillation: Gases: shortest chains; Petrol (gasoline); Kerosene (jet fuel); Diesel oil; Bitumen: longest chains; cooler; hotter; ↑ crude oil enters.
- **Image Asset Reference**: `None` · **Alt Text**: Crude Oil and Fractional Distillation: Gases: shortest chains; Petrol (gasoline); Kerosene (jet fuel); Diesel oil; Bitumen: longest chains; cooler; hotter; ↑ crude oil enters.
- **Visual Labels**: Fractional distillation of crude oil, Gases: shortest chains, Petrol (gasoline), Kerosene (jet fuel), Diesel oil, Bitumen: longest chains, cooler, hotter, ↑ crude oil enters
- **SVG Content**: Present (2521 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p305 Figure 15.2 box] Fractionating columns; gasoline and naphtha fractions named. Column layout is simplified.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpB` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `sB.1`: In fractional distillation, which fraction is collected nearest the top of the column? — Correct: d (a: The one with the highest boiling point | b: Bitumen | c: The one with the largest molecules | d: The one with the shortest chains and lowest boiling points)
    - [mcq] `sB.2`: Which alkane has the highest boiling point? — Correct: a (a: Pentane | b: Butane | c: Propane | d: Ethane)
    - [mcq] `sB.3`: Why are alkanes generally unreactive? — Correct: d (a: They are ionic compounds | b: Their bonds are very polar | c: They contain double bonds that are hard to break | d: Their C–C and C–H σ bonds are strong with low polarity, and they have no functional group)
    - [mcq] `sB.4`: Which statement best explains why alkanes are generally unreactive towards nucleophiles? — Correct: a (a: Their C–H bonds are only weakly polar, so they lack strongly electron-deficient centres | b: Their molecules carry full positive charges | c: Nucleophiles are always too large to approach | d: Their molecules contain a π bond that repels nucleophiles)
    - [mcq] `sB.5`: Which pair of features helps to explain why alkanes resist attack by electrophiles? — Correct: b (a: Many functional groups and low activation energy | b: Strong σ bonds and no exposed π bond or region of high electron density | c: A C=C bond and strong dipoles | d: Weak C–C bonds and lone pairs)

## Slide 16: `c01` — Complete Combustion
- **Learning Objective / Purpose**: Write equations for complete combustion of alkanes.
- **Indicators**: H15.5
- **On-Screen Educational Text**:
  - Complete combustion: CO₂ and H₂O
  - 2C₈H₁₈ + 25O₂ → 16CO₂ + 18H₂O
  - Balance C, then H, then O
- **Key Ideas**: Complete combustion: CO₂ and H₂O | 2C₈H₁₈ + 25O₂ → 16CO₂ + 18H₂O | Balance C, then H, then O
- **Complete Narration Text**: When an alkane burns in a plentiful supply of oxygen, all the carbon is oxidised to carbon dioxide and all the hydrogen is oxidised to water. This is complete combustion, and it is strongly exothermic. The coursebook uses octane, one of the alkanes in petrol. Two octane molecules react with twenty five oxygen molecules to give sixteen carbon dioxide and eighteen water. The equation can also be written with a half, as one octane plus twelve and a half oxygen giving eight carbon dioxide and nine water. To balance, fix the carbon first, then the hydrogen, and finally the oxygen.
- **Audio Asset Reference**: `audio/c01.360f8ea03e13.mp3` (43s, source: tts)
- **Visual Type**: `svg` · **Description**: Complete Combustion: Alkane + excess O₂ → CO₂ + H₂O; CH₄ + 2O₂ → CO₂ + 2H₂O; 2C₈H₁₈ + 25O₂ → 16CO₂ + 18H₂O; C₈H₁₈ + 12½O₂ → 8CO₂ + 9H₂O.
- **Image Asset Reference**: `None` · **Alt Text**: Complete Combustion: Alkane + excess O₂ → CO₂ + H₂O; CH₄ + 2O₂ → CO₂ + 2H₂O; 2C₈H₁₈ + 25O₂ → 16CO₂ + 18H₂O; C₈H₁₈ + 12½O₂ → 8CO₂ + 9H₂O.
- **Visual Labels**: Complete combustion, Alkane + excess O₂ → CO₂ + H₂O, CH₄ + 2O₂ → CO₂ + 2H₂O, 2C₈H₁₈ + 25O₂ → 16CO₂ + 18H₂O, C₈H₁₈ + 12½O₂ → 8CO₂ + 9H₂O
- **SVG Content**: Present (1517 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p307] Octane complete combustion with both forms of the equation.
- **Existing Checkpoints After This Slide**: None

## Slide 17: `c02` — Incomplete Combustion
- **Learning Objective / Purpose**: Describe incomplete combustion and why carbon monoxide is dangerous.
- **Indicators**: H15.5
- **On-Screen Educational Text**:
  - Limited oxygen gives carbon monoxide
  - CO is colourless, odourless and toxic
  - CO binds to haemoglobin
- **Key Ideas**: Limited oxygen gives carbon monoxide | CO is colourless, odourless and toxic | CO binds to haemoglobin
- **Complete Narration Text**: Inside a car engine, the supply of oxygen is limited, so some of the fuel undergoes incomplete combustion and forms carbon monoxide instead of carbon dioxide. For octane, two molecules react with seventeen oxygen molecules to give sixteen carbon monoxide and eighteen water. Carbon monoxide is a toxic gas that bonds to the haemoglobin in your blood. The haemoglobin can then no longer carry oxygen around the body. Victims feel dizzy, then lose consciousness, and may die. Carbon monoxide is odourless, which is why faulty gas heaters in poorly ventilated rooms are so dangerous.
- **Audio Asset Reference**: `audio/c02.e6d646bac3f8.mp3` (41s, source: tts)
- **Visual Type**: `svg` · **Description**: Incomplete Combustion: Limited O₂: CO (and sometimes C) forms; 2C₈H₁₈ + 17O₂ → 16CO + 18H₂O; C₈H₁₈ + 8½O₂ → 8CO + 9H₂O; CO binds to haemoglobin: oxygen not carried.
- **Image Asset Reference**: `None` · **Alt Text**: Incomplete Combustion: Limited O₂: CO (and sometimes C) forms; 2C₈H₁₈ + 17O₂ → 16CO + 18H₂O; C₈H₁₈ + 8½O₂ → 8CO + 9H₂O; CO binds to haemoglobin: oxygen not carried.
- **Visual Labels**: Incomplete combustion of octane, Limited O₂: CO (and sometimes C) forms, 2C₈H₁₈ + 17O₂ → 16CO + 18H₂O, C₈H₁₈ + 8½O₂ → 8CO + 9H₂O, CO binds to haemoglobin: oxygen not carried
- **SVG Content**: Present (1567 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p307] Incomplete combustion of octane, haemoglobin, faulty heaters.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcD1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qD.1`: Why is carbon monoxide poisonous? — Correct: a (a: It binds to haemoglobin so less oxygen is carried | b: It makes blood too thick | c: It displaces nitrogen from the air | d: It is acidic and burns the lungs)

## Slide 18: `c03` — Pollutants from Burning Fuels
- **Learning Objective / Purpose**: Link pollutants to sources and effects.
- **Indicators**: H15.5
- **On-Screen Educational Text**:
  - NO and NO₂ form from N₂ and O₂ at high temperature
  - Unburnt hydrocarbons (VOCs) escape
  - CO₂ is a greenhouse gas
- **Key Ideas**: NO and NO₂ form from N₂ and O₂ at high temperature | Unburnt hydrocarbons (VOCs) escape | CO₂ is a greenhouse gas
- **Complete Narration Text**: Road traffic releases several pollutants. Carbon monoxide comes from incomplete combustion. In normal combustion, nitrogen in the air is not oxidised, but at the very high temperatures inside car engines, nitrogen and oxygen react to form nitrogen oxides, mainly N O and N O 2. These reactions are reversible. Nitrogen oxides dissolve in rain to form acids and so contribute to acid rain, which kills trees, harms aquatic animals, erodes limestone and corrodes iron. Unburnt hydrocarbons, called volatile organic compounds, may be carcinogenic and contribute to photochemical smog, including P A N. Sulfur dioxide appears when fuels contain sulfur impurities.
- **Audio Asset Reference**: `audio/c03.f5073575eec6.mp3` (43s, source: tts)
- **Visual Type**: `svg` · **Description**: Pollutants from Burning Fuels: Pollutant; Source; Effect; CO; too little O₂; toxic gas; NO, NO₂; hot engine; acid rain; VOCs; unburnt fuel; smog, PAN; CO₂; all burning; warming; SO₂; sulfur in fuel; acid rain.
- **Image Asset Reference**: `None` · **Alt Text**: Pollutants from Burning Fuels: Pollutant; Source; Effect; CO; too little O₂; toxic gas; NO, NO₂; hot engine; acid rain; VOCs; unburnt fuel; smog, PAN; CO₂; all burning; warming; SO₂; sulfur in fuel; acid rain.
- **Visual Labels**: Pollutants from vehicles, Pollutant, Source, Effect, CO, too little O₂, toxic gas, NO, NO₂, hot engine, acid rain, VOCs, unburnt fuel, smog, PAN, CO₂, all burning, warming, SO₂, sulfur in fuel, acid rain
- **SVG Content**: Present (5000 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p307] N2 + O2 ⇌ 2NO, 2NO + O2 ⇌ 2NO2, acid rain, VOCs, PAN. SO2 row is supplementary.
- **Existing Checkpoints After This Slide**: None

## Slide 19: `c04` — Catalytic Converters
- **Learning Objective / Purpose**: Explain the reactions in a catalytic converter.
- **Indicators**: H15.5
- **On-Screen Educational Text**:
  - Pt, Pd or Rh on a honeycomb
  - 2CO + 2NO → 2CO₂ + N₂
  - CO₂ is not removed
- **Key Ideas**: Pt, Pd or Rh on a honeycomb | 2CO + 2NO → 2CO₂ + N₂ | CO₂ is not removed
- **Complete Narration Text**: Look at the catalytic converter on screen. Precious metals such as platinum are coated on a honeycomb structure, which gives a large surface area for reactions. Once warm, it carries out three changes. Carbon monoxide is oxidised to carbon dioxide. Nitrogen oxides are reduced to harmless nitrogen. Unburnt hydrocarbons are oxidised to carbon dioxide and water. One equation is two C O plus two N O giving two C O 2 plus N 2. Some carbon monoxide is also oxidised by oxygen. Notice that the converter cannot reduce carbon dioxide, a greenhouse gas. In fact, removing carbon monoxide releases more carbon dioxide, which contributes to global warming.
- **Audio Asset Reference**: `audio/c04.8e38896519a2.mp3` (47s, source: tts)
- **Visual Type**: `svg` · **Description**: Catalytic Converters: Pt, Pd or Rh on a honeycomb; CO; NO; unburnt HC; CO₂; N₂; CO₂ + H₂O; 2CO + 2NO → 2CO₂ + N₂; CO₂ is still released: it is a greenhouse gas.
- **Image Asset Reference**: `None` · **Alt Text**: Catalytic Converters: Pt, Pd or Rh on a honeycomb; CO; NO; unburnt HC; CO₂; N₂; CO₂ + H₂O; 2CO + 2NO → 2CO₂ + N₂; CO₂ is still released: it is a greenhouse gas.
- **Visual Labels**: Catalytic converter: gases in and out, Pt, Pd or Rh on a honeycomb, CO, NO, unburnt HC, CO₂, N₂, CO₂ + H₂O, 2CO + 2NO → 2CO₂ + N₂, CO₂ is still released: it is a greenhouse gas
- **SVG Content**: Present (3601 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p308 Figure 15.9] Three converter reactions; 2CO + O2 → 2CO2 also given.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpC` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `sC.1`: What are the products of the complete combustion of ethane? — Correct: a (a: Carbon dioxide and water | b: Carbon monoxide and water | c: Carbon dioxide only | d: Carbon and hydrogen)
    - [mcq] `sC.2`: 20 cm³ of propane burns completely. What volume of oxygen is needed, at the same temperature and pressure? — Correct: a (a: 100 cm³ | b: 120 cm³ | c: 40 cm³ | d: 60 cm³)
    - [mcq] `sC.3`: What does a catalytic converter do to nitrogen monoxide, NO? — Correct: b (a: Oxidises it to NO₂ | b: Reduces it to nitrogen | c: Converts it to ammonia | d: Dissolves it in water)
    - [mcq] `sC.4`: Which pollutant from sulfur impurities in fuels contributes to acid rain? — Correct: d (a: Unburnt hydrocarbons | b: CO₂ | c: CO | d: SO₂)

## Slide 20: `d01` — Free-Radical Substitution: Overview
- **Learning Objective / Purpose**: Introduce radicals and the three stages.
- **Indicators**: H15.6
- **On-Screen Educational Text**:
  - Alkane + halogen in UV light
  - Radical: unpaired electron
  - Initiation, propagation, termination
- **Key Ideas**: Alkane + halogen in UV light | Radical: unpaired electron | Initiation, propagation, termination
- **Complete Narration Text**: Alkanes do not react with chlorine in the dark, but in ultraviolet light they undergo substitution, which means one atom is swapped for another. Methane and chlorine make chloromethane and hydrogen chloride. The mechanism involves free radicals. A free radical is an atom or group with an unpaired electron, and radicals are very reactive. The reaction is a chain reaction with three stages. Initiation makes radicals. Propagation uses a radical and makes another, so the chain keeps going. Termination removes radicals when two of them meet. We write a radical with a dot to show the unpaired electron.
- **Audio Asset Reference**: `audio/d01.c2027cb96a72.mp3` (43s, source: tts)
- **Visual Type**: `svg` · **Description**: Free-Radical Substitution: Overview: 1 Initiation: Cl₂ → 2Cl• (UV light); 2 Propagation: a chain reaction of two steps; 3 Termination: radicals form a molecule; Radical = species with an unpaired electron.
- **Image Asset Reference**: `None` · **Alt Text**: Free-Radical Substitution: Overview: 1 Initiation: Cl₂ → 2Cl• (UV light); 2 Propagation: a chain reaction of two steps; 3 Termination: radicals form a molecule; Radical = species with an unpaired electron.
- **Visual Labels**: Free-radical substitution: three stages, 1 Initiation: Cl₂ → 2Cl• (UV light), 2 Propagation: a chain reaction of two steps, 3 Termination: radicals form a molecule, Radical = species with an unpaired electron
- **SVG Content**: Present (1901 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [CONTEXT] Built from the photographed coursebook pages; explanations are written for this lesson.
- **Existing Checkpoints After This Slide**: None

## Slide 21: `d02` — Initiation and Propagation
- **Learning Objective / Purpose**: Write the initiation and propagation steps for methane and chlorine.
- **Indicators**: H15.6
- **On-Screen Educational Text**:
  - Initiation: homolytic fission of Cl₂
  - Propagation uses and regenerates radicals
  - Overall: CH₄ + Cl₂ → CH₃Cl + HCl
- **Key Ideas**: Initiation: homolytic fission of Cl₂ | Propagation uses and regenerates radicals | Overall: CH₄ + Cl₂ → CH₃Cl + HCl
- **Complete Narration Text**: In initiation, ultraviolet light supplies the energy to break the Cl to Cl bond by homolytic fission. In homolytic fission the bonding pair is shared equally, so each chlorine atom gets one electron, giving two chlorine radicals. In the first propagation step, a chlorine radical takes a hydrogen atom from methane, forming hydrogen chloride and a methyl radical. In the second propagation step, the methyl radical removes a chlorine atom from a chlorine molecule, forming chloromethane and a new chlorine radical. That new radical repeats step one, so the chain continues. Adding the two propagation steps gives the overall equation.
- **Audio Asset Reference**: `audio/d02.97b51531342a.mp3` (43s, source: tts)
- **Visual Type**: `svg` · **Description**: Initiation and Propagation: Initiation: Cl₂ → 2Cl•; Propagation 1: Cl• + CH₄ → •CH₃ + HCl; Propagation 2: •CH₃ + Cl₂ → CH₃Cl + Cl•; Overall: CH₄ + Cl₂ → CH₃Cl + HCl.
- **Image Asset Reference**: `None` · **Alt Text**: Initiation and Propagation: Initiation: Cl₂ → 2Cl•; Propagation 1: Cl• + CH₄ → •CH₃ + HCl; Propagation 2: •CH₃ + Cl₂ → CH₃Cl + Cl•; Overall: CH₄ + Cl₂ → CH₃Cl + HCl.
- **Visual Labels**: Methane and chlorine, Initiation: Cl₂ → 2Cl•, Propagation 1: Cl• + CH₄ → •CH₃ + HCl, Propagation 2: •CH₃ + Cl₂ → CH₃Cl + Cl•, Overall: CH₄ + Cl₂ → CH₃Cl + HCl
- **SVG Content**: Present (1541 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [CONTEXT] Built from the photographed coursebook pages; explanations are written for this lesson.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcE1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [tapDiagram] `qE.1`: Tap the row that shows the initiation step. — Hotspot: h1

## Slide 22: `d02b` — Methane and Bromine: Initiation and Propagation
- **Learning Objective / Purpose**: Draw the first two stages with fishhook arrows.
- **Indicators**: H15.6
- **On-Screen Educational Text**:
  - Initiation: Br₂ → 2Br• (UV light)
  - Propagation 1: Br• + CH₄ → HBr + •CH₃
  - Propagation 2: •CH₃ + Br₂ → CH₃Br + Br•
- **Key Ideas**: Initiation: Br₂ → 2Br• (UV light) | Propagation 1: Br• + CH₄ → HBr + •CH₃ | Propagation 2: •CH₃ + Br₂ → CH₃Br + Br•
- **Complete Narration Text**: The overall reaction is methane plus bromine giving bromomethane and hydrogen bromide, in ultraviolet light. In initiation, the Br to Br bond breaks homolytically. Each fishhook arrow shows one electron moving, so two bromine radicals form, each with an unpaired electron shown as a dot. In propagation step one, a bromine radical removes a hydrogen atom from methane, forming hydrogen bromide and a methyl radical. In propagation step two, the methyl radical attacks a bromine molecule, forming bromomethane and a new bromine radical. That new radical can repeat step one, so the chain reaction continues. In each propagation step we start with a molecule and a radical, and finish with a different molecule and a different radical.
- **Audio Asset Reference**: `audio/d02b.23125a91e03d.mp3` (51s, source: tts)
- **Visual Type**: `svg` · **Description**: Methane and Bromine: Initiation and Propagation: Br; UV light; H–CH₃; propagation 1; H–Br; +; CH₃; Br–Br; propagation 2; CH₃–Br.
- **Image Asset Reference**: `None` · **Alt Text**: Methane and Bromine: Initiation and Propagation: Br; UV light; H–CH₃; propagation 1; H–Br; +; CH₃; Br–Br; propagation 2; CH₃–Br.
- **Visual Labels**: Methane + bromine: initiation and propagation, Br, UV light, H–CH₃, propagation 1, H–Br, +, CH₃, Br–Br, propagation 2, CH₃–Br
- **SVG Content**: Present (4679 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p309–310, p320 Q3] Methane + bromine mechanism, exam-style. Equations match the revision brief.
- **Existing Checkpoints After This Slide**: None

## Slide 23: `d03` — Termination Steps
- **Learning Objective / Purpose**: Write termination steps and explain the product mixture.
- **Indicators**: H15.6
- **On-Screen Educational Text**:
  - Termination: radicals form a molecule
  - Ethane can form as a by-product
  - Further substitution gives a mixture
- **Key Ideas**: Termination: radicals form a molecule | Ethane can form as a by-product | Further substitution gives a mixture
- **Complete Narration Text**: Termination happens when two radicals meet and combine, which removes radicals from the reaction. Two chlorine radicals form chlorine, a chlorine radical and a methyl radical form chloromethane, and two methyl radicals form ethane. Notice that ethane is a by-product, and its presence is good evidence for this mechanism. The reaction does not stop at one substitution. Chloromethane can also be attacked by chlorine radicals to give dichloromethane, then trichloromethane and tetrachloromethane. So free radical substitution always gives a mixture of products. Using a large excess of methane makes mono substitution more likely.
- **Audio Asset Reference**: `audio/d03.87ecdee2b25e.mp3` (40s, source: tts)
- **Visual Type**: `svg` · **Description**: Termination Steps: Cl• + Cl• → Cl₂; •CH₃ + Cl• → CH₃Cl; •CH₃ + •CH₃ → C₂H₆; More Cl: CH₂Cl₂, CHCl₃, CCl₄ also form.
- **Image Asset Reference**: `None` · **Alt Text**: Termination Steps: Cl• + Cl• → Cl₂; •CH₃ + Cl• → CH₃Cl; •CH₃ + •CH₃ → C₂H₆; More Cl: CH₂Cl₂, CHCl₃, CCl₄ also form.
- **Visual Labels**: Termination and mixtures, Cl• + Cl• → Cl₂, •CH₃ + Cl• → CH₃Cl, •CH₃ + •CH₃ → C₂H₆, More Cl: CH₂Cl₂, CHCl₃, CCl₄ also form
- **SVG Content**: Present (1508 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [CONTEXT] Built from the photographed coursebook pages; explanations are written for this lesson.
- **Existing Checkpoints After This Slide**: None

## Slide 24: `d03b` — Methane and Bromine: Termination
- **Learning Objective / Purpose**: Draw termination steps.
- **Indicators**: H15.6
- **On-Screen Educational Text**:
  - Termination: two radicals meet
  - They form one non-radical product
  - Those radicals leave the chain reaction
- **Key Ideas**: Termination: two radicals meet | They form one non-radical product | Those radicals leave the chain reaction
- **Complete Narration Text**: Termination steps are the final steps of the mechanism. Whenever two free radicals meet, they react with each other, and form a single non radical product. This removes those two radicals from the chain reaction, although other radicals in the mixture may still continue propagation. Look at the three examples on screen. Two bromine radicals combine to give a bromine molecule. A methyl radical and a bromine radical combine to give bromomethane. Two methyl radicals combine to give ethane. In each case two radicals go in and no radicals come out, which is the opposite of propagation, where a radical is regenerated. Notice each product molecule has all its electrons paired.
- **Audio Asset Reference**: `audio/d03b.6684924c02aa.mp3` (48s, source: tts)
- **Visual Type**: `svg` · **Description**: Methane and Bromine: Termination: Br; one product; Br–Br; CH₃; CH₃–Br; C₂H₆.
- **Image Asset Reference**: `None` · **Alt Text**: Methane and Bromine: Termination: Br; one product; Br–Br; CH₃; CH₃–Br; C₂H₆.
- **Visual Labels**: Methane + bromine: termination, Br, one product, Br–Br, CH₃, CH₃–Br, C₂H₆
- **SVG Content**: Present (3888 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p309 Termination steps; p310 Important box] Two free radicals → molecule, no radicals.
- **Existing Checkpoints After This Slide**: None

## Slide 25: `d04` — Mixtures and Longer Alkanes
- **Learning Objective / Purpose**: Predict products with longer alkanes and bromine.
- **Indicators**: H15.6
- **On-Screen Educational Text**:
  - Ethane and chlorine: several products possible
  - More Cl₂ gives more substitution
  - Mixtures are common, so it is a poor route to one pure product
- **Key Ideas**: Ethane and chlorine: several products possible | More Cl₂ gives more substitution | Mixtures are common, so it is a poor route to one pure product
- **Complete Narration Text**: The coursebook uses ethane and chlorine. A chlorine radical removes a hydrogen atom from ethane, forming hydrogen chloride and an ethyl radical. The ethyl radical attacks a chlorine molecule, giving chloroethane and a new chlorine radical. The chain does not have to stop there. Chlorine radicals can attack the chloroethane already formed, giving a variety of dichloroethanes, then trichloroethanes and so on. With enough chlorine we eventually get hexachloroethane. The more chlorine in the mixture, the more chlorine atoms the products contain. For this reason, the reaction is not a good way to prepare a pure sample of one halogenoalkane.
- **Audio Asset Reference**: `audio/d04.95f563c5d305.mp3` (43s, source: tts)
- **Visual Type**: `svg` · **Description**: Mixtures and Longer Alkanes: Cl• + CH₃CH₃ → •CH₂CH₃ + HCl; •CH₂CH₃ + Cl₂ → CH₃CH₂Cl + Cl•; Further steps: 1,1- and 1,2-dichloroethane; Excess Cl₂ can reach C₂Cl₆.
- **Image Asset Reference**: `None` · **Alt Text**: Mixtures and Longer Alkanes: Cl• + CH₃CH₃ → •CH₂CH₃ + HCl; •CH₂CH₃ + Cl₂ → CH₃CH₂Cl + Cl•; Further steps: 1,1- and 1,2-dichloroethane; Excess Cl₂ can reach C₂Cl₆.
- **Visual Labels**: Substitution in ethane, Cl• + CH₃CH₃ → •CH₂CH₃ + HCl, •CH₂CH₃ + Cl₂ → CH₃CH₂Cl + Cl•, Further steps: 1,1- and 1,2-dichloroethane, Excess Cl₂ can reach C₂Cl₆
- **SVG Content**: Present (1541 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p309] Ethane + chlorine propagation, mixture of chloroalkanes, hexachloroethane. Replaces the earlier absolute statement that substitution always gives a mixture.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpD` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `sD.1`: Which is a termination step? — Correct: a (a: •CH₃ + •CH₃ → C₂H₆ | b: •CH₃ + Cl₂ → CH₃Cl + Cl• | c: Cl₂ → 2Cl• | d: Cl• + CH₄ → •CH₃ + HCl)
    - [mcq] `sD.2`: What type of bond fission occurs in the initiation step? — Correct: a (a: Homolytic fission | b: No bond is broken | c: Ionic fission | d: Heterolytic fission)
    - [mcq] `sD.3`: Which condition is essential for methane to react with chlorine? — Correct: a (a: Ultraviolet light | b: A nickel catalyst | c: Hot concentrated KMnO₄ | d: High pressure)
    - [mcq] `sD.4`: What is a free radical? — Correct: c (a: A species with a positive charge and an empty orbital | b: An atom with a full outer shell | c: A species with an unpaired electron | d: A molecule containing a C=C bond)
    - [mcq] `sD.5`: Which equation is a propagation step in methane + bromine? — Correct: c (a: Br₂ → 2Br• | b: •CH₃ + Br• → CH₃Br | c: Br• + CH₄ → HBr + •CH₃ | d: 2Br• → Br₂)

## Slide 26: `e01` — Cracking
- **Learning Objective / Purpose**: Define cracking and explain why it is used.
- **Indicators**: H15.7
- **On-Screen Educational Text**:
  - Cracking breaks long chains into shorter ones
  - Produces shorter alkanes and alkenes
  - Alkene products are valuable feedstock
- **Key Ideas**: Cracking breaks long chains into shorter ones | Produces shorter alkanes and alkenes | Alkene products are valuable feedstock
- **Complete Narration Text**: Cracking is the process in which large, less useful hydrocarbon molecules are broken down into smaller, more useful molecules in an oil refinery. Lighter fractions, such as gasoline, are in high demand, and chemical engineers convert some of the excess heavier fractions into them. In the coursebook, large molecules are heated to a high temperature in a steel chamber with no oxygen, so combustion does not occur, and passed over an aluminium oxide catalyst. One example gives C 10 H 22 forming C 6 H 14 plus C 4 H 8. Cracking produces smaller alkanes and alkenes. The exact mixture depends on the feedstock, catalyst and conditions. The alkenes are very useful as the feedstock for plastics.
- **Audio Asset Reference**: `audio/e01.cc99dbe3ffbb.mp3` (51s, source: tts)
- **Visual Type**: `svg` · **Description**: Cracking: Large alkane → smaller alkane + alkene; C₁₀H₂₂ → C₆H₁₄ + C₄H₈ (coursebook); C₁₀H₂₂ → C₈H₁₈ + C₂H₄ (another example); Why: lighter fuels and alkenes for plastics.
- **Image Asset Reference**: `None` · **Alt Text**: Cracking: Large alkane → smaller alkane + alkene; C₁₀H₂₂ → C₆H₁₄ + C₄H₈ (coursebook); C₁₀H₂₂ → C₈H₁₈ + C₂H₄ (another example); Why: lighter fuels and alkenes for plastics.
- **Visual Labels**: Cracking over Al₂O₃ with heat, Large alkane → smaller alkane + alkene, C₁₀H₂₂ → C₆H₁₄ + C₄H₈ (coursebook), C₁₀H₂₂ → C₈H₁₈ + C₂H₄ (another example), Why: lighter fuels and alkenes for plastics
- **SVG Content**: Present (1583 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p310] Cracking key word, Al2O3 catalyst and heat, C10H22 → C6H14 + C4H8.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcF1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qF.1`: Which equation shows cracking? — Correct: b (a: CH₄ + Cl₂ → CH₃Cl + HCl | b: C₁₀H₂₂ → C₈H₁₈ + C₂H₄ | c: C₂H₄ + H₂ → C₂H₆ | d: C₃H₈ + 5O₂ → 3CO₂ + 4H₂O)

## Slide 27: `e02` — Cracking Conditions and Products
- **Learning Objective / Purpose**: Compare conditions and products of cracking methods.
- **Indicators**: H15.7
- **On-Screen Educational Text**:
  - Coursebook: high temperature, Al₂O₃ catalyst, no oxygen
  - Industrial catalytic cracking uses zeolites
  - Exact product mixture varies
- **Key Ideas**: Coursebook: high temperature, Al₂O₃ catalyst, no oxygen | Industrial catalytic cracking uses zeolites | Exact product mixture varies
- **Complete Narration Text**: The coursebook describes cracking with three features. There is no oxygen, so the hydrocarbons do not burn. The temperature is high. And an aluminium oxide catalyst is used. In industry, catalytic crackers often use zeolite catalysts at about four hundred and fifty degrees Celsius, and thermal cracking uses higher temperatures and pressure without a catalyst. These numbers are representative operating conditions, not fixed values. The products are smaller alkanes, used as fuels, and alkenes, used for chemicals and polymers. Their proportions depend on the feedstock, the catalyst and the conditions, so be careful not to say that one fixed set of products always forms.
- **Audio Asset Reference**: `audio/e02.f316e6f48e29.mp3` (45s, source: tts)
- **Visual Type**: `svg` · **Description**: Cracking Conditions and Products: Feature; Typical detail; Oxygen; none; Temperature; high; Catalyst; Al₂O₃ (book); Industry; zeolite common; Products; alkanes + alkenes.
- **Image Asset Reference**: `None` · **Alt Text**: Cracking Conditions and Products: Feature; Typical detail; Oxygen; none; Temperature; high; Catalyst; Al₂O₃ (book); Industry; zeolite common; Products; alkanes + alkenes.
- **Visual Labels**: Cracking conditions, Feature, Typical detail, Oxygen, none, Temperature, high, Catalyst, Al₂O₃ (book), Industry, zeolite common, Products, alkanes + alkenes
- **SVG Content**: Present (3484 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p310] Al2O3 + heat + no oxygen. [SUPPLEMENTARY] zeolite and about 450 °C and thermal cracking values are typical industrial detail, not taken from the photographed pages.
- **Existing Checkpoints After This Slide**: None

## Slide 28: `e03` — Completing Cracking Equations
- **Learning Objective / Purpose**: Deduce missing products by conserving atoms.
- **Indicators**: H15.7
- **On-Screen Educational Text**:
  - Count carbon atoms on each side
  - Count hydrogen atoms on each side
  - The missing product is what is left over
- **Key Ideas**: Count carbon atoms on each side | Count hydrogen atoms on each side | The missing product is what is left over
- **Complete Narration Text**: To complete a cracking equation, conserve atoms. Count the carbon atoms and hydrogen atoms in the large molecule, subtract those in the known product, and what is left is the missing product. In the first example, twelve carbons minus eight leaves four, and twenty six hydrogens minus eighteen leaves eight, so the missing product is C 4 H 8, an alkene. In the second, nine carbons minus seven leaves two, and twenty hydrogens minus sixteen leaves four, so the missing product is C 2 H 4, ethene. In the third, the leftover is four carbons and eight hydrogens, which can be two molecules of C 2 H 4. Finally, check that all carbon and hydrogen atoms are conserved and that your products are consistent with those given in the question.
- **Audio Asset Reference**: `audio/e03.c22f55393704.mp3` (57s, source: tts)
- **Visual Type**: `svg` · **Description**: Completing Cracking Equations: C₁₂H₂₆ → C₈H₁₈ + ?  Answer: C₄H₈; C₉H₂₀ → C₇H₁₆ + ?  Answer: C₂H₄; C₁₅H₃₂ → C₁₁H₂₄ + ?  Answer: 2C₂H₄; C₁₈H₃₆: alkene with 18 carbons, one C=C.
- **Image Asset Reference**: `None` · **Alt Text**: Completing Cracking Equations: C₁₂H₂₆ → C₈H₁₈ + ?  Answer: C₄H₈; C₉H₂₀ → C₇H₁₆ + ?  Answer: C₂H₄; C₁₅H₃₂ → C₁₁H₂₄ + ?  Answer: 2C₂H₄; C₁₈H₃₆: alkene with 18 carbons, one C=C.
- **Visual Labels**: Find the missing product, C₁₂H₂₆ → C₈H₁₈ + ?  Answer: C₄H₈, C₉H₂₀ → C₇H₁₆ + ?  Answer: C₂H₄, C₁₅H₃₂ → C₁₁H₂₄ + ?  Answer: 2C₂H₄, C₁₈H₃₆: alkene with 18 carbons, one C=C
- **SVG Content**: Present (1555 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p311 Question 4b, d] Alkene formula; nonane → heptane + ethene. Other examples are original.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpE` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `sE.1`: Why is catalytic cracking often preferred to thermal cracking? — Correct: d (a: It makes only alkenes | b: It requires a higher pressure | c: It uses no catalyst | d: It runs at a lower temperature and gives useful branched alkanes)
    - [mcq] `sE.2`: C₁₂H₂₆ → C₈H₁₈ + X. What is X? — Correct: b (a: C₄H₆ | b: C₄H₈ | c: C₄H₁₀ | d: C₅H₁₀)
    - [mcq] `sE.3`: Why is cracking carried out? — Correct: d (a: To remove all sulfur | b: To make alkane chains longer | c: To raise the boiling point of fuels | d: To convert long, less useful chains into shorter, more useful molecules)

## Slide 29: `f01` — Alkenes: The Double Bond
- **Learning Objective / Purpose**: Describe the C=C bond: sigma plus pi, planar, 120°.
- **Indicators**: H15.8
- **On-Screen Educational Text**:
  - Open-chain alkene with one C=C: CₙH₂ₙ
  - σ bond: head-on overlap
  - π bond: sideways overlap of p orbitals
- **Key Ideas**: Open-chain alkene with one C=C: CₙH₂ₙ | σ bond: head-on overlap | π bond: sideways overlap of p orbitals
- **Complete Narration Text**: Alkenes are unsaturated hydrocarbons. An open chain alkene with one double bond has the general formula C n H 2 n, and ethene, C 2 H 4, is the first member. The double bond has two parts. The sigma bond is formed by head on overlap of orbitals along the line between the nuclei, as in the left diagram. The pi bond is formed by sideways overlap of p orbitals, as in the right diagram, and it puts electron density above and below the plane of the molecule. Each carbon in the double bond has three bonding regions, so the atoms around it are planar with bond angles of about 120 degrees. Rotation about the double bond is restricted.
- **Audio Asset Reference**: `audio/f01.83b3a1db8578.mp3` (52s, source: tts)
- **Visual Type**: `svg` · **Description**: Alkenes: The Double Bond: C; σ bond; head-on overlap; on the bond axis; π bond; sideways overlap; above and below the plane.
- **Image Asset Reference**: `None` · **Alt Text**: Alkenes: The Double Bond: C; σ bond; head-on overlap; on the bond axis; π bond; sideways overlap; above and below the plane.
- **Visual Labels**: σ bond and π bond in ethene, C, σ bond, head-on overlap, on the bond axis, π bond, sideways overlap, above and below the plane
- **SVG Content**: Present (3284 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p310, p313, p321 Q6] Alkene definition, sigma and pi bond, ethene shape and bond angles. Orbital diagram is schematic.
- **Existing Checkpoints After This Slide**: None

## Slide 30: `f02` — Why Alkenes Are Reactive
- **Learning Objective / Purpose**: Explain reactivity and naming of alkenes.
- **Indicators**: H15.8
- **On-Screen Educational Text**:
  - Parent chain must contain the C=C
  - Number to give C=C the lowest locant
  - High electron density attracts electrophiles
- **Key Ideas**: Parent chain must contain the C=C | Number to give C=C the lowest locant | High electron density attracts electrophiles
- **Complete Narration Text**: Alkenes are more reactive than alkanes because of the pi bond. The four electrons in the double bond create an area of high electron density, which attracts electrophiles. An electrophile is a species that accepts a pair of electrons. Simple hydrocarbon alkenes are non polar or only weakly polar overall, but the exposed pi electrons still make them open to attack. When an alkene reacts, one bond of the double bond breaks, and a new single bond forms to each carbon, which is called addition. To name an alkene, the parent chain must contain the double bond. Number from the end that gives the double bond the lowest number, as in but 1 ene and but 2 ene.
- **Audio Asset Reference**: `audio/f02.8f91cd01e318.mp3` (51s, source: tts)
- **Visual Type**: `svg` · **Description**: Why Alkenes Are Reactive: π electrons are above and below the bond; π bond is weaker than σ bond; Attracts electrophiles: addition reactions; Naming: but-1-ene, but-2-ene, propene.
- **Image Asset Reference**: `None` · **Alt Text**: Why Alkenes Are Reactive: π electrons are above and below the bond; π bond is weaker than σ bond; Attracts electrophiles: addition reactions; Naming: but-1-ene, but-2-ene, propene.
- **Visual Labels**: Alkenes are more reactive than alkanes, π electrons are above and below the bond, π bond is weaker than σ bond, Attracts electrophiles: addition reactions, Naming: but-1-ene, but-2-ene, propene
- **SVG Content**: Present (1594 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p311, p314] Addition reactions; four electrons in the double bond; electrophiles attack.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcG1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qG.1`: Why are alkenes more reactive than alkanes? — Correct: a (a: The π bond is weaker and has exposed high electron density | b: They are polar molecules | c: They have more hydrogen atoms | d: Their C–H bonds are weaker)

## Slide 31: `f03` — Testing for Unsaturation
- **Learning Objective / Purpose**: Describe the bromine water test.
- **Indicators**: H15.8
- **On-Screen Educational Text**:
  - Shake the compound with bromine water
  - Alkene: orange to colourless
  - Alkane: stays orange
- **Key Ideas**: Shake the compound with bromine water | Alkene: orange to colourless | Alkane: stays orange
- **Complete Narration Text**: To test whether a compound is unsaturated, shake it with bromine water. Bromine water is orange or yellow, depending on its concentration. Look at the three test tubes. On the left is the bromine water. In the middle, an alkene has been added and shaken, and the mixture is colourless. On the right an alkane has been added, and the mixture stays orange. In the examination, state the colour change fully: orange to colourless. Do not say clear. The simple equation is that bromine adds across the double bond to give a dibromoalkane. In aqueous solution, other products can form too, but you need only the dibromo product for this course.
- **Audio Asset Reference**: `audio/f03.9e2154f3c986.mp3` (48s, source: tts)
- **Visual Type**: `svg` · **Description**: Testing for Unsaturation: Br₂(aq); orange; + alkene; colourless; + alkane; stays orange; Unsaturated: orange to colourless.
- **Image Asset Reference**: `None` · **Alt Text**: Testing for Unsaturation: Br₂(aq); orange; + alkene; colourless; + alkane; stays orange; Unsaturated: orange to colourless.
- **Visual Labels**: Bromine water test, Br₂(aq), orange, + alkene, colourless, + alkane, stays orange, Unsaturated: orange to colourless
- **SVG Content**: Present (2562 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p313 Figure 15.17] Bromine water test tubes. [ENRICHMENT] bromohydrin note.
- **Existing Checkpoints After This Slide**: None

## Slide 32: `f04` — Alkene Isomerism: cis and trans
- **Learning Objective / Purpose**: Show cis/trans isomerism in alkenes.
- **Indicators**: H15.8
- **On-Screen Educational Text**:
  - Position isomers: but-1-ene and but-2-ene
  - cis/trans: same side or opposite sides
  - E/Z uses priorities; but-2-ene cis = Z, trans = E
- **Key Ideas**: Position isomers: but-1-ene and but-2-ene | cis/trans: same side or opposite sides | E/Z uses priorities; but-2-ene cis = Z, trans = E
- **Complete Narration Text**: Alkenes show two kinds of isomerism. Position isomers, such as but 1 ene and but 2 ene, have the double bond in a different place. Alkenes can also show cis and trans isomerism. In cis but 2 ene, the two methyl groups are on the same side of the double bond. In trans but 2 ene, they are on opposite sides. The more general E and Z system uses the priorities of the groups on each carbon: Z means the higher priority groups are on the same side, and E means opposite sides. For but 2 ene, cis is Z and trans is E. This happens because the pi bond stops rotation about the double bond, so one isomer cannot turn into the other at room temperature. Each carbon of the double bond must have two different groups.
- **Audio Asset Reference**: `audio/f04.6de80dffdaed.mp3` (60s, source: tts)
- **Visual Type**: `svg` · **Description**: Alkene Isomerism: cis and trans: C; CH₃; H; cis-but-2-ene (Z); trans-but-2-ene (E); CH₃ groups on the same side; CH₃ groups on opposite sides; No rotation about C=C, so no interconversion.
- **Image Asset Reference**: `None` · **Alt Text**: Alkene Isomerism: cis and trans: C; CH₃; H; cis-but-2-ene (Z); trans-but-2-ene (E); CH₃ groups on the same side; CH₃ groups on opposite sides; No rotation about C=C, so no interconversion.
- **Visual Labels**: cis and trans isomers of but-2-ene, C, CH₃, H, cis-but-2-ene (Z), trans-but-2-ene (E), CH₃ groups on the same side, CH₃ groups on opposite sides, No rotation about C=C, so no interconversion
- **SVG Content**: Present (4377 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p321 Q5 cis/trans pent-2-ene] E/Z revision is brief; [VERIFY] syllabus requirement. Syllabus 9701 (2025–2027), as summarised from the Cambridge PDF by WebFetch: cis/trans isomerism and restricted rotation are required (13.4); E/Z is acceptable but not required. [VERIFY] against the PDF itself.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpF` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `sF.1`: What is observed when an alkene is shaken with bromine water? — Correct: d (a: No change | b: Orange to clear | c: Colourless to orange | d: Orange to colourless)
    - [mcq] `sF.2`: What is the approximate bond angle around each carbon of the C=C in ethene? — Correct: c (a: 180° | b: 90° | c: 120° | d: 109.5°)

## Slide 33: `g01` — Addition Reactions of Alkenes
- **Learning Objective / Purpose**: Summarise reagents, conditions and products.
- **Indicators**: H15.9
- **On-Screen Educational Text**:
  - Reagent adds across the C=C bond
  - H₂ with Pt/Ni and heat; HX(aq); steam with H₃PO₄; X₂(aq)
  - Product has only single bonds
- **Key Ideas**: Reagent adds across the C=C bond | H₂ with Pt/Ni and heat; HX(aq); steam with H₃PO₄; X₂(aq) | Product has only single bonds
- **Complete Narration Text**: In an addition reaction, one of the two bonds in the carbon to carbon double bond breaks, and a new single bond forms from each of the two carbon atoms. The general reaction is the alkene plus X Y giving a saturated product with X on one carbon and Y on the other. With hydrogen over a finely divided platinum or nickel catalyst, with heat, an alkane forms. With a concentrated hydrogen halide solution at room temperature, a halogenoalkane forms. With steam, using concentrated phosphoric acid as catalyst at high temperature and pressure, an alcohol forms. With chlorine or bromine solution at room temperature, a dihalogenoalkane forms. Learn every reagent, condition and product.
- **Audio Asset Reference**: `audio/g01.fa30c98ad8d0.mp3` (49s, source: tts)
- **Visual Type**: `svg` · **Description**: Addition Reactions of Alkenes: Reagent; Conditions; Product; H₂; Pt/Ni, heat; alkane; HBr(aq), HCl; room temp.; halogenoalkane; steam; H₃PO₄, high T, P; alcohol; X₂(aq); room temp.; dihaloalkane.
- **Image Asset Reference**: `None` · **Alt Text**: Addition Reactions of Alkenes: Reagent; Conditions; Product; H₂; Pt/Ni, heat; alkane; HBr(aq), HCl; room temp.; halogenoalkane; steam; H₃PO₄, high T, P; alcohol; X₂(aq); room temp.; dihaloalkane.
- **Visual Labels**: Alkene addition reactions, Reagent, Conditions, Product, H₂, Pt/Ni, heat, alkane, HBr(aq), HCl, room temp., halogenoalkane, steam, H₃PO₄, high T, P, alcohol, X₂(aq), room temp., dihaloalkane
- **SVG Content**: Present (4262 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p311–313 Figure 15.12] General addition; conditions as photographed. Specific temperature and pressure for steam are supplementary (next slides).
- **Existing Checkpoints After This Slide**: None

## Slide 34: `g02` — Hydrogenation
- **Learning Objective / Purpose**: Write equations for adding H₂ and steam to ethene.
- **Indicators**: H15.9
- **On-Screen Educational Text**:
  - Ethene + H₂ → ethane, Pt or Ni, heat
  - π bond lost; two new C–H bonds
  - Margarine: partial hydrogenation of oils
- **Key Ideas**: Ethene + H₂ → ethane, Pt or Ni, heat | π bond lost; two new C–H bonds | Margarine: partial hydrogenation of oils
- **Complete Narration Text**: Hydrogenation is the addition reaction of alkenes with hydrogen. When ethene and hydrogen gas are heated and passed over a finely divided platinum or nickel catalyst, ethane forms. On screen, the new carbon hydrogen bonds are in red. The pi bond has gone, but the carbon to carbon sigma bond remains. This reaction is used in margarine manufacture. Unsaturated oils, such as sunflower oil, have hydrocarbon chains with several double bonds. They are partially hydrogenated, which straightens the chains, raises the melting point, and changes the liquid into a soft solid that spreads easily. Not every double bond reacts, so the product is partially saturated.
- **Audio Asset Reference**: `audio/g02.1ca030b26937.mp3` (46s, source: tts)
- **Visual Type**: `svg` · **Description**: Hydrogenation: C; H; +; H–H; Pt or Ni; heat; π bond lost: two new C–H bonds form (red); C–C σ bond stays; product is ethane, C₂H₆.
- **Image Asset Reference**: `None` · **Alt Text**: Hydrogenation: C; H; +; H–H; Pt or Ni; heat; π bond lost: two new C–H bonds form (red); C–C σ bond stays; product is ethane, C₂H₆.
- **Visual Labels**: Hydrogenation of ethene, C, H, +, H–H, Pt or Ni, heat, π bond lost: two new C–H bonds form (red), C–C σ bond stays; product is ethane, C₂H₆
- **SVG Content**: Present (4908 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p312 Figure 15.13] Hydrogenation key word, Pt/Ni heat, margarine "partially saturated".
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcH1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qH.1`: Which reagent and catalyst convert ethene into ethanol industrially? — Correct: a (a: Steam with concentrated phosphoric acid | b: Hydrogen with nickel | c: Bromine water | d: Hot manganate(VII))

## Slide 35: `g03` — Hydrogen Halides and Halogens
- **Learning Objective / Purpose**: Write equations for HBr and Br₂ additions.
- **Indicators**: H15.9
- **On-Screen Educational Text**:
  - HBr adds H to one carbon, Br to the other
  - Br₂ adds one Br to each carbon
  - Room temperature, no catalyst
- **Key Ideas**: HBr adds H to one carbon, Br to the other | Br₂ adds one Br to each carbon | Room temperature, no catalyst
- **Complete Narration Text**: Look at the two addition reactions on screen. When ethene meets hydrogen bromide at room temperature, bromoethane forms. A hydrogen atom adds to one carbon and a bromine atom to the other, shown in red. When ethene reacts with bromine, 1,2-dibromoethane forms, with one bromine atom on each carbon of the former double bond. This is the reaction behind the bromine water test, and chlorine behaves in the same way. In both cases the product has only single bonds, so it is saturated. Notice that the molecular drawings are balanced: each carbon still has four bonds. Check valency every time you draw a product.
- **Audio Asset Reference**: `audio/g03.af9cd8ae5245.mp3` (45s, source: tts)
- **Visual Type**: `svg` · **Description**: Hydrogen Halides and Halogens: C; H; +; H–Br; room temp.; Br; bromoethane; Br–Br; 1,2-dibromoethane.
- **Image Asset Reference**: `None` · **Alt Text**: Hydrogen Halides and Halogens: C; H; +; H–Br; room temp.; Br; bromoethane; Br–Br; 1,2-dibromoethane.
- **Visual Labels**: Addition to ethene: where the atoms go, C, H, +, H–Br, room temp., Br, bromoethane, Br–Br, 1,2-dibromoethane
- **SVG Content**: Present (8288 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p312–313 Figures 15.12, 15.16] HBr and Br2 additions to ethene.
- **Existing Checkpoints After This Slide**: None

## Slide 36: `g04` — Hydration of Ethene
- **Learning Objective / Purpose**: Describe industrial hydration with a reversible equation.
- **Indicators**: H15.9
- **On-Screen Educational Text**:
  - Steam + ethene ⇌ ethanol
  - Concentrated H₃PO₄ catalyst
  - Industrial detail: about 300 °C, 60–70 atm
- **Key Ideas**: Steam + ethene ⇌ ethanol | Concentrated H₃PO₄ catalyst | Industrial detail: about 300 °C, 60–70 atm
- **Complete Narration Text**: In industry, alkenes react with steam to make alcohols. Ethene and steam react at a high temperature and pressure in the presence of concentrated phosphoric acid as a catalyst, giving ethanol. On screen we use a reversible arrow, because ethanol can break down to ethene and water again. Representative industrial conditions are about three hundred degrees Celsius and sixty to seventy atmospheres. The coursebook says only high temperature and pressure, so treat those numbers as supplementary industrial detail. The hydroxyl group adds to one carbon and the hydrogen to the other, shown in red. The ethanol in alcoholic drinks is made differently, by fermentation of glucose.
- **Audio Asset Reference**: `audio/g04.5b4650facf13.mp3` (46s, source: tts)
- **Visual Type**: `svg` · **Description**: Hydration of Ethene: C; H; +; H₂O(g); conc. H₃PO₄; ≈300 °C, 60–70 atm; OH; ethanol; Reversible: two arrows. 100% atom economy; Temperature and pressure: industrial detail.
- **Image Asset Reference**: `None` · **Alt Text**: Hydration of Ethene: C; H; +; H₂O(g); conc. H₃PO₄; ≈300 °C, 60–70 atm; OH; ethanol; Reversible: two arrows. 100% atom economy; Temperature and pressure: industrial detail.
- **Visual Labels**: Industrial hydration of ethene, C, H, +, H₂O(g), conc. H₃PO₄, ≈300 °C, 60–70 atm, OH, ethanol, Reversible: two arrows. 100% atom economy, Temperature and pressure: industrial detail
- **SVG Content**: Present (5198 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p313 Figure 15.15] Steam + ethene with conc. H3PO4. [SUPPLEMENTARY] numerical conditions; reversible arrow.
- **Existing Checkpoints After This Slide**: None

## Slide 37: `g05` — Atom Economy and Percentage Yield
- **Learning Objective / Purpose**: Distinguish atom economy from percentage yield.
- **Indicators**: H15.14
- **On-Screen Educational Text**:
  - Atom economy = mass of desired product ÷ total mass of products
  - Percentage yield compares actual with theoretical mass
  - Addition has 100% atom economy
- **Key Ideas**: Atom economy = mass of desired product ÷ total mass of products | Percentage yield compares actual with theoretical mass | Addition has 100% atom economy
- **Complete Narration Text**: Atom economy and percentage yield are different ideas. Atom economy tells you how much of the total mass of the products is the useful product, as a percentage. It is calculated from the equation, before any experiment. Percentage yield tells you how much product you actually made compared with the theoretical maximum. Addition reactions, where the reactants simply join, have one hundred percent atom economy, such as ethene plus steam making ethanol. Substitution has lower atom economy, because a second product forms. For methane and chlorine making chloromethane and hydrogen chloride, the useful product is fifty point five out of eighty seven point zero, which is fifty eight point zero percent.
- **Audio Asset Reference**: `audio/g05.ead77801cbd3.mp3` (48s, source: tts)
- **Visual Type**: `svg` · **Description**: Atom Economy and Percentage Yield: Atom economy = Mr desired ÷ Mr all products × 100; Ethene + steam → ethanol: 100%; CH₄ + Cl₂ → CH₃Cl + HCl: 58.0%; Percentage yield = actual ÷ theoretical × 100.
- **Image Asset Reference**: `None` · **Alt Text**: Atom Economy and Percentage Yield: Atom economy = Mr desired ÷ Mr all products × 100; Ethene + steam → ethanol: 100%; CH₄ + Cl₂ → CH₃Cl + HCl: 58.0%; Percentage yield = actual ÷ theoretical × 100.
- **Visual Labels**: Two different measures, Atom economy = Mr desired ÷ Mr all products × 100, Ethene + steam → ethanol: 100%, CH₄ + Cl₂ → CH₃Cl + HCl: 58.0%, Percentage yield = actual ÷ theoretical × 100
- **SVG Content**: Present (1569 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [SUPPLEMENTARY] Atom economy is not on the photographed pages; included as the revision brief requests. Values recomputed in verify.py.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpG` (retryRule: 2 attempts, then show the answer with the explanation):
    - [sequence] `sG.1`: Put these steps of alkene hydrogenation in order. — Order: s1 -> s2 -> s3
    - [mcq] `sG.2`: Which catalyst is used when alkenes react with hydrogen? — Correct: d (a: Vanadium(V) oxide | b: Concentrated phosphoric acid | c: Iron | d: Nickel)
    - [mcq] `sG.3`: Why does ethene + steam → ethanol have 100% atom economy? — Correct: d (a: The percentage yield is always 100% | b: The reaction is reversible | c: Ethene is cheap | d: Only one product forms)
    - [mcq] `sG.4`: What is the product of ethene and HBr? — Correct: a (a: Bromoethane | b: Ethanol | c: 1,2-dibromoethane | d: Ethane)
    - [mcq] `sG.5`: 4.20 g of ethene reacts with excess HBr to make bromoethane. 13.08 g of C₂H₅Br is collected. What is the percentage yield? (Ar: C 12.0, H 1.0, Br 80.0) — Correct: c (a: 36.4% | b: 125% | c: 80.0% | d: 20.0%)
    - [mcq] `sG.6`: What is the atom economy for making CH₃Br by CH₄ + Br₂ → CH₃Br + HBr? (Mr CH₃Br = 95.0, HBr = 81.0) — Correct: c (a: 46.0% | b: 100% | c: 54.0% | d: 95.0%)

## Slide 38: `h01` — Homolytic and Heterolytic Fission
- **Learning Objective / Purpose**: Define electrophile, homolytic and heterolytic fission.
- **Indicators**: H15.10
- **On-Screen Educational Text**:
  - Homolytic: one electron to each atom
  - Heterolytic: both electrons to one atom
  - Half arrow = one electron; full arrow = pair
- **Key Ideas**: Homolytic: one electron to each atom | Heterolytic: both electrons to one atom | Half arrow = one electron; full arrow = pair
- **Complete Narration Text**: Before the mechanism, we compare two ways to break a covalent bond. In homolytic fission, each atom takes one electron from the bonding pair, so two radicals form. We draw this with single headed arrows, called fishhook arrows, one for each electron. In heterolytic fission, one atom takes both electrons, so a positive and a negative ion form. We draw this with one full headed curly arrow, which shows the movement of an electron pair. A curly arrow starts at the bond or lone pair that the electrons come from, and finishes where they end up. An electrophile is a species that accepts a pair of electrons.
- **Audio Asset Reference**: `audio/h01.421dfa2aa719.mp3` (47s, source: tts)
- **Visual Type**: `svg` · **Description**: Homolytic and Heterolytic Fission: Homolytic fission; Heterolytic fission; Br; one electron each; two radicals: Br•; H; both electrons to Br; ions: H⁺ and Br⁻; Half arrow (fishhook) = one electron; full arrow = electron pair.
- **Image Asset Reference**: `None` · **Alt Text**: Homolytic and Heterolytic Fission: Homolytic fission; Heterolytic fission; Br; one electron each; two radicals: Br•; H; both electrons to Br; ions: H⁺ and Br⁻; Half arrow (fishhook) = one electron; full arrow = electron pair.
- **Visual Labels**: Two ways to break a bond, Homolytic fission, Heterolytic fission, Br, one electron each, two radicals: Br•, H, both electrons to Br, ions: H⁺ and Br⁻, Half arrow (fishhook) = one electron; full arrow = electron pair
- **SVG Content**: Present (3069 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p309, p314] Homolytic fission (free radicals) and heterolytic fission (bromine addition).
- **Existing Checkpoints After This Slide**: None

## Slide 39: `h02` — Ethene and HBr: Step 1
- **Learning Objective / Purpose**: Draw the first step of ethene with bromine.
- **Indicators**: H15.10
- **On-Screen Educational Text**:
  - HBr is polar: Hδ+ and Brδ−
  - π electrons attack the Hδ+
  - H–Br breaks heterolytically: C⁺ and Br⁻
- **Key Ideas**: HBr is polar: Hδ+ and Brδ− | π electrons attack the Hδ+ | H–Br breaks heterolytically: C⁺ and Br⁻
- **Complete Narration Text**: HBr is a polar molecule, because bromine is more electronegative than hydrogen. The hydrogen carries a partial positive charge and the bromine carries a partial negative charge. In the mechanism, the hydrogen atom acts as the electrophile, accepting a pair of electrons from the carbon to carbon double bond. Follow the first curly arrow on screen. It starts at the double bond and finishes at the hydrogen atom, so the pair of electrons forms a new carbon to hydrogen bond. The second curly arrow starts at the H to Br bond and finishes on the bromine atom. This is heterolytic fission, giving a carbocation and a bromide ion.
- **Audio Asset Reference**: `audio/h02.223e323b15da.mp3` (47s, source: tts)
- **Visual Type**: `svg` · **Description**: Ethene and HBr: Step 1: C; H; Br; δ+; δ−; π electron pair attacks the δ+ atom; π pair attacks Hδ+; H–Br breaks heterolytically; This gives a carbocation and Br⁻.
- **Image Asset Reference**: `None` · **Alt Text**: Ethene and HBr: Step 1: C; H; Br; δ+; δ−; π electron pair attacks the δ+ atom; π pair attacks Hδ+; H–Br breaks heterolytically; This gives a carbocation and Br⁻.
- **Visual Labels**: Ethene + HBr: step 1, C, H, Br, δ+, δ−, π electron pair attacks the δ+ atom, π pair attacks Hδ+; H–Br breaks heterolytically, This gives a carbocation and Br⁻
- **SVG Content**: Present (3572 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p312–314] Mechanism for HBr addition; the carbocation intermediate.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcI1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qI.1`: In electrophilic addition of Br₂ to ethene, what attacks the Brδ+ atom first? — Correct: c (a: A lone pair on Br⁻ | b: Hydrogen atoms of ethene | c: The π electrons of the double bond | d: A free radical)

## Slide 40: `h03` — Ethene and HBr: Step 2
- **Learning Objective / Purpose**: Complete the mechanism and compare with HBr.
- **Indicators**: H15.10
- **On-Screen Educational Text**:
  - Br⁻ has a lone pair
  - Curly arrow from lone pair to C⁺
  - Product: bromoethane
- **Key Ideas**: Br⁻ has a lone pair | Curly arrow from lone pair to C⁺ | Product: bromoethane
- **Complete Narration Text**: In step two, the bromide ion has a lone pair of electrons and is attracted to the positively charged carbon. On screen, the curly arrow starts at the lone pair and finishes at the positive carbon, where the new carbon to bromine bond forms. The product is bromoethane. The carbocation is a reaction intermediate, a species formed in one step of a mechanism and consumed in a later step. Carbocations are highly reactive because their positively charged carbon atoms are electron deficient. Notice the positive formal charge on the carbon in the intermediate. The final product has no charge. Show the lone pair and charges in any mechanism you draw.
- **Audio Asset Reference**: `audio/h03.21fe22807c4a.mp3` (48s, source: tts)
- **Visual Type**: `svg` · **Description**: Ethene and HBr: Step 2: C; H; +; carbocation intermediate; Br⁻; lone pair on the halide ion attacks C⁺; CH₃CH₂Br: bromoethane; Bromide attacks the C⁺; new C–Br bond.
- **Image Asset Reference**: `None` · **Alt Text**: Ethene and HBr: Step 2: C; H; +; carbocation intermediate; Br⁻; lone pair on the halide ion attacks C⁺; CH₃CH₂Br: bromoethane; Bromide attacks the C⁺; new C–Br bond.
- **Visual Labels**: Ethene + HBr: step 2, C, H, +, carbocation intermediate, Br⁻, lone pair on the halide ion attacks C⁺, CH₃CH₂Br: bromoethane, Bromide attacks the C⁺; new C–Br bond
- **SVG Content**: Present (3489 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p313] Key word intermediate; carbocation attacked by a negative ion.
- **Existing Checkpoints After This Slide**: None

## Slide 41: `h04` — Ethene and Bromine: Step 1
- **Learning Objective / Purpose**: Show induced dipole and the first curly arrows.
- **Indicators**: H15.10
- **On-Screen Educational Text**:
  - π electrons repel the Br–Br pair
  - Nearer Br becomes δ+ (induced dipole)
  - Br–Br breaks heterolytically
- **Key Ideas**: π electrons repel the Br–Br pair | Nearer Br becomes δ+ (induced dipole) | Br–Br breaks heterolytically
- **Complete Narration Text**: How can a non polar molecule like bromine act as an electrophile? As the bromine molecule approaches ethene, the area of high electron density around the double bond repels the pair of electrons in the Br to Br bond away from the nearer bromine atom. This makes the nearer bromine slightly positive and the further bromine slightly negative. This is an induced dipole. In the first curly arrow on screen, the pair of electrons moves from the double bond to the delta plus bromine. In the second curly arrow, the Br to Br bond breaks heterolytically and its electron pair moves onto the further bromine. That forms a carbocation and a bromide ion.
- **Audio Asset Reference**: `audio/h04.f42fae7aa697.mp3` (49s, source: tts)
- **Visual Type**: `svg` · **Description**: Ethene and Bromine: Step 1: C; H; Br; δ+; δ−; π electron pair attacks the δ+ atom; Induced dipole: π electrons repel the Br–Br pair; Nearer Br is δ+, further Br is δ−.
- **Image Asset Reference**: `None` · **Alt Text**: Ethene and Bromine: Step 1: C; H; Br; δ+; δ−; π electron pair attacks the δ+ atom; Induced dipole: π electrons repel the Br–Br pair; Nearer Br is δ+, further Br is δ−.
- **Visual Labels**: Ethene + Br₂: step 1, C, H, Br, δ+, δ−, π electron pair attacks the δ+ atom, Induced dipole: π electrons repel the Br–Br pair, Nearer Br is δ+, further Br is δ−
- **SVG Content**: Present (3575 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p314 Figure 15.18] Bromine as electrophile; induced dipole; heterolytic fission.
- **Existing Checkpoints After This Slide**: None

## Slide 42: `h05` — Ethene and Bromine: Step 2
- **Learning Objective / Purpose**: Complete the mechanism.
- **Indicators**: H15.10
- **On-Screen Educational Text**:
  - Carbocation intermediate has C⁺
  - Br⁻ lone pair attacks C⁺
  - Product: 1,2-dibromoethane
- **Key Ideas**: Carbocation intermediate has C⁺ | Br⁻ lone pair attacks C⁺ | Product: 1,2-dibromoethane
- **Complete Narration Text**: After step one we have a carbocation with a bromine atom on one carbon and a positive charge on the other. This is the highly reactive carbocation intermediate. The bromide ion has a lone pair of electrons. In step two, a curly arrow starts at the lone pair on the bromide ion and finishes at the positive carbon, forming a new carbon to bromine bond. The final product is 1,2-dibromoethane, with one bromine atom bonded to each carbon atom. Check your drawing: the carbons each have four bonds and no charge remains. In the examination, mark the partial charges, the lone pair, the curly arrows and the intermediate with its positive charge.
- **Audio Asset Reference**: `audio/h05.404b39a66ebd.mp3` (49s, source: tts)
- **Visual Type**: `svg` · **Description**: Ethene and Bromine: Step 2: C; H; Br; +; carbocation intermediate; Br⁻; lone pair on the halide ion attacks C⁺; BrCH₂CH₂Br: 1,2-dibromoethane; One Br on each carbon of the old C=C.
- **Image Asset Reference**: `None` · **Alt Text**: Ethene and Bromine: Step 2: C; H; Br; +; carbocation intermediate; Br⁻; lone pair on the halide ion attacks C⁺; BrCH₂CH₂Br: 1,2-dibromoethane; One Br on each carbon of the old C=C.
- **Visual Labels**: Ethene + Br₂: step 2, C, H, Br, +, carbocation intermediate, Br⁻, lone pair on the halide ion attacks C⁺, BrCH₂CH₂Br: 1,2-dibromoethane, One Br on each carbon of the old C=C
- **SVG Content**: Present (3497 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p314 Figure 15.18; p322 Q7d] Simplified carbocation mechanism as taught.
- **Existing Checkpoints After This Slide**: None

## Slide 43: `h06` — Ethene and Chlorine: Both Steps
- **Learning Objective / Purpose**: Apply the mechanism to chlorine.
- **Indicators**: H15.10
- **On-Screen Educational Text**:
  - Same simplified pattern as bromine
  - Induced dipole in Cl–Cl
  - Product: 1,2-dichloroethane
- **Key Ideas**: Same simplified pattern as bromine | Induced dipole in Cl–Cl | Product: 1,2-dichloroethane
- **Complete Narration Text**: Chlorine reacts with ethene by the same simplified electrophilic addition pattern as bromine, as the coursebook presents it. More detailed mechanisms exist, such as the bromonium ion model on the next slide, which is enrichment. The syllabus asks you to describe electrophilic addition, using bromine and ethene as an example, and the coursebook uses this simplified two step version. In the top row, the approaching ethene induces a dipole in the chlorine molecule. The electron pair from the double bond moves to the delta plus chlorine, and the Cl to Cl bond breaks heterolytically, giving a carbocation and a chloride ion. In the bottom row, the lone pair on the chloride ion attacks the positive carbon. The product is 1,2-dichloroethane. Chlorine acts as an electrophile because it accepts a pair of electrons. The coursebook asks you to explain how a chlorine molecule can act as an electrophile, so practise explaining the induced dipole in words as well as drawing it.
- **Audio Asset Reference**: `audio/h06.f3fb5db9e10c.mp3` (70s, source: tts)
- **Visual Type**: `svg` · **Description**: Ethene and Chlorine: Both Steps: C; H; Cl; δ+; δ−; → C⁺ and Cl⁻; +; Cl⁻; → ClCH₂CH₂Cl; 1,2-dichloroethane.
- **Image Asset Reference**: `None` · **Alt Text**: Ethene and Chlorine: Both Steps: C; H; Cl; δ+; δ−; → C⁺ and Cl⁻; +; Cl⁻; → ClCH₂CH₂Cl; 1,2-dichloroethane.
- **Visual Labels**: Ethene + Cl₂: both steps, C, H, Cl, δ+, δ−, → C⁺ and Cl⁻, +, Cl⁻, → ClCH₂CH₂Cl, 1,2-dichloroethane
- **SVG Content**: Present (5458 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p314 Question 5e–g] Explain chlorine as electrophile; draw mechanism with chlorine. Examination expectation: the simplified carbocation mechanism. Detailed mechanisms (bromonium) are enrichment. No official Cambridge mark scheme was inspected. Do not tell students that an alternative valid mechanism will be rejected; say only that the coursebook draws the simplified version.
- **Existing Checkpoints After This Slide**: None

## Slide 44: `h07` — Enrichment: The Bromonium Ion
- **Learning Objective / Purpose**: Separate advanced detail from the coursebook mechanism.
- **Indicators**: H15.10
- **On-Screen Educational Text**:
  - Coursebook: simple carbocation mechanism
  - Advanced: a cyclic bromonium ion
  - Aqueous bromine can form bromohydrins
- **Key Ideas**: Coursebook: simple carbocation mechanism | Advanced: a cyclic bromonium ion | Aqueous bromine can form bromohydrins
- **Complete Narration Text**: This slide is enrichment. The coursebook draws the simplified mechanism, so practise that first, and ask your teacher how your examination answers should be framed. Chemists have found that the reaction of bromine with an alkene is better described by a cyclic bromonium ion, a three membered ring in which the bromine bears a positive charge. The bromide ion then attacks from the opposite side of the ring. That model explains the stereochemistry seen in real reactions. A second advanced point concerns bromine water. Because water is present in large amounts, it can also attack the intermediate, and so a compound called a bromohydrin, with a bromine on one carbon and an O H on the other, can form alongside the dibromo product. The bromine water test observation does not change: orange to colourless.
- **Audio Asset Reference**: `audio/h07.31ff4eabc5dd.mp3` (58s, source: tts)
- **Visual Type**: `svg` · **Description**: Enrichment: The Bromonium Ion: Coursebook: carbocation, then Br⁻ attack; Advanced model: three-membered Br⁺ ring; Br⁻ then attacks from the opposite side; In water: bromohydrin can also form; Exam: use the coursebook mechanism.
- **Image Asset Reference**: `None` · **Alt Text**: Enrichment: The Bromonium Ion: Coursebook: carbocation, then Br⁻ attack; Advanced model: three-membered Br⁺ ring; Br⁻ then attacks from the opposite side; In water: bromohydrin can also form; Exam: use the coursebook mechanism.
- **Visual Labels**: Enrichment, not required in the coursebook, Coursebook: carbocation, then Br⁻ attack, Advanced model: three-membered Br⁺ ring, Br⁻ then attacks from the opposite side, In water: bromohydrin can also form, Exam: use the coursebook mechanism
- **SVG Content**: Present (1888 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [ENRICHMENT] Not on the photographed coursebook pages; [VERIFY] syllabus treatment. Syllabus 9701 (2025–2027) summary from WebFetch does not mention bromonium ions; treated as enrichment. [VERIFY] against the PDF. No official Cambridge mark scheme was inspected for bromonium treatment; the retrieved syllabus text does not mention it.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpH` (retryRule: 2 attempts, then show the answer with the explanation):
    - [sequence] `sH.1`: Put the stages of electrophilic addition of Br₂ to ethene in order. — Order: s1 -> s2 -> s3
    - [mcq] `sH.2`: What is an electrophile? — Correct: a (a: An electron-pair acceptor | b: A catalyst | c: An electron-pair donor | d: A species with an unpaired electron)
    - [mcq] `sH.3`: Why does Br₂ develop an induced dipole near ethene? — Correct: a (a: The high electron density of C=C repels the Br–Br electron pair | b: Bromine atoms differ | c: Br₂ is already polar | d: Heating polarises it)
    - [mcq] `sH.4`: In step 2 of ethene + Br₂, where does the curly arrow start? — Correct: d (a: At the C=C bond | b: At the positive carbon | c: At the Br–Br bond | d: At a lone pair on Br⁻)

## Slide 45: `i01` — Addition to Unsymmetrical Alkenes
- **Learning Objective / Purpose**: State the major product of HBr + propene.
- **Indicators**: H15.11
- **On-Screen Educational Text**:
  - H can add to either carbon of propene
  - Secondary carbocation is more stable
  - Major product: 2-bromopropane
- **Key Ideas**: H can add to either carbon of propene | Secondary carbocation is more stable | Major product: 2-bromopropane
- **Complete Narration Text**: Propene is unsymmetrical, so with longer asymmetric alkenes there are always two possible products. On screen, if the hydrogen adds to the end carbon, the positive charge sits on the middle carbon, giving a secondary carbocation and then 2-bromopropane. If the hydrogen adds to the middle carbon, the positive charge is on the end carbon, giving a primary carbocation and then 1-bromopropane. The coursebook states that where two addition products are possible, the major product is the one with the halogen atom bonded to the carbon of the double bond with the highest number of alkyl groups. Here that is 2-bromopropane. The primary route gives only a minor product.
- **Audio Asset Reference**: `audio/i01.a26d08c37c54.mp3` (47s, source: tts)
- **Visual Type**: `svg` · **Description**: Addition to Unsymmetrical Alkenes: propene + HBr; secondary C⁺; primary C⁺; 2-bromopropane; 1-bromopropane; CH₃C⁺HCH₃; CH₃CH₂C⁺H₂; CH₃CHBrCH₃: MAJOR; CH₃CH₂CH₂Br: minor; More stable intermediate forms faster.
- **Image Asset Reference**: `None` · **Alt Text**: Addition to Unsymmetrical Alkenes: propene + HBr; secondary C⁺; primary C⁺; 2-bromopropane; 1-bromopropane; CH₃C⁺HCH₃; CH₃CH₂C⁺H₂; CH₃CHBrCH₃: MAJOR; CH₃CH₂CH₂Br: minor; More stable intermediate forms faster.
- **Visual Labels**: Propene + HBr: two carbocation routes, propene + HBr, secondary C⁺, primary C⁺, 2-bromopropane, 1-bromopropane, CH₃C⁺HCH₃, CH₃CH₂C⁺H₂, CH₃CHBrCH₃: MAJOR, CH₃CH₂CH₂Br: minor, More stable intermediate forms faster
- **SVG Content**: Present (3382 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p312 and p313 Figure 15.14] Propene + HBr, major product 2-bromopropane via secondary carbocation.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcJ1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qJ.1`: What is the major product of propene with HBr? — Correct: b (a: propane | b: 2-bromopropane | c: 1-bromopropane | d: 1,2-dibromopropane)

## Slide 46: `i02` — Stability of Carbocations
- **Learning Objective / Purpose**: Explain stability using the inductive effect.
- **Indicators**: H15.11
- **On-Screen Educational Text**:
  - Each alkyl group donates electrons (+I)
  - Charge is spread: carbocation more stable
  - Tertiary > secondary > primary
- **Key Ideas**: Each alkyl group donates electrons (+I) | Charge is spread: carbocation more stable | Tertiary > secondary > primary
- **Complete Narration Text**: Carbocations are named by the number of alkyl groups attached to the positively charged carbon. A primary carbocation has one, a secondary has two and a tertiary has three. Each alkyl group tends to donate electrons along its bond to the positively charged carbon. This is the positive inductive effect, written plus I. It makes the positive charge less concentrated, which stabilises the ion. So a tertiary carbocation is the most stable and a primary carbocation is the least stable. A more stable intermediate forms more readily, so the product that comes from it is the major product. In the exam, say alkyl groups donate electrons, spreading the charge.
- **Audio Asset Reference**: `audio/i02.77f5c21bc47c.mp3` (47s, source: tts)
- **Visual Type**: `svg` · **Description**: Stability of Carbocations: Primary; Secondary; Tertiary; Least stable; More stable; Most stable; Alkyl groups push electrons (+I) to the C⁺.
- **Image Asset Reference**: `None` · **Alt Text**: Stability of Carbocations: Primary; Secondary; Tertiary; Least stable; More stable; Most stable; Alkyl groups push electrons (+I) to the C⁺.
- **Visual Labels**: Carbocation stability, Primary, Secondary, Tertiary, Least stable, More stable, Most stable, Alkyl groups push electrons (+I) to the C⁺
- **SVG Content**: Present (2845 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p304, p312] Alkyl groups electron donating; primary, secondary, tertiary carbocation stability.
- **Existing Checkpoints After This Slide**: None

## Slide 47: `i03` — Propene and HBr: Curly Arrows
- **Learning Objective / Purpose**: Draw the major pathway with arrows.
- **Indicators**: H15.11
- **On-Screen Educational Text**:
  - π pair attacks Hδ+
  - H bonds to the CH₂ carbon
  - C⁺ on the middle carbon: secondary
- **Key Ideas**: π pair attacks Hδ+ | H bonds to the CH₂ carbon | C⁺ on the middle carbon: secondary
- **Complete Narration Text**: Follow the major pathway with curly arrows. The first arrow starts at the double bond and finishes at the delta plus hydrogen of hydrogen bromide. The hydrogen bonds to the CH 2 carbon at the end, so the positive charge appears on the middle carbon, which has two methyl type alkyl groups attached through its neighbours: this is the secondary carbocation. The second arrow starts at the H to Br bond and finishes on the bromine, giving a bromide ion. Then the bromide ion uses a lone pair to attack the positive carbon, forming 2-bromopropane. The alternative, where hydrogen bonds to the middle carbon, would put the positive charge on an end carbon and give a less stable primary carbocation.
- **Audio Asset Reference**: `audio/i03.7e51cb97e8cf.mp3` (52s, source: tts)
- **Visual Type**: `svg` · **Description**: Propene and HBr: Curly Arrows: C; CH₃; H; Br; δ+; δ−; π pair takes H to the CH₂ carbon; Positive charge on the middle carbon: CH₃C⁺HCH₃; Br⁻ then attacks: 2-bromopropane (major).
- **Image Asset Reference**: `None` · **Alt Text**: Propene and HBr: Curly Arrows: C; CH₃; H; Br; δ+; δ−; π pair takes H to the CH₂ carbon; Positive charge on the middle carbon: CH₃C⁺HCH₃; Br⁻ then attacks: 2-bromopropane (major).
- **Visual Labels**: Propene + HBr: major route, curly arrows, C, CH₃, H, Br, δ+, δ−, π pair takes H to the CH₂ carbon, Positive charge on the middle carbon: CH₃C⁺HCH₃, Br⁻ then attacks: 2-bromopropane (major)
- **SVG Content**: Present (3619 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p313 Figure 15.14] Mechanism for HBr + propene.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpI` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `sI.1`: Which carbocation is the most stable? — Correct: d (a: Methyl | b: They are equally stable | c: Primary | d: Tertiary)
    - [mcq] `sI.2`: What is the major product of 2-methylpropene + HBr? — Correct: d (a: 1-bromo-2-methylpropane | b: 2,2-dibromopropane | c: 2-methylpropane | d: 2-bromo-2-methylpropane)
    - [mcq] `sI.3`: What is the major product of but-1-ene + HBr? — Correct: b (a: 1,2-dibromobutane | b: 2-bromobutane | c: 1-bromobutane | d: Butane)

## Slide 48: `j01` — Mild Oxidation: Diol
- **Learning Objective / Purpose**: Describe cold oxidation to a diol.
- **Indicators**: H15.12
- **On-Screen Educational Text**:
  - Cold, dilute, acidified KMnO₄
  - Purple becomes almost colourless
  - Product: a diol with two OH groups
- **Key Ideas**: Cold, dilute, acidified KMnO₄ | Purple becomes almost colourless | Product: a diol with two OH groups
- **Complete Narration Text**: The coursebook teaches that alkenes can be oxidised by acidified potassium manganate seven, a powerful oxidising agent. If an alkene is shaken with a cold, dilute acidified solution, the pale purple solution turns colourless, and the alkene is converted into a diol, a compound with two alcohol O H groups. On screen, ethene becomes ethane 1,2 diol, with one O H group on each carbon of the former double bond. Propene becomes propane 1,2 diol. The carbon chain stays intact. The equation uses O in square brackets to show oxygen from the oxidising agent. For propene: C H 3 C H double bond C H 2 plus water plus O gives C H 3 C H O H C H 2 O H.
- **Audio Asset Reference**: `audio/j01.ff112fbbe16c.mp3` (53s, source: tts)
- **Visual Type**: `svg` · **Description**: Mild Oxidation: Diol: C; H; [O], H₂O; OH; ethane-1,2-diol; CH₃; propane-1,2-diol; Purple KMnO₄ turns colourless.
- **Image Asset Reference**: `None` · **Alt Text**: Mild Oxidation: Diol: C; H; [O], H₂O; OH; ethane-1,2-diol; CH₃; propane-1,2-diol; Purple KMnO₄ turns colourless.
- **Visual Labels**: Mild oxidation: cold, dilute, acidified KMnO₄, C, H, [O], H₂O, OH, ethane-1,2-diol, CH₃, propane-1,2-diol, Purple KMnO₄ turns colourless
- **SVG Content**: Present (7896 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p314 Practical Activity 15.1, Figure 15.18 area; p315 Q6] Cold dilute acidified KMnO4 gives a diol. This resolves the earlier verification flag. Demonstration only; do not handle KMnO4 unsupervised.
- **Existing Checkpoints After This Slide**: None

## Slide 49: `j01b` — But-2-ene to Butane-2,3-diol
- **Learning Objective / Purpose**: Apply mild oxidation to but-2-ene.
- **Indicators**: H15.12
- **On-Screen Educational Text**:
  - But-2-ene: CH₃CH=CHCH₃
  - Cold, dilute, acidified KMnO₄
  - Product: butane-2,3-diol
- **Key Ideas**: But-2-ene: CH₃CH=CHCH₃ | Cold, dilute, acidified KMnO₄ | Product: butane-2,3-diol
- **Complete Narration Text**: Now apply the same idea to but 2 ene. When shaken with cold, dilute, acidified potassium manganate seven, each carbon of the double bond gains one O H group, so the product is butane 2,3 diol. The purple solution becomes colourless. The four carbon chain is intact, and the two O H groups are on carbons two and three. The equation is C H 3 C H double bond C H C H 3 plus water plus O giving C H 3 C H O H C H O H C H 3. Name the diol by finding the longest chain, numbering to give the lowest locants to the O H groups, and using the ending d i o l. As always, this practical is a teacher demonstration only.
- **Audio Asset Reference**: `audio/j01b.fc6bec7706a1.mp3` (56s, source: tts)
- **Visual Type**: `svg` · **Description**: But-2-ene to Butane-2,3-diol: C; CH₃; H; [O], H₂O; cold, dilute; OH; but-2-ene; butane-2,3-diol; One OH added to each carbon of the C=C bond; Purple becomes colourless: cold, dilute, acidified.
- **Image Asset Reference**: `None` · **Alt Text**: But-2-ene to Butane-2,3-diol: C; CH₃; H; [O], H₂O; cold, dilute; OH; but-2-ene; butane-2,3-diol; One OH added to each carbon of the C=C bond; Purple becomes colourless: cold, dilute, acidified.
- **Visual Labels**: But-2-ene to butane-2,3-diol, C, CH₃, H, [O], H₂O, cold, dilute, OH, but-2-ene, butane-2,3-diol, One OH added to each carbon of the C=C bond, Purple becomes colourless: cold, dilute, acidified
- **SVG Content**: Present (4969 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p315 Question 6b] But-2-ene with cold acidified KMnO4. Teacher demonstration only.
- **Existing Checkpoints After This Slide**: None

## Slide 50: `j02` — Hot Concentrated KMnO₄: Rules
- **Learning Objective / Purpose**: Predict products of oxidative cleavage.
- **Indicators**: H15.12
- **On-Screen Educational Text**:
  - Hot, concentrated, acidified KMnO₄ cleaves C=C
  - =CH₂ gives CO₂; =CHR gives RCOOH
  - =CR₂ gives a ketone
- **Key Ideas**: Hot, concentrated, acidified KMnO₄ cleaves C=C | =CH₂ gives CO₂; =CHR gives RCOOH | =CR₂ gives a ketone
- **Complete Narration Text**: Under harsh conditions, with hot, concentrated acidified potassium manganate seven, the carbon to carbon double bond is broken completely. Look at each carbon of the double bond separately. A carbon with two hydrogen atoms is oxidised to carbon dioxide. A carbon with one hydrogen and one alkyl group is first oxidised to an aldehyde, which is then further oxidised to a carboxylic acid. A carbon with two alkyl groups is oxidised to a ketone. The alkyl groups are labelled R. The two products show the position of the double bond in the original alkene, which is why this reaction is useful to chemists for working out structures.
- **Audio Asset Reference**: `audio/j02.f8f6e12f796f.mp3` (47s, source: tts)
- **Visual Type**: `svg` · **Description**: Hot Concentrated KMnO₄: Rules: Group on carbon; Product; =CH₂; CO₂ (+ H₂O); =CHR; RCHO, then RCOOH; =CR¹R²; ketone R¹R²C=O.
- **Image Asset Reference**: `None` · **Alt Text**: Hot Concentrated KMnO₄: Rules: Group on carbon; Product; =CH₂; CO₂ (+ H₂O); =CHR; RCHO, then RCOOH; =CR¹R²; ketone R¹R²C=O.
- **Visual Labels**: Each C of C=C is oxidised separately, Group on carbon, Product, =CH₂, CO₂ (+ H₂O), =CHR, RCHO, then RCOOH, =CR¹R², ketone R¹R²C=O
- **SVG Content**: Present (2500 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p314–315 Figure 15.19] Three oxidation rules; aldehyde then carboxylic acid.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcK1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qK.1`: Which product forms from a =CHR group of an alkene on hot concentrated KMnO₄? — Correct: a (a: A carboxylic acid | b: A diol | c: A ketone | d: Carbon dioxide)

## Slide 51: `j02b` — Hot Oxidation: Three Worked Examples
- **Learning Objective / Purpose**: Predict cleavage products with equations.
- **Indicators**: H15.12
- **On-Screen Educational Text**:
  - Propene + 5[O] → CH₃COOH + CO₂ + H₂O
  - 2-methylpropene + 4[O] → (CH₃)₂CO + CO₂ + H₂O
  - 2-methylbut-2-ene + 3[O] → CH₃COCH₃ + CH₃COOH
- **Key Ideas**: Propene + 5[O] → CH₃COOH + CO₂ + H₂O | 2-methylpropene + 4[O] → (CH₃)₂CO + CO₂ + H₂O | 2-methylbut-2-ene + 3[O] → CH₃COCH₃ + CH₃COOH
- **Complete Narration Text**: Now we apply the rules to three alkenes. Cut each double bond at the dotted line and oxidise each carbon separately. In propene, the C H 2 carbon gives carbon dioxide and water, and the C H C H 3 carbon gives ethanoic acid, so the equation uses five O. In 2-methylpropene, the C H 2 carbon gives carbon dioxide and water, and the carbon with two methyl groups gives propanone, a ketone, using four O. In 2-methylbut-2-ene, one carbon has two methyl groups and gives propanone. The other has one hydrogen and a methyl group, and gives ethanoic acid, using three O. In each case the number of carbon atoms in the products equals the number in the alkene.
- **Audio Asset Reference**: `audio/j02b.7d4909e56de4.mp3` (52s, source: tts)
- **Visual Type**: `svg` · **Description**: Hot Oxidation: Three Worked Examples: C; CH₃; H; [O]; CH₃COOH + CO₂ + H₂O; (CH₃)₂CO + CO₂ + H₂O; CH₃COCH₃ + CH₃COOH.
- **Image Asset Reference**: `None` · **Alt Text**: Hot Oxidation: Three Worked Examples: C; CH₃; H; [O]; CH₃COOH + CO₂ + H₂O; (CH₃)₂CO + CO₂ + H₂O; CH₃COCH₃ + CH₃COOH.
- **Visual Labels**: Hot, concentrated KMnO₄ cuts the C=C bond, C, CH₃, H, [O], CH₃COOH + CO₂ + H₂O, (CH₃)₂CO + CO₂ + H₂O, CH₃COCH₃ + CH₃COOH
- **SVG Content**: Present (6367 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p315 Figure 15.19; p315 Q6c] 2-methylpropene example is in the coursebook; others are original with equations recomputed.
- **Existing Checkpoints After This Slide**: None

## Slide 52: `j03` — Working Backwards to the Alkene
- **Learning Objective / Purpose**: Deduce an alkene from its oxidation products.
- **Indicators**: H15.12
- **On-Screen Educational Text**:
  - Identify the fragment from each carbon
  - Acid end: =CHR; ketone end: =CR₂
  - CO₂ means the double bond was at the end
- **Key Ideas**: Identify the fragment from each carbon | Acid end: =CHR; ketone end: =CR₂ | CO₂ means the double bond was at the end
- **Complete Narration Text**: To identify the original alkene, work backwards from the oxidation products. First, name the two products. A carboxylic acid came from a carbon with one hydrogen and one alkyl group. A ketone came from a carbon with two alkyl groups. Carbon dioxide came from a carbon with two hydrogens, so if carbon dioxide is given off, the double bond was between the end two carbon atoms of the alkene. Remove the oxygen, join the two carbon atoms with a double bond, and add the hydrogen atoms and groups back. Finally, count the carbon atoms: they must equal the total in the two products. Propanone and ethanoic acid give 2-methylbut-2-ene.
- **Audio Asset Reference**: `audio/j03.6c4e3637d44b.mp3` (47s, source: tts)
- **Visual Type**: `svg` · **Description**: Working Backwards to the Alkene: Name the two products; Acid: carbon had one H and one R; Ketone: carbon had two R groups; CO₂: carbon had two H atoms; Join the two carbons with C=C.
- **Image Asset Reference**: `None` · **Alt Text**: Working Backwards to the Alkene: Name the two products; Acid: carbon had one H and one R; Ketone: carbon had two R groups; CO₂: carbon had two H atoms; Join the two carbons with C=C.
- **Visual Labels**: Working backwards, Name the two products, Acid: carbon had one H and one R, Ketone: carbon had two R groups, CO₂: carbon had two H atoms, Join the two carbons with C=C
- **SVG Content**: Present (1791 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p315] "Work backwards to deduce the original alkene"; carbon dioxide indicates a terminal C=C.
- **Existing Checkpoints After This Slide**: None

## Slide 53: `j04` — Deducing Alkenes: Increasing Difficulty
- **Learning Objective / Purpose**: Practise reverse deduction on five examples.
- **Indicators**: H15.12
- **On-Screen Educational Text**:
  - Join the two carbons with C=C
  - Check the carbon count
  - Name the alkene
- **Key Ideas**: Join the two carbons with C=C | Check the carbon count | Name the alkene
- **Complete Narration Text**: Here are five reverse deductions, in increasing difficulty. In the first, carbon dioxide means an end carbon with two hydrogens, and ethanoic acid means a carbon with one hydrogen and a methyl group, so the alkene is propene. In the second, propanone and carbon dioxide give 2-methylpropene. In the third, two carboxylic acids with three carbons and two carbons give pent 2 ene, where the double bond is between carbons two and three. In the fourth, butanone and carbon dioxide give 2-methylbut-1-ene. In the fifth, only one product, propanone, forms from both ends, so the alkene is symmetrical: 2,3-dimethylbut-2-ene. For an alkene that exhibits E Z isomerism, oxidative cleavage generally cannot distinguish the two stereoisomers, because both produce the same fragments. Try covering the right column and deducing each alkene first, on paper.
- **Audio Asset Reference**: `audio/j04.0ca8a672e178.mp3` (58s, source: tts)
- **Visual Type**: `svg` · **Description**: Deducing Alkenes: Increasing Difficulty: Products; Alkene; CO₂ + CH₃COOH; propene; (CH₃)₂CO + CO₂; 2-methylpropene; CH₃CH₂COOH + CH₃COOH; pent-2-ene; CH₃COCH₂CH₃ + CO₂; 2-methylbut-1-ene; 2 × (CH₃)₂CO; 2,3-dimethylbut-2-ene.
- **Image Asset Reference**: `None` · **Alt Text**: Deducing Alkenes: Increasing Difficulty: Products; Alkene; CO₂ + CH₃COOH; propene; (CH₃)₂CO + CO₂; 2-methylpropene; CH₃CH₂COOH + CH₃COOH; pent-2-ene; CH₃COCH₂CH₃ + CO₂; 2-methylbut-1-ene; 2 × (CH₃)₂CO; 2,3-dimethylbut-2-ene.
- **Visual Labels**: Products → original alkene, Products, Alkene, CO₂ + CH₃COOH, propene, (CH₃)₂CO + CO₂, 2-methylpropene, CH₃CH₂COOH + CH₃COOH, pent-2-ene, CH₃COCH₂CH₃ + CO₂, 2-methylbut-1-ene, 2 × (CH₃)₂CO, 2,3-dimethylbut-2-ene
- **SVG Content**: Present (3545 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p322 Q9b, c] Pent-2-ene and but-1-ene/but-2-ene deduction; other levels are original.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpJ` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `sJ.1`: An alkene gives only propanone and carbon dioxide on hot concentrated KMnO₄. What is it? — Correct: c (a: Propene | b: But-2-ene | c: 2-methylpropene | d: Ethene)
    - [mcq] `sJ.2`: Ethene is shaken with cold dilute acidified KMnO₄. What forms? — Correct: b (a: Ethanoic acid | b: Ethane-1,2-diol | c: CO₂ and water | d: Ethanol)
    - [mcq] `sJ.3`: Propene is heated with hot concentrated acidified KMnO₄. Which products form? — Correct: d (a: Two molecules of ethanoic acid | b: Propane-1,2-diol | c: Propanone and carbon dioxide | d: Ethanoic acid and carbon dioxide)
    - [mcq] `sJ.4`: Which products form from 2-methylbut-2-ene with hot concentrated KMnO₄? — Correct: d (a: Two ethanoic acid molecules | b: Propanone and carbon dioxide | c: Butanone and carbon dioxide | d: Propanone and ethanoic acid)
    - [mcq] `sJ.5`: Hot oxidation gives only ethanoic acid. Which alkene reacted? — Correct: d (a: Propene | b: But-1-ene | c: Ethene | d: But-2-ene)

## Slide 54: `k01` — Addition Polymerisation
- **Learning Objective / Purpose**: Define addition polymers and the repeat unit.
- **Indicators**: H15.13
- **On-Screen Educational Text**:
  - Monomers contain C=C
  - The C=C opens; repeat unit in brackets
  - The polymer is the only product
- **Key Ideas**: Monomers contain C=C | The C=C opens; repeat unit in brackets | The polymer is the only product
- **Complete Narration Text**: Addition polymerisation is the reaction of many monomers containing at least one carbon to carbon double bond to form long chain polymers as the only product. On screen, many ethene molecules join. The pi bond in each C double bond C breaks, and then the monomers link together. The section in the square brackets is the repeat unit, with continuation bonds going through the brackets and a subscript n showing that the unit repeats, up to ten thousand times for poly ethene. The two carbon atoms of each double bond become the backbone of the chain. Because the polymer is the only product, no small molecule is lost.
- **Audio Asset Reference**: `audio/k01.b6a2ea53ec5b.mp3` (47s, source: tts)
- **Visual Type**: `svg` · **Description**: Addition Polymerisation: C; H; n; poly(ethene); No small molecule is lost: addition polymerisation.
- **Image Asset Reference**: `None` · **Alt Text**: Addition Polymerisation: C; H; n; poly(ethene); No small molecule is lost: addition polymerisation.
- **Visual Labels**: Ethene to poly(ethene), C, H, n, poly(ethene), No small molecule is lost: addition polymerisation
- **SVG Content**: Present (8397 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p315–316] Polymer, monomer, addition polymerisation, repeat unit, n up to 10 000.
- **Existing Checkpoints After This Slide**: None

## Slide 55: `k02` — Monomers and Repeat Units (1)
- **Learning Objective / Purpose**: Match monomers to polymers.
- **Indicators**: H15.13
- **On-Screen Educational Text**:
  - Propene: a CH₃ side group
  - Chloroethene: PVC
  - Tetrafluoroethene: PTFE
- **Key Ideas**: Propene: a CH₃ side group | Chloroethene: PVC | Tetrafluoroethene: PTFE
- **Complete Narration Text**: In poly alkenes made from one type of monomer, the repeat unit is the same as the monomer except that the carbon to carbon double bond is changed into a single bond. On screen, propene has a methyl side group, so poly propene has methyl groups sticking out of the carbon skeleton. Chloroethene, once called vinyl chloride, gives poly chloroethene, known as P V C. Tetrafluoroethene gives P T F E, used in non stick pans. In each case the side groups stay attached, and the continuation bonds go through the square brackets. Draw the repeat unit with correct brackets, continuation bonds and the subscript n.
- **Audio Asset Reference**: `audio/k02.c4d48e299821.mp3` (46s, source: tts)
- **Visual Type**: `svg` · **Description**: Monomers and Repeat Units (1): C; CH₃; H; n; poly(propene); Cl; PVC; F; PTFE.
- **Image Asset Reference**: `None` · **Alt Text**: Monomers and Repeat Units (1): C; CH₃; H; n; poly(propene); Cl; PVC; F; PTFE.
- **Visual Labels**: Three monomers and their repeat units, C, CH₃, H, n, poly(propene), Cl, PVC, F, PTFE
- **SVG Content**: Present (10792 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p316–318] Poly(propene), poly(chloroethene), PTFE question.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `qcL1` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `qL.1`: What is the monomer of PTFE? — Correct: d (a: Chloroethene | b: Propene | c: Ethene | d: Tetrafluoroethene)

## Slide 56: `k02b` — Monomers and Repeat Units (2)
- **Learning Objective / Purpose**: Show side groups larger than H.
- **Indicators**: H15.13
- **On-Screen Educational Text**:
  - Phenylethene gives poly(phenylethene)
  - But-1-ene gives poly(but-1-ene)
  - Monomers can have many carbons
- **Key Ideas**: Phenylethene gives poly(phenylethene) | But-1-ene gives poly(but-1-ene) | Monomers can have many carbons
- **Complete Narration Text**: Now two monomers with bigger side groups. Phenylethene, also called styrene, has a benzene ring attached to one carbon of the double bond. The polymer is poly phenylethene, with a phenyl group on every other backbone carbon. But 1 ene has an ethyl group on the double bond carbon, so the repeat unit has a C 2 H 5 side group. In both cases, the double bond opens, the two carbon atoms of the double bond stay in the backbone, and the large groups hang off as side groups. This shows that a monomer can contain many more than two carbon atoms: phenylethene has eight, and but 1 ene has four. Show the brackets, the continuation bonds and the subscript n.
- **Audio Asset Reference**: `audio/k02b.af42a2cd2868.mp3` (53s, source: tts)
- **Visual Type**: `svg` · **Description**: Monomers and Repeat Units (2): C; C₆H₅; H; n; poly(phenylethene); C₂H₅; poly(but-1-ene); Phenylethene and but-1-ene have more than two carbons.
- **Image Asset Reference**: `None` · **Alt Text**: Monomers and Repeat Units (2): C; C₆H₅; H; n; poly(phenylethene); C₂H₅; poly(but-1-ene); Phenylethene and but-1-ene have more than two carbons.
- **Visual Labels**: Side groups stay on the chain, C, C₆H₅, H, n, poly(phenylethene), C₂H₅, poly(but-1-ene), Phenylethene and but-1-ene have more than two carbons
- **SVG Content**: Present (7700 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p318] Phenyl and ethyl-substituted polymers; Figure on p318.
- **Existing Checkpoints After This Slide**: None

## Slide 57: `k03` — From Polymer to Monomer (1)
- **Learning Objective / Purpose**: Deduce repeat unit and monomer.
- **Indicators**: H15.13
- **On-Screen Educational Text**:
  - Split the chain into repeat units
  - Take two backbone carbons
  - Put the C=C back
- **Key Ideas**: Split the chain into repeat units | Take two backbone carbons | Put the C=C back
- **Complete Narration Text**: A monomer used in addition polymerisation can contain more than two carbon atoms. The two carbon atoms that originally formed the double bond become the backbone of the polymer, and any other groups remain as side groups. To find the monomer, first split the polymer chain into repeat units. Here the repeating pattern is two backbone carbons, one with a phenyl ring and one with only hydrogens. Then put the C double bond C back into the monomer. The monomer is phenylethene, which has eight carbon atoms in total. Always check that each carbon in your monomer has four bonds.
- **Audio Asset Reference**: `audio/k03.fe275d2f394d.mp3` (43s, source: tts)
- **Visual Type**: `svg` · **Description**: From Polymer to Monomer (1): C; C₆H₅; H; close the bracket, put C=C back; phenylethene.
- **Image Asset Reference**: `None` · **Alt Text**: From Polymer to Monomer (1): C; C₆H₅; H; close the bracket, put C=C back; phenylethene.
- **Visual Labels**: Polymer to monomer: phenyl side group, C, C₆H₅, H, close the bracket, put C=C back, phenylethene
- **SVG Content**: Present (5550 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p318] Identifying the monomer from a polymer section (phenyl example). CORRECTION: removes the earlier incorrect two-carbon statement.
- **Existing Checkpoints After This Slide**: None

## Slide 58: `k03b` — From Polymer to Monomer (2)
- **Learning Objective / Purpose**: Deduce but-1-ene from an ethyl-substituted chain.
- **Indicators**: H15.13
- **On-Screen Educational Text**:
  - Identify the repeating pattern
  - Two backbone carbons per repeat unit
  - Put the C=C back
- **Key Ideas**: Identify the repeating pattern | Two backbone carbons per repeat unit | Put the C=C back
- **Complete Narration Text**: Here is a polymer section with ethyl groups on alternate carbon atoms. First split the chain into repeat units. The pattern repeats every two backbone carbons: one with an ethyl group and one with hydrogens only. Draw one repeat unit inside brackets, then change the two backbone carbons from a single bond back to a double bond. The monomer is C H 2 double bond C H C 2 H 5, which is but 1 ene. Check that each carbon has four bonds. The coursebook also asks: if a waste batch of this polymer were burned in an inefficient industrial incinerator, which toxic gas could be released? The answer is carbon monoxide, from incomplete combustion.
- **Audio Asset Reference**: `audio/k03b.d54309c6d631.mp3` (50s, source: tts)
- **Visual Type**: `svg` · **Description**: From Polymer to Monomer (2): C; C₂H₅; H; close the bracket, put C=C back; but-1-ene.
- **Image Asset Reference**: `None` · **Alt Text**: From Polymer to Monomer (2): C; C₂H₅; H; close the bracket, put C=C back; but-1-ene.
- **Visual Labels**: Polymer to monomer: ethyl side group, C, C₂H₅, H, close the bracket, put C=C back, but-1-ene
- **SVG Content**: Present (5545 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p318 Question 8g, h] Ethyl-substituted polymer, toxic gas from an inefficient incinerator.
- **Existing Checkpoints After This Slide**: None

## Slide 59: `k04` — Disposing of Poly(alkene)s
- **Learning Objective / Purpose**: Evaluate disposal methods for addition polymers.
- **Indicators**: H15.13
- **On-Screen Educational Text**:
  - Landfill: persists, uses land
  - Recycling needs sorting
  - Energy recovery releases CO₂ and CO
- **Key Ideas**: Landfill: persists, uses land | Recycling needs sorting | Energy recovery releases CO₂ and CO
- **Complete Narration Text**: Plastics are widely used, but large scale use has created a disposal problem. Poly alkenes are effectively huge alkane molecules, so they resist chemical attack and can take hundreds of years to decompose in landfill. The coursebook describes them as non biodegradable, so waste poly alkenes pollute the environment for centuries, as plastic sachets and carrier bags do when they block drains in Ghanaian towns. The table compares options. Reuse reduces waste. Recycling by melting and re moulding saves raw materials but needs careful sorting by recycling code. Chemical or feedstock recycling breaks polymers into useful chemicals but needs energy. Landfill is simple but leaves persistent waste.
- **Audio Asset Reference**: `audio/k04.e4103e416372.mp3` (47s, source: tts)
- **Visual Type**: `svg` · **Description**: Disposing of Poly(alkene)s: Option; Benefit; Limit; Landfill; simple; persists; Reuse; less waste; not all items; Recycle; saves oil; needs sorting; Burn; energy; CO₂, CO; Feedstock; new chemicals; needs energy.
- **Image Asset Reference**: `None` · **Alt Text**: Disposing of Poly(alkene)s: Option; Benefit; Limit; Landfill; simple; persists; Reuse; less waste; not all items; Recycle; saves oil; needs sorting; Burn; energy; CO₂, CO; Feedstock; new chemicals; needs energy.
- **Visual Labels**: Waste options, Option, Benefit, Limit, Landfill, simple, persists, Reuse, less waste, not all items, Recycle, saves oil, needs sorting, Burn, energy, CO₂, CO, Feedstock, new chemicals, needs energy
- **SVG Content**: Present (4983 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p317] Disposal, non-biodegradable, recycling difficulty. Ghana examples (sachets, carrier bags, blocked drains) are local context, not textbook content. Never burn plastics as an activity.
- **Existing Checkpoints After This Slide**: None

## Slide 60: `k05` — Burning Plastic Waste
- **Learning Objective / Purpose**: Evaluate energy recovery and its hazards.
- **Indicators**: H15.13
- **On-Screen Educational Text**:
  - Energy recovery: benefit depends on process
  - Incomplete burning gives toxic CO
  - Burning PVC can release HCl; dioxins may form
- **Key Ideas**: Energy recovery: benefit depends on process | Incomplete burning gives toxic CO | Burning PVC can release HCl; dioxins may form
- **Complete Narration Text**: One way to deal with waste poly alkenes is to burn them and use the energy to generate electricity. If hydrocarbons burn in excess oxygen, the products are carbon dioxide and water. Incineration releases carbon dioxide and is not a zero carbon process. Its overall greenhouse gas impact depends on the waste being burned, the energy recovered and the alternative disposal method. Incomplete combustion produces toxic carbon monoxide. Burning poly chloroethene can release acidic hydrogen chloride gas, and under unsuitable combustion and cooling conditions, toxic chlorinated compounds, including dioxins, may also form. Controlled industrial incinerators use very high temperatures and gas cleaning. These are facts for evaluation only: students must never burn plastics, because the fumes are dangerous.
- **Audio Asset Reference**: `audio/k05.7672b92ed66e.mp3` (51s, source: tts)
- **Visual Type**: `svg` · **Description**: Burning Plastic Waste: Complete burning: CO₂ + H₂O; may displace fuel; CO₂ is still released to the air; Incomplete burning: toxic CO; PVC: HCl; dioxins possible if poorly burned; Controls: gas cleaning; high temperature.
- **Image Asset Reference**: `None` · **Alt Text**: Burning Plastic Waste: Complete burning: CO₂ + H₂O; may displace fuel; CO₂ is still released to the air; Incomplete burning: toxic CO; PVC: HCl; dioxins possible if poorly burned; Controls: gas cleaning; high temperature.
- **Visual Labels**: Energy recovery from plastic waste, Complete burning: CO₂ + H₂O; may displace fuel, CO₂ is still released to the air, Incomplete burning: toxic CO, PVC: HCl; dioxins possible if poorly burned, Controls: gas cleaning; high temperature
- **SVG Content**: Present (1874 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p317 Burning plastic waste] CO, HCl, dioxins, incinerator conditions. Safety note added.
- **Existing Checkpoints After This Slide**:
  - Checkpoint `cpK` (retryRule: 2 attempts, then show the answer with the explanation):
    - [mcq] `sK.1`: What is the repeat unit of poly(chloroethene)? — Correct: b (a: –CH=CHCl– | b: –CH₂–CHCl– | c: –CHCl–CHCl– | d: –CH₂–CH₂Cl–)
    - [mcq] `sK.2`: What is the repeat unit of PTFE? — Correct: d (a: –CF=CF– | b: –CH₂–CF₂– | c: –CF₂–CF₂–CF₂– | d: –CF₂–CF₂–)
    - [mcq] `sK.3`: A polymer has repeat unit –CH₂–CH(CH₃)–. What is the monomer? — Correct: b (a: 2-methylpropene | b: Propene | c: Ethene | d: But-1-ene)
    - [mcq] `sK.4`: Which statement about disposing of addition polymers is most accurate? — Correct: a (a: Burning can recover energy but may release CO, and HCl from PVC; dioxins can form under poor conditions | b: Burning plastic in an open fire is safe | c: Burning plastic gives only harmless CO₂ and water | d: All addition polymers biodegrade quickly)
    - [mcq] `sK.5`: Which is chemical (feedstock) recycling of polymer waste? — Correct: a (a: Cracking it into small molecules for new chemicals | b: Burning it to generate electricity | c: Melting and remoulding it | d: Burying it in landfill)

## Slide 61: `p01` — Practice 1: Combustion Volumes
- **Learning Objective / Purpose**: Set a combustion gas-volume task.
- **Indicators**: H15.14
- **On-Screen Educational Text**:
  - Task: 20 cm³ propane burns completely
  - Find O₂ used and CO₂ made
  - All gases at the same temperature and pressure
- **Key Ideas**: Task: 20 cm³ propane burns completely | Find O₂ used and CO₂ made | All gases at the same temperature and pressure
- **Complete Narration Text**: Here is your first practice question. Twenty cubic centimetres of propane, C 3 H 8, burns completely in excess oxygen. All gas volumes are measured at the same temperature and pressure. Write the balanced equation, then find the volume of oxygen used and the volume of carbon dioxide formed. Hint: equal volumes of gases at the same temperature and pressure contain equal numbers of molecules, so the ratio of volumes equals the ratio in the equation. Pause the lesson now and write your equation and working on paper before you move to the next slide.
- **Audio Asset Reference**: `audio/p01.0eebd8117331.mp3` (41s, source: tts)
- **Visual Type**: `svg` · **Description**: Practice 1: Combustion Volumes: 20 cm³ of propane burns completely.; 1 Write the balanced equation.; 2 Volume of O₂ used?; 3 Volume of CO₂ made?.
- **Image Asset Reference**: `None` · **Alt Text**: Practice 1: Combustion Volumes: 20 cm³ of propane burns completely.; 1 Write the balanced equation.; 2 Volume of O₂ used?; 3 Volume of CO₂ made?.
- **Visual Labels**: Practice 1, 20 cm³ of propane burns completely., 1 Write the balanced equation., 2 Volume of O₂ used?, 3 Volume of CO₂ made?
- **SVG Content**: Present (1497 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [CONTEXT] Built from the photographed coursebook pages; explanations are written for this lesson.
- **Existing Checkpoints After This Slide**: None

## Slide 62: `p02` — Practice 1: Worked Solution
- **Learning Objective / Purpose**: Show worked solution and marking guidance.
- **Indicators**: H15.14
- **On-Screen Educational Text**:
  - C₃H₈ + 5O₂ → 3CO₂ + 4H₂O
  - O₂ used: 5 × 20 = 100 cm³
  - CO₂ made: 3 × 20 = 60 cm³
- **Key Ideas**: C₃H₈ + 5O₂ → 3CO₂ + 4H₂O | O₂ used: 5 × 20 = 100 cm³ | CO₂ made: 3 × 20 = 60 cm³
- **Complete Narration Text**: The balanced equation is C 3 H 8 plus 5 O 2 giving 3 C O 2 plus 4 H 2 O. The ratio of propane to oxygen to carbon dioxide is one to five to three. So for twenty cubic centimetres of propane, oxygen used is five times twenty, which is one hundred cubic centimetres. Carbon dioxide formed is three times twenty, which is sixty cubic centimetres. A typical marking approach gives one mark for the correct equation, one for the ratio, and one for each correct volume with units. This is practice marking guidance written for this lesson, not an official Cambridge mark scheme. Check that you included the units.
- **Audio Asset Reference**: `audio/p02.996756359f3a.mp3` (49s, source: tts)
- **Visual Type**: `svg` · **Description**: Practice 1: Worked Solution: C₃H₈ + 5O₂ → 3CO₂ + 4H₂O; Ratio 1 : 5 : 3; O₂ used: 5 × 20 = 100 cm³; CO₂ made: 3 × 20 = 60 cm³.
- **Image Asset Reference**: `None` · **Alt Text**: Practice 1: Worked Solution: C₃H₈ + 5O₂ → 3CO₂ + 4H₂O; Ratio 1 : 5 : 3; O₂ used: 5 × 20 = 100 cm³; CO₂ made: 3 × 20 = 60 cm³.
- **Visual Labels**: Practice 1: solution, C₃H₈ + 5O₂ → 3CO₂ + 4H₂O, Ratio 1 : 5 : 3, O₂ used: 5 × 20 = 100 cm³, CO₂ made: 3 × 20 = 60 cm³
- **SVG Content**: Present (1500 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [VERIFY] Worked solution written for this lesson (the coursebook gives no answers); recomputed in verify.py.
- **Existing Checkpoints After This Slide**: None

## Slide 63: `p03` — Practice 2: Percentage Yield
- **Learning Objective / Purpose**: Set a percentage-yield task.
- **Indicators**: H15.14
- **On-Screen Educational Text**:
  - 14.0 g of ethene hydrated to ethanol
  - Actual mass of ethanol: 16.1 g
  - Find the percentage yield
- **Key Ideas**: 14.0 g of ethene hydrated to ethanol | Actual mass of ethanol: 16.1 g | Find the percentage yield
- **Complete Narration Text**: Practice question two is about percentage yield. Fourteen point zero grams of ethene reacts with excess steam to make ethanol. The mass of ethanol collected is sixteen point one grams. Calculate the percentage yield. Use these relative atomic masses: carbon twelve, hydrogen one and oxygen sixteen. The steps are: find the relative formula masses, work out the moles of ethene, use the one to one ratio to find the theoretical mass of ethanol, then divide the actual mass by the theoretical mass and multiply by one hundred. Pause and write your working on paper before you move on.
- **Audio Asset Reference**: `audio/p03.4ec535c84597.mp3` (43s, source: tts)
- **Visual Type**: `svg` · **Description**: Practice 2: Percentage Yield: 14.0 g ethene reacts with excess steam.; 16.1 g ethanol is collected.; 1 Mr of ethene and ethanol?; 2 Theoretical mass; percentage yield?.
- **Image Asset Reference**: `None` · **Alt Text**: Practice 2: Percentage Yield: 14.0 g ethene reacts with excess steam.; 16.1 g ethanol is collected.; 1 Mr of ethene and ethanol?; 2 Theoretical mass; percentage yield?.
- **Visual Labels**: Practice 2, 14.0 g ethene reacts with excess steam., 16.1 g ethanol is collected., 1 Mr of ethene and ethanol?, 2 Theoretical mass; percentage yield?
- **SVG Content**: Present (1522 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [CONTEXT] Built from the photographed coursebook pages; explanations are written for this lesson.
- **Existing Checkpoints After This Slide**: None

## Slide 64: `p04` — Practice 2: Worked Solution
- **Learning Objective / Purpose**: Show worked solution and marking guidance.
- **Indicators**: H15.14
- **On-Screen Educational Text**:
  - Mr: C₂H₄ = 28.0; C₂H₅OH = 46.0
  - Theoretical mass = 23.0 g
  - Yield = 16.1 ÷ 23.0 × 100 = 70.0%
- **Key Ideas**: Mr: C₂H₄ = 28.0; C₂H₅OH = 46.0 | Theoretical mass = 23.0 g | Yield = 16.1 ÷ 23.0 × 100 = 70.0%
- **Complete Narration Text**: First, the relative formula mass of ethene is twenty eight point zero and of ethanol is forty six point zero. The moles of ethene are fourteen point zero divided by twenty eight point zero, which is zero point five. The ratio is one to one, so the theoretical moles of ethanol are zero point five, and the theoretical mass is zero point five times forty six, which is twenty three point zero grams. The percentage yield is sixteen point one divided by twenty three point zero, times one hundred, which is seventy point zero percent. A practice marking approach gives marks for each relative formula mass, the theoretical mass, and the final percentage. This is guidance, not an official mark scheme.
- **Audio Asset Reference**: `audio/p04.83770c345f9e.mp3` (53s, source: tts)
- **Visual Type**: `svg` · **Description**: Practice 2: Worked Solution: Mr C₂H₄ = 28.0; Mr C₂H₅OH = 46.0; Moles ethene = 14.0 ÷ 28.0 = 0.500; Theoretical ethanol = 0.500 × 46.0 = 23.0 g; Yield = 16.1 ÷ 23.0 × 100 = 70.0%.
- **Image Asset Reference**: `None` · **Alt Text**: Practice 2: Worked Solution: Mr C₂H₄ = 28.0; Mr C₂H₅OH = 46.0; Moles ethene = 14.0 ÷ 28.0 = 0.500; Theoretical ethanol = 0.500 × 46.0 = 23.0 g; Yield = 16.1 ÷ 23.0 × 100 = 70.0%.
- **Visual Labels**: Practice 2: solution, Mr C₂H₄ = 28.0; Mr C₂H₅OH = 46.0, Moles ethene = 14.0 ÷ 28.0 = 0.500, Theoretical ethanol = 0.500 × 46.0 = 23.0 g, Yield = 16.1 ÷ 23.0 × 100 = 70.0%
- **SVG Content**: Present (1553 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [VERIFY] Worked solution written for this lesson; recomputed in verify.py.
- **Existing Checkpoints After This Slide**: None

## Slide 65: `p05` — Practice 3: Deduce the Alkene
- **Learning Objective / Purpose**: Set an oxidation-deduction task.
- **Indicators**: H15.14
- **On-Screen Educational Text**:
  - An alkene C₅H₁₀ is heated with KMnO₄
  - Products: propanone and ethanoic acid
  - Draw and name the alkene
- **Key Ideas**: An alkene C₅H₁₀ is heated with KMnO₄ | Products: propanone and ethanoic acid | Draw and name the alkene
- **Complete Narration Text**: Practice question three. An alkene with the molecular formula C 5 H 10 is heated with hot, concentrated, acidified potassium manganate seven. The products are propanone, a ketone, and ethanoic acid, a carboxylic acid. Deduce the structure of the alkene and name it. Hint: the ketone came from a double bond carbon with two alkyl groups, and the carboxylic acid came from a double bond carbon with one hydrogen and one alkyl group. Join the two carbons with a double bond and check that the total number of carbons is five. Draw the structure and write its name on paper before you open the worked solution.
- **Audio Asset Reference**: `audio/p05.41a732707ed3.mp3` (46s, source: tts)
- **Visual Type**: `svg` · **Description**: Practice 3: Deduce the Alkene: Alkene C₅H₁₀ + hot conc. acidified KMnO₄; Products: propanone and ethanoic acid; 1 Which carbon gave the ketone?; 2 Draw and name the alkene..
- **Image Asset Reference**: `None` · **Alt Text**: Practice 3: Deduce the Alkene: Alkene C₅H₁₀ + hot conc. acidified KMnO₄; Products: propanone and ethanoic acid; 1 Which carbon gave the ketone?; 2 Draw and name the alkene..
- **Visual Labels**: Practice 3, Alkene C₅H₁₀ + hot conc. acidified KMnO₄, Products: propanone and ethanoic acid, 1 Which carbon gave the ketone?, 2 Draw and name the alkene.
- **SVG Content**: Present (1526 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [CONTEXT] Built from the photographed coursebook pages; explanations are written for this lesson.
- **Existing Checkpoints After This Slide**: None

## Slide 66: `p06` — Practice 3: Worked Solution
- **Learning Objective / Purpose**: Show worked solution and marking guidance.
- **Indicators**: H15.14
- **On-Screen Educational Text**:
  - Propanone ← =C(CH₃)₂
  - Ethanoic acid ← =CHCH₃
  - Alkene: (CH₃)₂C=CHCH₃, 2-methylbut-2-ene
- **Key Ideas**: Propanone ← =C(CH₃)₂ | Ethanoic acid ← =CHCH₃ | Alkene: (CH₃)₂C=CHCH₃, 2-methylbut-2-ene
- **Complete Narration Text**: Propanone has three carbons, so it came from a carbon with two methyl groups, written equals C open bracket C H 3 close bracket 2. Ethanoic acid has two carbons, so it came from a carbon with one hydrogen and a methyl group, written equals C H C H 3. Joining these two carbons by a double bond gives C H 3, twice, attached to the first carbon, double bond, then C H C H 3. That is C H 3 twice, C, double bond, C H, C H 3. The longest chain containing the double bond has four carbons with a methyl branch on carbon two, so the name is 2 methylbut 2 ene. Check: five carbons, ten hydrogens. This is practice guidance, not an official mark scheme.
- **Audio Asset Reference**: `audio/p06.efa85263a351.mp3` (56s, source: tts)
- **Visual Type**: `svg` · **Description**: Practice 3: Worked Solution: Propanone came from =C(CH₃)₂; Ethanoic acid came from =CHCH₃; Join: (CH₃)₂C=CHCH₃; Name: 2-methylbut-2-ene.
- **Image Asset Reference**: `None` · **Alt Text**: Practice 3: Worked Solution: Propanone came from =C(CH₃)₂; Ethanoic acid came from =CHCH₃; Join: (CH₃)₂C=CHCH₃; Name: 2-methylbut-2-ene.
- **Visual Labels**: Practice 3: solution, Propanone came from =C(CH₃)₂, Ethanoic acid came from =CHCH₃, Join: (CH₃)₂C=CHCH₃, Name: 2-methylbut-2-ene
- **SVG Content**: Present (1511 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [VERIFY] Worked solution written for this lesson; recomputed in verify.py.
- **Existing Checkpoints After This Slide**: None

## Slide 67: `p07` — Practice 4: Ethane and Bromine
- **Learning Objective / Purpose**: Set a free-radical substitution task (paper practice).
- **Indicators**: H15.14
- **On-Screen Educational Text**:
  - Ethane reacts with bromine in UV light
  - Name the mechanism and type of fission
  - Write initiation, propagation and termination
- **Key Ideas**: Ethane reacts with bromine in UV light | Name the mechanism and type of fission | Write initiation, propagation and termination
- **Complete Narration Text**: Practice question four is an original Cambridge style question. Ethane reacts with bromine to give bromoethane and hydrogen bromide. Write your answers on paper. Part a: name the mechanism and state the essential conditions. Part b: write the balanced equation and name the type of bond breaking in the first step. Part c: write one equation for an initiation step, two equations for the propagation steps, and one equation for a termination step. Remember to show the unpaired electron on each radical with a dot. When you have written your answers, move to the next slide to mark yourself using the worked solution. This is paper based practice because the lesson cannot accept drawn answers.
- **Audio Asset Reference**: `audio/p07.ba74d64dac14.mp3` (50s, source: tts)
- **Visual Type**: `svg` · **Description**: Practice 4: Ethane and Bromine: Ethane + bromine → bromoethane + HBr; a Name the mechanism. Conditions?; b Balanced equation; bond fission type?; c Initiation, propagation, termination.
- **Image Asset Reference**: `None` · **Alt Text**: Practice 4: Ethane and Bromine: Ethane + bromine → bromoethane + HBr; a Name the mechanism. Conditions?; b Balanced equation; bond fission type?; c Initiation, propagation, termination.
- **Visual Labels**: Practice 4 (write on paper), Ethane + bromine → bromoethane + HBr, a Name the mechanism. Conditions?, b Balanced equation; bond fission type?, c Initiation, propagation, termination
- **SVG Content**: Present (1571 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p320 Q3 style] Original variant using ethane.
- **Existing Checkpoints After This Slide**: None

## Slide 68: `p08` — Practice 4: Worked Solution and Self-Marking
- **Learning Objective / Purpose**: Give the worked solution.
- **Indicators**: H15.14
- **On-Screen Educational Text**:
  - Free-radical substitution; UV light
  - Br₂ → 2Br•; Br• + C₂H₆ → HBr + •C₂H₅
  - •C₂H₅ + Br₂ → C₂H₅Br + Br•
- **Key Ideas**: Free-radical substitution; UV light | Br₂ → 2Br•; Br• + C₂H₆ → HBr + •C₂H₅ | •C₂H₅ + Br₂ → C₂H₅Br + Br•
- **Complete Narration Text**: Mark yourself. Part a: the mechanism is free radical substitution, and the essential condition is ultraviolet light, or sunlight. Part b: the equation is C 2 H 6 plus Br 2 giving C 2 H 5 Br plus H Br, and the first step involves homolytic fission. Part c, initiation: Br 2 gives two Br dot. Propagation: Br dot plus C 2 H 6 gives H Br plus C 2 H 5 dot, and C 2 H 5 dot plus Br 2 gives C 2 H 5 Br plus Br dot. Termination: for example, two Br dot give Br 2, or C 2 H 5 dot and Br dot give C 2 H 5 Br. Award yourself one mark for each correct, balanced, correctly dotted equation. This is practice guidance written for this lesson, not an official mark scheme.
- **Audio Asset Reference**: `audio/p08.e71216342c7c.mp3` (60s, source: tts)
- **Visual Type**: `svg` · **Description**: Practice 4: Worked Solution and Self-Marking: a Free-radical substitution; UV light; b C₂H₆ + Br₂ → C₂H₅Br + HBr; homolytic; Init: Br₂ → 2Br•; Prop: Br• + C₂H₆ → HBr + •C₂H₅; Prop: •C₂H₅ + Br₂ → C₂H₅Br + Br•.
- **Image Asset Reference**: `None` · **Alt Text**: Practice 4: Worked Solution and Self-Marking: a Free-radical substitution; UV light; b C₂H₆ + Br₂ → C₂H₅Br + HBr; homolytic; Init: Br₂ → 2Br•; Prop: Br• + C₂H₆ → HBr + •C₂H₅; Prop: •C₂H₅ + Br₂ → C₂H₅Br + Br•.
- **Visual Labels**: Practice 4: solution, a Free-radical substitution; UV light, b C₂H₆ + Br₂ → C₂H₅Br + HBr; homolytic, Init: Br₂ → 2Br•, Prop: Br• + C₂H₆ → HBr + •C₂H₅, Prop: •C₂H₅ + Br₂ → C₂H₅Br + Br•
- **SVG Content**: Present (1810 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [VERIFY] Worked solution written for this lesson and recomputed in verify.py.
- **Existing Checkpoints After This Slide**: None

## Slide 69: `p09` — Practice 5: Percentage Yield
- **Learning Objective / Purpose**: Set a yield task for ethene and bromine.
- **Indicators**: H15.14
- **On-Screen Educational Text**:
  - 5.60 g ethene reacts with excess bromine
  - 33.84 g of 1,2-dibromoethane is made
  - Calculate the percentage yield
- **Key Ideas**: 5.60 g ethene reacts with excess bromine | 33.84 g of 1,2-dibromoethane is made | Calculate the percentage yield
- **Complete Narration Text**: Practice question five. Five point six zero grams of ethene reacts with excess bromine to make 1,2-dibromoethane. The mass collected is thirty three point eight four grams. Use A r values of carbon twelve point zero, hydrogen one point zero and bromine eighty point zero. Part a: calculate the moles of ethene used. Part b: calculate the theoretical mass of 1,2-dibromoethane and the percentage yield. Part c: calculate the mass that would form if the percentage yield had been seventy five point zero percent. Write your working on paper, with units, and then check against the worked solution on the next slide.
- **Audio Asset Reference**: `audio/p09.be5c0646ef5f.mp3` (44s, source: tts)
- **Visual Type**: `svg` · **Description**: Practice 5: Percentage Yield: 5.60 g C₂H₄ + excess Br₂; 33.84 g C₂H₄Br₂ is collected; a Moles of ethene used?; b Theoretical mass; percentage yield?; c Mass if the yield were 75.0%?.
- **Image Asset Reference**: `None` · **Alt Text**: Practice 5: Percentage Yield: 5.60 g C₂H₄ + excess Br₂; 33.84 g C₂H₄Br₂ is collected; a Moles of ethene used?; b Theoretical mass; percentage yield?; c Mass if the yield were 75.0%?.
- **Visual Labels**: Practice 5 (A: C 12.0, H 1.0, Br 80.0), 5.60 g C₂H₄ + excess Br₂, 33.84 g C₂H₄Br₂ is collected, a Moles of ethene used?, b Theoretical mass; percentage yield?, c Mass if the yield were 75.0%?
- **SVG Content**: Present (1836 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [TEXTBOOK p321–322 Q4, Q8 style] Original numbers.
- **Existing Checkpoints After This Slide**: None

## Slide 70: `p10` — Practice 5: Worked Solution
- **Learning Objective / Purpose**: Give the worked solution.
- **Indicators**: H15.14
- **On-Screen Educational Text**:
  - Moles ethene = 5.60 ÷ 28.0 = 0.200
  - Theoretical = 0.200 × 188.0 = 37.6 g
  - Yield = 33.84 ÷ 37.6 × 100 = 90.0%
- **Key Ideas**: Moles ethene = 5.60 ÷ 28.0 = 0.200 | Theoretical = 0.200 × 188.0 = 37.6 g | Yield = 33.84 ÷ 37.6 × 100 = 90.0%
- **Complete Narration Text**: The relative formula mass of ethene is twenty eight point zero. For 1,2-dibromoethane, two carbons give twenty four, four hydrogens give four, and two bromines give one hundred and sixty, a total of one hundred and eighty eight point zero. Part a: moles of ethene are five point six zero divided by twenty eight point zero, which is zero point two zero zero. Part b: the ratio is one to one, so the theoretical mass is zero point two zero zero times one hundred and eighty eight, which is thirty seven point six grams. The percentage yield is thirty three point eight four divided by thirty seven point six, times one hundred, which is ninety point zero percent. Part c: seventy five percent of thirty seven point six grams is twenty eight point two grams. Practice guidance, not an official mark scheme.
- **Audio Asset Reference**: `audio/p10.03bdfb554d42.mp3` (62s, source: tts)
- **Visual Type**: `svg` · **Description**: Practice 5: Worked Solution: Mr C₂H₄ = 28.0; Mr C₂H₄Br₂ = 188.0; a 5.60 ÷ 28.0 = 0.200 mol; b 0.200 × 188.0 = 37.6 g; Yield = 33.84 ÷ 37.6 × 100 = 90.0%; c 0.750 × 37.6 = 28.2 g.
- **Image Asset Reference**: `None` · **Alt Text**: Practice 5: Worked Solution: Mr C₂H₄ = 28.0; Mr C₂H₄Br₂ = 188.0; a 5.60 ÷ 28.0 = 0.200 mol; b 0.200 × 188.0 = 37.6 g; Yield = 33.84 ÷ 37.6 × 100 = 90.0%; c 0.750 × 37.6 = 28.2 g.
- **Visual Labels**: Practice 5: solution, Mr C₂H₄ = 28.0; Mr C₂H₄Br₂ = 188.0, a 5.60 ÷ 28.0 = 0.200 mol, b 0.200 × 188.0 = 37.6 g, Yield = 33.84 ÷ 37.6 × 100 = 90.0%, c 0.750 × 37.6 = 28.2 g
- **SVG Content**: Present (1797 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [VERIFY] Recomputed in verify.py.
- **Existing Checkpoints After This Slide**: None

## Slide 71: `z01` — Chapter Recap
- **Learning Objective / Purpose**: Recap the chapter and prepare for the mastery check.
- **Indicators**: H15.14
- **On-Screen Educational Text**:
  - Alkanes: unreactive but burn and undergo radical substitution
  - Alkenes: π bond, electrophilic addition
  - Reagents, conditions, observations, mechanisms
- **Key Ideas**: Alkanes: unreactive but burn and undergo radical substitution | Alkenes: π bond, electrophilic addition | Reagents, conditions, observations, mechanisms
- **Complete Narration Text**: Let us recap the chapter. Open chain alkanes are saturated hydrocarbons with the general formula C n H 2 n plus 2. They are fairly unreactive because their sigma bonds are strong and of low polarity, they have no functional group, and many reactions have high activation energies, but they burn and undergo free radical substitution with halogens in ultraviolet light. Cracking breaks large alkanes into smaller alkanes and alkenes. Alkenes, with general formula C n H 2 n for one double bond, contain a pi bond and undergo electrophilic addition, with the more stable carbocation giving the major product. Potassium manganate seven oxidises alkenes to diols when cold and cleaves them when hot. Alkenes form addition polymers, which are often persistent waste, so reuse, recycling and carefully controlled energy recovery all matter. Now try the mastery check.
- **Audio Asset Reference**: `audio/z01.abc4bdd8c813.mp3` (60s, source: tts)
- **Visual Type**: `svg` · **Description**: Chapter Recap: Alkanes: CₙH₂ₙ₊₂, unreactive, burn, radicals; Cracking: large alkane → smaller alkane + alkene; Alkenes: π bond, electrophilic addition; Oxidation: diol (cold); cleavage (hot); Addition polymers: repeat unit, disposal.
- **Image Asset Reference**: `None` · **Alt Text**: Chapter Recap: Alkanes: CₙH₂ₙ₊₂, unreactive, burn, radicals; Cracking: large alkane → smaller alkane + alkene; Alkenes: π bond, electrophilic addition; Oxidation: diol (cold); cleavage (hot); Addition polymers: repeat unit, disposal.
- **Visual Labels**: Chapter 15 in one page, Alkanes: CₙH₂ₙ₊₂, unreactive, burn, radicals, Cracking: large alkane → smaller alkane + alkene, Alkenes: π bond, electrophilic addition, Oxidation: diol (cold); cleavage (hot), Addition polymers: repeat unit, disposal
- **SVG Content**: Present (1870 chars; preserved verbatim in lessons/ JSON)
- **Existing Interactive Configuration**: None
- **Teacher Note**: [CONTEXT] Built from the photographed coursebook pages; explanations are written for this lesson. [TEXTBOOK p319] Chapter summary and reflection activity.
- **Existing Checkpoints After This Slide**: None

## End-of-Lesson Mastery Check (Pass Mark: 16)
- [mcq] `mC.1`: What is the general formula of the alkenes? — Correct: a (a: CₙH₂ₙ | b: CₙH₂ₙ₊₂ | c: CₙHₙ | d: CₙH₂ₙ₋₂)
- [mcq] `mC.2`: What are the main forces between alkane molecules? — Correct: b (a: Ionic attractions | b: Instantaneous dipole–induced dipole forces | c: Permanent dipole–dipole forces | d: Hydrogen bonds)
- [mcq] `mC.3`: Which pollutant forms from nitrogen and oxygen in the hot engine air? — Correct: d (a: CH₄ | b: CO | c: SO₂ | d: NOₓ)
- [mcq] `mC.4`: Why does free-radical substitution of methane give a mixture of products? — Correct: d (a: Chlorine is a very weak oxidant | b: Methane has several isomers | c: UV light breaks C–C bonds | d: More hydrogens can be substituted in later steps)
- [mcq] `mC.5`: What does a curly arrow show? — Correct: d (a: The movement of an atom | b: The direction of heat flow | c: The rate of reaction | d: The movement of an electron pair)
- [mcq] `mC.6`: In HBr + propene, why is 2-bromopropane the major product? — Correct: b (a: Bromine is bigger than hydrogen | b: It forms through the more stable secondary carbocation | c: It has fewer bonds | d: It forms through a primary carbocation)
- [mcq] `mC.7`: 10 cm³ of ethane burns completely in excess oxygen. What volume of CO₂ forms at the same temperature and pressure? — Correct: a (a: 20 cm³ | b: 10 cm³ | c: 35 cm³ | d: 30 cm³)
- [mcq] `mC.8`: Theoretical yield is 23.0 g and 16.1 g is made. What is the percentage yield? — Correct: b (a: 143% | b: 70.0% | c: 7.0% | d: 30.0%)
- [mcq] `mC.9`: What is the name of CH₃CH(CH₃)CH₂CH₃? — Correct: c (a: 3-methylbutane | b: Pentane | c: 2-methylbutane | d: 2-methylpropane)
- [mcq] `mC.10`: Which fraction from crude oil has the highest boiling point? — Correct: d (a: Petrol | b: Kerosene | c: Refinery gas | d: Bitumen)
- [mcq] `mC.11`: Which catalyst is used in catalytic cracking? — Correct: c (a: Iron | b: Nickel | c: A zeolite | d: Concentrated sulfuric acid)
- [mcq] `mC.12`: Which observation shows a gas is ethene, not ethane? — Correct: d (a: Bromine water stays orange | b: The gas has no smell | c: Limewater turns milky | d: Bromine water turns from orange to colourless)
- [mcq] `mC.13`: Ethene reacts with hydrogen over a nickel catalyst. What forms? — Correct: b (a: Ethane-1,2-diol | b: Ethane | c: Ethanol | d: Bromoethane)
- [mcq] `mC.14`: Hot concentrated acidified KMnO₄ oxidises 2-methylpropene. Which products form? — Correct: c (a: Two propanone molecules | b: 2-methylpropane-1,2-diol | c: Propanone and carbon dioxide | d: Ethanoic acid and CO₂)
- [mcq] `mC.15`: Propene reacts with cold dilute acidified KMnO₄. What is the organic product? — Correct: d (a: Ethanoic acid and CO₂ | b: Propanone | c: Propan-1-ol | d: Propane-1,2-diol)
- [mcq] `mC.16`: What is the monomer of PVC? — Correct: d (a: Ethene | b: Tetrafluoroethene | c: Propene | d: Chloroethene)
- [mcq] `mC.17`: Why can an alkene undergo addition polymerisation? — Correct: a (a: It contains a C=C bond that can open to join monomers | b: It loses water on joining | c: It is a polar molecule | d: It contains a C–H bond that breaks)
- [mcq] `mC.18`: What is the product of ethene and chlorine? — Correct: b (a: Ethane | b: 1,2-dichloroethane | c: Chloroethane | d: Dichloromethane)
- [mcq] `mC.19`: Which species is a free radical? — Correct: b (a: HBr | b: Br• | c: Br⁻ | d: CH₄)
- [mcq] `mC.20`: Which carbocation forms in the major route of propene + HBr? — Correct: d (a: CH₃CH₂CH₂⁺ | b: CH₃CH(Br)CH₂⁺ | c: CH₃⁺ | d: CH₃CH⁺CH₃)
