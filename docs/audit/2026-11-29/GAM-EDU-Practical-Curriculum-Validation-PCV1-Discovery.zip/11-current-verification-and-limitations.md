# 11 — Current Verification Status & Honest Limitations (Section 13 Resolution)

1. **Final complete 3,868-test regression suite**:
   - On the full `npx vitest run` (100 files, 3,868 tests) before the final 3 version-string updates, **3,865 / 3,868** passed (97/100 files); the only 3 failures were hardcoded `engineVersion === '1.6.0'` assertions in `data-stats-lab.test.tsx`, `geometry-constructor.test.tsx`, and `measurement-lab.test.tsx`.
   - After updating those 3 assertions and clearing the TS ratchet, all 7 affected/new suites (**73 / 73 tests**) were re-run and passed, alongside `tsc-report.mjs --ratchet` (`351 <= 351`), `check-lockfile-sync.mjs` (OK), math oracle (`10,200` executed / `9,448` distinct, `0` discrepancies), and `npm run build` (exit 0). A fresh single-shot rerun of all 100 files together has not yet been re-executed since commit `512fca19`.
2. **Latest CI rules and security jobs**:
   - Local verification does not run the Firebase Emulator or GitHub Actions runner; CI workflow `.github/workflows/foundation-verification.yml` executes automatically on push to `fixed-version` (`512fca19`) and should be checked on GitHub Actions for emulator rules pass status.
3. **Does `simultaneous-linear` require a new `math-evaluator` engine version?**:
   - **Recommendation: YES, bump `math-evaluator` `engineVersion` to `1.2.0` (holding `productionVersion` at `1.1.0`) before authoring `simultaneous-linear` in live CDN lessons**, because older deployed `1.1.0` clients do not contain `math-eval-linear-systems.ts` or a UI renderer for `mode: 'simultaneous-linear'`. (Not changed during PCV-1 discovery.)
4. **Positional `(n+1)/4` quartile convention curriculum source evidence**:
   - Documented in Cambridge IGCSE Mathematics 0580 syllabus (Section 9.5 / specimen papers: discrete data quartiles at `(n+1)/4` and `3(n+1)/4` positions) and NaCCA SHS Core Mathematics statistics units. Default remains `'tukey-exclusive'`; `'positional-n-plus-1'` is strictly opt-in.
5. **Accessibility findings awaiting live browser re-verification**:
   - `D-038` (contrast), `D-039` (image-alt), `D-040` (touch targets), and `D-042` (scrollable regions) are implemented in source and unit-tested in `accessibility-standards.test.tsx`, but **live Playwright + axe-core browser re-verification remains outstanding** (local Chromium headless shell binary not installed on this machine). `D-041`/`D-043`/`D-044` from Claude's CP3 interim report remain untouched/open for independent audit.
6. **Is production activation required for the proposed science pilots?**:
   - **NO** for Phase-1 enrichment using already-LIVE engines (`process-stepper 1.0.0`, `diagram-hotspots 1.0.0`, `graph-slider 1.0.0`, `rule-explorer 1.0.0`, `math-evaluator 1.1.0`, `equation-balancer 1.1.0`, `electrical-circuit 1.1.0`, `atom-bond-builder 1.2.0`).
   - **YES** only if we include `sort-classify 1.0.0` or `measurement-lab 1.4.0` in live CDN lessons (which requires owner Vercel promotion + explicit `productionVersion` activation).
