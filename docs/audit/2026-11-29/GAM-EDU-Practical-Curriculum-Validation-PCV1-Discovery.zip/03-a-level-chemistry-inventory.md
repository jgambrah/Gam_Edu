# 03 — Seeded A-Level Chemistry Lessons Inventory (Live CDN Ground Truth)

## Halogenoalkanes (Cambridge International AS & A Level Chemistry)
- **Exact Lesson ID**: `a-level-chem-halogenoalkanes`
- **Exact Title**: Halogenoalkanes (Cambridge International AS & A Level Chemistry)
- **Cambridge Syllabus Code & Version**: Halogenoalkanes (syllabus code to be confirmed) (Subject: Chemistry)
- **Curriculum Chapter / Topic**: Organic chemistry: halogen compounds
- **Actual App URLs**: Staff dashboard `/dashboard/narrated-lessons/a-level-chem-halogenoalkanes` · Direct route `/narrated-lessons/a-level-chem-halogenoalkanes`
- **Source JSON Location**: `.narrated-lesson-build/a-level-chem-halogenoalkanes/lesson.json` (local working copy — lacks published CDN `audioUrl`/`imageUrl`)
- **CDN Catalogue Entry**: `catalogueVersion: 96`, `packagePath: packages/a-level-chem-halogenoalkanes.30c94f3bca64.json`, `status: published`, `updatedAt: 2026-11-24T15:40:34.915Z`
- **Current Published Version (Content Hash)**: `30c94f3bca64` (schemaVersion `0.3-pilot`)
- **Slides**: 34 · **Narration Segments (with MP3)**: 34 · **Illustrations**: 1 · **SVGs**: 33
- **Assessments**: 17 checkpoints (44 items) + 1 Mastery Check (8 items, passMark 6)
- **Existing Interactive Activities**: **0**
- **Current Engine Version Requirements**: None (standard narrated lesson player v0.3)
- **Repo vs Published CDN Diff**: Same 34 slides and text structure; live CDN JSON additionally includes immutable `audioUrl` and `imageUrl` CDN links stamped by `publish-lesson.ts`.

## Hydrocarbons: Alkanes and Alkenes (Cambridge International AS & A Level Chemistry)
- **Exact Lesson ID**: `cambridge-as-a-level-chemistry-hydrocarbons`
- **Exact Title**: Hydrocarbons: Alkanes and Alkenes (Cambridge International AS & A Level Chemistry)
- **Cambridge Syllabus Code & Version**: Cambridge International AS & A Level Chemistry 9701 (2025–2027 syllabus), Coursebook Chapter 15 (Subject: Chemistry)
- **Curriculum Chapter / Topic**: Hydrocarbons
- **Actual App URLs**: Staff dashboard `/dashboard/narrated-lessons/cambridge-as-a-level-chemistry-hydrocarbons` · Direct route `/narrated-lessons/cambridge-as-a-level-chemistry-hydrocarbons`
- **Source JSON Location**: Published on Firebase Storage CDN only (no local `.narrated-lesson-build` copy on this machine)
- **CDN Catalogue Entry**: `catalogueVersion: 96`, `packagePath: packages/cambridge-as-a-level-chemistry-hydrocarbons.739c1252e89e.json`, `status: published`, `updatedAt: 2026-11-24T14:37:20.331Z`
- **Current Published Version (Content Hash)**: `739c1252e89e` (schemaVersion `0.3-pilot`)
- **Slides**: 71 · **Narration Segments (with MP3)**: 71 · **Illustrations**: 1 · **SVGs**: 70
- **Assessments**: 23 checkpoints (60 items) + 1 Mastery Check (20 items, passMark 16)
- **Existing Interactive Activities**: **0**
- **Current Engine Version Requirements**: None (standard narrated lesson player v0.3)
- **Repo vs Published CDN Diff**: No local copy in repository; live CDN JSON retrieved directly and archived verbatim in `lessons/a-level-chemistry/`.
