# 08 — Existing Student-Practice Infrastructure Audit

Inspected `NarratedLessonPlayer.tsx`, `CdnLessonPlayerLoader.tsx`, `LessonNotesAndQuestions.tsx`, `InteractiveEngineRegistry.tsx`, `ConstructionLabShell.tsx`, and `types.ts`.

## 1. Supported Practice & Assessment Capabilities
| Capability | Currently Supported? | Exact Mechanism |
|---|---|---|
| **Guided practice** | Yes | Slide-embedded `slide.interactive` blocks (up to 4 per slide) + `LessonNotesAndQuestions` worked examples with step-by-step hints & reveal |
| **Independent practice** | Yes | `math-evaluator` (`independent` / `exam-practice` modes), `construction-lab` check mode, `sort-classify`, plus Senior Academy deep links (`senior-academy-map.ts`) |
| **Prediction questions** | Yes | Built into `ConstructionLabShell`, `GraphSliderEngine`, `ProcessStepperEngine`, and `MathEvaluatorEngine` (`prediction` config object) |
| **Multiple-choice questions** | Yes | Native `McqItem` inside `lesson.checkpoints[]` and `lesson.masteryCheck` |
| **Sequencing** | Yes | Native `SequenceItem` inside checkpoints/masteryCheck + `process-stepper` & `sort-classify` (`order-sequence`) |
| **Diagram identification** | Yes | Native `TapDiagramItem` inside checkpoints + `diagram-hotspots` (`identify` mode) |
| **Numerical answers** | Yes | `math-evaluator` (`numeric-quantity`, SI units, sig-figs/dp), `measurement-lab`, `data-stats-lab` |
| **Mathematical working** | Yes | `MathWorkingWorkspace.tsx` (`multi-step-working` with M/A/B/ECF marking) |
| **Equation balancing** | Yes | `construction-lab: equation-balancer` (`1.1.0` LIVE) |
| **Construction-based assessment** | Yes | All 9 `construction-lab` domain adapters (`Check` button with deterministic grading) |
| **Multiple valid answers** | Yes | Supported across `math-evaluator`, `sort-classify`, `geometry-constructor` (reflected solutions, all 11 cube nets), `number-manipulative` (equivalent fractions, non-canonical base-ten, min-coin ties) |
| **Misconception-specific feedback** | Yes | Native `onWrong[]` misconception feedback on every checkpoint/mastery item + `misconceptionChecks` in `math-evaluator` |
| **Hints & Retry** | Yes | `hints[]` on all interactive engines, `hintText` on checkpoints, `retryRule` on checkpoints, Reset/Undo on all labs |
| **Mastery checks & End-of-lesson assessments** | Yes | Native `lesson.masteryCheck` with configurable `passMark` + `Questions` stage in `LessonNotesAndQuestions` (Recall/Understand/Why/Apply/Trap) |
| **Progress tracking** | Partial (Client-side) | Slide completion, checkpoint scores, and `LessonNotesAndQuestions` "Understood" state are stored in browser `localStorage` (0 Firestore writes during interactive exploration). |
| **Existing teacher resources** | Yes | `slide.teacherNote`, `lesson.extensionActivity` (hands-on practicals with materials/safety note), `lesson.coverageMatrix`, `slide.askTeacherContext` (curated FAQs + guarded Ask Teacher API). |

## 2. Integration Path & Current Limitations
- **How to integrate**: Add validated `interactive: [ ... ]` array entries directly onto existing slides in a new versioned lesson JSON while keeping `lessonId`, `slide.id`, `narration`, `audioUrl`, `visual`, `checkpoints`, and `masteryCheck` 100% intact.
- **Limitations**:
  1. Interactive activity completion inside `slide.interactive` is currently **practice exploration (ephemeral / 0 Firestore writes)**; `persistCompletion` is a reserved schema flag not yet wired to Firestore gradebooks.
  2. `localStorage` progress is device-local (does not roam across devices or report to teacher gradebooks yet).
  3. Data cost is minimal (CDN immutable JSON + lazy-loaded engine chunks + Low-Data Mode fallback).
