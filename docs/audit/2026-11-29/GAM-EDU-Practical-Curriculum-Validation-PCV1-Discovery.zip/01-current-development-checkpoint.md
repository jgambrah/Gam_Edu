# 01 — Current Development Checkpoint & Deployment Baseline

## 1. Repository & Git Baseline
- **Branch**: `fixed-version`
- **HEAD & `origin/fixed-version` SHA**: `512fca19755dd4ae989132a0260d99e382d8732a` (`512fca19`)
- **Next.js version**: `15.5.29`

## 2. Preserved Development Roadmap Checkpoint
- **Last reported development commit**: `512fca19`
- **Step 5E-A**: Implemented (`f5150330`); independent browser accessibility verification outstanding.
- **Step 5E-B**: Geometry educational close-out implemented (`1e2ed1b9`).
- **Step 5E-C**: Simultaneous equations and selectable quartile convention implemented (`d9c64274`).
- **Step 5F**: Primary Number Manipulatives implemented (`d08f01f1`).
- **Step 5G**: Physics Workbench is the next foundation development assignment (not commenced).
- **Step 5H**: Visual Programming, Art Studio and Game Zone remains planned.
- **Step 6**: Final Foundation Integration remains planned.
- **Temporary assignment**: Practical Curriculum Validation — Pilot 1 (**PCV-1**).
- **Claude Independent Audit**: Checkpoint 3 remains temporarily paused at `baba1cdd`; no Claude findings are marked independently verified by Gemini.

## 3. Deployment, Player, Release Gate & CDN Status
- **Production deployment commit**: Controlled manually by the owner in Vercel. Pushing to `origin/fixed-version` creates a Vercel preview build (if Git integration is enabled) but does **not** automatically promote to Production.
- **Does the owner need to promote before practical testing?**:
  - For **currently live engines** (`rule-explorer 1.0.0`, `graph-slider 1.0.0`, `process-stepper 1.0.0`, `diagram-hotspots 1.0.0`, `code-playground 1.0.0`, `math-evaluator 1.1.0`, `construction-lab 1.0.0–1.3.0` including `equation-balancer`, `electrical-circuit`, `bio-sequence-builder`, `atom-bond-builder`, `geometry-constructor`): these are already production-activated! However, testing **Step 5E-A accessibility fixes**, **Step 5E-B/C**, **`sort-classify 1.0.0`**, or **`measurement-lab 1.4.0`** in a live Vercel URL requires either testing on the **Vercel Preview deployment** for `512fca19` or an explicit owner promotion after review.
- **Lesson player**: `NarratedLessonPlayer.tsx` + `CdnLessonPlayerLoader.tsx` (supports schema `0.3`, `slide.interactive` via `InteractiveEngineRegistry.tsx`, Listen / Notes / Questions stages, Audio narration, SVG sanitiser DOMPurify 3.5.0, Low-Data mode, Ask Teacher guard).
- **Student Enrichment release gate**: **UNDER CONSTRUCTION** (`src/lib/student-enrichment-release.ts`; `NEXT_PUBLIC_STUDENT_ENRICHMENT_RELEASED` is NOT set). Ordinary student accounts are restricted; authenticated `Director`, `Administrator`, and `Teacher` staff roles can access `/dashboard/narrated-lessons` and `/dashboard/narrated-lessons/[lessonId]`.
- **CDN catalogue & asset versioning**:
  - Bucket: `gs://gamedu-69888475-f5783.firebasestorage.app/story-spark-preview/narrated-lessons/`
  - Live `catalogue.json`: `catalogueVersion: 96`, `updatedAt: 2026-11-26T10:19:49.105Z`, `49` entries (`Cache-Control: public, max-age=60, stale-while-revalidate=300`).
  - Lesson packages: content-addressed immutable JSON `packages/<lessonId>.<hash12>.json` (`Cache-Control: public, max-age=31536000, immutable`).
  - Media assets: `<lessonId>/audio/sXX.mp3` and `<lessonId>/images/sXX.webp` (immutable CDN cache, reused automatically on re-publish via `--skip-media`).
