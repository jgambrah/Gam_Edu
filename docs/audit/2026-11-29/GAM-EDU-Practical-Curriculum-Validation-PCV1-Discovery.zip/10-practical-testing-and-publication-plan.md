# 10 — Practical Testing, Controlled Publication & Safe Rollback Plan

## 1. Zero-Destruction Asset Preservation
- `scripts/lessons/publish-lesson.ts` publishes content-addressed immutable JSON files (`packages/<lessonId>.<hash12>.json`).
- **Original lesson versions are NEVER overwritten or deleted** on Firebase Storage CDN. Recording the original `packageHash` (in `manifest.json` and `03/05`) guarantees instant 1-step rollback by pointing `catalogue.json` back to the previous `packagePath` & `packageHash`.
- Using `npm run lesson:publish -- <enriched.json> --skip-media` reuses **100% of existing audio MP3s and illustration WebPs** with **0 paid AI/TTS credits**.

## 2. Recommended Safe Staff-Only Testing Workflow
1. **Stage 1 — Local / Vercel Preview Validation (0 live CDN changes)**:
   - ChatGPT designs the exact `slide.interactive` JSON blocks for approved slides.
   - Gemini validates every enriched lesson JSON against `assertValidLessonInteractives` (both `allowDevOnlyEngines: true` and `false`) and tests in a staff-authenticated local or Vercel Preview build.
2. **Stage 2 — Engine Activation Decision (Owner-Controlled)**:
   - **Zero activation needed** for enrichment using LIVE engines (`process-stepper`, `diagram-hotspots`, `graph-slider`, `rule-explorer`, `math-evaluator 1.1.0`, `equation-balancer 1.1.0`, `electrical-circuit 1.1.0`, `atom-bond-builder 1.2.0`).
   - If ChatGPT's approved design uses `sort-classify 1.0.0` or `measurement-lab 1.4.0`, those require: (a) owner promotion of `fixed-version` to Vercel Production, and (b) explicit activation of their `productionVersion` in `interactive-schema.ts` ONLY after verification.
3. **Stage 3 — Controlled Publication & Staff Live Review**:
   - Publish approved enriched lesson JSON with `--skip-media` (preserving every `lessonId`, `slide.id`, `audioUrl`, and `imageUrl`).
   - Because Student Enrichment remains **Under Construction** (`src/lib/student-enrichment-release.ts`), only authenticated `Director`, `Administrator`, and `Teacher` accounts can open `/dashboard/narrated-lessons/<lessonId>` to test live; ordinary student access remains restricted.
4. **Stage 4 — Instant Rollback (if ever needed)**:
   - Restore the recorded pre-enrichment `packagePath` and `packageHash` in `catalogue.json` (cache TTL 60s). Zero data loss, zero broken progress.
