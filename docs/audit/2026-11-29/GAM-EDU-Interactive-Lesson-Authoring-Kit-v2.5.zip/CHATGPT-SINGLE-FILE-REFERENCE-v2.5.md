# GAM EDU — Interactive Lesson Authoring Reference (v2.5 · Step 5E Close-Out & Step 5F Primary Number Manipulatives)

- **Branch:** `fixed-version` (Manual Vercel Promotion Policy; Student Enrichment Under Construction).
- **Step 5D Close-Out (`data-stats-lab` `1.5.0`):** Genuine SVG renderers for Pie sectors, Pictogram symbols, Stacked Dot Plot, Frequency Polygon, Min-Max & Tukey 1.5-IQR Box Plot with outliers, Histogram, Cumulative Frequency, and Scatterplot; complete set-based mode grading (single/multi/none); state-gated experimental probability.
- **Step 5E Geometry Extensions (`construction-lab: geometry-constructor` `1.6.0`, `productionVersion` held at `1.3.0`):** RHS triangle construction (reflected solutions), virtual-protractor angles, alternate segment theorem, equal tangents, chord perpendicular bisector, extended loci & combined feasible regions (including finite-segment endpoint arcs), and exact 3D rigid-rotation cube-net foldability solver certifying all 11 valid cube nets under all rotations/reflections + cuboid SA/volume.
- **Step 5H Planning Audit Preserved:** `STEP_5H_CREATIVE_COMPUTATIONAL_AUDIT.md`.

# GAM EDU — Comprehensive Outstanding Foundation Verification Register (Reconciled 17 Items)

| # | Verification Area | Status | Target Stage |
| :---: | :--- | :---: | :---: |
| 1 | Actual compressed JS transfers (Next.js build / DevTools) | Pending | Step 6 |
| 2 | Shared validator bundle impact on non-lesson routes | Pending | Step 6 |
| 3 | Live selective loading trace (DevTools Network) | Pending | Step 6 |
| 4 | Cold-cache & warm-cache performance (throttled 3G/4G) | Pending | Step 6 |
| 5 | Low-end Android device CPU/memory profiling | Pending | Step 6 |
| 6 | Actual 360px portrait & landscape visual testing | Pending | Step 6 |
| 7 | Live keyboard-only navigation & focus-ring walkthrough | Pending | Step 6 |
| 8 | Live screen-reader audit (NVDA / VoiceOver / TalkBack) | Pending | Step 6 |
| 9 | Low-Data Mode live network trace | Pending | Step 6 |
| 10 | Live browser maximum-bound activity performance | Partial (Vitest done) | Step 6 |
| 11 | Core Web Vitals (LCP, INP, CLS) | Pending | Step 6 |
| 12 | Cross-engine multi-activity live state isolation | Partial (Vitest done) | Step 6 |
| 13 | Backward compatibility end-to-end on live CDN lessons | Partial (190+ bundled schema) | Step 6 |
| 14 | Controlled publication & instant catalogue rollback drill | Pending | Step 6 |
| 15 | Core school management live smoke test | Partial (Vitest + boundary) | Step 6 |
| 16 | Scalability & operating cost model (1,000 lessons x 10k students) | Pending | Step 6 |
| 17 | Content lifecycle, version migration & corrupted CDN asset recovery | Pending | Step 6 |


---

# GAM EDU — Interactive Lesson JSON Authoring Guide (`slide.interactive` v1)

This guide is the authoritative reference for human curriculum authors and AI content agents generating interactive activities inside GAM EDU Narrated Lessons. Following this specification allows lessons to be validated and published via `scripts/lessons/publish-lesson.ts` with **zero application code changes**.

---

## 1. Where `slide.interactive` Lives

Inside any slide object in `lesson.slides[]`, add the optional `interactive` field as either:
- A single `SlideInteractiveConfig` JSON object, OR
- An array of up to **4** `SlideInteractiveConfig` JSON objects (`SlideInteractiveConfig[]`).

Slides without `interactive` continue working identically as standard narrated slides.

---

## 2. Supported Engine Identifiers & Production Compatibility Manifest

All eight engines in `SUPPORTED_INTERACTIVE_ENGINES` (`src/lib/narrated-lessons/interactive-schema.ts`): Steps 1–5A (`rule-explorer`, `code-playground`, `graph-slider`, `process-stepper`, `diagram-hotspots`, `construction-lab` `1.3.0`, and `math-evaluator` `1.1.0`) are verified **Production LIVE** on `https://gam-it-service.app`; Step 5B (`sort-classify` `1.0.0`) is integrated on `fixed-version` with `productionVersion: null` pending manual Vercel production promotion and live verification:

| Engine ID | Status | Installed `engineVersion` | Configured `productionVersion` | Supported `schemaVersion` | Minimum `minEngineVersion` | Use Case |
| :--- | :--- | :---: | :---: | :---: | :---: | :--- |
| `rule-explorer` | **Production LIVE** | `1.0.0` | `1.0.0` | `1` | `"1.0.0"` | Cross-subject condition/rule toggling (CS, Chemistry, Biology, Physics, Geography, Civics) |
| `code-playground` | **Production LIVE** | `1.0.0` | `1.0.0` | `1` | `"1.0.0"` | Live sandboxed Python 3 (Pyodide), Cambridge 0478 Pseudocode, and Read-Only SQL (`SELECT`) |
| `graph-slider` | **Production LIVE** | `1.0.0` | `1.0.0` | `1` | `"1.0.0"` | Cross-subject dynamic graph, sliders, piecewise & step waveforms, readouts, predictions & compound discovery challenges |
| `process-stepper` | **Production LIVE** | `1.0.0` | `1.0.0` | `1` | `"1.0.0"` | Cross-subject linear & cyclic process/mechanism stepper with state snapshots, visual modes A/B/C, `reactionMeta`, predictions & sequencing |
| `diagram-hotspots` | **Production LIVE** | `1.0.0` | `1.0.0` | `1` | `"1.0.0"` | Cross-subject interactive WebP/PNG diagram, point/rect hotspots, structure-to-function links, progressive disclosure, Identify challenges & `nonVisualQuestion` |
| `construction-lab` | **1.3.0 Production LIVE · 1.4.0–1.6.0 Integrated** | `1.6.0` | `1.3.0` (held until 1.4.0–1.6.0 live-verified) | `1` | `"1.0.0"`–`"1.3.0"` (LIVE) · `"1.4.0"` (`measurement-lab`) · `"1.5.0"` (`data-stats-lab`) · `"1.6.0"` (`geometry-constructor` Step 5E: RHS, circle theorems, loci/regions, cube nets) | All Step 1–4F construction labs (LIVE), plus `measurement-lab` (Step 5C), `data-stats-lab` (Step 5D), and `geometry-constructor` Step 5E extensions |
| `math-evaluator` | **Production LIVE (`1.1.0`)** | `1.1.0` | `1.1.0` | `1` | `"1.0.0"` (single-answer) · `"1.1.0"` (`multi-step-working`) | Bounded exact rational, polynomial, surd, domain, equation, interval, 7-component SI unit, significant-figure, symbolic calculus evaluator (`1.0.0`), and multi-step working/marking workspace (`1.1.0`) |
| `sort-classify` | **Integrated (`fixed-version`) — Preview Gate** | `1.0.0` | `null` (pending manual Vercel promotion) | `1` | `"1.0.0"` | Cross-subject `category-bins` (with optional overlapping set membership), `pair-matching` (1:1 or many-to-many), `cloze-tiles` (word bank with reusable tokens), and `order-sequence` (with multiple valid orderings) |

> **Version Distinction:** `engineVersion` is the version installed in the codebase; `productionVersion` is the highest version verified live on `https://gam-it-service.app` after manual Vercel promotion; `schemaVersion` is the JSON config schema format (`1`); `minEngineVersion` is the minimum engine version required by a specific slide activity.

---

## 3. Base Schema Fields (All Engines)

Strict field allowlisting is enforced — **unknown keys are rejected**.

| Field | Type | Required | Rules |
| :--- | :--- | :---: | :--- |
| `id` | `string` | **Yes** | `^[A-Za-z0-9_-]{2,64}$`. Must be **globally unique** across all slides in the lesson (including multiple activities on the same slide). |
| `engine` | `string` | **Yes** | Must be one of the seven implemented engine IDs: `rule-explorer`, `code-playground`, `construction-lab`, `graph-slider`, `process-stepper`, `diagram-hotspots` (all Production LIVE), or `math-evaluator` (Step 5A Preview Only — blocked at production publish gate while `productionVersion: null`). |
| `schemaVersion` | `number` | **Yes** | Must be `1`. |
| `minEngineVersion` | `string` | No (Required `"1.1.0"` Step 4D, `"1.2.0"` Step 4E, `"1.3.0"` Step 4F Preview) | SemVer `MAJOR.MINOR.PATCH` (e.g. `"1.0.0"`, `"1.1.0"`, `"1.2.0"`, `"1.3.0"`). Rejected if higher than the engine's `productionVersion` (at publish time) or `engineVersion` (at runtime). |
| `title` | `string` | **Yes** | At least 2 non-whitespace characters. Short student-facing heading. |
| `instructions` | `string` | **Yes** | At least 4 non-whitespace characters. Clear action prompt for the learner. |
| `accessibilityLabel` | `string` | **Yes** | At least 4 non-whitespace characters. Screen-reader landmark label (`aria-label`). |
| `fallbackText` | `string` | **Yes** | At least 4 non-whitespace characters. Educational text summary shown in Low-Data Mode or graceful fallback. |
| `hints` | `string[]` | No | Up to **6** non-empty progressive hint strings. |
| `persistCompletion` | `boolean` | No | **Reserved for future use.** Currently ignored at runtime (zero Firestore reads/writes). |

---

## 4. Engine-Specific Configuration Requirements

### A. `rule-explorer` (Cross-Subject Declarative Condition Explorer)

Extra allowed top-level fields: `subjectTag`, `inputs`, `rule`, `output`.

- `subjectTag` *(optional string)*: Short curriculum badge (e.g. `"Computer Science"`, `"Chemistry"`, `"Biology"`).
- `inputs` *(required array, 1–8 items)*: Each item allows only:
  - `id` *(required string, `^[A-Za-z0-9_-]{1,40}$`, unique within activity)*
  - `label` *(required non-empty string)*
  - `defaultValue` *(optional boolean, default `false`)*
  - `trueText` *(optional string, default `"YES"`)*
  - `falseText` *(optional string, default `"NO"`)*
- `rule` *(required Declarative AST)*:
  - Leaf node: `{ "input": "<inputId>" }` (must reference a declared `inputs[].id`)
  - Operator node: `{ "operator": "AND" | "OR" | "NOT" | "XOR", "operands": [ ... ] }`
  - **Arity rules**: `NOT` requires **exactly 1** operand; `AND`, `OR`, `XOR` require **2 to 8** operands.
  - **Complexity limits**: Maximum nesting depth **6**, maximum **32** AST nodes.
- `output` *(required object)*: Allows only:
  - `trueLabel` *(required string)*
  - `falseLabel` *(required string)*
  - `explanationTrue` *(required string)*
  - `explanationFalse` *(required string)*
  - `showBinaryValues` *(optional boolean — set `true` for CS binary `1`/`0` badges, `false` for general Science/Humanities)*

### B. `code-playground` (Python 3, Cambridge Pseudocode, Read-Only SQL)

Extra allowed top-level fields: `languages`, `pythonStarter`, `pseudocodeStarter`, `sqlStarter`, `publicTests`.

- `languages` *(required non-empty array)*: Subset of `["python", "pseudocode", "sql"]`. First item is the default active tab.
- `pythonStarter` *(optional string)*: Starter Python 3 code (executed in isolated Pyodide Web Worker).
- `pseudocodeStarter` *(optional string)*: Starter Cambridge IGCSE Pseudocode (executed in browser AST runner).
- `sqlStarter` *(optional string)*: Starter **read-only `SELECT`** SQL query. DDL/DML keywords (`DROP`, `DELETE`, `INSERT`, `UPDATE`, `ALTER`, `TRUNCATE`, `CREATE`, `ATTACH`, `DETACH`) are rejected.
- `publicTests` *(optional array, max 8 items)*: Each item allows only `{ "stdin": string, "expectedStdout": string }`.

### C. `construction-lab` (Step 4D — Production LIVE `1.1.0`)

> **Production Status:** `construction-lab` is verified live in production (`implemented: true, engineVersion: "1.1.0", productionVersion: "1.1.0"`). Existing `labKind: "boolean-circuit"` lessons without `circuitConfig` remain 100% compatible (`minEngineVersion: "1.0.0"`). All Step 4D domain adapters (`equation-balancer`, `electrical-circuit`, `bio-sequence-builder`, and declarative `boolean-circuit` with `circuitConfig`) **MUST** declare `"minEngineVersion": "1.1.0"` and now pass the production publish gate.

Shared optional fields across all Step 4D domain adapters: `subjectTag`, `modelNote`, `prediction` (`{ prompt, options (2..4), correctIndex, explanation }`), `successExplanation`.

- **`labKind: "boolean-circuit"`**:
  - **Legacy (`1.0.0` LIVE):** `{ labKind: "boolean-circuit", activityId? }` — preserves `BooleanCircuitLab.tsx` and all seeded Chapter 10 lessons unchanged.
  - **Declarative (`1.1.0` LIVE):** Add `circuitConfig` (`{ inputs (1..4), outputLabel?, allowedGates, initialGates? (<=10, cycle-free), initialOutput?, targetTruthTable (2^n binary outputs), gradingMode? ("functional-equivalence" | "specified-gate-structure"), targetNetlist?, maxGates?, successExplanation? }`). Reuses `circuit-engine.ts` with zero duplicate logic.
- **`labKind: "equation-balancer"` (`1.1.0` LIVE — Chemistry Stoichiometry & Charge Conservation)**:
  - Fields: `reactants` (1–6), `products` (1–6), `arrow?` (`"→" | "⇌" | "->"`), `maxCoefficient?` (`2..12`), `requireSimplestRatio?` (default `true`), `showAtomVisuals?`, `difficulty?` (`"foundation" | "standard" | "challenge"`).
  - Each species: `{ formula, display?, charge? (-8..+8), state? ("s"|"l"|"g"|"aq"), isElectron? }`. Validates real IUPAC element symbols, balanced parentheses (nesting ≤ 2), positive integer subscripts, and authoring-time solvability within `1..maxCoefficient`. Students adjust whole-number coefficients only (never subscripts).
- **`labKind: "electrical-circuit"` (`1.1.0` LIVE — Bounded DC Circuit Builder)**:
  - Fields: `topology` (`"series" | "parallel-2-branch" | "series-parallel"`), `supplyVoltageV` (`1..24`), `palette` (1–8 components: `wire`, `switch-open`, `switch-closed`, `resistor`, `lamp`, `ammeter`, `voltmeter` with finite `resistanceOhm` `1..1000` for resistors/lamps only), `slots` (2–8, `position`: `"main" | "branch-a" | "branch-b" | "voltmeter-probe"`), `goal?` (structural `requiredComponents` + numerical `targetTotalCurrentA`, `targetBranchACurrentA`, `targetBranchBCurrentA`, `targetVoltmeterV`), `isMisconceptionActivity?`.
  - Never uses `Infinity` in JSON; detects short circuits safely (no finite current computed through 0 Ω closed loop) and diagnoses meter misconnections. Lamps use simplified constant-resistance models with qualitative brightness.
- **`labKind: "bio-sequence-builder"` (`1.1.0` LIVE — Biological Sequence & Inheritance Builder)**:
  - Modes: `"dna-base-pairing"` (antiparallel A–T/C–G), `"dna-to-mrna"` (3′→5′ template → 5′→3′ mRNA, A→U, catches T-in-RNA), `"mrna-translation"` (standard 64-codon table, N→C polypeptide, STOP codons terminate without assigning an amino acid, `isCompleteCodingSequence?`), `"monohybrid-punnett"` (`parent1Genotype`, `parent2Genotype`, `dominantAllele`, `dominantTrait?`, `recessiveTrait?`, `inheritanceAssumption?`, ratios presented strictly as probabilities).
- **`labKind: "atom-bond-builder"` (`1.2.0` Production LIVE — Atomic & Molecular Bonding Laboratory)**:
  - **Required:** `"minEngineVersion": "1.2.0"`, `"curriculumLevel": "introductory" | "igcse" | "as-a-level"`, and `"mode"`:
    - `"atomic-structure"`: `representation` (`"shells"` for `Z = 1..20` simplified first-20 filling model, or `"subshells"` for `Z = 1..30` `1s..3d` with Cr/Cu anomalies and `4s`-before-`3d` cation ionisation), `targetElement`, `targetMassNumber` (physically verified isotopes unless `allowHypotheticalIsotope: true`; flags radioactive Carbon-14), `targetCharge?`, `lockNucleus?`.
    - `"ionic-bonding"`: up to **6 ions** (`NaCl`, `MgO`, `MgCl₂`, `CaCl₂`, `Al₂O₃`), `cationElement`, `anionElement`, `targetCationCount`, `targetAnionCount`, `targetCationCharge`, `targetAnionCharge`, `requireSimplestRatio?` (default `true`; rejects electrically neutral non-simplest ratios like `Na₂Cl₂`). Framed as extended ionic lattice empirical composition, never isolated molecules.
    - `"covalent-bonding"`: `2..8` atoms (`Z = 1..30, Br, I`), single/double/triple/dative bonds, learner-controlled lone pairs, `formulaDisplay` consistency check, `netCharge?`, `octetPolicy` (`"strict-duet-octet"` | `"electron-deficient"` | `"expanded-octet"`), atom-specific `minValenceElectrons`/`maxValenceElectrons` (`BF₃`, `PCl₅`, `SF₆`), coordinate donor/acceptor validation (`NH₃ + H⁺ → NH₄⁺`), `referenceBonds?`. Odd-electron radicals and resonance hybrids are rejected cleanly.
    - `"molecular-geometry"`: bounded VSEPR (`stericNumber 2..6`, multiple bonds count as 1 domain), `centralElement`, `surroundingElements` (2–6), `targetBondingDomains`, `targetLonePairs`, `targetElectronGeometry`, `targetMolecularShape`, `targetBondAngleLabel`, `checkPolarity?`, `expectedPolar?`. Evaluates polarity via true 3D VSEPR unit-vector Pauling dipole summation (`CO₂` non-polar vs `HCN` polar; `CH₄` non-polar vs `CH₃Cl` polar).
  - **Scientific Model Disclaimers (Mandatory):**
    - Electronegativity-based molecular polarity calculations are simplified educational approximations, not exact experimental dipole-moment predictions.
    - The supported element registry (`Z = 1..30`, plus `Br`, `I`) does not imply unrestricted validation of transition-metal bonding or coordination complexes.
    - Individual orbital spin-box construction, resonance hybrids, odd-electron radicals, molecular orbital (MO) theory, and heavyweight 3D molecular viewers remain outside the approved scope.
  - **Existing engines reused (no duplication):** Metallic bonding & Intermolecular Forces (noting London dispersion forces occur between ALL molecules) use existing LIVE `diagram-hotspots`, `process-stepper`, `rule-explorer`, and `graph-slider`.
- **`labKind: "geometry-constructor"` (`1.3.0` Production LIVE — Geometry Construction Laboratory)**:
  - **Required:** `"minEngineVersion": "1.3.0"`, `"curriculumLevel": "introductory" | "igcse" | "as-a-level"` and `"mode"`:
    - `"compass-straightedge"`: `gridBounds`, `initialPoints` (`1..60`), `initialSegments?` (`<= 80`), `constructionGoal` (`perpendicular-bisector`, `angle-bisector`, `triangle-sss`, `triangle-sas`, `triangle-asa`, `locus-circle`, `parallel-line`, `perpendicular-through-point`), `requireConstructionArcs?` (verifies genuine equal-radius / intersecting arc provenance, never merely counting unrelated arcs), `distanceTolerance?` (`0.01..1.0`), `angleToleranceDeg?` (`0.1..5.0`). Validates SSS/SAS/ASA triangle feasibility at authoring time and accepts both mirrored orientations.
    - `"transformations"`: `gridBounds` (with `step` in `(0, 5]`), `preImageVertices` (`3..8`, simple non-self-intersecting polygon), `transformation` (`translation`, `reflection` across `x-axis`, `y-axis`, `y = x`, `y = −x`, `x = k`, `y = k`, `rotation` about arbitrary `(cx, cy)`, `enlargement` with non-zero `scaleFactor`, including fractional and negative scale factors), `requireLabelledCorrespondence?`. Enforces authoring-time grid reachability (`isReachableOnGrid`) and in-bounds checks for every expected image vertex.
    - `"coordinate-geometry"`: `gridBounds`, `coordGoal` (`midpoint`, `parallel-through-point`, `perpendicular-through-point`, `line-from-equation`). Uses general line form `ax + by + c = 0` so horizontal and vertical perpendicular lines never produce `Infinity` or `NaN` (vertical gradients report `"undefined (vertical)"`).
    - `"circle-theorems"`: `circleTheorem` (`angle-at-centre`, `semicircle-90`, `same-segment`, `cyclic-quadrilateral`, `tangent-radius`), `fixedAnglesDeg`, `movablePointAngleDeg`, `targetPrompt`, `expectedAngleDeg?` (cross-checked against derived mathematical angle at authoring time), `angleToleranceDeg?`. Enforces arc/chord domain guards (major vs minor/reflex arc, non-crossing cyclic quadrilateral).
  - **Existing engines reused (no duplication):** 3D solid geometry nets reuse existing LIVE `process-stepper` / `diagram-hotspots`.

### D. `graph-slider` (Step 4A — Production LIVE `1.0.0`)

> **Production Status:** `graph-slider` is verified live in production (`implemented: true, engineVersion: "1.0.0", productionVersion: "1.0.0"`).

Extra allowed top-level fields: `subjectTag`, `modelNote`, `xVar`, `axes`, `sliders`, `curves`, `readouts`, `prediction`, `challenges`, `samples`, `showDataTable`.

- `axes` *(required)*: `{ xLabel, xUnit?, xMin, xMax, yLabel, yUnit?, yMin, yMax }` (`xMax > xMin`, `yMax > yMin`).
- `sliders` *(optional, 0–4 items)*: `{ id, label, min, max, step, defaultValue, unit?, presets? }` (`step > 0`, `min <= defaultValue <= max`, `presets` within `[min, max]`).
- `curves` *(required, 1–4 items; max 8 total curves per slide)*:
  - `kind`: `"formula"` (default), `"piecewise"` (2–24 `{ x, y }` points), or `"step"` (2–24 `{ x, y }` discrete step-line points).
  - `color`: strict 6-digit hex (`#RRGGBB`); `style`: `"solid" | "dashed" | "dotted"`; `isReference?: boolean`; `domainMin?`, `domainMax?`; `stopAtYZero?: boolean` (for projectile landing root bisection — never stops at initial launch point).
- `readouts` *(optional, 0–4 items)*: `{ id, label, expr, unit?, precision? (0..4) }`.
- `prediction` *(optional Predict-before-Experiment prompt)*: `{ prompt, options (2..4), correctIndex, explanation }`.
- `challenges` *(optional, 0–3 items)*: `{ id, prompt, check: { operator: "AND" | "OR", conditions (1..4) }, successText, hintText? }`. Each condition targets one `sliderId` or `readoutId` with `min`/`max` or `target` + `tolerance`.
- **Safe Mathematical Expression Grammar** (`src/lib/narrated-lessons/math-expr.ts`, zero `eval()`):
  - **Precedence (lowest → highest):** `+`/`-` (left) → `*`/`/` (left) → unary `+`/`-` (binds looser than `^`, so `-2^2 = -4`, `(-2)^2 = 4`) → `^` (right-associative, `2^3^2 = 512`, `2^-3 = 0.125`) → primary.
  - **Constants:** `PI`, `E`.
  - **Unary functions (arity = 1):** `abs`, `sin`, `cos`, `tan`, `sqrt`, `ln`, `log10`, `exp`, `deg2rad`, `rad2deg`, `floor`, `ceil`, `round`. (Trig uses radians internally; use `deg2rad(theta)` for degrees.)
  - **Multi-arg functions (arity = 2..4):** `min`, `max`.
  - **Limits:** Max AST depth **8**, max **48** AST nodes, max **200** sample points per curve, max `24,576` bytes per activity.
  - **Mathematical Status Distinction (`evaluateMathAstDetailed`):**
    - `undefined`: mathematically undefined operations (`1/0`, `ln(0)`, `log10(0)`, `tan(PI/2)`, `0^-1`) → displays `"Undefined"`.
    - `outside-real-domain`: operations outside the supported real numbers (`sqrt(-4)`, `ln(-2)`, `(-2)^0.5`) → displays `"Outside real domain"`.
    - `exceeds-numeric-limit`: mathematically valid results exceeding `±1e12` or `|exponent| > 100` (e.g. `10^50`) → displays `"Exceeds numeric limit"` (never mislabelled as mathematically undefined).
  - **Deferred in v1.0:** Parametric plotting `(x(t), y(t))` and continuous animation loops (e.g., Solar System orbital animation) are intentionally deferred.

### E. `process-stepper` (Step 4B — Production LIVE `1.0.0`)

> **Production Status:** `process-stepper` is verified live in production (`implemented: true, engineVersion: "1.0.0", productionVersion: "1.0.0"`).

Extra allowed top-level fields: `subjectTag`, `modelNote`, `mode`, `visualMode`, `sharedVisual`, `stages`, `sequenceChallenge`.

- `mode` *(required)*: `"linear"` (stops at final stage with Replay) or `"cyclic"` (wraps cleanly from final stage back to Stage 1 with explicit cycle-restart notice).
- `visualMode` *(optional, default `"diagram"`)*:
  - `"diagram"` (Mode A): Auto-generated accessible linear/cyclic flow overview highlighting active & visited stages (visited ≠ mastery).
  - `"stage-illustrations"` (Mode B): Renders stage-specific `stage.visual` (`{ src, altText, caption? }`) from approved WebP/PNG paths with Enlarge lightbox.
  - `"shared-highlight"` (Mode C): Renders `sharedVisual` with a declarative bounded `stage.highlightRegion` (`{ xPct, yPct, widthPct, heightPct, label }`, all within `0..100%`) and Enlarge lightbox.
- `stages` *(required, 2–10 items, unique IDs)*:
  - Required: `id`, `title`, `summary`.
  - Optional pedagogy: `shortLabel`, `equation` (highlighted chemical/algebraic equation, ≤ 180 chars), `startingCondition`, `whatChanges`, `whyItMatters`, `connectionToNext`, `commonMisconception`, `inputs[]`, `outputs[]`.
  - Optional `reactionMeta` *(for A-Level Chemistry & Biology mechanisms)*: `{ reactants?, intermediates?, products?, bondsBroken?, bondsFormed?, electronMovement? }` (up to 4 strings per list, ≤ 120 chars each; `electronMovement` ≤ 200 chars). Supports electrophilic addition, nucleophilic substitution, peptide bond condensation/hydrolysis, DNA replication, transcription/translation, polymerisation, and electrolysis cleanly with approved WebP/PNG diagrams and zero 3D/molecular simulator bloat.
  - Optional `stateSnapshot` *(0–6 items)*: `[{ id, label, value }]` (rejects prototype keys like `constructor`/`__proto__`; values ≤ 80 chars; renders accessible textual diff badges `"Changed (was ...)"`, `"New in this stage"`, `"Removed"`, `"Unchanged"`).
  - Optional `prediction` *(max 3 across activity)*: `{ prompt, options (2..4), correctIndex, explanation }` (non-blocking).
- `sequenceChallenge` *(optional, max 1)*: `{ id, prompt, stageIdsToOrder (2..6 valid stage IDs), explanation }` — keyboard-accessible `Move Up`/`Move Down` controls (zero drag-and-drop).
- **Deferred in v1.0:** Stage-specific audio tracks (deferred to avoid competing with `NarratedLessonPlayer` main narration audio), branching state machines, and continuous animation.

### F. `diagram-hotspots` (Step 4C — Production LIVE `1.0.0`)

> **Production Status:** `diagram-hotspots` is verified live in production (`implemented: true, engineVersion: "1.0.0", productionVersion: "1.0.0"`).

Extra allowed top-level fields: `subjectTag`, `modelNote`, `diagram`, `defaultMode`, `progressiveDisclosure`, `guidedOrder`, `hotspots`, `identifyPrompts`.

- `diagram` *(required)*: `{ src, altText, identifyAltText?, caption? }` — approved **WebP or PNG** path only (validated by shared `visual-region.ts`; raw SVG markup, untrusted external URLs, `..` and `%2e`/`%2f` traversal are rejected). In Identify mode before checking, `identifyAltText` (or a neutral unlabelled fallback) replaces `altText` and `caption` is hidden so answers never leak to screen readers or captions.
- `hotspots` *(required, 2–12 items, unique IDs)*:
  - Point hotspot: `{ id, label, xPct, yPct, summary, ... }` (`0..100%` relative to the rendered image).
  - Rectangular hotspot: add `widthPct`, `heightPct` (`> 0`, `xPct + widthPct <= 100`, `yPct + heightPct <= 100`).
  - Optional pedagogy: `functionText`, `structureToFunction`, `equation` (≤ 180 chars), `commonMisconception`, `linkedHotspotIds` (max 6 valid non-self IDs), `relationshipExplanation`, `discoveryPrompt`.
- `guidedOrder` *(optional)*: ordered array of hotspot IDs for `Prev Part` / `Next Part` guided tours.
- `progressiveDisclosure` *(optional boolean)*: starts on a clean diagram so learners observe before revealing markers.
- `identifyPrompts` *(optional, 0–6 items)*: `{ id, prompt, targetHotspotId, explanation, hintText?, nonVisualQuestion? }`.
  - Before checking, **all pin & list labels are concealed as `Region 1`, `Region 2`…** and `caption`/`altText` are concealed so answers never leak.
  - `nonVisualQuestion` *(optional, recommended for every Identify prompt)*: `{ prompt, options (2..4), correctIndex, explanation? }` — provides a genuinely equivalent conceptual text-only identification question toggleable for screen-reader and nonvisual learners.
- **Deferred in v1.0:** Freeform polygon hitboxes, in-app diagram editing, 3D molecular viewers, and synchronised side-by-side diagram comparison.

### G. `sort-classify` (Step 5B — Integrated on `fixed-version`, `productionVersion: null`)

> **Production Status:** `sort-classify` (`engineVersion: "1.0.0"`, `productionVersion: null`) is integrated into `fixed-version` and previewable at `/narrated-lessons/sort-classify-pilot-preview` (which fails closed with `404` in production). It remains blocked at the production publish gate until manually promoted to Vercel and verified live.

Extra allowed top-level fields: `subjectTag`, `curriculumLevel`, `mode`, `prediction`, `successExplanation`, `bins`, `items`, `allowMultipleBinsPerItem`, `leftItems`, `rightItems`, `expectedMatches`, `allowManyToMany`, `template`, `blanks`, `tokens`, `reusableTokens`, `acceptedOrders`.

- **`mode: "category-bins"`**:
  - `bins` *(2–6 items)*: `{ id, label, description? }`
  - `items` *(2–24 items)*: `{ id, label, validBinIds: string[], misconceptionByBin?: Record<string, string> }`
  - `allowMultipleBinsPerItem?` *(boolean, default `false`)*: when `true`, learners may place an item into multiple bins (e.g. overlapping sets / prime & even numbers / amphoteric oxides) and grading checks exact set equality against `validBinIds`.
- **`mode: "pair-matching"`**:
  - `leftItems` *(2–12)*, `rightItems` *(2–12)*: `{ id, label }`
  - `expectedMatches` *(1–24)*: `{ leftId, rightId }`
  - `allowManyToMany?` *(boolean, default `false`)*: supports 1:1 or many-to-many matching cleanly.
- **`mode: "cloze-tiles"`**:
  - `template` *(string with `{{blankId}}` placeholders)*
  - `blanks` *(1–12 items)*: `{ id, acceptedTokenIds: string[], misconceptionByToken?: Record<string, string> }` (each blank may accept multiple valid tokens).
  - `tokens` *(2–24 items)*: `{ id, label }`
  - `reusableTokens?` *(boolean, default `false`)*: when `false`, each token can be used in at most one blank; when `true`, tokens can be reused across blanks.
- **`mode: "order-sequence"`**:
  - `items` *(3–12 items)*: `{ id, label }`
  - `acceptedOrders` *(1–8)*: each a complete permutation of `items[].id` (supports multiple equally valid chronological, algorithmic, or experimental sequences).

---

## 5. Resource Limits

| Limit | Maximum |
| :--- | :---: |
| Serialized JSON size per activity | **24,576 bytes (24 KB)** |
| Interactive activities per slide | **4** |
| `rule-explorer` inputs | **8** |
| `rule-explorer` AST nesting depth | **6** |
| `rule-explorer` total AST nodes | **32** |
| `hints` per activity | **6** |
| `publicTests` per `code-playground` | **8** |

---

## 6. Security, Accessibility & Low-Data Requirements

1. **Zero Teacher Secrets in Public JSON**: Keys such as `teacherReference`, `teacherPseudocode`, `gradingTests`, `solutionSql`, `teacherSolutions`, `hiddenTests`, `answerKey`, `modelSolution`, and `rubricAnswers` are recursively blocked at publish and runtime. Public student guidance (`hints`, `publicTests`, `explanationTrue`, `explanationFalse`) is allowed.
2. **Educational Code vs. Application Code**: Legitimate CS text or sandboxed starter code may mention programming concepts (e.g. explaining why `eval()` is dangerous) safely because all text is rendered via React text nodes (never `dangerouslySetInnerHTML`) and starter code runs inside isolated sandboxes. Executable URL protocols (`javascript:`, `vbscript:`, `data:text/html`) are always blocked.
3. **Accessibility**: Always provide meaningful `accessibilityLabel` and `instructions`. Never rely on color alone — provide clear `trueText`/`falseText` and `trueLabel`/`falseLabel`.
4. **Low-Data Mode**: Every activity **must** provide a pedagogically useful `fallbackText` so learners on 2G/3G networks in Low-Data Mode receive the full conceptual takeaway without downloading heavy lab chunks (with an opt-in button to load the engine manually).

---

## 7. State, Reset & Progress Behaviour

- **Ephemeral Local State**: `rule-explorer` holds toggle state in local React state (resettable via the Reset button; **0 Firestore reads/writes**).
- **Slide Navigation**: Navigating away from a slide unmounts its interactive widget; returning restores the configured `defaultValue` state cleanly.
- **Shared-Computer Draft Isolation (`code-playground`)**:
  - For authenticated users, drafts are stored in `localStorage` scoped strictly by school and user: `gam:inline-code:v2:${schoolId}:${userId}:${lessonId}:${activityId}:${mode}` (students sharing a school computer never see another student's drafts; 0 Firestore writes).
  - For unauthenticated/public preview sessions, drafts are stored in tab-scoped `sessionStorage` (`gam:inline-code:v2:session:...`) and cleared automatically when the tab closes.
- **Multiple Activities per Slide**: Each item in `slide.interactive[]` mounts with its own `id` key and completely isolated state.
- **`persistCompletion` Status**: **Reserved (not yet implemented).** Existing lesson step/checkpoint/mastery progress restoration (`localStorage` + `resolveRestoredStepIndex`) continues working unchanged.

---

## 8. Built-in Read-Only SQL Fixture (`Stock` Table)

The inline SQL runner executes read-only `SELECT` queries against GAM EDU's built-in `Stock` table (`src/lib/sql-practice/igcse-sql-engine.ts`):

| ItemID | ItemName | Colour | Quantity | Price | Ordered |
| :--- | :--- | :--- | :-: | :-: | :-: |
| `A01` | Pen | Blue | 12 | 2.5 | 0 |
| `A02` | Ruler | Red | 5 | 4.0 | 1 |
| `A03` | Book | Blue | 20 | 8.0 | 0 |
| `A04` | Bag | Red | 5 | 35.0 | 0 |
| `A05` | Pencil | Green | 0 | 1.5 | 1 |

**Expected result** for `SELECT ItemName, Price FROM Stock WHERE Quantity < 6 ORDER BY Price DESC;`:

| ItemName | Price |
| :--- | :-: |
| Bag | 35 |
| Ruler | 4 |
| Pencil | 1.5 |

---

## 9. Production Engine Compatibility & Rollback Policy

- **Production-First Rule**: Never publish a live CDN lesson requiring an engine or `minEngineVersion` that has not yet been deployed and verified in production. `SUPPORTED_INTERACTIVE_ENGINES[id].productionVersion` tracks the highest version verified in production (`null` for dev-branch-only or Step 4 reserved engines), and `assertValidLessonInteractives` rejects any lesson whose engine or `minEngineVersion` exceeds `productionVersion`.
- **Rollback Implications**: Once live CDN lessons depend on `slide.interactive`, reverting the web app to a revision prior to `InteractiveEngineRegistry` (or prior to a newly published engine) would prevent those interactive widgets from mounting. Always keep `InteractiveEngineRegistry` forward-compatible (additive schema changes only) and rely on each activity's mandatory `fallbackText` for graceful degradation if an older client ever encounters a newer engine.

---

## 10. Valid & Invalid Configuration Examples

See machine-readable valid examples for all six implemented engines in [examples/interactive-lesson-examples.json](./examples/interactive-lesson-examples.json).

### Common Invalid Authoring Mistakes (Rejected by `publish-lesson.ts`)

| Mistake | Why Rejected |
| :--- | :--- |
| `"labKind": "atom-bond-builder"` or `"geometry-constructor"` | Deferred future construction extension — not yet implemented |
| Step 4D `construction-lab` domain (`equation-balancer`, `electrical-circuit`, `bio-sequence-builder`, or declarative `boolean-circuit` with `circuitConfig`) with `"minEngineVersion": "1.0.0"` | Step 4D domains require `"minEngineVersion": "1.1.0"` or higher |
| `"schemaVersion": 2` | Only `schemaVersion: 1` is supported |
| `"minEngineVersion": "2.0.0"` | Exceeds verified `productionVersion` (`1.0.0` or `1.1.0`) |
| Unknown field like `"customCss": "..."` or `"onClick": "..."` | Strict schema allowlist rejects unknown keys |
| `{ "operator": "AND", "operands": [{ "input": "a" }] }` | `AND`/`OR`/`XOR` require 2–8 operands (`NOT` requires exactly 1) |
| `{ "input": "missingId" }` | References an input ID not declared in `inputs[]` |
| Duplicate `"id"` on two activities (same slide or different slides) | Activity IDs must be unique per lesson |
| `"sqlStarter": "DROP TABLE Stock;"` | Inline SQL is strictly read-only `SELECT` |
| Including `"answerKey"` or `"hiddenTests"` | Protected teacher-only fields are prohibited in public CDN JSON |


---

# GAM EDU — Student Enrichment Architecture & Maintenance Standard

> **Permanent Architectural Standard** — Mandatory for all developers and AI coding agents (Antigravity, Gemini, Claude, Codex, Cursor) working on GAM EDU.

## 1. Core Context & Modular-Monolith Boundary

GAM EDU is fundamentally a **comprehensive school management system** (administration, finance, billing, attendance, HR, academics, reporting). Narrated lessons, interactive laboratories, stories, and study clubs form an integrated **Student Enrichment & Independent Learning** subsystem inside the same modular monolith.

- **One integrated application**: Do not introduce microservices, separate repositories, or a separate CMS without explicit architectural approval.
- **Strict one-way dependency boundary**:
  - Core school management routes (`finance`, `financials`, `accounts`, `attendance`, `admin`, `students`, `staff`, `payroll`, `boarding`, `transport`, `dashboard/layout.tsx`) **MUST NOT** import student-enrichment engines (`narrated-lessons`, `boolean-logic`, `sql-practice`, `pseudocode-runner`, `python-runner`).
  - Enforced automatically by `src/lib/narrated-lessons/architecture-boundaries.test.ts`.

## 2. Core Scaling Principle

> **The educational content library can grow almost indefinitely (1,000+ lessons), but the application codebase should grow only when genuinely new reusable capabilities are required.**

- **CDN-First Content**: All lesson JSONs, images (WebP), and narration audio (MP3) live in Firebase Cloud Storage (`story-spark-preview/narrated-lessons/`) with content-hashed immutable caching (`max-age=31536000, immutable`). Adding or updating a lesson using supported engines **MUST NOT** require a Git push or Vercel deployment.
- **No Lesson-Specific React Components**: Do **NOT** create new per-lesson React components or add hardcoded `if (lesson.lessonId === '...')` branches in `NarratedLessonPlayer.tsx` without explicit architectural approval.
- **Reuse Existing Interactive Engines**: Reuse existing Python (`python-runner.ts`), Pseudocode (`pseudocode-runner.ts`), SQL (`igcse-sql-engine.ts`), Boolean Circuit Lab & Construction Lab domain adapters (`ConstructionLabRouter.tsx` — `boolean-circuit` legacy 1.0.0 LIVE; `equation-balancer`, `electrical-circuit`, `bio-sequence-builder`, and declarative `boolean-circuit` 1.1.0 LIVE; `atom-bond-builder` 1.2.0 LIVE), Rule Explorer (`RuleExplorerEngine.tsx`), Graph & Slider Engine (`GraphSliderEngine.tsx`), Process & Mechanism Engine (`ProcessStepperEngine.tsx`), and Diagram & Hotspots Engine (`DiagramHotspotsEngine.tsx`) through `InteractiveEngineRegistry.tsx`. Do not build competing editors or monolithic universal simulators.
- **Lazy Loading Heavy Modules**: Heavy interactive labs, language runtimes, and reviewer-only tools (`PointerCueEditor`) must be lazy-loaded so unrelated school management routes and non-CS lessons do not download them.

## 3. Security & Privacy Standards

- **SVG Sanitisation (Mandatory)**: All inline SVG content from CDN lesson JSONs must pass strict allowlist sanitisation (`src/lib/narrated-lessons/svg-sanitizer.ts`) at **both** publish time (`publish-lesson.ts`) and render time (`NarratedLessonPlayer.tsx`).
  - Forbidden: `<script>`, `<foreignObject>`, `<iframe>`, `<object>`, `<embed>`, `<animate>`, `<set>`, all `on*` event attributes, `javascript:` / `vbscript:` / `data:` URIs, and external `http(s)://` references in `href`/`xlink:href`.
  - Allowed: Safe geometric, text, gradient, marker, clipPath, filter, and internal `#id` references required for accurate educational diagrams.
- **No Arbitrary Executable Code in Lesson JSON**: Never execute CDN JSON fields with `eval()` or `new Function()`. Use declarative rule trees and restricted expression parsers only.
- **Teacher Solutions Isolation**: Never include `teacherReference`, `teacherPseudocode`, `gradingTests`, or `solutionSql` in public CDN lesson packages or client JS bundles.
- **Zero-Write Interactive State**: Ordinary slider, toggle, circuit, pseudocode, and SQL exploration runs locally in browser state (0 Firestore reads/writes). Only meaningful progress/assessments are persisted.

## 4. Schema Evolution, Progress Preservation & Rollback

- **Stable IDs**: Never renumber or rename existing `lessonId`, `slide.id`, `checkpoint.id`, or `item.id` values on published lessons.
- **Progress Preservation**: `NarratedLessonPlayer` persists stable `currentStepId` alongside `stepIdx` (see `src/lib/narrated-lessons/progress-migration.ts`). Never silently reset returning students' progress or mark newly inserted slides as completed.
- **Publish-Time Gates (`scripts/lessons/publish-lesson.ts`)**: Every publish must validate schema/IDs, pronunciation coverage (`assertPronunciationCoverage`), SVG safety (`assertSafeSvg`), absence of protected teacher keys, and automatically back up the prior `catalogue.json` generation for instant rollback.
- **Preserve Approved Pedagogy**: Architectural refactoring must preserve approved educational quality, narration, illustrations, transitions, mobile readability, and accessibility.

## 5. Approval, Under-Construction Gate & Release Discipline

- **Owner's Revised Accelerated Development Policy (Student Enrichment Only)**: Because participating schools have been notified that Student Enrichment is **Under Construction**, the owner has authorised accelerated implementation, automated verification, controlled integration into `fixed-version`, and curriculum lesson development using available capabilities — without requiring repeated individual preview acceptance cycles for every approved foundation step. Official release to ordinary students remains strictly subject to the owner's explicit approval.
- **Under-Construction Access Gate (`src/lib/student-enrichment-release.ts`)**: All 19 Student Enrichment route trees (`/dashboard/narrated-lessons/*`, `/dashboard/coding-club/*`, `/dashboard/cambridge-lessons/*`, `/dashboard/nursery-bloom/*`, `/dashboard/senior-academy/*`, `/dashboard/senior_academy/*`, `/dashboard/class-stories/*`, `/dashboard/study-club/*`, `/dashboard/maths-club*/*`, `/dashboard/science-club*/*`, `/dashboard/ela-club/*`, `/dashboard/game-zone/*`, `/dashboard/think-tank/*`, `/narrated-lessons/*`, `/story-spark-preview/*`, `/topical-labs/*`) enforce a fail-closed under-construction access gate reusing `useRole()` + `useUser()` (zero extra Firestore reads/writes; zero hardcoded owner identifiers in client release policy). Trusted school-staff roles (`Director`, `Administrator`, `Teacher`) may access and review; ordinary students (`Student`, `Parent`, unauthenticated) see an Under Construction notice until the owner enables `NEXT_PUBLIC_STUDENT_ENRICHMENT_RELEASED=true` (note: changing `NEXT_PUBLIC_*` requires a **new build and deployment**).
- **Manual Vercel Production Promotion Policy (Mandatory)**: Production releases on `https://gam-it-service.app` are promoted **manually** in Vercel. A successful Git push to `origin/fixed-version` or a "Ready" preview build does **not** establish that a revision is live in production. Always provide the exact commit SHA and verify live behaviour on `https://gam-it-service.app` after explicit manual promotion.
- Do not delete legacy lesson files or modify unrelated core school-management modules.
- Do not generate paid media (TTS/image generation) without separate explicit approval.
- Run the canonical 23-suite regression baseline (19 student-enrichment + 4 core school-management suites) plus any new feature suites before every release.

## 6. Permanent Interactive Foundation Roadmap (Approved Sequence)

1. **Steps 1–4F (LIVE on `https://gam-it-service.app`):** Security hardening, selective lazy loading, `InteractiveEngineRegistry`, `code-playground` (`1.0.0`), `rule-explorer` (`1.0.0`), `graph-slider` (`1.0.0`), `process-stepper` (`1.0.0`), `diagram-hotspots` (`1.0.0`), and `construction-lab` (`1.3.0`: `boolean-circuit`, `equation-balancer`, `electrical-circuit`, `bio-sequence-builder`, `atom-bond-builder`, `geometry-constructor`).
2. **Step 5A.1 — Mathematical Answer Evaluator (`math-evaluator` `1.0.0`):** *Production LIVE on `https://gam-it-service.app` (`productionVersion: '1.1.0'`).* Five discriminated modes (`numeric-quantity`, `algebraic-expression`, `equation-solution`, `inequality-interval`, `calculus-check`), exact `BigRat`/polynomial/surd/symbolic equivalence, unified 1D real domain certification, strict verification policies (`exact-only`, `exact-or-symbolic`, `allow-bounded-numeric`), exact SI units & precision, and calculus domain restriction UI.
3. **Step 5A.2 & Step 5A.3 — Mathematical Working Workspace (`math-evaluator` `1.1.0`, `mode: 'multi-step-working'`) & 10,000-Case SymPy Oracle Verification:** *Production LIVE on `https://gam-it-service.app` (`productionVersion: '1.1.0'`).* Extends `math-evaluator` (zero duplicate engine family); age-appropriate touch/keyboard keypads, 8-status bounded step verifier, declarative M/A/B/ECF marking engine, Guided/Independent/Exam-Practice modes, and 10,000-case independent Python/SymPy oracle verification with structural uniqueness accounting and strict marking-sum invariants (0 false accepts, 0 false rejects, 0 unexpected indeterminates, 0 marking mismatches). Simultaneous linear equations remain explicitly deferred.
4. **Step 5B — Sorting and Classification (`sort-classify` `1.0.0`):** *Integrated into `fixed-version` (`productionVersion: null` pending manual Vercel production promotion & live verification).* Eighth top-level interactive engine family with four cross-subject modes (`category-bins` with overlapping set membership & explicit empty-set decisions, `pair-matching` with enforced 1:1 cardinality or many-to-many, `cloze-tiles` with bipartite feasibility checking for non-reusable tokens, and `order-sequence` with closest-order diagnostics & deterministic tie-breaking), approved optional visual assets, accessible drag-and-drop + keyboard UI, and 15-slide / 19-activity pilot.
5. **Step 5C — Virtual Measuring Instruments (`construction-lab: measurement-lab` `1.4.0`):** *Integrated into `fixed-version` (`productionVersion` held at `'1.3.0'` pending manual Vercel promotion & live verification).* Nine graduated SVG instrument models with active alignment/parallax/tare/range manipulation, negative zero-error wraparound, over-range rejection, unit-consistent sig-figs, and 15-slide pilot.
6. **Step 5D — Probability and Statistics (`construction-lab: data-stats-lab` `1.5.0`):** *Integrated into `fixed-version` (`productionVersion` held at `'1.3.0'` pending manual Vercel promotion & live verification).* Genuine SVG renderers for all 8 chart types (bar, pictogram, pie sectors, stacked dot plot, frequency polygon, frequency-density histogram, cumulative frequency, min-max & Tukey 1.5-IQR box plot), set-based mode grading (single/multi/none), state-gated experimental probability, and 20-slide pilot.
7. **Step 5E — Remaining Geometry Capabilities (`construction-lab: geometry-constructor` `1.6.0`):** *Integrated into `fixed-version` (`construction-lab` `engineVersion: '1.6.0'`, `productionVersion` held at `'1.3.0'` pending manual Vercel promotion & live verification).* RHS triangle construction (both reflected orientations), virtual-protractor angle construction, alternate segment theorem, equal tangents from external point, chord perpendicular bisector, extended loci & combined feasible regions (including finite-segment endpoint arcs & parallel/intersecting line bisectors), and exact 3D rigid-rotation cube-net foldability solver certifying all 11 valid cube nets under all rotations/reflections + cuboid SA/volume; 12-slide pilot preserving 100% Step 4F compatibility.
8. **Step 5F — Primary Number Manipulatives (`construction-lab: number-manipulative`):** *Planned.*
9. **Step 5G — Bounded Physics Workbench (`construction-lab: physics-workbench`):** *Planned.*
10. **Step 5H — Visual Programming & Computational Thinking Studio (including bounded Art Studio & Game Zone integration):** *Planned — accepted planning reference saved at [`docs/STEP_5H_CREATIVE_COMPUTATIONAL_AUDIT.md`](STEP_5H_CREATIVE_COMPUTATIONAL_AUDIT.md). Do NOT commence until Steps 5A–5G are complete (investigate any confirmed high-severity security items in its register promptly).*
11. **Step 6 — Comprehensive Foundation Verification & Final Sign-Off:** *Planned.*
12. **Curriculum Content Development & Official Student Release:** Real NaCCA and Cambridge curriculum lessons may be developed alongside foundation work using production-compatible engines; official release to ordinary students awaits the owner's explicit approval.


---

# GAM EDU — Mathematical Curriculum Capability Matrix & Deferred Linear-Systems Assessment (Step 5A.3)

> **Scope Honesty Notice:** This matrix maps GAM EDU's verified Step 5A.1 (`math-evaluator` `1.0.0`) and Step 5A.2 (`math-evaluator` `1.1.0`) capabilities against NaCCA and Cambridge Mathematics & STEM syllabuses. Passing finite automated oracle tests (10,000 unique cases) provides strong regression assurance within certified classes, **not** a claim of universal mathematical completeness.

---

## 1. Capability Legend
- **Full (Bounded):** Fully supported and certified within Step 5A.1/5A.2 exact/symbolic resource bounds.
- **Partial:** Supported for common school sub-classes; complex edge cases return `indeterminate-unverified` or require manual review.
- **Other Engine:** Supported cleanly through another existing GAM EDU interactive engine (`graph-slider`, `construction-lab`, `diagram-hotspots`, `process-stepper`, `code-playground`).
- **Manual / Teacher:** Requires human/teacher grading (open-ended proofs, essay justifications, sketch interpretation).
- **Deferred:** Explicitly planned for a future bounded step (not claimed today).
- **Unsupported:** Out of scope for client-side bounded evaluation (heavyweight CAS / general theorem proving).

---

## 2. Curriculum Capability Matrix

| Curriculum / Domain | Key Topics | Status | Engine / Notes |
| :--- | :--- | :--- | :--- |
| **NaCCA Primary Mathematics (B1–B6)** | Whole-number arithmetic, order of operations, fractions (equivalent/reduced), decimals, percentages, ratios, money/discounts | **Full (Bounded)** | `math-evaluator` (`numeric-quantity`, `multi-step-working` with `primary` keypad) |
| **NaCCA Primary Mathematics (B1–B6)** | Place-value blocks, fraction bars, number lines, regrouping manipulatives | **Deferred (Step 5F)** | Planned for `construction-lab: number-manipulative` |
| **NaCCA JHS Mathematics (B7–B9)** | Integers, powers/indices, algebraic expansion & collection, factorisation, linear equations, linear inequalities & sign reversal, simple financial maths | **Full (Bounded)** | `math-evaluator` (`1.0.0` + `1.1.0` `lower-secondary` keypad) |
| **NaCCA JHS Mathematics (B7–B9)** | Geometric constructions, transformations, coordinate plotting | **Other Engine** | `construction-lab: geometry-constructor` (`1.3.0` LIVE) |
| **NaCCA SHS Core & Elective Maths** | Surds, quadratic equations (factorisation, completing the square, quadratic formula), rational expressions & domains, logarithms (with explicit domain), univariate differentiation & integration (`+ C`) | **Full (Bounded)** | `math-evaluator` (`igcse` / `as-a-level` keypads) |
| **NaCCA SHS Core & Elective Maths** | 2×2 / 3×3 simultaneous linear equations, matrices, vectors, probability/statistics distributions | **Deferred** | Linear systems deferred (see Section 3); Probability/Stats planned for Step 5D |
| **Cambridge Primary & Lower Secondary (0096 / 0862)** | Number operations, fractions/percentages, algebraic expressions, linear equations/inequalities, unit conversions, formula substitution | **Full (Bounded)** | `math-evaluator` (`primary` / `lower-secondary`) + `graph-slider` for linear graphs |
| **Cambridge IGCSE Mathematics (0580)** | Exact fractions/surds, sig-figs & decimal rounding, expansion/factorisation, quadratics, rational & single-radical equations, compound inequalities & intervals, algebraic fractions + excluded values, differentiation of polynomials | **Full (Bounded)** | `math-evaluator` (`igcse` keypad, M/A/B/ECF formative marking) |
| **Cambridge IGCSE Mathematics (0580)** | Simultaneous linear/non-linear equations, circle theorems, loci/constructions, kinematics graphs, histograms/boxplots | **Partial / Other Engine / Deferred** | Circle theorems & constructions → `geometry-constructor`; Graphs → `graph-slider`; Simultaneous equations → **Deferred**; Stats → Step 5D |
| **Cambridge IGCSE Additional Maths (0606)** | Surds/indices/logs (explicit domain), polynomials (up to degree 6), quadratic inequalities (interval union), differentiation & antiderivatives (`ln|x| + C`, trig in radians) | **Partial** | Univariate certified classes supported; arbitrary trig identities & non-linear systems return `indeterminate-unverified` |
| **Cambridge AS & A Level Maths (9709)** | Pure 1/2/3: algebraic manipulation, quadratics, rational/radical equations, logarithmic laws under explicit domain, symbolic differentiation & standard antiderivatives (`+ C`, `ln|x|`) | **Partial** | Supported within Step 5A.1/5A.2 bounds; integration by parts/substitution chains outside basic forms, differential equations, complex numbers, vectors, and formal proofs are **Unsupported / Manual** |
| **Physics (IGCSE 0625 / NaCCA)** | Formula substitution, exact 7-component SI unit conversions (`m/s` ↔ `km/h`, `°C` ↔ `K` absolute/difference, `N`, `J`, `W`, `Pa`), sig-figs, scientific notation | **Full (Bounded)** | `math-evaluator` (`numeric-quantity`, `formula-unit`) + `graph-slider` + `electrical-circuit` |
| **Chemistry (IGCSE 0620 / NaCCA)** | Molarity (`mol/dm^3` ↔ `mol/m^3`), stoichiometry calculations, percentage yield | **Full (Bounded) + Other Engine** | `math-evaluator` for numeric/unit calculations; `equation-balancer` & `atom-bond-builder` LIVE |
| **Economics / Accounting / Business** | Gross profit margin vs mark-up, percentage change, discounts, elasticity calculations, compound financial formulas | **Full (Bounded)** | `math-evaluator` (`numeric-quantity` with `%`, `multi-step-working`) |

---

## 3. Deferred Simultaneous Linear Equations — Bounded Design Recommendation (Section 14)

**Current Status:** Explicitly **DEFERRED** (not implemented or claimed in Step 5A.3).

**Feasibility Assessment:** A lightweight exact-rational 2×2 and 3×3 linear-system verifier can be added safely in a future minor extension (`math-evaluator` `1.2.0`) with **zero CAS dependencies**:
- **Exact `BigRat` Gaussian Elimination / RREF:** Parse each equation into exact linear form $a_i x + b_i y (+ c_i z) = d_i$ using existing `astToRationalPoly` (`polyDegree <= 1`).
- **Exact Classification of All 3 Cases:**
  1. **Unique solution** ($\det(A) \neq 0$): exact rational tuple $(x^*, y^*)$ or $(x^*, y^*, z^*)$.
  2. **No solution** (inconsistent row $[0 \dots 0 \mid k], k \neq 0$): `empty-set`.
  3. **Infinitely many solutions** (consistent rank-deficient system): `dependent-infinite`.
- **Multi-Step Support (Substitution & Elimination):** Verify that each derived equation is an exact linear combination of the current system (preserving the solution set) and verify substitution steps against the original system, consuming the shared cumulative `EvalOpBudget`.
- **Recommendation:** Retain as explicitly deferred during Step 5A.3 closure so Step 5A.3 stays focused on reliability certification of existing `1.0.0`/`1.1.0` capabilities; schedule as an optional Step 5A.4 micro-extension if prioritised by curriculum authors.


---

# GAM EDU — Step 5H: Existing Creative & Computational Learning Features Audit & Permanent Planning Reference

> **Status:** Accepted Planning Reference (**96/100** review score). **Do NOT commence Step 5H implementation yet** — continue the approved foundation sequence (`5A → 5B → 5C → 5D → 5E → 5F → 5G → 5H → 6`).  
> **Inclusion:** Mandatory reference in `AGENTS.md`, `docs/STUDENT_ENRICHMENT_STANDARD.md`, and all subsequent Authoring Kits.

---

## 1. Audited Existing Creative & Computational Assets (Preserve & Reuse)

Direct read-only codebase inspection confirmed substantial working educational investments that **MUST be preserved** and not needlessly rebuilt or replaced:

| Existing Feature / Route | Actual Current Implementation | Preservation Mandate |
| :--- | :--- | :--- |
| **Game Zone (`/dashboard/game-zone`)** | Cyber Logic Arcade: AI/offline trivia, `BinaryCodeBreaker`, `BooleanGates`, Kahoot Hub links, and existing XP / achievement integration | **Preserve** as an educational challenge & computational-thinking destination; reuse XP/achievements; surface selected JSON-driven visual programming challenges without duplicating execution engines; do **not** build multiplayer merely because an orphaned lobby component exists |
| **Logic Lab (`/dashboard/coding-club/logic-lab`)** | 43 built-in missions using click-to-append Python token chips running free client-side via Pyodide Web Worker (`src/lib/python-runner.ts`) | **Preserve** all 43 built-in missions |
| **Python Academy (`/dashboard/coding-club/python-academy`)** | 73 lesson & mission entries running Monaco + Pyodide Web Worker | **Preserve** all 73 entries |
| **SQL Lab (`/dashboard/coding-club/sql-lab`)** | Read-only SQL practice (`src/lib/sql-practice/igcse-sql-engine.ts`) | **Preserve** |
| **Scratch / TurboWarp Links (`/dashboard/coding-club`)** | External TurboWarp iframe (`13a80b48`) replacing deleted `ScratchEngine.tsx` (`b0c6ad95`, `39a85349`, `5fdef7ad`) | **Preserve** existing links alongside future built-in visual studio |
| **Art Studio (`src/app/dashboard/nursery-bloom/page.tsx`, lines 4901–5316)** | Embedded inside the 522 KB Nursery Bloom monolith; currently has unscaled click coordinates and a stubbed "Save Masterpiece" button | **Preserve**; do **not** undertake a full Nursery Bloom monolith refactor; apply bounded reusable canvas & truthful export/save improvements in Step 5H |
| **Story Spark, Think Tank & Code Playground** | Illustrated story reader, critical thinking hub, and `InlineCodePlayground` (`code-playground` `1.0.0` LIVE — Python 3, Cambridge 0478 Pseudocode, Read-Only SQL) | **Preserve** all existing capabilities |
| **Orphaned `src/components/BlocklyEditor.tsx`** | Zero imports anywhere in app; executes generated JS via unsafe `new Function()` | **NEVER revive as-is** (security risk recorded in Section 6) |

---

## 2. Approved Future Architecture: Visual Programming Studio (Step 5H)

1. **Strict Separation of Editor and Execution Engine:**
   - Separate the visual block editor UI from the deterministic execution engine.
   - During Step 5H design, formally evaluate **Blockly** (measuring actual compressed JS transfer, not estimates) versus a **lightweight custom structured block editor**.
   - **NEVER** revive abandoned `BlocklyEditor.tsx` or `ScratchEngine.tsx` as-is.
   - **NEVER** execute generated JavaScript through `eval()` or `new Function()`.
2. **Bounded Deterministic TypeScript AST Interpreter:**
   - Programs are represented as strictly schema-validated **JSON AST structures**.
   - Supports coloured structured blocks, accessible keyboard + touch construction and reordering, variables, expressions, conditions, loops, bounded execution limits (step/loop caps), step-by-step tracing, **Play / Pause / Step / Stop / Reset**, and deterministic educational grading.
   - Generates **read-only Python and Cambridge 0478 Pseudocode** equivalents strictly where semantically accurate (do **not** claim arbitrary Python-to-block conversion).
3. **Engine Family Placement:**
   - **Prefer extending `code-playground`** (zero unnecessary engine-family sprawl). If a separate top-level engine family is demonstrably necessary, provide explicit architectural justification before implementation.

---

## 3. Prioritised Stage Capabilities

| Priority | Stage | Required Capabilities |
| :---: | :--- | :--- |
| **1 (Mandatory)** | **A. Grid Navigator** | Character movement, direction & turning, walls & obstacles, collectibles, goals, sensor predicates, maze & algorithm challenges |
| **2 (Mandatory)** | **B. Turtle Graphics** | Pen up/down & movement, angles, colours, geometric shapes, symmetry, repeating patterns, mathematical art |
| **3 (Feasibility Assessment)** | **C. Bounded Single-Character Animation** | Simple movement, appearance changes, dialogue, and safe reuse of Art Studio assets where feasible — **NO** unrestricted concurrency, complex physics, or full Scratch clone |

---

## 4. Bounded Art Studio & Game Zone Integration

- **Art Studio (Bounded Improvement — No Monolith Refactor):**
  - Correct canvas coordinate scaling (`getBoundingClientRect` → internal canvas resolution).
  - **Truthful save confirmation:** Never claim artwork has been saved unless the save operation actually succeeded.
  - Real local image export (including transparent PNG export where appropriate), basic Undo/Redo, artwork preservation across appropriate navigation, reusable character/background assets, and safe integration with the Visual Programming Studio.
  - Any persistent student asset storage must be explicitly **school-scoped** with strict access controls and resource limits.
- **Game Zone Integration:**
  - Surface selected JSON-driven visual programming challenges inside Game Zone reusing existing XP/achievement flows without duplicating execution engines. No multiplayer work.

---

## 5. Educational Progression & Curriculum Verification

- **Progression Pathway:** `Visual Programming Studio → Logic Lab → Python Academy → Advanced Programming & Computer Science`.
- **Curriculum Grounding:** Verify actual **Ghana NaCCA** (Basic 1–6, CCP Basic 7–9, SHS Computing) and **Cambridge** (`0059` Primary, `0860` Lower Secondary, `0478` IGCSE, `9618` AS & A Level) objectives during Step 5H design. Do **not** claim `> 90%` coverage without a verified indicator-level or syllabus-level matrix.

---

## 6. Outstanding Security, Functional & Technical Debt Register

> **Security Escalation Rule:** Confirmed high-severity security risks MUST be investigated promptly — never defer an active exploitable vulnerability solely because it relates to a later stage.

| # | Item | Category | Risk / Action |
| :---: | :--- | :--- | :--- |
| 1 | Unsafe `new Function()` execution in orphaned `src/components/BlocklyEditor.tsx` | Security | Orphaned (0 imports); never revive; schedule clean removal or explicit quarantine |
| 2 | Hardcoded administrator identifiers in legacy modules | Security | Audit & replace with role/claims-based checks where still present (Under-Construction gate already cleaned) |
| 3 | Legacy unscoped project storage | Security / Multi-tenancy | Ensure all student project/asset persistence is strictly `schoolId`-scoped with Firestore rule enforcement |
| 4 | Python Worker isolation & network-access verification | Security | Verify `python-runner.ts` Pyodide Web Worker isolation and confirm no unintended network/credential exfiltration |
| 5 | Art Studio false "Save Masterpiece" confirmation | Functional | Fix so save status is truthful and performs real export or verified scoped persistence |
| 6 | Art Studio canvas coordinate scaling defect | Functional | Scale pointer coordinates from CSS display box to internal canvas dimensions |
| 7 | Orphaned Game Zone lobby component | Technical Debt | Do not implement multiplayer; audit for clean removal or isolation |
| 8 | Unused `blockly` and `p5` package dependencies (if present in `package.json`) | Bundle / Supply Chain | Audit and prune unused packages if confirmed unreferenced |
| 9 | Existing paid AI credit consumption in Game Zone / Nursery Bloom | Operating Cost | Ensure Step 5H visual execution, grading, and animation use **zero paid AI** and **zero per-step/per-run Firestore writes** |
| 10 | Third-party Scratch / TurboWarp external link dependency | Availability | Retain as optional external links; built-in Step 5H studio provides offline/low-data resilience |

---

## 7. Performance, Cost & Roadmap Discipline

- Independently lazy-load all Step 5H modules; measure **actual compressed JS transfers** (not estimates).
- Zero paid AI calls and zero per-step/per-run Firestore writes during visual program execution, deterministic grading, or animation.
- **Do NOT start Step 5H now.** Complete Steps `5A → 5B → 5C → 5D → 5E → 5F → 5G` first, followed by `5H` and `Step 6` (Comprehensive Foundation Verification).


---

# v2.4 Addendum — Independent Audit Corrections (authoritative where it differs from the text above)

The sections above are the v2.3 reference, preserved. Where this addendum differs, **this addendum wins.**

## A. Permanent roles and tracking (new)
Gemini = Primary Developer · Claude = Independent Auditor and Corrective Engineer · ChatGPT = Technical Coordinator · Owner = final authority. Documents: `coordination/` folder (`AGENT_COORDINATION_PROTOCOL.md`, Gemini and Claude roadmaps and progress files, `CONSOLIDATED_DEFECT_REGISTER.csv`, `FOUNDATION_MASTER_STATUS.md`). Findings are classified `CLAUDE_FIX`, `GEMINI_BUILD`, `JOINT_REVIEW`, `OWNER_DECISION`, `VERIFICATION_REQUIRED`.

## B. `data-stats-lab` behaviour (engine 1.5.0 text above is amended)
- **Mode:** a value is a mode when it occurs most often among repeated values. "No mode" only when no value repeats. `[3,3,3]` has mode 3; `[1,1,2,2]` has modes 1 and 2; `[2,4,6,8]` has no mode. Authors using `targetMeasure: 'mode'` with expected "none" must use data in which no value repeats.
- **Dot plot:** every observation is drawn; stacks taller than 10 print "×N" and keep spacing larger than the dot diameter.
- **Pictogram:** symbols are mathematically proportional; the leftover fraction is one part-symbol cut to that fraction of a symbol (frequency 5 with `pictogramUnit` 4 = 1 and a quarter symbol). Nothing is rounded; the exact frequency is always printed. Choose a `pictogramUnit` that divides the frequencies when whole or half symbols are wanted.
- **Frequency polygon:** plots **frequency** against class mid-points for equal class widths (frequency **density** only when widths differ), closed to the axis one class width beyond the first and last mid-points.
- **Charts** (histogram, cumulative frequency, bar) show numeric y-axis ticks (0, half, maximum) and axis titles.
- **Quartiles:** `tukey-exclusive`, `tukey-inclusive`, `linear-interpolation`. The (n+1)/4 positional method is **not** offered (D-011, Gemini after syllabus evidence).

## C. `code-playground` (Python) execution model
Learner Python runs **only** in a sandboxed opaque-origin iframe with a CSP (connect-src limited to the Pyodide CDN path). Code ≤ 100,000 characters, stdin ≤ 50,000, validation ≤ 20,000, sandbox output ≤ 200,000 characters. Lessons must not rely on network access from Python (no `micropip` installs, no `js.fetch`). `strictInput: true` works (a previous escaping bug made it always fail). If the browser cannot provide the sandbox, Python is disabled with a message. Pseudocode `ARRAY` declarations are limited to 100,000 cells per array.

## D. Ask Teacher
`POST /api/narrated-lessons/ask` requires a signed-in user with a school and, while Under Construction, a staff role (Director/Administrator/Teacher or equivalent spellings). Request body ≤ 4 KB; lesson/slide ids `^[A-Za-z0-9_.-]{1,80}$`; question ≤ 400 characters; answers ≤ 1,200 characters. A Firestore-backed daily cap (30 per user, 1,000 per school by default; `ASK_TEACHER_USER_DAILY_CAP`, `ASK_TEACHER_SCHOOL_DAILY_CAP`) applies only to paid AI calls and fails closed.

## E. Math evaluator verification
`scripts/math-oracle/run-independent-oracle.ts` reports **10,000 cases executed, 9,248 structurally distinct**, and exits non-zero on any false accept, false reject, unexpected indeterminate, marking mismatch, duplicate or excessive mark, or if fewer than 9,000 distinct cases are generated. `--no-write` leaves the committed report untouched. Bounded exact linear simultaneous equations are feasible and assigned to Gemini (D-032).

## F. Verification gates
`.github/workflows/foundation-verification.yml`: `npm ci`, `node scripts/audit/check-lockfile-sync.mjs`, enrichment/security/sandbox/execution/Ask Teacher tests, the oracle, the TypeScript ratchet (`docs/tsc-baseline.json`, currently 351) and the Firestore/Storage emulator rules tests.

## G. Verified independently (do not re-derive)
Cube nets (35 free hexominoes, 11 fold, engine agrees on 1,120 variants), electron configurations Z=1–30 with Cr/Cu, 15 ions, equation/charge balance, genetic code degeneracy, Punnett squares, DC circuit KCL/KVL/short/open cases, SQL read-only guarantees, pseudocode DIV/MOD/arrays/limits, SVG sanitiser (33 vectors + 1,500 fuzz payloads).

## H. Not yet verified (see `OUTSTANDING_VERIFICATION_REGISTER.md`)
Browser/mobile/accessibility, performance measurement, measuring-instrument rendering, curriculum documents, publication/rollback lifecycle, Safari/Firefox Python sandbox, live emulator rules results.


---

## v2.5 Addendum — Step 5E Close-Out & Step 5F Primary Number Manipulatives (2026-11-28)

### 1. Step 5E-A — Shared Accessibility Improvements (D-038, D-039, D-040, D-042)
- WCAG AA (>=4.5:1) high-contrast primary controls in `NarratedLessonPlayer.tsx`, `GraphSliderEngine.tsx`, and `MeasurementLab.tsx`.
- Explicit `altText` on all 13 slides of `step4f-geometry-pilot.json` plus non-empty `alt` fallback in `NarratedLessonPlayer.tsx`.
- Minimum 44px touch targets (`min-h-[44px]`) on range sliders and toolbar/preset buttons; 48px primary touch targets in Step 5F.
- Keyboard-focusable scrollable regions (`tabIndex={0} role="region" aria-label="..."`) in `ProcessStepperEngine.tsx` and `EquationBalancerLab.tsx`.

### 2. Step 5E-B — Geometry Educational Close-Out (D-031)
- `triangle-rhs` (reflected solutions + compass hypotenuse arc provenance) and `protractor-angle` (interactive SVG virtual protractor overlay + Plot Protractor Ray tool) wired into `CompassWorkbench` and `geometry-compass.ts`.
- Full SVG visualisations in `CircleTheoremWorkbench` for `alternate-segment`, `equal-tangents`, and `chord-perp-bisector`.
- Interactive SVG coordinate plane in `LociRegionWorkbench` with shaded feasible regions and finite-segment stadium endpoint arcs.
- Congruence & Similarity live readout in `TransformationsWorkbench` and Undo + folded face labels in `CubeNetWorkbench`.

### 3. Step 5E-C — Exact Linear Simultaneous Equations (D-032) & Positional Quartiles (D-011)
- New `simultaneous-linear` mode in `math-evaluator` (`math-eval-linear-systems.ts`) using exact `BigRat` RREF Gaussian elimination for 2×2 and 3×3 systems (unique, no-solution, infinitely-many, substitution/elimination working lines, swapped-variable diagnostics, independent substitution verification).
- 200 new independent oracle cases added to `run-independent-oracle.ts` (10,200 executed / 9,448 structurally distinct, 0 discrepancies).
- Explicitly selectable `'positional-n-plus-1'` `(n+1)/4` quartile convention in `data-stats-engine.ts` (preserving default `'tukey-exclusive'`).

### 4. Step 5F — Primary Number Manipulatives (`construction-lab`, `labKind: 'number-manipulative'`, `engineVersion: '1.7.0'`, `productionVersion: '1.3.0'`)
- 9 CPA modes covering counting/1:1, single & double ten frames, number bonds, base-ten place value with bidirectional canonical/non-canonical regrouping, proportional number lines, multiplication arrays / equal grouping / division with remainders, exact rational fraction bars & decimal place value, authentic Bank of Ghana currency in exact integer pesewas (exact amount / make change / minimum pieces), continuous hour-hand analogue clocks (12h/24h & elapsed time), and repeating/growing patterns.
- 18-slide NaCCA/Cambridge Primary pilot fixture (`step5f-number-manipulatives-pilot.json`) and dev-only preview route failing closed in production.
